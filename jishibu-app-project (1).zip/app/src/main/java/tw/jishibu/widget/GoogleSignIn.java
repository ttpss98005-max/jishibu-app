package tw.jishibu.widget;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import java.util.concurrent.Executor;

/** 原生 Google 登入:跳出系統的帳號選擇器,拿到 Google 的 ID token(跟網頁版同一個 Google 用戶端)。 */
final class GoogleSignIn {
    private GoogleSignIn() {}

    /** 跟網頁版登入用的是同一個網路用戶端 ID(不是祕密,本來就寫在網頁裡)。 */
    static final String WEB_CLIENT_ID = "826476371547-f1omvto42ta1s5t7knkph573a74cm89i.apps.googleusercontent.com";

    interface Done {
        void ok(String idToken);
        void fail(String message);
    }

    static void start(Activity a, final Done cb) {
        final Handler main = new Handler(Looper.getMainLooper());
        Executor ex = new Executor() {
            @Override public void execute(Runnable r) { main.post(r); }
        };
        try {
            CredentialManager cm = CredentialManager.create(a);
            GetSignInWithGoogleOption opt = new GetSignInWithGoogleOption.Builder(WEB_CLIENT_ID).build();
            GetCredentialRequest req = new GetCredentialRequest.Builder().addCredentialOption(opt).build();
            cm.getCredentialAsync(a, req, null, ex, new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                @Override public void onResult(GetCredentialResponse r) {
                    try {
                        Credential c = r.getCredential();
                        if (c instanceof CustomCredential
                                && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())) {
                            GoogleIdTokenCredential g = GoogleIdTokenCredential.createFrom(((CustomCredential) c).getData());
                            cb.ok(g.getIdToken());
                        } else {
                            cb.fail("沒有拿到 Google 帳號資料");
                        }
                    } catch (Exception e) {
                        cb.fail("Google 登入資料解析失敗:" + e.getMessage());
                    }
                }

                @Override public void onError(GetCredentialException e) {
                    if (e instanceof GetCredentialCancellationException) cb.fail("已取消登入");
                    else cb.fail("Google 登入失敗(" + e.getType() + "):" + e.getMessage());
                }
            });
        } catch (Throwable t) {
            cb.fail("無法開啟 Google 登入:" + t.getMessage());
        }
    }
}
