package tw.jishibu.widget;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.Window;

/** 系統列(狀態列、下方的導覽鍵列)的顏色和圖示深淺。 */
final class SysBars {
    private SysBars() {}

    /**
     * 狀態列用主題色、導覽鍵列用卡片底色。導覽鍵列的底色是淺色時,圖示要改成深色,
     * 不然白底配淺色圖示,三個導覽鍵幾乎看不見(深色配色則維持淺色圖示)。
     */
    @SuppressWarnings("deprecation")
    static void apply(Activity a, int statusColor, int navColor) {
        try {
            Window w = a.getWindow();
            if (w == null) return;
            w.setStatusBarColor(statusColor);
            w.setNavigationBarColor(navColor);
            View dv = w.getDecorView();
            int f = dv.getSystemUiVisibility();
            if (Color.luminance(navColor) > 0.5f) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            else f &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            dv.setSystemUiVisibility(f);
        } catch (Throwable ignore) { }
    }
}
