package tw.jishibu.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.AbsoluteSizeSpan;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.widget.TextView;

/**
 * 月曆上的時段方塊(淡色塊 + 左色條,跟網頁版 .cal-rng 一樣):顏色是事項的分類顏色。
 * cl = 這個方塊從上一週接過來(左邊切平、沒有色條),cr = 還會接到下一週(右邊切平)。
 */
final class RangeBox extends TextView {
    RangeBox(Context c, String title, String range, int color, boolean cl, boolean cr, boolean done) {
        super(c);
        setSingleLine(true);
        setEllipsize(TextUtils.TruncateAt.END);
        setGravity(Gravity.CENTER_VERTICAL);
        setIncludeFontPadding(false);
        setTextSize(11f);
        setTypeface(getTypeface(), android.graphics.Typeface.BOLD);
        setTextColor(color);
        setPadding(Ui.dp(c, cl ? 9 : 11), 0, Ui.dp(c, cr ? 6 : 9), 0);
        SpannableStringBuilder sb = new SpannableStringBuilder();
        if (cl) sb.append("‹ ");
        sb.append(title);
        int s = sb.length();
        sb.append("  ").append(range);
        sb.setSpan(new AbsoluteSizeSpan(Math.round(9.5f * c.getResources().getDisplayMetrics().scaledDensity)), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new ForegroundColorSpan((color & 0x00FFFFFF) | 0xB3000000), s, sb.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (cr) sb.append(" ›");
        setText(sb);
        setBackground(new Bg(c, color, cl, cr));
        if (done) setAlpha(0.45f);
        setContentDescription(title + " " + range);
    }

    private static final class Bg extends Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF r = new RectF();
        private final int color;
        private final float rad, bar;
        private final boolean cl, cr;

        Bg(Context c, int color, boolean cl, boolean cr) {
            this.color = color; this.cl = cl; this.cr = cr;
            rad = Ui.dp(c, 9);
            bar = Ui.dp(c, 3);
        }

        @Override public void draw(Canvas cv) {
            r.set(getBounds());
            float l = cl ? 0f : rad, rr = cr ? 0f : rad;
            path.reset();
            path.addRoundRect(r, new float[]{l, l, rr, rr, rr, rr, l, l}, Path.Direction.CW);
            p.setColor((color & 0x00FFFFFF) | 0x29000000);   // 16% 透明度的分類色
            cv.drawPath(path, p);
            if (!cl) {
                cv.save();
                cv.clipPath(path);
                p.setColor(color);
                cv.drawRect(r.left, r.top, r.left + bar, r.bottom, p);
                cv.restore();
            }
        }

        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
