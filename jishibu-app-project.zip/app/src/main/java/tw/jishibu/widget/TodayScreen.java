package tw.jishibu.widget;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.List;

/** 今天:今天(和過期)的待辦、今天要做的習慣、特別的日子。 */
final class TodayScreen extends Screen {
    TodayScreen(MainActivity a) { super(a); }

    @Override
    void build() {
        final String today = Model.today();
        content.addView(Ui.tv(a, Model.prettyDay(today), 26, Ui.INK, true));

        List<Model.Entry> todo = Model.todoUpTo(today);
        List<Model.Entry> done = Model.doneOn(today);
        String sub = todo.isEmpty() ? "今天的待辦都完成了" : "還有 " + todo.size() + " 件待辦";
        if (Repo.pendingCount() > 0) sub += " · 同步中";
        content.addView(Ui.tv(a, sub, 14, Ui.SOFT, false));

        List<Model.Entry> specials = Model.specialsOn(today);
        if (!specials.isEmpty()) {
            content.addView(Ui.section(a, "特別的日子"));
            LinearLayout card = Ui.card(a);
            for (Model.Entry e : specials) card.addView(Ui.entryRow(a, e, Ui.subtitleFor(e, today), false, again));
            content.addView(card);
        }

        content.addView(Ui.section(a, "待辦"));
        LinearLayout card = Ui.card(a);
        if (todo.isEmpty()) {
            card.addView(Ui.tv(a, "沒有待辦,休息一下", 15, Ui.SOFT, false));
        } else {
            for (Model.Entry e : todo) {
                boolean overdue = !e.date.isEmpty() && e.date.compareTo(today) < 0;
                card.addView(Ui.entryRow(a, e, Ui.subtitleFor(e, today), overdue, again));
            }
        }
        content.addView(card);

        List<JSONObject> habits = Model.habits();
        boolean any = false;
        LinearLayout hc = Ui.card(a);
        for (final JSONObject h : habits) {
            if (!Model.habitScheduledOn(h, today)) continue;
            any = true;
            final String hid = Model.s(h, "id");
            boolean checked = Model.habitChecked(hid, today);
            LinearLayout r = Ui.row(a);
            r.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 8));
            TextView ck = Ui.check(a, checked, 26);
            ((LinearLayout.LayoutParams) ck.getLayoutParams()).rightMargin = Ui.dp(a, 12);
            r.addView(ck);
            TextView name = Ui.tv(a, Model.s(h, "name", ""), 16, checked ? Ui.SOFT : Ui.INK, false);
            r.addView(name, Ui.weight(1));
            String val = Model.habitValueText(h, today);
            if (!val.isEmpty()) r.addView(Ui.tv(a, val + (Model.s(h, "unit").isEmpty() ? "" : " " + Model.s(h, "unit")), 14, Ui.ACCENT, true));
            r.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { Dialogs.habitTap(a, h, today, again); }
            });
            hc.addView(r);
        }
        if (any) {
            content.addView(Ui.section(a, "今天的習慣"));
            content.addView(hc);
        }

        if (!done.isEmpty()) {
            content.addView(Ui.section(a, "今天完成了"));
            LinearLayout dc = Ui.card(a);
            for (Model.Entry e : done) dc.addView(Ui.entryRow(a, e, Ui.subtitleFor(e, today), false, again));
            content.addView(dc);
        }

        TextView add = Ui.pill(a, "＋ 新增事項", true);
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { Dialogs.addTask(a, today, again); }
        });
        content.addView(add, Ui.mw(a, 20));
    }
}
