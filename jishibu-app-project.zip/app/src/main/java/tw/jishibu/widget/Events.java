package tw.jishibu.widget;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** 把記事簿的資料整理成「哪一天有什麼事」。 */
final class Events {
    private Events() {}

    static final int TASK = 0, SPECIAL = 1, DONE = 2;

    static final class Item {
        final String title;
        final int kind;
        final String time;
        Item(String title, int kind, String time) { this.title = title; this.kind = kind; this.time = time; }
    }

    private static boolean isYmd(String s) {
        return s != null && s.length() == 10 && s.charAt(4) == '-' && s.charAt(7) == '-'
                && Character.isDigit(s.charAt(0)) && Character.isDigit(s.charAt(9));
    }

    private static String cut(String s) {
        if (s == null) return "";
        s = s.trim();
        return s.length() > 40 ? s.substring(0, 40) : s;
    }

    private static JSONArray item(String date, String title, int kind, String time) {
        JSONArray a = new JSONArray();
        a.put(date); a.put(cut(title)); a.put(kind); a.put(time == null ? "" : time);
        return a;
    }

    /** 時段:只存一筆(開始日, 標題, 種類, 結束日有設的時間, 結束日, 分類顏色),桌面月曆自己畫成跨日期的色塊。 */
    private static JSONArray range(String start, String end, String title, int kind, String time, String color) {
        JSONArray a = item(start, title, kind, time);
        a.put(end); a.put(color == null ? "" : color);
        return a;
    }

    /** 一個時段(桌面月曆用)。 */
    static final class Range {
        final String title, s, e;
        final int color;
        final boolean done;
        Range(String title, String s, String e, int color, boolean done) { this.title = title; this.s = s; this.e = e; this.color = color; this.done = done; }
    }

    /** 精簡版 → 時段清單。 */
    static List<Range> ranges(String compactJson) {
        List<Range> r = new ArrayList<>();
        try {
            JSONArray all = new JSONArray(compactJson);
            for (int i = 0; i < all.length(); i++) {
                JSONArray a = all.getJSONArray(i);
                String end = a.length() >= 5 ? a.optString(4, "") : "";
                if (!isYmd(end)) continue;
                String col = a.length() >= 6 ? a.optString(5, "") : "";
                int color = 0xFF2F9E78;
                try { if (!col.isEmpty()) color = Theme.parse(col); } catch (Exception ignore) { }
                r.add(new Range(a.getString(1), a.getString(0), end, color, a.getInt(2) == DONE));
            }
        } catch (JSONException ignore) { }
        return r;
    }

    /** 雲端整份資料 → 精簡版(只留日曆用得到的)。 */
    static String compact(String dataJson) throws JSONException {
        JSONObject d = new JSONObject(dataJson);
        JSONArray out = new JSONArray();

        java.util.Map<String, String> catColor = new HashMap<>();
        JSONArray cats = d.optJSONArray("categories");
        for (int i = 0; cats != null && i < cats.length(); i++) {
            JSONObject c = cats.optJSONObject(i);
            if (c != null) catColor.put(Model.s(c, "id"), Model.s(c, "color", ""));
        }
        JSONArray tasks = d.optJSONArray("tasks");
        if (tasks != null) {
            for (int i = 0; i < tasks.length(); i++) {
                JSONObject t = tasks.optJSONObject(i);
                if (t == null) continue;
                String due = Model.s(t, "dueDate", "");
                String start = Model.s(t, "startDate", "");
                if (isYmd(due) && isYmd(start) && start.compareTo(due) < 0) {
                    String dt = Model.s(t, "dueTime", "");
                    out.put(range(start, due, Model.s(t, "title", ""), "done".equals(Model.s(t, "status")) ? DONE : TASK,
                            Model.isHm(dt) ? dt : "", catColor.get(Model.s(t, "categoryId"))));
                } else if (isYmd(due)) {
                    String dt = Model.s(t, "dueTime", "");
                    out.put(item(due, Model.s(t, "title", ""), "done".equals(Model.s(t, "status")) ? DONE : TASK, Model.isHm(dt) ? dt : ""));
                }
            }
        }

        JSONArray sp = d.optJSONArray("specialDays");
        if (sp != null) {
            for (int i = 0; i < sp.length(); i++) {
                JSONObject x = sp.optJSONObject(i);
                if (x == null || !"festival".equals(Model.s(x, "kind"))) continue;
                String date = Model.s(x, "date", "");
                if (!isYmd(date)) continue;
                String key = x.optBoolean("yearly", true) ? "0000" + date.substring(4) : date;
                out.put(item(key, Model.s(x, "name", ""), SPECIAL, ""));
            }
        }
        return out.toString();
    }

    /** 精簡版 → 日期索引。key 是 yyyy-MM-dd;每年重複的用 0000-MM-dd,查詢時自動合併。 */
    static Map<String, List<Item>> index(String compactJson) {
        Map<String, List<Item>> m = new HashMap<>();
        try {
            JSONArray all = new JSONArray(compactJson);
            for (int i = 0; i < all.length(); i++) {
                JSONArray a = all.getJSONArray(i);
                if (a.length() >= 5 && !a.optString(4, "").isEmpty()) continue;   // 時段另外畫成色塊
                List<Item> l = m.get(a.getString(0));
                if (l == null) { l = new ArrayList<>(); m.put(a.getString(0), l); }
                l.add(new Item(a.getString(1), a.getInt(2), a.getString(3)));
            }
        } catch (JSONException ignore) { }
        return m;
    }

    static List<Item> forDay(Map<String, List<Item>> idx, int y, int mo, int d) {
        String ymd = String.format(java.util.Locale.US, "%04d-%02d-%02d", y, mo, d);
        String yearly = String.format(java.util.Locale.US, "0000-%02d-%02d", mo, d);
        List<Item> r = new ArrayList<>();
        List<Item> a = idx.get(ymd), b = idx.get(yearly);
        if (a != null) r.addAll(a);
        if (b != null) r.addAll(b);
        Collections.sort(r, new Comparator<Item>() {
            @Override public int compare(Item p, Item q) {
                int gp = group(p), gq = group(q);
                if (gp != gq) return gp - gq;
                return p.time.compareTo(q.time);
            }
        });
        return r;
    }

    /** 日期(節日)先、未完成的事、最後是已完成。 */
    private static int group(Item i) {
        return i.kind == SPECIAL ? 0 : (i.kind == TASK ? 1 : 2);
    }
}
