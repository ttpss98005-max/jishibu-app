package tw.jishibu.widget;

/** 農曆與節日換算(1900–2100),照網頁版 solar2lunar / getDayInfo 逐行移植。 */
final class Lunar {
    private Lunar() {}

    private static final int[] INFO = {
        0x04bd8, 0x04ae0, 0x0a570, 0x054d5, 0x0d260, 0x0d950, 0x16554, 0x056a0, 0x09ad0, 0x055d2,
        0x04ae0, 0x0a5b6, 0x0a4d0, 0x0d250, 0x1d255, 0x0b540, 0x0d6a0, 0x0ada2, 0x095b0, 0x14977,
        0x04970, 0x0a4b0, 0x0b4b5, 0x06a50, 0x06d40, 0x1ab54, 0x02b60, 0x09570, 0x052f2, 0x04970,
        0x06566, 0x0d4a0, 0x0ea50, 0x06e95, 0x05ad0, 0x02b60, 0x186e3, 0x092e0, 0x1c8d7, 0x0c950,
        0x0d4a0, 0x1d8a6, 0x0b550, 0x056a0, 0x1a5b4, 0x025d0, 0x092d0, 0x0d2b2, 0x0a950, 0x0b557,
        0x06ca0, 0x0b550, 0x15355, 0x04da0, 0x0a5b0, 0x14573, 0x052b0, 0x0a9a8, 0x0e950, 0x06aa0,
        0x0aea6, 0x0ab50, 0x04b60, 0x0aae4, 0x0a570, 0x05260, 0x0f263, 0x0d950, 0x05b57, 0x056a0,
        0x096d0, 0x04dd5, 0x04ad0, 0x0a4d0, 0x0d4d4, 0x0d250, 0x0d558, 0x0b540, 0x0b6a0, 0x195a6,
        0x095b0, 0x049b0, 0x0a974, 0x0a4b0, 0x0b27a, 0x06a50, 0x06d40, 0x0af46, 0x0ab60, 0x09570,
        0x04af5, 0x04970, 0x064b0, 0x074a3, 0x0ea50, 0x06b58, 0x055c0, 0x0ab60, 0x096d5, 0x092e0,
        0x0c960, 0x0d954, 0x0d4a0, 0x0da50, 0x07552, 0x056a0, 0x0abb7, 0x025d0, 0x092d0, 0x0cab5,
        0x0a950, 0x0b4a0, 0x0baa4, 0x0ad50, 0x055d9, 0x04ba0, 0x0a5b0, 0x15176, 0x052b0, 0x0a930,
        0x07954, 0x06aa0, 0x0ad50, 0x05b52, 0x04b60, 0x0a6e6, 0x0a4e0, 0x0d260, 0x0ea65, 0x0d530,
        0x05aa0, 0x076a3, 0x096d0, 0x04afb, 0x04ad0, 0x0a4d0, 0x1d0b6, 0x0d250, 0x0d520, 0x0dd45,
        0x0b5a0, 0x056d0, 0x055b2, 0x049b0, 0x0a577, 0x0a4b0, 0x0aa50, 0x1b255, 0x06d20, 0x0ada0,
        0x14b63, 0x09370, 0x049f8, 0x04970, 0x064b0, 0x168a6, 0x0ea50, 0x06b20, 0x1a6c4, 0x0aae0,
        0x0a2e0, 0x0d2e3, 0x0c960, 0x0d557, 0x0d4a0, 0x0da50, 0x05d55, 0x056a0, 0x0a6d0, 0x055d4,
        0x052d0, 0x0a9b8, 0x0a950, 0x0b4a0, 0x0b6a6, 0x0ad50, 0x055a0, 0x0aba4, 0x0a5b0, 0x052b0,
        0x0b273, 0x06930, 0x07337, 0x06aa0, 0x0ad50, 0x14b55, 0x04b60, 0x0a570, 0x054e4, 0x0d160,
        0x0e968, 0x0d520, 0x0daa0, 0x16aa6, 0x056d0, 0x04ae0, 0x0a9d4, 0x0a2d0, 0x0d150, 0x0f252,
        0x0d520
    };
    private static final String[] GAN = {"甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"};
    private static final String[] ZHI = {"子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"};
    private static final String[] N1 = {"日", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十"};
    private static final String[] N2 = {"初", "十", "廿", "卅"};
    private static final String[] N3 = {"正", "二", "三", "四", "五", "六", "七", "八", "九", "十", "冬", "腊"};

    /** 農曆日期。 */
    static final class L {
        int year, month, day;
        boolean leap;
        String ganZhiYear;
    }

    /** 某一天的顯示資訊。 */
    static final class DayInfo {
        String lunarText = "";
        String festival;      // 節日名稱,沒有為 null
        boolean holiday;      // 放假
        boolean weekend;
    }

    static int leapMonth(int y) { return INFO[y - 1900] & 0xf; }

    static int leapDays(int y) { return leapMonth(y) != 0 ? ((INFO[y - 1900] & 0x10000) != 0 ? 30 : 29) : 0; }

    static int monthDays(int y, int m) { return (INFO[y - 1900] & (0x10000 >> m)) != 0 ? 30 : 29; }

    static int yearDays(int y) {
        int sum = 348;
        for (int i = 0x8000; i > 0x8; i >>= 1) sum += (INFO[y - 1900] & i) != 0 ? 1 : 0;
        return sum + leapDays(y);
    }

    static String monthName(int m) { return N3[m - 1] + "月"; }

    static String dayName(int d) {
        if (d == 10) return "初十";
        if (d == 20) return "二十";
        if (d == 30) return "三十";
        return N2[d / 10] + N1[d % 10];
    }

    static String ganZhiYear(int y) {
        int g = (y - 3) % 10, z = (y - 3) % 12;
        if (g == 0) g = 10;
        if (z == 0) z = 12;
        return GAN[g - 1] + ZHI[z - 1];
    }

    /** 西曆年月日 → 從 1970-01-01 起算的天數(不受時區影響)。 */
    static long epochDay(int y, int m, int d) {
        long yy = m <= 2 ? y - 1 : y;
        long era = (yy >= 0 ? yy : yy - 399) / 400;
        long yoe = yy - era * 400;
        long mp = (m + 9) % 12;
        long doy = (153 * mp + 2) / 5 + d - 1;
        long doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
        return era * 146097 + doe - 719468;
    }

    /** epochDay 的反運算,回傳 {年, 月, 日}。 */
    static int[] fromEpochDay(long z) {
        z += 719468;
        long era = (z >= 0 ? z : z - 146096) / 146097;
        long doe = z - era * 146097;
        long yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
        long y = yoe + era * 400;
        long doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
        long mp = (5 * doy + 2) / 153;
        long d = doy - (153 * mp + 2) / 5 + 1;
        long m = mp < 10 ? mp + 3 : mp - 9;
        return new int[]{(int) (m <= 2 ? y + 1 : y), (int) m, (int) d};
    }

    static L solar2lunar(int y, int m, int d) {
        if (y < 1900 || y > 2100) return null;
        long offset = epochDay(y, m, d) - epochDay(1900, 1, 31);
        int i, temp = 0;
        for (i = 1900; i < 2101 && offset > 0; i++) {
            temp = yearDays(i);
            offset -= temp;
        }
        if (offset < 0) { offset += temp; i--; }
        int year = i;
        int leap = leapMonth(i);
        boolean isLeap = false;
        for (i = 1; i < 13 && offset > 0; i++) {
            if (leap > 0 && i == (leap + 1) && !isLeap) { --i; isLeap = true; temp = leapDays(year); }
            else { temp = monthDays(year, i); }
            if (isLeap && i == (leap + 1)) isLeap = false;
            offset -= temp;
        }
        if (offset == 0 && leap > 0 && i == leap + 1) {
            if (isLeap) { isLeap = false; } else { isLeap = true; --i; }
        }
        if (offset < 0) { offset += temp; --i; }
        L l = new L();
        l.year = year;
        l.month = i;
        l.day = (int) offset + 1;
        l.leap = isLeap;
        l.ganZhiYear = ganZhiYear(year);
        return l;
    }

    static String lunarFestival(int m, int d, boolean isLeap) {
        if (isLeap) return null;
        String k = m + "-" + d;
        switch (k) {
            case "1-1": return "春節";
            case "1-15": return "元宵節";
            case "2-2": return "龍抬頭";
            case "5-5": return "端午節";
            case "7-7": return "七夕";
            case "7-15": return "中元節";
            case "8-15": return "中秋節";
            case "9-9": return "重陽節";
            case "12-8": return "臘八節";
            default: return null;
        }
    }

    static String solarFestival(int m, int d) {
        String k = m + "-" + d;
        switch (k) {
            case "1-1": return "元旦";
            case "2-14": return "情人節";
            case "2-28": return "和平紀念日";
            case "3-8": return "婦女節";
            case "3-12": return "植樹節";
            case "4-4": return "兒童節";
            case "5-1": return "勞動節";
            case "9-28": return "教師節";
            case "10-10": return "國慶日";
            case "10-25": return "光復節";
            case "11-12": return "國父誕辰";
            case "12-25": return "行憲紀念日";
            default: return null;
        }
    }

    private static boolean twHolidaySolar(int m, int d) {
        return (m == 1 && d == 1) || (m == 2 && d == 28) || (m == 4 && d == 4) || (m == 5 && d == 1) || (m == 10 && d == 10);
    }

    static boolean isNewYearEve(int y, int m, int d) {
        int[] n = fromEpochDay(epochDay(y, m, d) + 1);
        L ln = solar2lunar(n[0], n[1], n[2]);
        return ln != null && ln.month == 1 && ln.day == 1 && !ln.leap;
    }

    /** 星期幾(0 = 日)。 */
    static int dow(int y, int m, int d) {
        long e = epochDay(y, m, d);
        return (int) (((e + 4) % 7 + 7) % 7);
    }

    static DayInfo dayInfo(int y, int m, int d) {
        DayInfo r = new DayInfo();
        L l = solar2lunar(y, m, d);
        String lFestRaw = null;
        if (l != null) {
            r.lunarText = l.day == 1 ? (l.leap ? "閏" : "") + monthName(l.month) : dayName(l.day);
            lFestRaw = lunarFestival(l.month, l.day, l.leap);
        }
        String sFest = solarFestival(m, d);
        boolean eve = isNewYearEve(y, m, d);
        String lFest = eve ? "除夕" : lFestRaw;
        r.festival = sFest != null ? sFest : lFest;
        boolean holiday = twHolidaySolar(m, d);
        if (eve || "春節".equals(lFest) || "端午節".equals(lFest) || "中秋節".equals(lFest)) holiday = true;
        r.holiday = holiday;
        int w = dow(y, m, d);
        r.weekend = w == 0 || w == 6;
        return r;
    }
}
