package tw.jishibu.widget;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;

/** 網頁版 .modal 的樣子:白色 24px 圓角卡片、標題、底部「取消 / 確定」膠囊按鈕。 */
final class Modal {
    private Modal() {}

    /** 按確定時呼叫。回傳 true 才會關閉視窗(欄位沒填好可以回 false 讓視窗留著)。 */
    interface Ok { boolean run(); }
    interface StrCb { void on(String s); }

    /** 空白的圓角卡片視窗。內容自己放進回傳的 box(已經有 padding)。 */
    static final class Sheet {
        final Dialog dialog;
        final LinearLayout box;
        Sheet(Dialog d, LinearLayout b) { dialog = d; box = b; }
        void dismiss() { dialog.dismiss(); }
    }

    private static final java.util.List<Dialog> OPEN = new java.util.ArrayList<>();

    /** 目前開著的視窗(後開的在後面)。新手教學要在裡面找按鈕。 */
    static java.util.List<Dialog> openList() {
        java.util.List<Dialog> l = new java.util.ArrayList<>();
        for (Dialog d : OPEN) if (d.isShowing()) l.add(d);
        return l;
    }

    /** 目前有沒有視窗開著(視窗會蓋住底下的提示條,所以這時提示要改用系統的 Toast)。 */
    static boolean anyOpen() {
        for (Dialog d : OPEN) if (d.isShowing()) return true;
        return false;
    }

    /** 從桌面小工具等外面進來要換頁時:把目前開著的視窗(新增事項、新增細項、側欄…)全部關掉,不要留在新的頁面上。 */
    static void dismissAll() {
        for (Dialog d : new java.util.ArrayList<>(OPEN)) {
            try { if (d.isShowing()) d.dismiss(); } catch (Exception ignore) { }
        }
    }

    /** 全螢幕的自製視窗(早安/晚安回顧)也要登記,這樣提示條才知道要改用 Toast。onDismiss 在關閉時呼叫。 */
    static void track(final Dialog d, final Runnable onDismiss) {
        OPEN.add(d);
        d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface x) {
                OPEN.remove(d);
                if (onDismiss != null) onDismiss.run();
            }
        });
    }

    static Sheet sheet(Activity a) {
        final Dialog d = new Dialog(a);
        OPEN.add(d);
        d.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface x) { OPEN.remove(d); }
        });
        LinearLayout outer = Ui.col(a);
        outer.setPadding(Ui.dp(a, 20), Ui.dp(a, 20), Ui.dp(a, 20), Ui.dp(a, 20));
        ScrollView sv = new ScrollView(a);
        LinearLayout box = Ui.col(a);
        box.setPadding(Ui.dp(a, 24), Ui.dp(a, 24), Ui.dp(a, 24), Ui.dp(a, 20));
        box.setBackground(Ui.shape(a, 0xFFFFFFFF, 24, 0, 0));
        sv.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        outer.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        d.setContentView(outer);
        if (d.getWindow() != null) {
            d.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            d.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
            d.getWindow().setGravity(Gravity.CENTER);
            d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        return new Sheet(d, box);
    }

    /** 一般表單視窗:標題 + 內容 + 取消/確定。 */
    static Dialog show(Activity a, String title, View body, String okText, final Ok ok) {
        final Sheet s = sheet(a);
        if (title != null) {
            TextView t = Ui.tv(a, title, 16, Ui.CARD_INK, true);
            t.setPadding(0, 0, 0, Ui.dp(a, 8));
            s.box.addView(t);
        }
        if (body != null) s.box.addView(body);
        LinearLayout actions = Ui.row(a);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        actions.addView(Ui.btnGhost(a, ok == null ? "關閉" : "取消", new View.OnClickListener() {
            @Override public void onClick(View v) { s.dismiss(); }
        }));
        if (ok != null) {
            actions.addView(Ui.btnPrimary(a, okText == null ? "確定" : okText, new View.OnClickListener() {
                @Override public void onClick(View v) { if (ok.run()) s.dismiss(); }
            }), Ui.gap(a, 8));
        }
        s.box.addView(actions, Ui.mw(a, 22));
        s.dialog.show();
        return s.dialog;
    }

    /** 確認視窗(刪除之類)。danger 為真時確定鈕是紅色。 */
    static void confirm(Activity a, String title, String msg, String okText, boolean danger, final Runnable onOk) {
        final Sheet s = sheet(a);
        s.box.addView(Ui.tv(a, title, 16, Ui.CARD_INK, true));
        if (msg != null && !msg.isEmpty()) {
            TextView m = Ui.tv(a, msg, 13.5f, Ui.SOFT, false);
            m.setLineSpacing(0, 1.3f);
            s.box.addView(m, Ui.mw(a, 10));
        }
        LinearLayout actions = Ui.row(a);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        actions.addView(Ui.btnGhost(a, "取消", new View.OnClickListener() {
            @Override public void onClick(View v) { s.dismiss(); }
        }));
        TextView okBtn = Ui.btnPrimary(a, okText == null ? "確定" : okText, new View.OnClickListener() {
            @Override public void onClick(View v) { s.dismiss(); if (onOk != null) onOk.run(); }
        });
        if (danger) okBtn.setBackground(Ui.shape(a, Ui.DANGER, 999, 0, 0));
        actions.addView(okBtn, Ui.gap(a, 8));
        s.box.addView(actions, Ui.mw(a, 22));
        s.dialog.show();
    }


    static void alert(Activity a, String title, String msg) {
        final Sheet s = sheet(a);
        s.box.addView(Ui.tv(a, title, 16, Ui.CARD_INK, true));
        if (msg != null) {
            TextView m = Ui.tv(a, msg, 13.5f, Ui.SOFT, false);
            m.setLineSpacing(0, 1.3f);
            s.box.addView(m, Ui.mw(a, 10));
        }
        LinearLayout actions = Ui.row(a);
        actions.setGravity(Gravity.END);
        actions.addView(Ui.btnPrimary(a, "知道了", new View.OnClickListener() {
            @Override public void onClick(View v) { s.dismiss(); }
        }));
        s.box.addView(actions, Ui.mw(a, 22));
        s.dialog.show();
    }

    /** 從幾個選項裡選一個(底部清單)。selected 是目前選的(-1 沒有)。 */
    static void choose(Activity a, String title, String[] labels, int selected, final Ui.IntCb cb) {
        final Sheet s = sheet(a);
        if (title != null) {
            TextView t = Ui.tv(a, title, 16, Ui.CARD_INK, true);
            t.setPadding(0, 0, 0, Ui.dp(a, 8));
            s.box.addView(t);
        }
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView row = Ui.tv(a, labels[i], 14, i == selected ? Ui.ACCENT : Ui.CARD_INK, i == selected);
            row.setPadding(Ui.dp(a, 12), Ui.dp(a, 12), Ui.dp(a, 12), Ui.dp(a, 12));
            if (i == selected) row.setBackground(Ui.shape(a, Ui.ACCENT_SOFT, 12, 0, 0));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { s.dismiss(); if (cb != null) cb.on(idx); }
            });
            s.box.addView(row, Ui.mw(a, 2));
        }
        s.dialog.show();
    }

    /** 日期選擇。current 是 yyyy-MM-dd(可空)。 */
    static void pickDate(Activity a, String current, final StrCb cb) {
        Calendar c = Model.isDay(current) ? Model.parse(current) : Calendar.getInstance();
        new DatePickerDialog(a, new DatePickerDialog.OnDateSetListener() {
            @Override public void onDateSet(DatePicker v, int y, int m, int d) { cb.on(Model.ymd(y, m + 1, d)); }
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    /** 時間選擇。current 是 HH:mm(可空)。 */
    static void pickTime(Activity a, String current, final StrCb cb) {
        int h = 9, m = 0;
        if (current != null && current.length() >= 5 && current.charAt(2) == ':') {
            try { h = Integer.parseInt(current.substring(0, 2)); m = Integer.parseInt(current.substring(3, 5)); } catch (NumberFormatException ignore) { }
        }
        new TimePickerDialog(a, new TimePickerDialog.OnTimeSetListener() {
            @Override public void onTimeSet(TimePicker v, int hh, int mm) {
                cb.on(String.format(java.util.Locale.US, "%02d:%02d", hh, mm));
            }
        }, h, m, true).show();
    }
}
