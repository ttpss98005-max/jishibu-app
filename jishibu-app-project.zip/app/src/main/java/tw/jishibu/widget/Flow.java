package tw.jishibu.widget;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * 自動換行的橫排(等於網頁的 display:flex; flex-wrap:wrap; align-items:center)。
 * 一般子元件依內容大小排;用 Flow.grow(view, 基準寬dp) 標記的元件像 flex:1 1 基準寬:
 * 先用基準寬判斷會不會換行,同一行剩下的空間再平分給它。
 */
final class Flow extends ViewGroup {
    private final int hgap, vgap;
    private int[] px = new int[0], py = new int[0];

    private static final class Grow {
        final int basis;
        Grow(int b) { basis = b; }
    }

    Flow(Context c, float hgapDp, float vgapDp) {
        super(c);
        hgap = Ui.dp(c, hgapDp);
        vgap = Ui.dp(c, vgapDp);
    }

    /** 標記為「會填滿同一行剩餘空間」的元件。 */
    static <T extends View> T grow(T v, float basisDp) {
        v.setTag(new Grow(Ui.dp(v.getContext(), basisDp)));
        return v;
    }

    /** 子元件有指定固定寬高(LayoutParams)就照辦,否則依內容。 */
    private static int wSpecFor(View c, int avail) {
        ViewGroup.LayoutParams lp = c.getLayoutParams();
        if (lp != null && lp.width > 0) return MeasureSpec.makeMeasureSpec(lp.width, MeasureSpec.EXACTLY);
        return MeasureSpec.makeMeasureSpec(avail, MeasureSpec.AT_MOST);
    }

    private static int hSpecFor(View c) {
        ViewGroup.LayoutParams lp = c.getLayoutParams();
        if (lp != null && lp.height > 0) return MeasureSpec.makeMeasureSpec(lp.height, MeasureSpec.EXACTLY);
        return MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);
    }

    private static boolean isGrow(View v) { return v.getTag() instanceof Grow; }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int mode = MeasureSpec.getMode(wSpec);
        int avail = MeasureSpec.getSize(wSpec) - getPaddingLeft() - getPaddingRight();
        if (mode == MeasureSpec.UNSPECIFIED) avail = Integer.MAX_VALUE / 4;
        int n = getChildCount();
        int[] w = new int[n], h = new int[n];
        for (int i = 0; i < n; i++) {
            View c = getChildAt(i);
            if (c.getVisibility() == View.GONE) continue;
            if (isGrow(c)) {
                w[i] = Math.min(((Grow) c.getTag()).basis, avail);
            } else {
                c.measure(wSpecFor(c, avail), hSpecFor(c));
                w[i] = c.getMeasuredWidth();
            }
        }
        // 分行
        List<int[]> lines = new ArrayList<>(); // [起, 迄)
        int start = 0, used = 0;
        for (int i = 0; i < n; i++) {
            View c = getChildAt(i);
            if (c.getVisibility() == View.GONE) continue;
            int need = (used == 0 ? 0 : hgap) + w[i];
            if (used > 0 && used + need > avail) {
                lines.add(new int[]{start, i});
                start = i;
                used = w[i];
            } else {
                used += need;
            }
        }
        if (start < n) lines.add(new int[]{start, n});

        if (px.length != n) { px = new int[n]; py = new int[n]; }
        int y = 0, maxRight = 0;
        for (int li = 0; li < lines.size(); li++) {
            int[] ln = lines.get(li);
            int total = 0, vis = 0, growers = 0;
            for (int i = ln[0]; i < ln[1]; i++) {
                View c = getChildAt(i);
                if (c.getVisibility() == View.GONE) continue;
                total += w[i];
                vis++;
                if (isGrow(c)) growers++;
            }
            if (vis == 0) continue;
            total += hgap * (vis - 1);
            int extra = Math.max(0, avail - total);
            int lineH = 0;
            for (int i = ln[0]; i < ln[1]; i++) {
                View c = getChildAt(i);
                if (c.getVisibility() == View.GONE) continue;
                if (isGrow(c)) {
                    int cw = w[i] + (growers > 0 && mode != MeasureSpec.UNSPECIFIED ? extra / growers : 0);
                    w[i] = cw;
                    c.measure(MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY), hSpecFor(c));
                }
                h[i] = c.getMeasuredHeight();
                lineH = Math.max(lineH, h[i]);
            }
            int x = 0;
            for (int i = ln[0]; i < ln[1]; i++) {
                View c = getChildAt(i);
                if (c.getVisibility() == View.GONE) continue;
                px[i] = x;
                py[i] = y + (lineH - h[i]) / 2;
                x += w[i] + hgap;
            }
            maxRight = Math.max(maxRight, x - hgap);
            y += lineH + vgap;
        }
        if (!lines.isEmpty()) y -= vgap;
        int width = mode == MeasureSpec.EXACTLY ? MeasureSpec.getSize(wSpec) : maxRight + getPaddingLeft() + getPaddingRight();
        setMeasuredDimension(width, y + getPaddingTop() + getPaddingBottom());
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        for (int i = 0; i < getChildCount(); i++) {
            View c = getChildAt(i);
            if (c.getVisibility() == View.GONE || i >= px.length) continue;
            int left = getPaddingLeft() + px[i], top = getPaddingTop() + py[i];
            c.layout(left, top, left + c.getMeasuredWidth(), top + c.getMeasuredHeight());
        }
    }
}
