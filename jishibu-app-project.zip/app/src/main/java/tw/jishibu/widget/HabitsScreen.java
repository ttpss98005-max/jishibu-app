package tw.jishibu.widget;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 「習慣」分頁:一週日期條(含心情小臉)、打卡 / 統計、習慣總覽側欄、新增/編輯習慣、長按拖曳排序。
 * 資料:habits[{id,name,type:'boolean'|'time'|'quantity',unit,remindTime,freq,weekdays,monthdays,createdAt}],
 * habitLogs[習慣id][日期] = {value, checked}。照網頁版 renderHabitCheckin / renderHabitStats 等。
 */
final class HabitsScreen extends ScrollScreen {
    private static String habitDate = null;
    private static int weekOffset = 0;
    private static int tab = 0;                 // 0 打卡 / 1 統計
    private static int prevIdx = -1;            // 日期條上次選到第幾格(做滑動動畫)
    private static String armedDay = null;      // 過去的日子:第一次點只切換,第二次點才開心情
    private static String pendingBounce = null; // 剛打卡的格子,重畫後彈跳
    private static String pendingMilestone = null;

    private static final String[] DOW = {"日", "一", "二", "三", "四", "五", "六"};

    HabitsScreen(MainActivity a) { super(a); }

    @Override void onShow() {
        tab = 0;       // 切回來一律先看「打卡」(網頁版 switchMainView('habits') 也是)
        super.onShow();
    }

    // ---------- 資料讀取 ----------

    private static boolean future(String day) { return day.compareTo(Model.today()) > 0; }

    private static boolean has(JSONObject h, String day) { return Model.habitChecked(Model.s(h, "id"), day); }

    /**
     * 那天的打卡紀錄,統一成 {value, checked}。
     * 網頁版為了省空間,存檔時會把簡單紀錄壓成單一值(例如 "07:30"、2000、true),所以雲端資料兩種格式都有。
     */
    private static JSONObject entry(String hid, String day) {
        Object raw = Model.logEntry(hid, day);
        if (raw == null || raw == JSONObject.NULL) return null;
        if (raw instanceof JSONObject) return (JSONObject) raw;
        JSONObject o = new JSONObject();
        try {
            o.put("value", raw);
            o.put("checked", Model.habitChecked(hid, day));
        } catch (JSONException ignore) { }
        return o;
    }

    /** 這個習慣有打卡的所有日期。 */
    private static List<String> checkedDays(String hid) {
        List<String> r = new ArrayList<>();
        JSONObject d = Repo.data();
        JSONObject logs = d == null ? null : d.optJSONObject("habitLogs");
        if (logs == null) return r;
        Object cur = logs.opt(hid);
        if (cur instanceof JSONObject) {
            Iterator<String> it = ((JSONObject) cur).keys();
            while (it.hasNext()) { String k = it.next(); if (Model.habitChecked(hid, k)) r.add(k); }
        } else if (cur instanceof JSONArray) {
            JSONArray arr = (JSONArray) cur;
            for (int i = 0; i < arr.length(); i++) r.add(arr.optString(i));
        }
        return r;
    }

    private static String earliest(JSONObject h) {
        String e = Model.s(h, "createdAt", Model.today());
        if (!Model.isDay(e)) e = Model.today();
        for (String d : checkedDays(Model.s(h, "id"))) if (Model.isDay(d) && d.compareTo(e) < 0) e = d;
        return e;
    }

    private static int rate(JSONObject h, int days) {
        int count = 0;
        String d = Model.today();
        for (int i = 0; i < days; i++) {
            if (has(h, d)) count++;
            d = Model.addDays(d, -1);
        }
        return Math.round(count * 100f / days);
    }

    private static int rateAll(JSONObject h) {
        String e = earliest(h);
        int total = Math.max(1, (int) (Lunar.epochDay(Integer.parseInt(Model.today().substring(0, 4)), Integer.parseInt(Model.today().substring(5, 7)), Integer.parseInt(Model.today().substring(8, 10)))
                - Lunar.epochDay(Integer.parseInt(e.substring(0, 4)), Integer.parseInt(e.substring(5, 7)), Integer.parseInt(e.substring(8, 10)))) + 1);
        int count = checkedDays(Model.s(h, "id")).size();
        return Math.round(count * 100f / total);
    }

    static String freqLabel(JSONObject h) {
        String f = Model.s(h, "freq", "daily");
        if (f.isEmpty() || "daily".equals(f)) return "每天";
        if ("weekly".equals(f)) {
            List<Integer> ds = ints(h.optJSONArray("weekdays"));
            if (ds.isEmpty()) return "每週(尚未選擇星期)";
            StringBuilder sb = new StringBuilder("每週");
            for (int i = 0; i < ds.size(); i++) { if (i > 0) sb.append("、"); sb.append(DOW[ds.get(i) % 7]); }
            return sb.toString();
        }
        if ("monthly".equals(f)) {
            List<Integer> ds = ints(h.optJSONArray("monthdays"));
            if (ds.isEmpty()) return "每月(尚未選擇日期)";
            StringBuilder sb = new StringBuilder("每月");
            for (int i = 0; i < ds.size(); i++) { if (i > 0) sb.append("、"); sb.append(ds.get(i)); }
            return sb.append("號").toString();
        }
        return "每天";
    }

    private static List<Integer> ints(JSONArray a) {
        List<Integer> r = new ArrayList<>();
        if (a != null) for (int i = 0; i < a.length(); i++) r.add(a.optInt(i));
        java.util.Collections.sort(r);
        return r;
    }

    // ---------- 畫面 ----------

    @Override void build() {
        if (habitDate == null) habitDate = Model.today();
        content.addView(weekStrip(), Ui.mw(a, 0));
        content.addView(Ui.spacer(a, 18));

        // 工具列:總覽側欄 | 打卡/統計 | 新增
        LinearLayout bar = Ui.row(a);
        FrameLayout side = new FrameLayout(a);
        side.setBackground(Ui.shape(a, Ui.CHIP_BG, 10, 0, 0));
        side.setContentDescription("習慣總覽");
        side.addView(new SvgIcon(a, "<line x1=\"4\" y1=\"7\" x2=\"20\" y2=\"7\"/><line x1=\"4\" y1=\"12\" x2=\"20\" y2=\"12\"/><line x1=\"4\" y1=\"17\" x2=\"14\" y2=\"17\"/>", 20, Ui.SOFT),
                new FrameLayout.LayoutParams(Ui.dp(a, 20), Ui.dp(a, 20), Gravity.CENTER));
        side.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openSidebar(); }
        });
        bar.addView(side, new LinearLayout.LayoutParams(Ui.dp(a, 36), Ui.dp(a, 36)));
        View sp1 = new View(a);
        bar.addView(sp1, new LinearLayout.LayoutParams(0, 1, 1f));
        bar.addView(Ui.pillTabs(a, new String[]{"打卡", "統計"}, tab, new Ui.IntCb() {
            @Override public void on(int i) { tab = i; refresh(); }
        }));
        View sp2 = new View(a);
        bar.addView(sp2, new LinearLayout.LayoutParams(0, 1, 1f));
        bar.addView(Ui.btnPrimary(a, "＋ 新增習慣", new View.OnClickListener() {
            @Override public void onClick(View v) { openHabitModal(null); }
        }));
        content.addView(bar, Ui.mw(a, 0));
        content.addView(Ui.spacer(a, 16));

        if (tab == 0) buildCheckin(); else buildStats();
        pendingBounce = null;
        pendingMilestone = null;
    }

    // ----- 一週日期條 -----

    private View weekStrip() {
        LinearLayout box = Ui.col(a);
        String today = Model.today();
        String base = Model.addDays(today, weekOffset * 7);
        int dow = Lunar.dow(Integer.parseInt(base.substring(0, 4)), Integer.parseInt(base.substring(5, 7)), Integer.parseInt(base.substring(8, 10)));
        final String start = Model.addDays(base, -dow);
        String end = Model.addDays(start, 6);

        LinearLayout nav = Ui.row(a);
        nav.setGravity(Gravity.CENTER);
        nav.addView(arrow("‹", true, new View.OnClickListener() {
            @Override public void onClick(View v) { weekOffset = Math.min(0, weekOffset - 1); refresh(); }
        }));
        TextView range = Ui.tv(a, Model.fmtDate(start) + " - " + Model.fmtDate(end), 11.5f, Ui.SOFT, true);
        range.setGravity(Gravity.CENTER);
        range.setMinWidth(Ui.dp(a, 80));
        nav.addView(range, Ui.gap(a, 14));
        nav.addView(arrow("›", weekOffset < 0, new View.OnClickListener() {
            @Override public void onClick(View v) { weekOffset = Math.min(0, weekOffset + 1); refresh(); }
        }), Ui.gap(a, 14));
        box.addView(nav, Ui.mw(a, 0));
        box.addView(Ui.spacer(a, 8));

        final FrameLayout strip = new FrameLayout(a);
        final View indicator = new View(a);
        indicator.setBackground(Ui.shape(a, Ui.SURFACE, 14, 0, 0));
        indicator.setElevation(Ui.dp(a, 2));
        indicator.setVisibility(View.GONE);
        strip.addView(indicator, new FrameLayout.LayoutParams(0, 0));

        LinearLayout days = new LinearLayout(a);
        days.setOrientation(LinearLayout.HORIZONTAL);
        int selIdx = -1;
        for (int i = 0; i < 7; i++) {
            final String day = Model.addDays(start, i);
            boolean isToday = day.equals(today), isSel = day.equals(habitDate);
            if (isSel) selIdx = i;
            LinearLayout cell = Ui.col(a);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(Ui.dp(a, 2), Ui.dp(a, 8), Ui.dp(a, 2), Ui.dp(a, 8));
            cell.addView(Ui.tv(a, DOW[i], 11, isToday ? Ui.ACCENT : Ui.SOFT, isToday));
            String mood = null;
            if (day.compareTo(today) <= 0) {
                JSONObject rec = Repo.data().optJSONObject("dayRecaps");
                JSONObject r = rec == null ? null : rec.optJSONObject(day);
                if (r != null) mood = Model.s(r, "mood", "");
                if (mood != null && mood.isEmpty()) mood = null;
            }
            FrameLayout slot = new FrameLayout(a);
            if (mood != null) {
                slot.addView(Mood.face(a, mood, 26), new FrameLayout.LayoutParams(Ui.dp(a, 26), Ui.dp(a, 26), Gravity.CENTER));
            } else {
                TextView n = Ui.tv(a, String.valueOf(Integer.parseInt(day.substring(8, 10))), 13, isSel ? Ui.ACCENT : Ui.SOFT, true);
                n.setGravity(Gravity.CENTER);
                slot.addView(n, new FrameLayout.LayoutParams(Ui.dp(a, 34), Ui.dp(a, 34), Gravity.CENTER));
            }
            cell.addView(slot, new LinearLayout.LayoutParams(Ui.dp(a, 34), Ui.dp(a, 34)));
            Ui.lp(slot).topMargin = Ui.dp(a, 6);
            cell.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openDay(day); }
            });
            days.addView(cell, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        days.setElevation(Ui.dp(a, 3));   // 要比白色底塊(2dp)高,字才不會被蓋住
        strip.addView(days, new FrameLayout.LayoutParams(-1, -2));
        box.addView(strip, Ui.mw(a, 0));

        // 滑動的白色底塊
        final int idx = selIdx;
        final int from = prevIdx;
        prevIdx = idx;
        if (idx >= 0) {
            strip.post(new Runnable() {
                @Override public void run() {
                    int w = strip.getWidth() / 7, h = strip.getHeight();
                    if (w <= 0 || h <= 0) return;
                    int pad = Ui.dp(a, 2);
                    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w - pad * 2, h - pad * 2);
                    lp.topMargin = pad;
                    indicator.setLayoutParams(lp);
                    indicator.setVisibility(View.VISIBLE);
                    final float x1 = idx * w + pad;
                    final float x0 = (from >= 0 ? from : idx) * w + pad;
                    indicator.setTranslationX(x0);
                    if (x0 != x1) {
                        ValueAnimator va = ValueAnimator.ofFloat(x0, x1);
                        va.setDuration(280);
                        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                            @Override public void onAnimationUpdate(ValueAnimator an) {
                                indicator.setTranslationX((Float) an.getAnimatedValue());
                            }
                        });
                        va.start();
                    }
                }
            });
        }
        return box;
    }

    private View arrow(String s, boolean enabled, View.OnClickListener l) {
        TextView t = Ui.tv(a, s, 14, Ui.SOFT, false);
        t.setGravity(Gravity.CENTER);
        t.setBackground(Ui.shape(a, Ui.CHIP_BG, 13, 0, 0));
        t.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(a, 26), Ui.dp(a, 26)));
        if (enabled) t.setOnClickListener(l); else t.setAlpha(0.35f);
        return t;
    }

    /** 點日期條:切到那天;今天(晚安時段)/過去的日子可再點開心情。照網頁版 openDayMoodFlow。 */
    private void openDay(String day) {
        habitDate = day;
        tab = 0;
        String today = Model.today();
        if (day.compareTo(today) > 0) { armedDay = null; refresh(); return; }
        if (day.equals(today) && !Recap.nightWindowActive(day)) { armedDay = null; refresh(); return; }
        if (day.equals(armedDay)) {
            armedDay = null;
            boolean simple = !Recap.nightWindowActive(day);
            if (day.equals(today) && !simple) {
                JSONObject d = Repo.data();
                if (today.equals(Model.s(d, "lastAutoRecapDate", ""))) simple = true;
                else Repo.set(a, today, "lastAutoRecapDate");
            }
            refresh();
            Recap.show(a, day, true, simple);
        } else {
            armedDay = day;
            refresh();
        }
    }

    // ----- 打卡 -----

    private void buildCheckin() {
        List<JSONObject> habits = Model.habits();
        if (habits.isEmpty()) {
            content.addView(Ui.empty(a, "還沒有任何習慣,點右上角「＋新增習慣」開始每天打卡"));
            return;
        }
        final String day = habitDate;
        boolean fut = future(day);
        final List<JSONObject> sched = new ArrayList<>();
        for (JSONObject h : habits) if (Model.habitScheduledOn(h, day)) sched.add(h);
        int done = 0;
        for (JSONObject h : sched) if (has(h, day)) done++;
        String label = day.equals(Model.today()) ? "今日" : day.substring(5).replace('-', '/');
        content.addView(Ui.tv(a, label + "已完成 " + done + " / " + sched.size() + " 項習慣" + (fut ? "(未來日期尚無法勾選)" : ""), 12.5f, Ui.SOFT, false), Ui.mw(a, 0));
        content.addView(Ui.spacer(a, 14));

        final LinearLayout table = Ui.col(a);
        for (int i = 0; i < sched.size(); i++) table.addView(habitRow(sched.get(i), i, day, fut, table));
        content.addView(table, Ui.mw(a, 0));
    }

    private View habitRow(final JSONObject h, int idx, final String day, boolean fut, LinearLayout table) {
        final String hid = Model.s(h, "id");
        String type = Model.s(h, "type", "boolean");
        JSONObject en = entry(hid, day);
        boolean checked = Model.habitChecked(hid, day);
        int streak = Model.habitStreak(h, day);

        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setBackground(Ui.shape(a, Ui.TASK_BG, 16, Ui.BORDER, 1.5f));
        card.setElevation(Ui.dp(a, 1));
        int bw = Ui.dp(a, 2);
        card.setPadding(bw, bw, bw, bw);
        card.setTag(hid);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(-1, -2);
        clp.bottomMargin = Ui.dp(a, 10);
        card.setLayoutParams(clp);

        // 左:拖曳把手 + 序號
        LinearLayout num = Ui.col(a);
        num.setGravity(Gravity.CENTER);
        LinearLayout handle = Ui.col(a);
        handle.setGravity(Gravity.CENTER);
        handle.setPadding(Ui.dp(a, 6), Ui.dp(a, 8), Ui.dp(a, 6), Ui.dp(a, 8));
        handle.setContentDescription("長按拖曳排序");
        for (int k = 0; k < 3; k++) {
            View line = new View(a);
            line.setBackground(Ui.shape(a, Ui.SOFT, 1, 0, 0));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(a, 14), Math.max(2, Ui.dp(a, 2)));
            if (k > 0) lp.topMargin = Ui.dp(a, 3);
            handle.addView(line, lp);
        }
        handle.setOnTouchListener(new Dragger(table, card));
        num.addView(handle);
        num.addView(Ui.tv(a, String.valueOf(idx + 1), 10, Ui.SOFT, false));
        card.addView(num, new LinearLayout.LayoutParams(Ui.dp(a, 40), -1));

        // 中:名稱 + 編輯/刪除
        LinearLayout nameBox = Ui.row(a);
        nameBox.setPadding(0, Ui.dp(a, 14), Ui.dp(a, 8), Ui.dp(a, 14));
        View dot = new View(a);
        dot.setBackground(Ui.shape(a, Ui.ACCENT, 9, 0, 0));
        nameBox.addView(dot, new LinearLayout.LayoutParams(Ui.dp(a, 9), Ui.dp(a, 9)));
        LinearLayout col = Ui.col(a);
        col.addView(Ui.tv(a, Model.s(h, "name"), 14, checked ? Ui.SOFT : Ui.CARD_INK, true));
        LinearLayout links = Ui.row(a);
        links.addView(link("編輯", new View.OnClickListener() {
            @Override public void onClick(View v) { openHabitModal(hid); }
        }));
        links.addView(link("刪除", new View.OnClickListener() {
            @Override public void onClick(View v) { deleteHabit(hid); }
        }), Ui.gap(a, 8));
        col.addView(links, Ui.wrap(a, 2));
        nameBox.addView(col, wl(10));
        card.addView(nameBox, new LinearLayout.LayoutParams(0, -1, 1f));

        // 右:輸入 + 打卡 + 連續天數
        LinearLayout right = Ui.col(a);
        right.setGravity(Gravity.CENTER);
        right.setPadding(Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10));
        float r = Ui.dp(a, 15);
        GradientDrawable rbg = new GradientDrawable();
        rbg.setColor(Ui.CHIP_BG);
        rbg.setCornerRadii(new float[]{0, 0, r, r, r, r, 0, 0});
        right.setBackground(rbg);

        if ("quantity".equals(type)) {
            right.addView(quantityInput(hid, day, en, fut), new LinearLayout.LayoutParams(Ui.dp(a, 64), -2));
            TextView unit = Ui.tv(a, Model.s(h, "unit", ""), 12, Ui.SOFT, false);
            unit.setGravity(Gravity.CENTER);
            right.addView(unit, Ui.mw(a, 2));
        } else if ("time".equals(type)) {
            right.addView(timeInput(hid, day, en, fut), new LinearLayout.LayoutParams(Ui.dp(a, 100), -2));
        }
        LinearLayout ck = Ui.row(a);
        final Check chk = new Check(a, 22, checked);
        chk.setContentDescription("打卡:" + Model.s(h, "name"));
        if (fut) chk.setAlpha(0.35f);
        else {
            final boolean bool = "boolean".equals(type);
            chk.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { if (bool) toggleBoolean(h, day); else toggleChecked(h, day); }
            });
        }
        ck.addView(chk);
        TextView badge = Ui.chip(a, "連續" + streak + "天", 12.5f, Ui.ACCENT, Ui.ACCENT_SOFT, true);
        final FrameLayout badgeWrap = new FrameLayout(a);
        badgeWrap.addView(badge, new FrameLayout.LayoutParams(-2, -2));
        ck.addView(badgeWrap, Ui.gap(a, 6));
        right.addView(ck, Ui.mw(a, ("boolean".equals(type)) ? 0 : 6));
        card.addView(right, new LinearLayout.LayoutParams(Ui.dp(a, 128), -1));

        if (pendingBounce != null && pendingBounce.equals(hid + ":" + day)) {
            chk.post(new Runnable() { @Override public void run() { chk.bounce(); } });
        }
        if (pendingMilestone != null && pendingMilestone.equals(hid)) {
            badgeWrap.post(new Runnable() { @Override public void run() { glow(badgeWrap); } });
        }
        return card;
    }

    private LinearLayout.LayoutParams wl(float left) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.leftMargin = Ui.dp(a, left);
        return p;
    }

    private TextView link(String s, View.OnClickListener l) {
        TextView t = Ui.tv(a, s, 13, 0xFFC7C3B8, false);
        t.setPadding(0, Ui.dp(a, 3), Ui.dp(a, 6), Ui.dp(a, 3));
        t.setOnClickListener(l);
        return t;
    }

    private EditText quantityInput(final String hid, final String day, JSONObject en, boolean fut) {
        String val = "";
        if (en != null && en.has("value") && !en.isNull("value")) {
            Object v = en.opt("value");
            if (v instanceof Number) {
                double dv = ((Number) v).doubleValue();
                val = dv == Math.rint(dv) ? String.valueOf((long) dv) : String.valueOf(dv);
            } else if (!(v instanceof Boolean)) val = String.valueOf(v);
        }
        final EditText e = Ui.numberInput(a, "", val, true);
        e.setTextSize(14);
        e.setGravity(Gravity.CENTER);
        e.setPadding(Ui.dp(a, 4), Ui.dp(a, 7), Ui.dp(a, 4), Ui.dp(a, 7));
        e.setBackground(Ui.shape(a, 0xFFFFFFFF, 10, Ui.BORDER, 1.5f));
        e.setImeOptions(EditorInfo.IME_ACTION_DONE);
        final String orig = val;
        if (fut) { e.setEnabled(false); e.setAlpha(0.4f); return e; }
        final boolean[] sent = {false};
        e.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    commitQuantity(hid, day, e.getText().toString().trim(), orig);
                    sent[0] = true;
                    e.clearFocus();
                    return true;
                }
                return false;
            }
        });
        e.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus && !sent[0]) commitQuantity(hid, day, e.getText().toString().trim(), orig);
                if (hasFocus) sent[0] = false;
            }
        });
        return e;
    }

    private void commitQuantity(String hid, String day, String raw, String orig) {
        if (raw.equals(orig)) return;
        setHabitValue(hid, day, raw, "quantity");
    }

    private TextView timeInput(final String hid, final String day, JSONObject en, boolean fut) {
        String val = "";
        if (en != null && en.has("value") && !en.isNull("value") && !(en.opt("value") instanceof Boolean)) val = String.valueOf(en.opt("value"));
        final String cur = val;
        TextView t = Ui.tv(a, val.isEmpty() ? "--:--" : val, 14, Ui.CARD_INK, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(a, 4), Ui.dp(a, 7), Ui.dp(a, 4), Ui.dp(a, 7));
        t.setBackground(Ui.shape(a, 0xFFFFFFFF, 10, Ui.BORDER, 1.5f));
        if (fut) { t.setAlpha(0.4f); return t; }
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Modal.pickTime(a, cur, new Modal.StrCb() {
                    @Override public void on(String s) { setHabitValue(hid, day, s, "time"); }
                });
            }
        });
        t.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                if (cur.isEmpty()) return true;
                Modal.confirm(a, "清除這天的時間?", null, "清除", true, new Runnable() {
                    @Override public void run() { setHabitValue(hid, day, "", "time"); }
                });
                return true;
            }
        });
        return t;
    }

    // ----- 打卡動作(照網頁版 setHabitBoolean / setHabitChecked / setHabitValue) -----

    private static final int[] MILESTONES = {7, 30, 100, 365};

    private void afterCheck(JSONObject h, String day) {
        String hid = Model.s(h, "id");
        pendingBounce = hid + ":" + day;
        int st = Model.habitStreak(h, day);
        for (int m : MILESTONES) if (m == st) pendingMilestone = hid;
        a.refreshCurrent();
    }

    private void toggleBoolean(JSONObject h, String day) {
        if (future(day)) return;
        String hid = Model.s(h, "id");
        boolean now = !Model.habitChecked(hid, day);
        JSONObject v = new JSONObject();
        try { v.put("value", true); v.put("checked", now); } catch (JSONException ignore) { }
        Repo.set(a, v, "habitLogs", hid, day);
        if (now) afterCheck(h, day); else a.refreshCurrent();
    }

    private void toggleChecked(JSONObject h, String day) {
        if (future(day)) return;
        String hid = Model.s(h, "id");
        JSONObject en = entry(hid, day);
        boolean now = !(en != null && en.optBoolean("checked", false));
        boolean storedAsObject = Model.logEntry(hid, day) instanceof JSONObject;
        if (en != null && storedAsObject) {
            JSONObject set = new JSONObject();
            try { set.put("checked", now); } catch (JSONException ignore) { }
            Repo.patch(a, set, null, "habitLogs", hid, day);
        } else if (en != null) {
            // 雲端存的是壓縮格式(單一值):整筆換成 {value, checked},原本的值保留
            JSONObject v = new JSONObject();
            try { v.put("value", en.opt("value")); v.put("checked", now); } catch (JSONException ignore) { }
            Repo.set(a, v, "habitLogs", hid, day);
        } else {
            JSONObject v = new JSONObject();
            try { v.put("checked", now); } catch (JSONException ignore) { }
            Repo.set(a, v, "habitLogs", hid, day);
        }
        if (now) afterCheck(h, day); else a.refreshCurrent();
    }

    private void setHabitValue(String hid, String day, String raw, String type) {
        if (future(day)) return;
        JSONObject h = null;
        for (JSONObject x : Model.habits()) if (hid.equals(Model.s(x, "id"))) h = x;
        boolean just = false;
        if (raw.isEmpty()) {
            Repo.del(a, "habitLogs", hid, day);
        } else if ("quantity".equals(type)) {
            double num;
            try { num = Double.parseDouble(raw); } catch (NumberFormatException e) { return; }
            JSONObject v = new JSONObject();
            try { v.put("value", num); v.put("checked", true); } catch (JSONException ignore) { }
            Repo.set(a, v, "habitLogs", hid, day);
            just = true;
        } else {
            JSONObject v = new JSONObject();
            try { v.put("value", raw); v.put("checked", true); } catch (JSONException ignore) { }
            Repo.set(a, v, "habitLogs", hid, day);
            just = true;
        }
        if (just && h != null) afterCheck(h, day); else a.refreshCurrent();
    }

    /** 連續天數達到 7/30/100/365 天:徽章外圈閃一圈橘光。 */
    private void glow(final FrameLayout wrap) {
        final View halo = new View(a);
        halo.setBackground(Ui.shape(a, 0xB3F2A93B, 999, 0, 0));
        wrap.addView(halo, 0, new FrameLayout.LayoutParams(-1, -1));
        ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(900);
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator an) {
                float t = (Float) an.getAnimatedValue();
                halo.setAlpha(0.7f * (1f - t));
                halo.setScaleX(1f + 0.45f * t);
                halo.setScaleY(1f + 0.9f * t);
                if (t >= 1f) wrap.removeView(halo);
            }
        });
        va.start();
    }

    // ----- 長按拖曳排序 -----

    /** 按住把手 0.38 秒後進入拖曳:整張卡片跟著手指,碰到上下鄰居的中線就換位置;放開才寫入順序。 */
    private final class Dragger implements View.OnTouchListener {
        private final LinearLayout table;
        private final View row;
        private float startRawY, slotInitial;
        private boolean dragging;
        private Runnable starter;

        Dragger(LinearLayout table, View row) { this.table = table; this.row = row; }

        private float gap() { return Ui.dp(a, 10); }

        private float topOf(int index) {
            float y = 0;
            for (int i = 0; i < index; i++) y += table.getChildAt(i).getHeight() + gap();
            return y;
        }

        @Override public boolean onTouch(final View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startRawY = e.getRawY();
                    dragging = false;
                    starter = new Runnable() {
                        @Override public void run() {
                            dragging = true;
                            if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
                            v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                            slotInitial = topOf(table.indexOfChild(row));
                            row.setElevation(Ui.dp(a, 8));
                            row.setScaleX(1.02f);
                            row.setScaleY(1.02f);
                            row.setAlpha(0.95f);
                        }
                    };
                    v.postDelayed(starter, 380);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (!dragging) {
                        if (Math.abs(e.getRawY() - startRawY) > Ui.dp(a, 10)) v.removeCallbacks(starter);
                        return true;
                    }
                    move(e.getRawY());
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.removeCallbacks(starter);
                    if (dragging) { dragging = false; finish(); }
                    return true;
                default:
                    return true;
            }
        }

        private void move(float rawY) {
            int n = table.getChildCount();
            int idx = table.indexOfChild(row);
            float rowH = row.getHeight();
            for (int guard = 0; guard < n; guard++) {
                float slot = topOf(idx);
                float trans = (rawY - startRawY) - (slot - slotInitial);
                float center = slot + trans + rowH / 2f;
                boolean swapped = false;
                if (idx < n - 1) {
                    View next = table.getChildAt(idx + 1);
                    float nextCenter = topOf(idx + 1) + next.getHeight() / 2f;
                    if (center > nextCenter) {
                        table.removeView(row);
                        table.addView(row, idx + 1);
                        idx++;
                        swapped = true;
                    }
                }
                if (!swapped && idx > 0) {
                    View prev = table.getChildAt(idx - 1);
                    float prevCenter = topOf(idx - 1) + prev.getHeight() / 2f;
                    if (center < prevCenter) {
                        table.removeView(row);
                        table.addView(row, idx - 1);
                        idx--;
                        swapped = true;
                    }
                }
                if (!swapped) break;
            }
            float slot = topOf(idx);
            row.setTranslationY((rawY - startRawY) - (slot - slotInitial));
        }

        private void finish() {
            row.setTranslationY(0);
            row.setScaleX(1f);
            row.setScaleY(1f);
            row.setAlpha(1f);
            row.setElevation(Ui.dp(a, 1));
            List<String> visible = new ArrayList<>();
            for (int i = 0; i < table.getChildCount(); i++) visible.add(String.valueOf(table.getChildAt(i).getTag()));
            // 全部習慣的順序:看得到的那幾個照新順序填回它們原本佔的位置,沒排程(看不到)的維持不動
            List<String> full = new ArrayList<>();
            for (JSONObject h : Model.habits()) full.add(Model.s(h, "id"));
            List<String> out = new ArrayList<>();
            int k = 0;
            for (String id : full) {
                if (visible.contains(id)) { if (k < visible.size()) out.add(visible.get(k++)); }
                else out.add(id);
            }
            if (!out.equals(full)) Repo.order(a, out, "habits");
            a.refreshCurrent();
        }
    }

    // ----- 統計 -----

    private void buildStats() {
        List<JSONObject> habits = Model.habits();
        if (habits.isEmpty()) {
            content.addView(Ui.empty(a, "還沒有任何習慣,先到「打卡」新增一個吧"));
            return;
        }
        for (JSONObject h : habits) {
            LinearLayout card = Ui.taskCard(a);
            card.setPadding(Ui.dp(a, 18), Ui.dp(a, 16), Ui.dp(a, 18), Ui.dp(a, 16));
            String type = Model.s(h, "type", "boolean");
            if ("boolean".equals(type)) {
                card.addView(Ui.tv(a, Model.s(h, "name"), 13.5f, Ui.CARD_INK, true));
                card.addView(Ui.spacer(a, 12));
                card.addView(rateRow("近7天", rate(h, 7)), Ui.mw(a, 0));
                card.addView(rateRow("近30天", rate(h, 30)), Ui.mw(a, 9));
                card.addView(rateRow("總計", rateAll(h)), Ui.mw(a, 9));
            } else {
                card.addView(Ui.tv(a, Model.s(h, "name") + "(歷史趨勢)", 13.5f, Ui.CARD_INK, true));
                card.addView(Ui.spacer(a, 12));
                card.addView(chart(h), Ui.mw(a, 0));
            }
            content.addView(card, Ui.mw(a, 12));
        }
    }

    private View rateRow(String label, int val) {
        LinearLayout row = Ui.row(a);
        TextView l = Ui.tv(a, label, 11.5f, Ui.SOFT, false);
        row.addView(l, new LinearLayout.LayoutParams(Ui.dp(a, 52), -2));
        RateBar bar = new RateBar(val);
        row.addView(bar, new LinearLayout.LayoutParams(0, Ui.dp(a, 8), 1f));
        TextView v = Ui.tv(a, val + "%", 11.5f, Ui.SOFT, false);
        v.setGravity(Gravity.END);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(Ui.dp(a, 40), -2);
        row.addView(v, vp);
        Ui.lp(bar).leftMargin = Ui.dp(a, 10);
        Ui.lp(bar).rightMargin = Ui.dp(a, 10);
        return row;
    }

    /** 進度條:0.8 秒由左長到目標。 */
    private final class RateBar extends View {
        private final int target;
        private float t = 0f;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean started = false;

        RateBar(int target) { super(a); this.target = target; }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (started) return;
            started = true;
            ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
            va.setDuration(800);
            va.setInterpolator(new DecelerateInterpolator(2f));
            va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator an) { t = (Float) an.getAnimatedValue(); invalidate(); }
            });
            va.start();
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Ui.BORDER);
            c.drawRoundRect(new RectF(0, 0, w, h), h / 2f, h / 2f, p);
            float fw = w * Math.max(0, Math.min(100, target)) / 100f * t;
            if (fw > 0.5f) {
                p.setColor(Ui.ACCENT);
                c.drawRoundRect(new RectF(0, 0, Math.max(fw, h), h), h / 2f, h / 2f, p);
            }
        }
    }

    private static double minutes(String t) {
        try {
            String[] p = t.split(":");
            return Integer.parseInt(p[0]) * 60 + Integer.parseInt(p[1]);
        } catch (Exception e) {
            return 0;
        }
    }

    private static String minutesLabel(double m) {
        int h = (int) Math.floor(m / 60), mm = (int) Math.round(m % 60);
        return String.format(java.util.Locale.US, "%02d:%02d", ((h % 24) + 24) % 24, mm);
    }

    private View chart(JSONObject h) {
        String hid = Model.s(h, "id");
        if (checkedDays(hid).isEmpty()) {
            TextView e = Ui.empty(a, "尚無紀錄");
            e.setPadding(0, Ui.dp(a, 24), 0, Ui.dp(a, 24));
            return e;
        }
        String startD = earliest(h), endD = Model.today();
        List<String> days = new ArrayList<>();
        String d = startD;
        int guard = 0;
        while (d.compareTo(endD) <= 0 && guard++ < 20000) { days.add(d); d = Model.addDays(d, 1); }
        boolean isTime = "time".equals(Model.s(h, "type"));
        float[] vals = new float[days.size()];
        for (int i = 0; i < vals.length; i++) {
            String day = days.get(i);
            JSONObject en = entry(hid, day);
            double v = 0;
            if (en != null && en.optBoolean("checked", false) && en.has("value") && !en.isNull("value")) {
                Object raw = en.opt("value");
                if (!"".equals(raw)) {
                    if (isTime) v = minutes(String.valueOf(raw));
                    else if (raw instanceof Number) v = ((Number) raw).doubleValue();
                    else if (raw instanceof Boolean) v = ((Boolean) raw) ? 1 : 0;
                    else {
                        try { v = Double.parseDouble(String.valueOf(raw)); } catch (NumberFormatException ex) { v = 0; }
                    }
                }
            }
            vals[i] = (float) v;
        }
        float min = Float.MAX_VALUE, max = -Float.MAX_VALUE;
        for (float v : vals) { min = Math.min(min, v); max = Math.max(max, v); }
        if (min == max) { min -= 1; max += 1; }
        String unit = Model.s(h, "unit", "");
        String[] labels = {fmt(max, isTime, unit), fmt(min, isTime, unit), days.get(0).substring(5).replace('-', '/'), days.get(days.size() - 1).substring(5).replace('-', '/')};
        return new HabitChart(a, vals, labels);
    }

    private static String fmt(float v, boolean isTime, String unit) {
        if (isTime) return minutesLabel(v);
        double r = Math.round(v * 10) / 10.0;
        String s = r == Math.rint(r) ? String.valueOf((long) r) : String.valueOf(r);
        return s + (unit.isEmpty() ? "" : " " + unit);
    }

    // ---------- 側欄:習慣總覽 ----------

    private void openSidebar() {
        final Dialog dlg = new Dialog(a);
        FrameLayout root = new FrameLayout(a);
        final LinearLayout panel = Ui.col(a);
        panel.setBackgroundColor(Ui.SURFACE);
        panel.setPadding(Ui.dp(a, 20), Ui.dp(a, 24), Ui.dp(a, 20), Ui.dp(a, 20));
        panel.setClickable(true);

        LinearLayout head = Ui.row(a);
        head.addView(Ui.tv(a, "習慣總覽", 16, Ui.CARD_INK, true), new LinearLayout.LayoutParams(0, -2, 1f));
        TextView close = Ui.tv(a, "×", 20, Ui.SOFT, false);
        close.setPadding(Ui.dp(a, 8), Ui.dp(a, 4), Ui.dp(a, 8), Ui.dp(a, 4));
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { dlg.dismiss(); }
        });
        head.addView(close);
        panel.addView(head, Ui.mw(a, 0));
        panel.addView(Ui.spacer(a, 14));

        android.widget.ScrollView sv = new android.widget.ScrollView(a);
        LinearLayout list = Ui.col(a);
        List<JSONObject> habits = Model.habits();
        if (habits.isEmpty()) {
            TextView e = Ui.tv(a, "還沒有任何習慣", 13, Ui.SOFT, false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, Ui.dp(a, 30), 0, Ui.dp(a, 30));
            list.addView(e);
        }
        for (final JSONObject h : habits) {
            final String hid = Model.s(h, "id");
            LinearLayout item = Ui.col(a);
            item.setPadding(0, Ui.dp(a, 12), 0, Ui.dp(a, 12));
            item.addView(Ui.tv(a, Model.s(h, "name"), 14, Ui.CARD_INK, true));
            TextView fq = Ui.tv(a, freqLabel(h), 12, Ui.SOFT, false);
            item.addView(fq, Ui.mw(a, 3));
            LinearLayout act = Ui.row(a);
            TextView edit = Ui.tv(a, "編輯", 12.5f, Ui.ACCENT, false);
            edit.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dlg.dismiss(); openHabitModal(hid); }
            });
            TextView del = Ui.tv(a, "刪除", 12.5f, Ui.DANGER, false);
            del.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { dlg.dismiss(); deleteHabit(hid); }
            });
            act.addView(edit);
            act.addView(del, Ui.gap(a, 14));
            item.addView(act, Ui.mw(a, 8));
            list.addView(item, new LinearLayout.LayoutParams(-1, -2));
            list.addView(Ui.hline(a));
        }
        sv.addView(list, new ViewGroup.LayoutParams(-1, -2));
        panel.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        int screenW = a.getResources().getDisplayMetrics().widthPixels;
        int w = Math.min((int) (screenW * 0.82f), Ui.dp(a, 320));
        root.addView(panel, new FrameLayout.LayoutParams(w, -1, Gravity.START));
        root.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { dlg.dismiss(); }
        });
        dlg.setContentView(root);
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0));
            dlg.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
            dlg.getWindow().setGravity(Gravity.START);
            dlg.getWindow().setDimAmount(0.35f);
        }
        dlg.show();
        panel.setTranslationX(-w);
        ValueAnimator va = ValueAnimator.ofFloat(-w, 0f);
        va.setDuration(250);
        va.setInterpolator(new DecelerateInterpolator(2f));
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator an) { panel.setTranslationX((Float) an.getAnimatedValue()); }
        });
        va.start();
    }

    // ---------- 新增 / 編輯 / 刪除 ----------

    private void openHabitModal(final String habitId) {
        JSONObject found = null;
        if (habitId != null) for (JSONObject x : Model.habits()) if (habitId.equals(Model.s(x, "id"))) found = x;
        final JSONObject h = found;
        final String[] type = {"boolean"};
        final String[] freq = {h == null ? "daily" : Model.s(h, "freq", "daily")};
        if (freq[0].isEmpty()) freq[0] = "daily";
        final boolean[] wd = new boolean[7];
        final boolean[] md = new boolean[32];
        if (h != null) {
            for (int v : ints(h.optJSONArray("weekdays"))) if (v >= 0 && v < 7) wd[v] = true;
            for (int v : ints(h.optJSONArray("monthdays"))) if (v >= 1 && v <= 31) md[v] = true;
        }

        Form f = new Form(a);
        final Form.Text name = f.text("習慣名稱", h == null ? "" : Model.s(h, "name"), "例如:喝水量");
        final EditText[] unitBox = new EditText[1];
        if (h == null) {
            final LinearLayout unitField = Ui.col(a);
            unitBox[0] = Ui.input(a, "例如:公斤、公升、次", "");
            View unitF = Ui.field(a, "單位", unitBox[0]);
            unitField.addView(unitF);
            unitField.setVisibility(View.GONE);
            f.add(Ui.field(a, "紀錄方式", Ui.pillTabs(a, new String[]{"打卡", "時間", "數量"}, 0, new Ui.IntCb() {
                @Override public void on(int i) {
                    type[0] = i == 0 ? "boolean" : i == 1 ? "time" : "quantity";
                    unitField.setVisibility("quantity".equals(type[0]) ? View.VISIBLE : View.GONE);
                }
            })));
            f.add(unitField);
        }
        final LinearLayout weekdayField = Ui.col(a), monthdayField = Ui.col(a);
        weekdayField.addView(Ui.field(a, "星期幾要做(可多選)", weekdayPicker(wd)));
        monthdayField.addView(Ui.field(a, "每月幾號要做(可多選)", monthdayPicker(md)));
        weekdayField.setVisibility("weekly".equals(freq[0]) ? View.VISIBLE : View.GONE);
        monthdayField.setVisibility("monthly".equals(freq[0]) ? View.VISIBLE : View.GONE);
        int fi = "weekly".equals(freq[0]) ? 1 : "monthly".equals(freq[0]) ? 2 : 0;
        f.add(Ui.field(a, "重複頻率", Ui.pillTabs(a, new String[]{"每天", "每週", "每月"}, fi, new Ui.IntCb() {
            @Override public void on(int i) {
                freq[0] = i == 0 ? "daily" : i == 1 ? "weekly" : "monthly";
                weekdayField.setVisibility(i == 1 ? View.VISIBLE : View.GONE);
                monthdayField.setVisibility(i == 2 ? View.VISIBLE : View.GONE);
            }
        })));
        f.add(weekdayField);
        f.add(monthdayField);
        final Form.Date remind = f.time("每日提醒時間(可留空)", h == null ? "" : Model.s(h, "remindTime", ""));

        Modal.show(a, h != null ? "編輯習慣" : "新增習慣", f.view(), h != null ? "儲存" : "新增", new Modal.Ok() {
            @Override public boolean run() {
                String nm = name.get();
                if (nm.isEmpty()) { Ui.toast(a, "請輸入習慣名稱"); return false; }
                String rt = remind.get();
                JSONArray wda = new JSONArray(), mda = new JSONArray();
                for (int i = 0; i < 7; i++) if (wd[i]) wda.put(i);
                for (int i = 1; i <= 31; i++) if (md[i]) mda.put(i);
                if ("weekly".equals(freq[0]) && wda.length() == 0) { Ui.toast(a, "請選擇每週要做的星期"); return false; }
                if ("monthly".equals(freq[0]) && mda.length() == 0) { Ui.toast(a, "請選擇每月要做的日期"); return false; }
                try {
                    if (h != null) {
                        JSONObject set = new JSONObject();
                        set.put("name", nm);
                        set.put("remindTime", rt.isEmpty() ? JSONObject.NULL : rt);
                        set.put("freq", freq[0]);
                        set.put("weekdays", wda);
                        set.put("monthdays", mda);
                        Repo.patch(a, set, null, "habits", habitId);
                        JSONObject forRem = new JSONObject(h.toString());
                        forRem.put("name", nm);
                        forRem.put("remindTime", rt);
                        Reminders.habit(a, forRem);
                    } else {
                        String unit = "";
                        if ("quantity".equals(type[0])) {
                            unit = unitBox[0].getText().toString().trim();
                            if (unit.isEmpty()) { Ui.toast(a, "請輸入數量單位,例如:公斤、公升"); return false; }
                        }
                        JSONObject item = new JSONObject();
                        item.put("id", Repo.newId());
                        item.put("name", nm);
                        item.put("type", type[0]);
                        item.put("unit", unit);
                        item.put("remindTime", rt.isEmpty() ? JSONObject.NULL : rt);
                        item.put("freq", freq[0]);
                        item.put("weekdays", wda);
                        item.put("monthdays", mda);
                        item.put("createdAt", Model.today());
                        Repo.add(a, item, -1, "habits");
                        JSONObject forRem = new JSONObject(item.toString());
                        forRem.put("remindTime", rt);
                        Reminders.habit(a, forRem);
                    }
                } catch (JSONException ignore) { }
                a.refreshCurrent();
                return true;
            }
        });
    }

    private View weekdayPicker(final boolean[] sel) {
        LinearLayout row = Ui.row(a);
        final TextView[] btns = new TextView[7];
        for (int i = 0; i < 7; i++) {
            final int d = i;
            TextView b = Ui.tv(a, DOW[i], 13, Ui.CARD_INK, true);
            b.setGravity(Gravity.CENTER);
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { sel[d] = !sel[d]; paintPick(btns[d], sel[d], 19); }
            });
            btns[i] = b;
            paintPick(b, sel[i], 19);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(a, 36), 1f);
            if (i > 0) lp.leftMargin = Ui.dp(a, 4);
            row.addView(b, lp);
        }
        return row;
    }

    private View monthdayPicker(final boolean[] sel) {
        LinearLayout grid = Ui.col(a);
        final TextView[] btns = new TextView[32];
        for (int r = 0; r < 5; r++) {
            LinearLayout row = new LinearLayout(a);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c = 0; c < 7; c++) {
                int d = r * 7 + c + 1;
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(a, 32), 1f);
                lp.setMargins(Ui.dp(a, 2), Ui.dp(a, 2), Ui.dp(a, 2), Ui.dp(a, 2));
                if (d > 31) { row.addView(new View(a), lp); continue; }
                final int day = d;
                TextView b = Ui.tv(a, String.valueOf(d), 12.5f, Ui.CARD_INK, true);
                b.setGravity(Gravity.CENTER);
                b.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { sel[day] = !sel[day]; paintPick(btns[day], sel[day], 10); }
                });
                btns[d] = b;
                paintPick(b, sel[d], 10);
                row.addView(b, lp);
            }
            grid.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        return grid;
    }

    private void paintPick(TextView b, boolean on, float radius) {
        b.setTextColor(on ? Ui.ON_ACCENT : 0xFF1A1A1A);
        b.setBackground(on ? Ui.shape(a, Ui.ACCENT, radius, Ui.ACCENT, 1.5f) : Ui.shape(a, 0xFFFFFFFF, radius, Ui.BORDER, 1.5f));
    }

    private void deleteHabit(final String id) {
        JSONObject found = null;
        int at = -1, i = 0;
        for (JSONObject x : Model.habits()) { if (id.equals(Model.s(x, "id"))) { found = x; at = i; } i++; }
        if (found == null) return;
        final JSONObject h = found;
        final int idx = at;
        Modal.confirm(a, "確定要刪除這個習慣嗎?", "所有打卡紀錄與統計數值都會一併刪除,此動作無法復原。", "刪除", true, new Runnable() {
            @Override public void run() {
                final JSONObject removed;
                try { removed = new JSONObject(h.toString()); } catch (JSONException e) { return; }
                JSONObject logs = Repo.data().optJSONObject("habitLogs");
                Object lg = logs == null ? null : logs.opt(id);
                Object copy = null;
                try {
                    if (lg instanceof JSONObject) copy = new JSONObject(lg.toString());
                    else if (lg instanceof JSONArray) copy = new JSONArray(lg.toString());
                } catch (JSONException ignore) { }
                final Object removedLog = copy;
                Repo.del(a, "habits", id);
                if (lg != null) Repo.del(a, "habitLogs", id);
                Reminders.habitRemove(a, id);
                a.refreshCurrent();
                a.undo("已刪除習慣「" + Model.s(removed, "name") + "」", new Runnable() {
                    @Override public void run() {
                        Repo.add(a, removed, idx, "habits");
                        if (removedLog != null) Repo.set(a, removedLog, "habitLogs", id);
                        Reminders.habit(a, removed);
                        a.refreshCurrent();
                    }
                });
            }
        });
    }
}
