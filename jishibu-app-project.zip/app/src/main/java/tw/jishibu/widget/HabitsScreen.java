package tw.jishibu.widget;

import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.List;

/** 習慣:最近 7 天的打卡,點圓圈打卡或輸入數量/時間。 */
final class HabitsScreen extends Screen {
    HabitsScreen(MainActivity a) { super(a); }

    @Override
    void build() {
        final String today = Model.today();
        content.addView(Ui.tv(a, "習慣", 26, Ui.INK, true));
        List<JSONObject> habits = Model.habits();
        if (habits.isEmpty()) {
            note("還沒有習慣。新增習慣目前請先用網頁版。");
            return;
        }
        for (final JSONObject h : habits) {
            LinearLayout card = Ui.card(a);
            String hid = Model.s(h, "id");
            int streak = Model.habitStreak(h, today);
            if (streak == 0 && Model.habitScheduledOn(h, today)) streak = Model.habitStreak(h, Model.addDays(today, -1));

            LinearLayout head = Ui.row(a);
            head.addView(Ui.tv(a, Model.s(h, "name", ""), 17, Ui.INK, true), Ui.weight(1));
            if (streak > 0) head.addView(Ui.tv(a, "連續 " + streak + " 天", 13, Ui.ACCENT, true));
            card.addView(head);
            String type = Model.s(h, "type", "boolean");
            if ("quantity".equals(type) && !Model.s(h, "unit").isEmpty()) {
                card.addView(Ui.tv(a, "單位:" + Model.s(h, "unit"), 12, Ui.SOFT, false));
            } else if ("time".equals(type)) {
                card.addView(Ui.tv(a, "記錄時間", 12, Ui.SOFT, false));
            }

            LinearLayout days = Ui.row(a);
            for (int i = 6; i >= 0; i--) {
                final String d = Model.addDays(today, -i);
                boolean scheduled = Model.habitScheduledOn(h, d);
                boolean checked = Model.habitChecked(hid, d);
                LinearLayout c = Ui.col(a);
                c.setGravity(Gravity.CENTER_HORIZONTAL);
                TextView wd = Ui.tv(a, d.equals(today) ? "今" : Model.weekday(d), 11, d.equals(today) ? Ui.ACCENT : Ui.SOFT, d.equals(today));
                wd.setGravity(Gravity.CENTER);
                c.addView(wd);
                TextView dot = new TextView(a);
                dot.setGravity(Gravity.CENTER);
                dot.setTextSize(11);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(a, 36), Ui.dp(a, 36));
                lp.topMargin = Ui.dp(a, 4);
                if (checked) {
                    dot.setBackground(Ui.shape(a, Ui.ACCENT, 18, 0, 0));
                    String v = "boolean".equals(type) ? "✓" : Model.habitValueText(h, d);
                    dot.setText(v.isEmpty() ? "✓" : v);
                    dot.setTextColor(Ui.ON_ACCENT);
                } else {
                    dot.setBackground(Ui.shape(a, 0x00000000, 18, scheduled ? Ui.SOFT : Ui.LINE, 2));
                    dot.setText(String.valueOf(Integer.parseInt(d.substring(8, 10))));
                    dot.setTextColor(scheduled ? Ui.SOFT : Ui.LINE);
                }
                c.addView(dot, lp);
                c.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { Dialogs.habitTap(a, h, d, again); }
                });
                days.addView(c, Ui.weight(1));
            }
            card.addView(days, Ui.mw(a, 10));
            content.addView(card, Ui.mw(a, 12));
        }
    }
}
