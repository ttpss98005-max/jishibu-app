package tw.jishibu.widget;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 資料版本 11 → 12 的升級(跟網頁版 migrateSubtaskSettings 一模一樣的規則)。
 *
 * 新規則:細項只有名稱和備註;日期、時間、提醒只有事項才有。
 * 舊資料裡「有時間」的細項這樣處理:
 *   1. 原事項還沒完成 → 細項搬出來變成獨立的事項(沿用同一個 id):日期、時間、提醒原樣帶過去;
 *      細項做完了就是已完成的事項,沒做完就是未完成的事項;分類跟原事項一樣;標題後面加「（原事項名稱）」;排在原事項後面。
 *   2. 原事項已經完成 → 細項留在原事項底下,只清掉時間和提醒。
 *   3. 沒有時間的細項:不動(只清掉多餘的 time / reminder 欄位)。
 * 一律先在複本上做,做完逐項核對(每個原本的事項和細項都還在、標題完整、備註和完成狀態沒變、數量對得上),
 * 核對沒過就丟出例外、原資料一個字都不改。重複執行不會再變(沒有東西可轉就什麼都不做)。
 */
final class Migrate {
    private Migrate() {}

    /** 這個 App 從哪個資料版本升級上來。 */
    static final int FROM = 11;

    private static final Pattern TIME = Pattern.compile("(\\d{4}-\\d{2}-\\d{2})T([01]\\d|2[0-3]):([0-5]\\d).*", Pattern.DOTALL);

    static final class Result {
        int promoted;
        /** 升級讓 tasks 少掉的節點數(給寫入前的安全檢查當「刻意減少」的額度)。 */
        int removedNodes;
        /** 要刪掉的雲端提醒 id(被清掉的提醒,或搬出去時已經做完的)。 */
        final List<String> reminderDelete = new ArrayList<>();
        /** 要用事項資料重寫的雲端提醒(搬出來、還沒做完、有開提醒的事項 id)。 */
        final List<String> reminderWrite = new ArrayList<>();
        boolean changed() { return promoted > 0 || removedNodes != 0 || !reminderDelete.isEmpty(); }
    }

    private static boolean isObj(Object o) { return o instanceof JSONObject; }

    private static boolean hasLegacy(JSONObject s) { return s.has("time") || s.has("reminder"); }

    /** 有沒有細項還帶著 time / reminder 欄位。 */
    static boolean needed(JSONObject doc) {
        JSONArray tasks = doc == null ? null : doc.optJSONArray("tasks");
        if (tasks == null) return false;
        for (int i = 0; i < tasks.length(); i++) {
            JSONObject t = tasks.optJSONObject(i);
            JSONArray subs = t == null ? null : t.optJSONArray("subtasks");
            if (subs == null) continue;
            for (int j = 0; j < subs.length(); j++) {
                JSONObject s = subs.optJSONObject(j);
                if (s != null && hasLegacy(s)) return true;
            }
        }
        return false;
    }

    private static String timeStr(JSONObject s) {
        Object o = s.opt("time");
        return o instanceof String ? (String) o : "";
    }

    private static String str(JSONObject o, String k) {
        Object v = o.opt(k);
        return v instanceof String ? (String) v : (v == null || v == JSONObject.NULL ? "" : String.valueOf(v));
    }

    private static void fail(String why) throws Exception {
        throw new Exception("資料版本升級的檢查沒通過(" + why + "),為了保護你的資料,這次沒有做任何修改");
    }

    /** 升級 doc.tasks。成功才會改 doc;核對失敗丟出例外、doc 完全不動。沒有東西可轉就什麼都不做。 */
    static Result run(JSONObject doc) throws Exception {
        Result res = new Result();
        JSONArray src = doc.optJSONArray("tasks");
        if (src == null || !needed(doc)) return res;

        JSONArray work = new JSONArray(src.toString());
        Set<String> taken = new HashSet<>();
        for (int i = 0; i < work.length(); i++) {
            JSONObject t = work.optJSONObject(i);
            if (t != null) taken.add(str(t, "id"));
        }
        JSONArray out = new JSONArray();
        List<String[]> promotedMap = new ArrayList<>();   // {原細項 id, 新事項 id, 標題, 狀態, 備註}

        for (int i = 0; i < work.length(); i++) {
            Object raw = work.opt(i);
            out.put(raw);
            if (!isObj(raw)) continue;
            JSONObject t = (JSONObject) raw;
            JSONArray subs = t.optJSONArray("subtasks");
            if (subs == null) continue;
            JSONArray keep = new JSONArray();
            List<JSONObject> promoted = new ArrayList<>();
            boolean parentDone = "done".equals(t.opt("status"));
            for (int j = 0; j < subs.length(); j++) {
                Object so = subs.opt(j);
                if (!isObj(so)) { keep.put(so); continue; }
                JSONObject s = (JSONObject) so;
                Matcher m = TIME.matcher(timeStr(s));
                boolean hasTime = m.matches();
                boolean hadReminder = Boolean.TRUE.equals(s.opt("reminder"));
                if (hasTime && !parentDone) {
                    String sid = str(s, "id");
                    String nid = sid;
                    while (nid.isEmpty() || taken.contains(nid)) nid = Repo.newId();
                    taken.add(nid);
                    JSONObject nt = new JSONObject(s.toString());
                    boolean subDone = "done".equals(s.opt("status"));
                    nt.put("id", nid);
                    nt.put("categoryId", t.has("categoryId") ? t.opt("categoryId") : JSONObject.NULL);
                    nt.put("title", str(s, "title") + "（" + str(t, "title") + "）");
                    nt.put("dueDate", m.group(1));
                    nt.put("dueTime", m.group(2) + ":" + m.group(3));
                    nt.put("reminder", hadReminder);
                    nt.put("status", subDone ? "done" : "pending");
                    nt.put("subtasks", new JSONArray());
                    nt.remove("time");
                    promoted.add(nt);
                    promotedMap.add(new String[]{sid, nid, str(s, "title"), subDone ? "done" : "x", str(s, "note")});
                    if (hadReminder && !subDone) res.reminderWrite.add(nid);
                    else if (hadReminder) res.reminderDelete.add(nid);
                } else {
                    if (hadReminder) res.reminderDelete.add(str(s, "id"));
                    s.remove("time");
                    s.remove("reminder");
                    keep.put(s);
                }
            }
            t.put("subtasks", keep);
            for (JSONObject p : promoted) out.put(p);
        }

        // ---- 核對:任何一項對不上就整個放棄 ----
        Map<String, JSONObject> outById = new HashMap<>();
        for (int i = 0; i < out.length(); i++) {
            JSONObject t = out.optJSONObject(i);
            if (t != null && !outById.containsKey(str(t, "id"))) outById.put(str(t, "id"), t);
        }
        int srcCount = src.length();
        int subBefore = 0, subAfter = 0;
        for (int i = 0; i < src.length(); i++) {
            JSONObject t = src.optJSONObject(i);
            if (t == null) continue;
            JSONObject nt = outById.get(str(t, "id"));
            if (nt == null) fail("事項不見了:" + str(t, "title"));
            if (!str(nt, "title").equals(str(t, "title")) || !str(nt, "status").equals(str(t, "status"))
                    || !str(nt, "note").equals(str(t, "note")) || !str(nt, "dueDate").equals(str(t, "dueDate"))) {
                fail("事項被改到:" + str(t, "title"));
            }
            JSONArray ss = t.optJSONArray("subtasks");
            if (ss != null) subBefore += ss.length();
        }
        for (int i = 0; i < out.length(); i++) {
            JSONObject t = out.optJSONObject(i);
            JSONArray ss = t == null ? null : t.optJSONArray("subtasks");
            if (ss != null) subAfter += ss.length();
        }
        if (out.length() != srcCount + promotedMap.size()) fail("事項數量對不上");
        if (subAfter != subBefore - promotedMap.size()) fail("細項數量對不上");
        Set<String> promotedSubIds = new HashSet<>();
        for (String[] p : promotedMap) {
            promotedSubIds.add(p[0]);
            JSONObject nt = outById.get(p[1]);
            if (nt == null || !str(nt, "title").startsWith(p[2]) || !str(nt, "note").equals(p[4])
                    || "done".equals(nt.opt("status")) != "done".equals(p[3])) {
                fail("搬出來的細項核對失敗:" + p[2]);
            }
        }
        for (int i = 0; i < src.length(); i++) {
            JSONObject t = src.optJSONObject(i);
            JSONArray ss = t == null ? null : t.optJSONArray("subtasks");
            if (ss == null) continue;
            JSONObject nt = outById.get(str(t, "id"));
            JSONArray nss = nt == null ? null : nt.optJSONArray("subtasks");
            for (int j = 0; j < ss.length(); j++) {
                JSONObject s = ss.optJSONObject(j);
                if (s == null || promotedSubIds.contains(str(s, "id"))) continue;
                JSONObject kept = null;
                for (int k = 0; nss != null && k < nss.length(); k++) {
                    JSONObject x = nss.optJSONObject(k);
                    if (x != null && str(x, "id").equals(str(s, "id"))) { kept = x; break; }
                }
                if (kept == null || !str(kept, "title").equals(str(s, "title")) || !str(kept, "status").equals(str(s, "status"))
                        || !str(kept, "note").equals(str(s, "note"))) {
                    fail("細項被改到:" + str(s, "title"));
                }
            }
        }

        // ---- 通過:換上去 ----
        int before = Doc.nodes(src);
        doc.put("tasks", out);
        res.promoted = promotedMap.size();
        res.removedNodes = Math.max(0, before - Doc.nodes(out));
        return res;
    }

    // ---------- 舊版留下的操作 ----------

    /**
     * 舊版(資料版本 11)排隊、還沒送出的操作,如果指到「已經搬成事項的細項」,把路徑改指到那個事項(id 沒變);
     * 並把舊的 time 欄位換成事項的 dueDate / dueTime。找不到就維持原樣(套用時會安靜略過,跟以前一樣)。
     */
    static void remap(JSONObject doc, JSONObject op) {
        try {
            JSONArray p = op.optJSONArray("path");
            if (p == null || p.length() < 4 || !"tasks".equals(p.optString(0)) || !"subtasks".equals(p.optString(2))) return;
            JSONArray tasks = doc.optJSONArray("tasks");
            if (tasks == null) return;
            String tid = p.optString(1), sid = p.optString(3);
            JSONObject parent = null, top = null;
            for (int i = 0; i < tasks.length(); i++) {
                JSONObject t = tasks.optJSONObject(i);
                if (t == null) continue;
                if (parent == null && tid.equals(str(t, "id"))) parent = t;
                if (top == null && sid.equals(str(t, "id"))) top = t;
            }
            if (top == null) return;
            JSONArray subs = parent == null ? null : parent.optJSONArray("subtasks");
            for (int j = 0; subs != null && j < subs.length(); j++) {
                JSONObject s = subs.optJSONObject(j);
                if (s != null && sid.equals(str(s, "id"))) return;   // 還是細項,不用改
            }
            JSONArray np = new JSONArray();
            np.put("tasks"); np.put(sid);
            for (int k = 4; k < p.length(); k++) np.put(p.opt(k));
            op.put("path", np);
            JSONObject set = op.optJSONObject("set");
            if (set != null && set.has("time")) {
                Object tv = set.opt("time");
                set.remove("time");
                Matcher m = TIME.matcher(tv instanceof String ? (String) tv : "");
                if (m.matches()) {
                    set.put("dueDate", m.group(1));
                    set.put("dueTime", m.group(2) + ":" + m.group(3));
                } else {
                    set.put("dueDate", "");
                    set.put("dueTime", "");
                    set.put("reminder", false);
                }
            }
        } catch (JSONException ignore) { }
    }
}
