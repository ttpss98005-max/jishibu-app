package tw.jishibu.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 登入畫面,照網頁版:整片「翻磚」動畫背景 + 置中的白色卡片(記事簿 / 使用 Google 登入)。
 * 沒登入時一開 App 就是這個畫面;登入成功後淡出(0.5 秒),進入習慣頁。
 * 動畫兩種節奏(跟網頁一樣):忙碌(按下登入、載入資料)整片連續翻面;等你操作時整片靜止、只隨機輕翻 5 塊。
 */
final class LoginScreen extends FrameLayout {
    private static final String PREF = "jishibu_login", KEY_ACCENT = "accent";
    private static final int DEFAULT_ACCENT = 0xFF3A6B5E;

    /** 記下目前的強調色,下次登入畫面(例如登出後)沿用同一個配色。 */
    static void saveAccent(Context c, int accent) {
        try { c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt(KEY_ACCENT, accent).apply(); }
        catch (Exception ignore) { }
    }

    static int savedAccent(Context c) {
        try { return c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt(KEY_ACCENT, DEFAULT_ACCENT); }
        catch (Exception e) { return DEFAULT_ACCENT; }
    }

    private final MainActivity a;
    private final Bg bg;
    private final LinearLayout card;
    private final TextView note, googleText;
    private final View googleBtn;

    LoginScreen(MainActivity act) {
        super(act);
        a = act;
        int accent = savedAccent(act);
        setBackgroundColor(Scene.mix(0xFFFFFFFF, accent, 0x22 / 255.0));
        setClickable(true);   // 擋住底下的畫面,不讓點到

        bg = new Bg(act, accent);
        addView(bg, new LayoutParams(-1, -1));

        // 白色卡片:圓角 26、內距 44/40、最寬 360、佔 88% 寬
        int sw = act.getResources().getDisplayMetrics().widthPixels;
        int cw = Math.min(Ui.dp(act, 360), (int) (sw * 0.88f));
        card = new LinearLayout(act);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(Ui.dp(act, 40), Ui.dp(act, 44), Ui.dp(act, 40), Ui.dp(act, 44));
        card.setBackground(Ui.shape(act, 0xFFFFFFFF, 26, 0, 0));
        card.setElevation(Ui.dp(act, 8));
        LayoutParams cp = new LayoutParams(cw, -2, Gravity.CENTER);
        addView(card, cp);

        TextView title = Ui.tv(act, "記事簿", 22, 0xFF1A1A1A, true);
        title.setLetterSpacing(0.02f);
        title.setGravity(Gravity.CENTER);
        card.addView(title, new LinearLayout.LayoutParams(-2, -2));

        // Google 按鈕(跟網頁的 Google 按鈕同款:白底、細邊框、膠囊、彩色 G)
        googleBtn = buildGoogleButton(act);
        googleText = (TextView) ((ViewGroup) googleBtn).getChildAt(1);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(Ui.dp(act, 280), Ui.dp(act, 44));
        gp.topMargin = Ui.dp(act, 22);
        card.addView(googleBtn, gp);
        googleBtn.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { a.googleLogin(); }
        });

        note = Ui.tv(act, "", 11, 0xFF8A8A8A, false);
        note.setLineSpacing(0, 1.4f);
        note.setPadding(Ui.dp(act, 14), Ui.dp(act, 12), Ui.dp(act, 14), Ui.dp(act, 12));
        note.setBackground(Ui.shape(act, 0xFFFAFAF7, 14, 0, 0));
        note.setVisibility(GONE);
        card.addView(note, Ui.mw(act, 16));
    }

    private View buildGoogleButton(Context c) {
        LinearLayout b = new LinearLayout(c);
        b.setOrientation(LinearLayout.HORIZONTAL);
        b.setGravity(Gravity.CENTER);
        b.setBackground(Ui.shape(c, 0xFFFFFFFF, 22, 0xFFDADCE0, 1));
        b.setPadding(Ui.dp(c, 12), 0, Ui.dp(c, 12), 0);
        b.addView(new GLogo(c), new LinearLayout.LayoutParams(Ui.dp(c, 18), Ui.dp(c, 18)));
        TextView t = Ui.tv(c, "使用 Google 登入", 14, 0xFF3C4043, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.leftMargin = Ui.dp(c, 10);
        b.addView(t, tp);
        return b;
    }

    // ---------- 給 MainActivity 用 ----------

    /** 忙碌:動畫整片連續翻、按鈕變淡不能重按。 */
    void setBusy(boolean busy) {
        bg.setBusy(busy);
        googleBtn.setAlpha(busy ? 0.55f : 1f);
        googleBtn.setEnabled(!busy);
        googleText.setText(busy ? "登入中…" : "使用 Google 登入");
    }

    void showNote(String s) {
        if (s == null || s.isEmpty()) { note.setVisibility(GONE); return; }
        note.setText(s);
        note.setVisibility(VISIBLE);
    }

    /** 淡入(登出後回到登入畫面)。 */
    void fadeIn() {
        setAlpha(0f);
        animate().alpha(1f).setDuration(400).start();
        card.setTranslationY(Ui.dp(a, 6));
        card.animate().translationY(0).setDuration(400).start();
    }

    /** 登入成功:0.5 秒淡出,結束後拆掉並停止動畫。 */
    void fadeOut(final Runnable done) {
        setEnabled(false);
        animate().alpha(0f).setDuration(500).withEndAction(new Runnable() {
            @Override public void run() {
                bg.stopAnim();
                if (done != null) done.run();
            }
        }).start();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        bg.startAnim();
    }

    @Override protected void onDetachedFromWindow() {
        bg.stopAnim();
        super.onDetachedFromWindow();
    }

    // ---------- 彩色 Google「G」 ----------

    private static final class GLogo extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        GLogo(Context c) { super(c); p.setStyle(Paint.Style.STROKE); }
        @Override protected void onDraw(Canvas cv) {
            float s = Math.min(getWidth(), getHeight()), w = s * 0.2f, r = (s - w) / 2f, cx = getWidth() / 2f, cy = getHeight() / 2f;
            RectF rc = new RectF(cx - r, cy - r, cx + r, cy + r);
            p.setStrokeWidth(w);
            p.setStrokeCap(Paint.Cap.BUTT);
            p.setColor(0xFFEA4335); cv.drawArc(rc, 215, 100, false, p);
            p.setColor(0xFFFBBC05); cv.drawArc(rc, 140, 75, false, p);
            p.setColor(0xFF34A853); cv.drawArc(rc, 40, 100, false, p);
            p.setColor(0xFF4285F4); cv.drawArc(rc, -45, 85, false, p);
            p.setStyle(Paint.Style.FILL);
            cv.drawRect(cx, cy - w / 2f, cx + r + w / 2f, cy + w / 2f, p);   // 右邊的橫槓
            p.setStyle(Paint.Style.STROKE);
        }
    }

    // ---------- 翻磚動畫背景(照網頁 LoginBg 逐項移植) ----------

    private static final class Bg extends View {
        private static final int[] TYPES = {0, 1, 3};
        private static final int[][] COMBOS = {{0, 1}, {1, 3}, {3, 0}, {2, 1}};   // [底, 圖形],0=soft 1=accent 2=deep 3=paper
        private static final double PERIOD = 1.9, DELAY = .085, F = 2.4, IDLE_GAP = 1.7, IDLE_F = 1.9;
        private static final int IDLE_COUNT = 5;

        private static final class Tile { int i, j, idx, base, rot0; int[] types = new int[4], combos = new int[4]; }
        private static final class Wave { double start, f, dk; int dir; boolean soft; int[] only; }

        private final int accent;
        private final int[] pal = new int[4];   // soft, accent, deep, paper
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path[] shapes = new Path[4];
        private final RectF rect = new RectF();
        private List<Tile> tiles = new ArrayList<>();
        private List<Integer> seen = new ArrayList<>();
        private final List<Wave> waves = new ArrayList<>();
        private int cols, rows, baseCount, waveSeq;
        private float tile, oy;
        private boolean busy, running;
        private long t0;
        private int[] idleRnd;   // mulberry32 狀態(只有一個值)

        Bg(Context c, int accent) {
            super(c);
            this.accent = accent;
            Scene.C col = Scene.derive(accent);
            pal[0] = col.soft; pal[1] = col.accent; pal[2] = col.deep; pal[3] = col.sky;
            // 磚的三種圖形(單位座標 -1..1):四分之一圓、半圓、三角
            Path q = new Path(); q.moveTo(-1, -1); q.arcTo(new RectF(-3, -3, 1, 1), 0, 90); q.close(); shapes[0] = q;
            Path h = new Path(); h.arcTo(new RectF(-1, -.5f, 1, 1.5f), 180, 180); h.close(); shapes[1] = h;
            Path t = new Path(); t.moveTo(-1, 1); t.lineTo(1, 1); t.lineTo(-1, -1); t.close(); shapes[3] = t;
            shapes[2] = shapes[3];
            idleRnd = new int[]{777};
            busy = false;
        }

        void setBusy(boolean b) { busy = b; }

        void startAnim() {
            if (running) return;
            running = true;
            t0 = SystemClock.uptimeMillis();
            waves.clear(); baseCount = 0; waveSeq = 0;
            tiles = new ArrayList<>();
            postInvalidateOnAnimation();
        }

        void stopAnim() { running = false; }

        // JS 版的 mulberry32:狀態放在長度 1 的陣列裡
        private static double rnd(int[] st) {
            st[0] += 0x6D2B79F5;
            int a = st[0];
            int t = (a ^ (a >>> 15)) * (1 | a);
            t = (t + ((t ^ (t >>> 7)) * (61 | t))) ^ t;
            return ((t ^ (t >>> 14)) & 0xFFFFFFFFL) / 4294967296.0;
        }

        private void build(int w, int h) {
            float dens = getContext().getResources().getDisplayMetrics().density;
            float wdp = w / dens;
            cols = (int) Math.max(3, Math.min(10, Math.round(wdp / 130f)));
            tile = w / (float) cols;
            rows = (int) Math.ceil(h / tile) + 1;
            oy = (h - rows * tile) / 2f;
            int[] st = {4242};
            tiles = new ArrayList<>();
            seen = new ArrayList<>();
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    Tile T = new Tile();
                    T.i = i; T.j = j; T.idx = j * cols + i;
                    for (int k = 0; k < 4; k++) {
                        T.types[k] = TYPES[(int) Math.floor(rnd(st) * TYPES.length)];
                        T.combos[k] = (int) Math.floor(rnd(st) * COMBOS.length);
                    }
                    for (int k = 1; k < 4; k++) if (T.combos[k] == T.combos[k - 1]) T.combos[k] = (T.combos[k] + 1) % COMBOS.length;
                    T.rot0 = (int) Math.floor(rnd(st) * 4);
                    tiles.add(T);
                    float cy = oy + j * tile + tile / 2f;
                    if (cy > 0 && cy < h) seen.add(T.idx);
                }
            }
            waves.clear(); baseCount = 0; waveSeq = 0;
        }

        private static double spring(double t, double f, double z) {
            if (t <= 0) return 0;
            double w = Math.PI * 2 * f, wd = w * Math.sqrt(1 - z * z);
            return 1 - Math.exp(-z * w * t) * (Math.cos(wd * t) + (z * w / wd) * Math.sin(wd * t));
        }

        private double delayOf(int dir, double dk, int i, int j) {
            if (dir == 0) return (i + j) * dk;
            if (dir == 1) return (cols - 1 - i + j) * dk;
            double ci = (cols - 1) / 2.0, cj = (rows - 1) / 2.0;
            return Math.hypot(i - ci, j - cj) * dk * 1.7;
        }

        @Override protected void onDraw(Canvas cv) {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            if (tiles.isEmpty()) build(w, h);
            double t = (SystemClock.uptimeMillis() - t0) / 1000.0;
            cv.drawColor(pal[3]);

            // 排程:忙碌時每 PERIOD 秒翻整片一波;等你操作時每 IDLE_GAP 秒只翻 IDLE_COUNT 塊隨機的磚
            double gap = busy ? PERIOD : IDLE_GAP;
            Wave lastW = waves.isEmpty() ? null : waves.get(waves.size() - 1);
            if (lastW == null || t >= lastW.start + gap) {
                Wave nw = new Wave();
                nw.start = (lastW == null || t - lastW.start > gap * 1.5) ? t : lastW.start + gap;
                if (!busy) {
                    List<Integer> pool = new ArrayList<>(seen);
                    int n = Math.min(IDLE_COUNT, pool.size());
                    nw.only = new int[n];
                    for (int k = 0; k < n; k++) nw.only[k] = pool.remove((int) Math.floor(rnd(idleRnd) * pool.size()));
                }
                nw.dir = waveSeq % 3;
                nw.f = busy ? F : IDLE_F;
                nw.dk = busy ? DELAY : 0;
                nw.soft = !busy;
                waves.add(nw);
                waveSeq++;
            }
            // 早就翻完的波合併成計數
            while (!waves.isEmpty() && t - waves.get(0).start > 4) {
                Wave old = waves.remove(0);
                if (old.only != null) { for (int idx : old.only) tiles.get(idx).base++; } else baseCount++;
            }
            for (Tile T : tiles) {
                double rot = T.rot0 * Math.PI / 2 + (baseCount + T.base) * Math.PI / 2, kick = 0;
                int passed = baseCount + T.base;
                for (Wave wv : waves) {
                    if (wv.only != null) {
                        boolean has = false;
                        for (int idx : wv.only) if (idx == T.idx) { has = true; break; }
                        if (!has) continue;
                    }
                    double d = delayOf(wv.dir, wv.dk, T.i, T.j), ta = t - wv.start - d, sp = spring(ta, wv.f, .45);
                    rot += sp * Math.PI / 2;
                    if (sp > .5) passed++;
                    if (ta >= 0) kick = Math.max(kick, Math.exp(-ta * 6) * (wv.soft ? .5 : 1));
                }
                int cI = passed % 4;
                int[] combo = COMBOS[T.combos[cI]];
                int type = T.types[cI];
                float x = T.i * tile, y = oy + T.j * tile;
                cv.save();
                rect.set(x, y, x + tile + .5f, y + tile + .5f);
                cv.clipRect(rect);
                fill.setColor(pal[combo[0]]);
                cv.drawRect(rect, fill);
                cv.translate(x + tile / 2f, y + tile / 2f);
                cv.rotate((float) Math.toDegrees(rot));
                float hs = (float) (tile / 2f * (1 + .05 * kick));
                cv.scale(hs, hs);
                fill.setColor(pal[combo[1]]);
                cv.drawPath(shapes[type], fill);
                cv.restore();
            }
            if (running) postInvalidateOnAnimation();
        }

        @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            tiles = new ArrayList<>();
        }
    }
}
