package tw.jishibu.widget;

import android.content.Context;

/** 心情小臉(網頁版 moodFaceSvgSmall,圓角方塊 40x40)。mood: bad / good / 其他(普通)。 */
final class Mood {
    private Mood() {}

    private static final String BAD = "<rect width=\"40\" height=\"40\" rx=\"10\" fill=\"#5B9BD5\"/><circle cx=\"14\" cy=\"17\" r=\"2.2\" fill=\"#fff\"/><circle cx=\"26\" cy=\"17\" r=\"2.2\" fill=\"#fff\"/><path d=\"M13 27 Q20 22 27 27\" stroke=\"#fff\" stroke-width=\"2.2\" fill=\"none\" stroke-linecap=\"round\"/>";
    private static final String GOOD = "<rect width=\"40\" height=\"40\" rx=\"10\" fill=\"#F2A93B\"/><path d=\"M11 16 Q14 13 17 16\" stroke=\"#fff\" stroke-width=\"2.2\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M23 16 Q26 13 29 16\" stroke=\"#fff\" stroke-width=\"2.2\" fill=\"none\" stroke-linecap=\"round\"/><path d=\"M12 23 Q20 31 28 23\" stroke=\"#fff\" stroke-width=\"2.4\" fill=\"none\" stroke-linecap=\"round\"/>";
    private static final String OK = "<rect width=\"40\" height=\"40\" rx=\"10\" fill=\"#EDE3CC\"/><circle cx=\"14\" cy=\"17\" r=\"2.2\" fill=\"#5A5346\"/><circle cx=\"26\" cy=\"17\" r=\"2.2\" fill=\"#5A5346\"/><line x1=\"14\" y1=\"26\" x2=\"26\" y2=\"26\" stroke=\"#5A5346\" stroke-width=\"2.2\" stroke-linecap=\"round\"/>";

    /** 選心情畫面用的大臉(「不好」多一滴眼淚)。 */
    private static final String BAD_LARGE = BAD + "<path d=\"M25 20 q2.5 3 0.5 6.5\" stroke=\"#fff\" stroke-width=\"1.6\" fill=\"none\" stroke-linecap=\"round\" opacity=\"0.85\"/>";

    static SvgIcon faceLarge(Context c, String mood, int sizeDp) {
        return SvgIcon.withBox(c, "bad".equals(mood) ? BAD_LARGE : svg(mood), sizeDp, 40f);
    }

    static String svg(String mood) {
        if ("bad".equals(mood)) return BAD;
        if ("good".equals(mood)) return GOOD;
        return OK;
    }

    static SvgIcon face(Context c, String mood, int sizeDp) {
        return SvgIcon.withBox(c, svg(mood), sizeDp, 40f);
    }
}
