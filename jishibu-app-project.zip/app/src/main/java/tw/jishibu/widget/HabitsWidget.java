package tw.jishibu.widget;

/** 桌面小工具:Habits(內容和更新都在 Widgets)。 */
public class HabitsWidget extends Widgets.Base {
    @Override int kind() { return Widgets.HABITS; }
}
