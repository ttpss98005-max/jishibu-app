package tw.jishibu.widget;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;

/**
 * 從備份檔還原(網頁版 readBackupPayload / applyRestore)。
 * 還原是「整份取代」,所以比一般存檔更小心:
 *   1. 備份檔先在複本上檢查格式,不合格就原封不動拒絕,目前資料完全不動。
 *   2. 還原的那一刻,雲端現有的整份資料會先備份進 history(pre-restore-時間),跟取代是同一個動作,不會有只做一半的狀況。
 *   3. 只有在雲端還停在剛讀到的版本時才寫入;期間被別的裝置改過就放棄,請使用者重來。
 *   4. 太大(超過雲端單一文件上限)的備份不在手機上還原,請用網頁版(它會自動壓縮收納舊資料)。
 */
final class Restore {
    private Restore() {}

    static final class Parsed {
        JSONObject data;
        String exportedAt = "", email = "";
        int tasks, habits, expenses, quickNotes, dayRecaps;
        /** 舊版(資料版本 11)的備份還原時順便升級的結果;還原成功後雲端提醒要跟著換。 */
        Migrate.Result migrated;
    }

    private static final String[] NEED_ARRAYS = {"tasks", "categories", "habits", "expenses", "expenseCategories", "incomeCategories", "accounts"};
    private static final String[] FILL_ARRAYS = {"quickNotes", "bookmarks", "recurring", "customPalettes", "specialDays"};
    private static final String[] FILL_OBJECTS = {"habitLogs", "dayRecaps", "categoryBudgets", "leaveByMonth", "salaryRecorded"};

    /** 讀備份檔文字。格式不對丟出帶中文原因的例外。 */
    static Parsed read(String text) throws Exception {
        JSONObject obj;
        try {
            obj = new JSONObject(text);
        } catch (Exception e) {
            throw new Exception("檔案內容不是有效的備份檔");
        }
        JSONObject cand = obj.optJSONObject("data") != null ? obj.optJSONObject("data") : obj;   // 也接受直接是資料本體的檔案
        if (cand.optJSONArray("tasks") == null && cand.optJSONArray("habits") == null && cand.optJSONArray("expenses") == null) {
            throw new Exception("這不是記事簿的備份檔");
        }
        if (cand.optInt("schemaVersion", 0) > Repo.SCHEMA) throw new Exception("這份備份來自比較新的版本，請先更新 App");
        if (cand.has("archives")) Backup.inflate(cand, null, null);   // 收納的舊資料先解開併回來(解不開就丟例外,不會還原出缺一塊的資料)
        for (String k : NEED_ARRAYS) {
            if (cand.optJSONArray(k) == null) throw new Exception("這份備份檔的格式比較舊或不完整（缺少 " + k + "），請用網頁版還原");
        }
        if (cand.optJSONObject("payroll") == null) throw new Exception("這份備份檔的格式比較舊或不完整（缺少 payroll），請用網頁版還原");
        Migrate.Result mig = null;
        if (cand.optInt("schemaVersion", 0) == Migrate.FROM) {
            // 上一版的備份:細項的日期、時間、提醒照新規則轉成事項(核對沒過就整個拒絕,不會還原出壞資料)
            mig = Migrate.run(cand);
            cand.put("schemaVersion", Repo.SCHEMA);
        }
        if (cand.optInt("schemaVersion", 0) != Repo.SCHEMA) throw new Exception("這份備份是舊版格式，請用網頁版還原");
        for (String k : FILL_ARRAYS) if (cand.optJSONArray(k) == null) cand.put(k, new JSONArray());
        for (String k : FILL_OBJECTS) if (cand.optJSONObject(k) == null) cand.put(k, new JSONObject());
        Parsed p = new Parsed();
        p.data = cand;
        p.migrated = mig;
        p.exportedAt = obj != cand ? obj.optString("exportedAt", "") : "";
        p.email = obj != cand ? obj.optString("email", "") : "";
        if ("null".equals(p.email)) p.email = "";
        p.tasks = cand.optJSONArray("tasks").length();
        p.habits = cand.optJSONArray("habits").length();
        p.expenses = cand.optJSONArray("expenses").length();
        p.quickNotes = cand.optJSONArray("quickNotes").length();
        p.dayRecaps = cand.optJSONObject("dayRecaps").length();
        return p;
    }

    /** 網頁版 compactHabitLogs:簡單的打卡存成單一值,檔案比較小。 */
    static void compactLogs(JSONObject d) throws Exception {
        JSONObject logs = d.optJSONObject("habitLogs");
        if (logs == null) return;
        Iterator<String> hi = logs.keys();
        while (hi.hasNext()) {
            JSONObject days = logs.optJSONObject(hi.next());
            if (days == null) continue;
            Iterator<String> di = days.keys();
            java.util.List<String> keys = new java.util.ArrayList<>();
            while (di.hasNext()) keys.add(di.next());
            for (String day : keys) {
                Object e = days.opt(day);
                if (!(e instanceof JSONObject)) continue;
                JSONObject o = (JSONObject) e;
                if (o.length() == 2 && o.optBoolean("checked", false) && o.has("value")) {
                    Object v = o.opt("value");
                    boolean simple = Boolean.TRUE.equals(v) || v instanceof Number || (v instanceof String && !((String) v).isEmpty());
                    if (simple) days.put(day, v);
                }
            }
        }
    }

    /** 真的還原。成功回傳 null,失敗回傳原因(失敗時雲端和手機上的資料都沒有被動到)。要在背景執行緒呼叫。 */
    static String apply(Context c, Parsed p) {
        try {
            compactLogs(p.data);
        } catch (Exception e) {
            return "還原失敗：整理備份內容時出錯";
        }
        String err = Repo.replaceAll(c, p.data);
        if (err == null) {
            // 還原成功:事項提醒用還原後的事項整批重排;升級時被清掉的舊提醒從雲端刪掉
            try {
                if (p.migrated != null) for (String id : p.migrated.reminderDelete) Reminders.remove(c, id);
                Reminders.syncTasksFrom(c, p.data.optJSONArray("tasks"));
            } catch (Exception ignore) { }
        }
        return err;
    }
}
