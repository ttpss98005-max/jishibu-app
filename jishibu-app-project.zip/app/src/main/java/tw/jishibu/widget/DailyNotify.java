package tw.jishibu.widget;

import android.content.Context;

import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 早安 / 晚安推播(網頁版 syncDailyNotifications):把未來 7 天的通知寫進 reminders 排程,
 * 到時間由後端送到這個帳號已登記推播的裝置。文件 id 固定(種類+日期+使用者),重寫只會覆蓋、不會重複。
 * 設定存在資料的 notifySettings({morning:{on,time}, night:{on,time}}),跟網頁版共用。
 */
final class DailyNotify {
    private DailyNotify() {}

    static final String MORNING_TIME = "06:00", NIGHT_TIME = "20:00";
    private static final int HORIZON_DAYS = 7;
    private static final Map<String, String> SIG = new HashMap<>();

    static boolean on(String kind) {
        JSONObject d = Repo.data();
        JSONObject ns = d == null ? null : d.optJSONObject("notifySettings");
        JSONObject k = ns == null ? null : ns.optJSONObject(kind);
        return k != null && k.optBoolean("on", false);
    }

    static boolean greetOn() { return on("morning") || on("night"); }

    /** 「早晚安推播」開關:兩則一起開關。 */
    static void setGreet(Context c, boolean turnOn) {
        JSONObject d = Repo.data();
        if (d == null) return;
        JSONObject ns;
        try {
            JSONObject old = d.optJSONObject("notifySettings");
            ns = old == null ? new JSONObject() : new JSONObject(old.toString());
            ns.put("morning", new JSONObject().put("on", turnOn).put("time", MORNING_TIME));
            ns.put("night", new JSONObject().put("on", turnOn).put("time", NIGHT_TIME));
        } catch (Exception e) {
            return;
        }
        Repo.set(c, ns, "notifySettings");
        sync(c, true);
    }

    private static String docId(Context c, String kind, String day) {
        return "daily_" + kind + "_" + day + "_" + Store.key(c).replaceAll("[^A-Za-z0-9_-]", "_");
    }

    static long dueAt(String day, String time) {
        Calendar t = Model.parse(day);
        t.set(Calendar.HOUR_OF_DAY, Integer.parseInt(time.substring(0, 2)));
        t.set(Calendar.MINUTE, Integer.parseInt(time.substring(3, 5)));
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        return t.getTimeInMillis();
    }

    /** 早安 / 晚安的標題和內容。 */
    static String[] text(String kind, String day) {
        if ("morning".equals(kind)) {
            int n = 0;
            List<JSONObject> hs = Model.habits();
            for (JSONObject h : hs) if (Model.habitScheduledOn(h, day)) n++;
            return new String[]{"早安", n > 0 ? "新的一天，今天有 " + n + " 個習慣要打卡。" : "新的一天開始了，今天也慢慢來。"};
        }
        return new String[]{"晚安", "今天辛苦了，睡前花一分鐘回顧今天、選個心情吧。"};
    }

    /** 同步排程。cleanup 為真時,關掉的種類會把未來 7 天的排程清掉。 */
    static void sync(Context c, boolean cleanup) {
        if (!Store.linked(c) || Repo.data() == null) return;
        long now = System.currentTimeMillis();
        String[] kinds = {"morning", "night"};
        for (String kind : kinds) {
            boolean on = on(kind);
            String time = "morning".equals(kind) ? MORNING_TIME : NIGHT_TIME;
            for (int i = 0; i < HORIZON_DAYS; i++) {
                String day = Model.addDays(Model.today(), i);
                String id = docId(c, kind, day);
                if (!on) {
                    if (cleanup) { SIG.remove(id); Reminders.remove(c, id); }
                    continue;
                }
                long due = dueAt(day, time);
                if (due <= now + 120000L) continue;
                String[] tb = text(kind, day);
                String title = tb[0], body = tb[1];
                String sig = title + "|" + body + "|" + due;
                if (sig.equals(SIG.get(id))) continue;
                Reminders.put(c, id, title, body, due);
                SIG.put(id, sig);
            }
        }
    }
}
