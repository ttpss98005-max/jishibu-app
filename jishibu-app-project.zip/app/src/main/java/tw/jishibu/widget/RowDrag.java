package tw.jishibu.widget;

import android.content.Context;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

/**
 * 長按把手拖曳排序(習慣、清單共用,對應網頁版的 rowHandlePointerDown):
 * 按住把手 0.38 秒後進入拖曳,整張卡片跟著手指,碰到上下鄰居的中線就換位置;放開才回報順序。
 * table 裡每張卡片的 tag 是它的 id;卡片之間的間距是 gapDp。
 */
final class RowDrag implements View.OnTouchListener {
    interface Done { void on(List<String> orderedIds); }

    private final Context c;
    private final LinearLayout table;
    private final View row;
    private final float gapDp;
    private final float elevDp;
    private final Done done;
    private float startRawY, slotInitial;
    private boolean dragging;
    private Runnable starter;

    RowDrag(Context c, LinearLayout table, View row, float gapDp, float elevDp, Done done) {
        this.c = c;
        this.table = table;
        this.row = row;
        this.gapDp = gapDp;
        this.elevDp = elevDp;
        this.done = done;
    }

    private float topOf(int index) {
        float y = 0;
        for (int i = 0; i < index; i++) y += table.getChildAt(i).getHeight() + Ui.dp(c, gapDp);
        return y;
    }

    @Override public boolean onTouch(final View v, MotionEvent e) {
        switch (e.getAction()) {
            case MotionEvent.ACTION_DOWN:
                startRawY = e.getRawY();
                dragging = false;
                starter = new Runnable() {
                    @Override public void run() {
                        dragging = true;
                        if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
                        v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                        slotInitial = topOf(table.indexOfChild(row));
                        row.setElevation(Ui.dp(c, 8));
                        row.setScaleX(1.02f);
                        row.setScaleY(1.02f);
                        row.setAlpha(0.95f);
                    }
                };
                v.postDelayed(starter, 380);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (!dragging) {
                    if (Math.abs(e.getRawY() - startRawY) > Ui.dp(c, 10)) v.removeCallbacks(starter);
                    return true;
                }
                move(e.getRawY());
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                v.removeCallbacks(starter);
                if (dragging) { dragging = false; finish(); }
                return true;
            default:
                return true;
        }
    }

    private void move(float rawY) {
        int n = table.getChildCount();
        int idx = table.indexOfChild(row);
        float rowH = row.getHeight();
        for (int guard = 0; guard < n; guard++) {
            float slot = topOf(idx);
            float trans = (rawY - startRawY) - (slot - slotInitial);
            float center = slot + trans + rowH / 2f;
            boolean swapped = false;
            if (idx < n - 1) {
                View next = table.getChildAt(idx + 1);
                float nextCenter = topOf(idx + 1) + next.getHeight() / 2f;
                if (center > nextCenter) {
                    table.removeView(row);
                    table.addView(row, idx + 1);
                    idx++;
                    swapped = true;
                }
            }
            if (!swapped && idx > 0) {
                View prev = table.getChildAt(idx - 1);
                float prevCenter = topOf(idx - 1) + prev.getHeight() / 2f;
                if (center < prevCenter) {
                    table.removeView(row);
                    table.addView(row, idx - 1);
                    idx--;
                    swapped = true;
                }
            }
            if (!swapped) break;
        }
        float slot = topOf(idx);
        row.setTranslationY((rawY - startRawY) - (slot - slotInitial));
    }

    private void finish() {
        row.setTranslationY(0);
        row.setScaleX(1f);
        row.setScaleY(1f);
        row.setAlpha(1f);
        Ui.soft(row, elevDp);
        List<String> ids = new ArrayList<>();
        for (int i = 0; i < table.getChildCount(); i++) {
            Object tag = table.getChildAt(i).getTag();
            if (tag instanceof String) ids.add((String) tag);      // 清單裡的「今天」分隔線沒有 id,不算
        }
        if (done != null) done.on(ids);
    }
}
