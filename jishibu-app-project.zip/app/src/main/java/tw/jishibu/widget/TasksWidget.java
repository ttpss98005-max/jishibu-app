package tw.jishibu.widget;

/** 桌面小工具:Tasks(內容和更新都在 Widgets)。 */
public class TasksWidget extends Widgets.Base {
    @Override int kind() { return Widgets.TASKS; }
}
