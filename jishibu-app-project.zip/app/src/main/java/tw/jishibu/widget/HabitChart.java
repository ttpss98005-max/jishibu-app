package tw.jishibu.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * 習慣「歷史趨勢」折線圖(網頁版 buildHabitLineChart):560x150 的畫布等比例縮放到寬度、高 150dp 內置中;
 * 平滑曲線(Catmull-Rom 轉貝茲)、圓點、左上/左下數值標籤、底部起訖日期。進場動畫:線 1.1 秒畫出來,圓點依序淡入。
 */
final class HabitChart extends View {
    private static final float W = 560f, H = 150f, PAD_L = 42f, PAD_R = 12f, PAD_T = 14f, PAD_B = 22f;

    private final float[] xs, ys;
    private final float dotR;
    private final String maxLabel, minLabel, firstLabel, lastLabel;
    private final Path full = new Path();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float elapsed = 0f;   // 秒:0 ~ 1.4
    private final int heightPx;
    private boolean started = false;

    /** values:每一天的數值(沒打卡 = 0);labels 為 {最大值文字, 最小值文字, 起始日, 結束日}。 */
    HabitChart(Context c, float[] values, String[] labels) {
        super(c);
        heightPx = Ui.dp(c, 150);
        int n = values.length;
        float min = Float.MAX_VALUE, max = -Float.MAX_VALUE;
        for (float v : values) { min = Math.min(min, v); max = Math.max(max, v); }
        if (min == max) { min -= 1; max += 1; }
        float innerW = W - PAD_L - PAD_R, innerH = H - PAD_T - PAD_B;
        float stepX = n > 1 ? innerW / (n - 1) : 0f;
        xs = new float[n];
        ys = new float[n];
        for (int i = 0; i < n; i++) {
            xs[i] = PAD_L + i * stepX;
            ys[i] = PAD_T + innerH * (1f - (values[i] - min) / (max - min));
        }
        dotR = n > 60 ? 0f : n > 30 ? 1.8f : 3.2f;
        maxLabel = labels[0];
        minLabel = labels[1];
        firstLabel = labels[2];
        lastLabel = labels[3];
        buildPath();
    }

    private void buildPath() {
        int n = xs.length;
        if (n < 2) return;
        full.moveTo(xs[0], ys[0]);
        if (n == 2) { full.lineTo(xs[1], ys[1]); return; }
        for (int i = 0; i < n - 1; i++) {
            int i0 = i > 0 ? i - 1 : i, i3 = i + 2 < n ? i + 2 : i + 1;
            float c1x = xs[i] + (xs[i + 1] - xs[i0]) / 6f, c1y = ys[i] + (ys[i + 1] - ys[i0]) / 6f;
            float c2x = xs[i + 1] - (xs[i3] - xs[i]) / 6f, c2y = ys[i + 1] - (ys[i3] - ys[i]) / 6f;
            full.cubicTo(c1x, c1y, c2x, c2y, xs[i + 1], ys[i + 1]);
        }
    }

    @Override protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), heightPx);
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (started) return;
        started = true;
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1.4f);
        a.setDuration(1400);
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator va) {
                elapsed = (Float) va.getAnimatedValue();
                invalidate();
            }
        });
        a.start();
    }

    @Override protected void onDraw(Canvas c) {
        float vw = getWidth(), vh = getHeight();
        if (vw <= 0) return;
        float s = Math.min(vw / W, vh / H);
        c.save();
        c.translate((vw - W * s) / 2f, (vh - H * s) / 2f);
        c.scale(s, s);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1f);
        paint.setColor(Ui.BORDER);
        c.drawLine(PAD_L, PAD_T, PAD_L, H - PAD_B, paint);
        c.drawLine(PAD_L, H - PAD_B, W - PAD_R, H - PAD_B, paint);

        // 線:1.1 秒內由左畫到右(ease-out)
        float t = Math.min(1f, elapsed / 1.1f);
        float prog = 1f - (1f - t) * (1f - t);
        if (xs.length >= 2 && prog > 0f) {
            PathMeasure pm = new PathMeasure(full, false);
            Path part = new Path();
            pm.getSegment(0f, pm.getLength() * prog, part, true);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2f);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeJoin(Paint.Join.ROUND);
            paint.setColor(Ui.ACCENT);
            c.drawPath(part, paint);
        }
        // 圓點:依序淡入(每顆 0.3 秒)
        if (dotR > 0f) {
            int n = xs.length;
            paint.setStyle(Paint.Style.FILL);
            for (int i = 0; i < n; i++) {
                float delay = ((float) i / Math.max(n - 1, 1)) * 1.1f;
                float a = Math.max(0f, Math.min(1f, (elapsed - delay) / 0.3f));
                if (a <= 0f) continue;
                paint.setColor(Ui.ACCENT);
                paint.setAlpha((int) (255 * a));
                c.drawCircle(xs[i], ys[i], dotR, paint);
            }
            paint.setAlpha(255);
        }
        // 文字
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Ui.SOFT);
        paint.setTextSize(9f);
        paint.setTextAlign(Paint.Align.LEFT);
        c.drawText(maxLabel, 2f, PAD_T + 4f, paint);
        c.drawText(minLabel, 2f, H - PAD_B, paint);
        c.drawText(firstLabel, PAD_L, H - 4f, paint);
        c.drawText(lastLabel, W - PAD_R - 26f, H - 4f, paint);
        c.restore();
    }
}
