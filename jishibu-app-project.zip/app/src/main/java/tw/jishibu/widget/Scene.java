package tw.jishibu.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 早安(極簡日出)/晚安(海上新月)的全螢幕動畫。逐行照網頁版 SceneAnim 移植:
 * 畫面單位用 dp(跟網頁的 px 一樣大),顏色全部由目前配色的強調色推算。
 */
final class Scene extends View {
    // ---------- 顏色 ----------
    static final class C {
        int accent, deep, soft, sky, acc2, n1, n2, n3, n4, n5, moon, star;
    }

    private static double clamp(double x, double a, double b) { return Math.max(a, Math.min(b, x)); }
    private static double lerp(double a, double b, double t) { return a + (b - a) * t; }
    private static double inv(double a, double b, double t) { return clamp((t - a) / (b - a), 0, 1); }
    private static double smooth(double a, double b, double x) { double t = inv(a, b, x); return t * t * (3 - 2 * t); }
    private static double outCubic(double t) { return 1 - Math.pow(1 - t, 3); }
    private static double spring(double t, double f, double z) {
        if (t <= 0) return 0;
        double w = Math.PI * 2 * f, wd = w * Math.sqrt(1 - z * z);
        return 1 - Math.exp(-z * w * t) * (Math.cos(wd * t) + (z * w / wd) * Math.sin(wd * t));
    }

    static int rgbHex(double r, double g, double b) {
        return Color.rgb((int) clamp(Math.round(r), 0, 255), (int) clamp(Math.round(g), 0, 255), (int) clamp(Math.round(b), 0, 255));
    }

    static double[] rgbToHsl(int r8, int g8, int b8) {
        double r = r8 / 255.0, g = g8 / 255.0, b = b8 / 255.0;
        double mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
        double h = 0, s = 0, l = (mx + mn) / 2, d = mx - mn;
        if (d != 0) {
            s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
            if (mx == r) h = (g - b) / d + (g < b ? 6 : 0);
            else if (mx == g) h = (b - r) / d + 2;
            else h = (r - g) / d + 4;
            h *= 60;
        }
        return new double[]{h, s, l};
    }

    static int hslToColor(double h, double s, double l) {
        h = ((h % 360) + 360) % 360;
        double c = (1 - Math.abs(2 * l - 1)) * s, x = c * (1 - Math.abs((h / 60) % 2 - 1)), m = l - c / 2;
        double r = 0, g = 0, b = 0;
        if (h < 60) { r = c; g = x; }
        else if (h < 120) { r = x; g = c; }
        else if (h < 180) { g = c; b = x; }
        else if (h < 240) { g = x; b = c; }
        else if (h < 300) { r = x; b = c; }
        else { r = c; b = x; }
        return rgbHex((r + m) * 255, (g + m) * 255, (b + m) * 255);
    }

    static int mix(int a, int b, double t) {
        return rgbHex(lerp(Color.red(a), Color.red(b), t), lerp(Color.green(a), Color.green(b), t), lerp(Color.blue(a), Color.blue(b), t));
    }

    static C derive(int accent) {
        double[] hsl = rgbToHsl(Color.red(accent), Color.green(accent), Color.blue(accent));
        double h = hsl[0], l = hsl[2];
        double s = clamp(hsl[1], .3, .82), sn = s * .62;
        double hn = h + ((((250 - h) % 360) + 540) % 360 - 180) * .38;
        int sky = hslToColor(h, s * .5, .975);
        C c = new C();
        c.accent = accent;
        c.deep = hslToColor(h, s, clamp(l * .6, .16, .32));
        c.soft = hslToColor(h, s * .7, .84);
        c.sky = sky;
        c.acc2 = mix(accent, sky, .5);
        c.n1 = hslToColor(hn, sn, .19);
        c.n2 = hslToColor(hn, sn, .235);
        c.n3 = hslToColor(hn, sn * .9, .31);
        c.n4 = hslToColor(hn, sn, .13);
        c.n5 = hslToColor(hn, sn, .085);
        c.moon = hslToColor(hn, s * .45, .94);
        c.star = hslToColor(hn, s * .55, .88);
        return c;
    }

    // ---------- 狀態 ----------
    private final boolean morning;
    private final C col;
    private final String l1, l2;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private float density = 1f;
    private long t0 = 0;
    private ValueAnimator ticker;
    private double lastW = -1, lastH = -1;

    // morning layout
    private static final class Mt { double x, ay, r, d; int o; String col; }
    private List<Mt> mts = new ArrayList<>();
    private double U, R, y0, y1, hillsTop;
    // night layout
    private static final class Star { double x, y, s, ph, fr; }
    private static final class Isl { double x, ay, r, baseY; boolean dark; }
    private List<Star> stars = new ArrayList<>();
    private List<Isl> islands = new ArrayList<>();
    private double hz, dy;
    // card
    private double cardY, cardSpace, cardAt;

    Scene(Context c, boolean morning, String l1, String l2) {
        super(c);
        this.morning = morning;
        this.l1 = l1;
        this.l2 = l2;
        this.col = derive(Ui.ACCENT);
        this.cardAt = morning ? 3.4 : 4.0;
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (ticker != null) return;
        t0 = System.nanoTime();
        ticker = ValueAnimator.ofFloat(0f, 1f);
        ticker.setDuration(1000);
        ticker.setRepeatCount(ValueAnimator.INFINITE);
        ticker.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) { invalidate(); }
        });
        ticker.start();
    }

    @Override protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stop();
    }

    void stop() {
        if (ticker != null) { ticker.cancel(); ticker = null; }
    }

    // ---------- 排版(畫面大小改變時重算) ----------
    private void build(double w, double h) {
        if (morning) buildMorning(w, h); else buildNight(w, h);
        lastW = w; lastH = h;
    }

    private void buildMorning(double w, double h) {
        U = Math.min(w, h * .56);
        R = .18 * U;
        boolean phone = w <= U * 1.02;
        double Ws = phone ? w : U;
        double[][] base = {{.14, .60, .15, 0, .35, 0}, {.82, .64, .15, 1, .5, 1}, {.46, .76, .13, 2, .65, 2}};
        String[] names = {"acc2", "accent", "deep"};
        mts = new ArrayList<>();
        for (int rep = phone ? 0 : -8; rep <= (phone ? 0 : 8); rep++) {
            for (double[] q : base) {
                double x = w / 2 + (q[0] - .5) * Ws + rep * Ws, ay = q[1] * h, hb = h * 1.6 - ay;
                if (x + hb < 0 || x - hb > w) continue;
                Mt m = new Mt();
                m.x = x; m.ay = ay; m.r = q[2] * U; m.col = names[(int) q[3]]; m.d = q[4] + Math.abs(rep) * .1; m.o = (int) q[5];
                mts.add(m);
            }
        }
        Collections.sort(mts, new Comparator<Mt>() {
            @Override public int compare(Mt a, Mt b) { return a.o - b.o; }
        });
        y0 = 0;
        for (int i = 0; i <= 60; i++) {
            double dx = -R + 2 * R * i / 60;
            y0 = Math.max(y0, ridgeOf(w / 2 + dx, h * 3) + Math.sqrt(Math.max(0, R * R - dx * dx)));
        }
        y0 += 6;
        y1 = h * .3;
        hillsTop = Double.MAX_VALUE;
        for (Mt q : mts) hillsTop = Math.min(hillsTop, q.ay + .4142 * q.r);
        cardY = ((y1 + R) + hillsTop) / 2;
        cardSpace = hillsTop - (y1 + R);
    }

    private double ridgeOf(double x, double floor) {
        double y = floor;
        for (Mt q : mts) {
            double dx = Math.abs(x - q.x);
            double top = dx <= .7071 * q.r ? q.ay + 1.4142 * q.r - Math.sqrt(q.r * q.r - dx * dx) : q.ay + dx;
            if (top < y) y = top;
        }
        return y;
    }

    private static final class Rng {
        int a;
        Rng(int seed) { a = seed; }
        double next() {
            a = a + 0x6D2B79F5;
            int t = (a ^ (a >>> 15)) * (1 | a);
            t = (t + ((t ^ (t >>> 7)) * (61 | t))) ^ t;
            return ((t ^ (t >>> 14)) & 0xFFFFFFFFL) / 4294967296.0;
        }
    }

    private void buildNight(double w, double h) {
        U = Math.min(w, h * .56);
        hz = h * .56;
        R = .15 * U;
        dy = h * .028;
        Rng rs = new Rng(5);
        stars = new ArrayList<>();
        for (int k = 0; k < 11; k++) {
            double x, y;
            int n = 0;
            do {
                x = w * (.06 + .88 * rs.next());
                y = hz * (.05 + .7 * rs.next());
                n++;
            } while (n < 40 && Math.hypot(x - w / 2, y - h * .26) < R * 3.1);
            Star s = new Star();
            s.x = x; s.y = y;
            s.s = U * (.012 + .014 * rs.next());
            s.ph = rs.next() * 6.28;
            s.fr = 1.2 + rs.next() * 1.4;
            stars.add(s);
        }
        islands = new ArrayList<>();
        islands.add(isl(w * .10 + U * .19, U * .12, false));
        islands.add(isl(w * .10, U * .22, true));
        islands.add(isl(w * .90 - U * .16, U * .10, false));
        islands.add(isl(w * .90, U * .19, true));
        cardY = (hz + dy * 6 + h) / 2;
        cardSpace = h - (hz + dy * 6);
    }

    private Isl isl(double x, double th, boolean dark) {
        Isl i = new Isl();
        i.x = x; i.ay = hz - th; i.r = th * .3; i.baseY = hz + th + 12; i.dark = dark;
        return i;
    }

    // ---------- 繪圖小工具 ----------
    private void fill(int color, double alpha) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        p.setAlpha((int) Math.round(255 * clamp(alpha, 0, 1)));
    }

    private void disc(Canvas c, double x, double y, double r, int color, double a) {
        if (r <= 0) return;
        fill(color, a);
        c.drawCircle((float) x, (float) y, (float) r, p);
    }

    private void capsule(Canvas c, double x, double y, double w, double h, int color, double a) {
        if (w <= 0 || h <= 0) return;
        fill(color, a);
        float r = (float) Math.min(h / 2, w / 2);
        rf.set((float) x, (float) y, (float) (x + w), (float) (y + h));
        c.drawRoundRect(rf, r, r, p);
    }

    private void crescent(Canvas c, double x, double y, double R, int color) {
        c.save();
        path.reset();
        path.addCircle((float) x, (float) y, (float) R, Path.Direction.CW);
        c.clipPath(path);
        path.reset();
        rf.set((float) (x - R * 2), (float) (y - R * 2), (float) (x + R * 2), (float) (y + R * 2));
        path.addRect(rf, Path.Direction.CW);
        path.addCircle((float) (x + R * .5), (float) (y - R * .14), (float) (R * .86), Path.Direction.CW);
        path.setFillType(Path.FillType.EVEN_ODD);
        fill(color, 1);
        c.drawPath(path, p);
        path.setFillType(Path.FillType.WINDING);
        c.restore();
    }

    /** 大圓角三角形(尖角在 ax,ay,頂端圓角半徑 r,底邊在 baseY,整個往下移 oy)。 */
    private void mountain(Canvas c, double ax, double ay, double r, double baseY, int color, double oy) {
        double hb = baseY - ay;
        double[][] P = {{ax, ay + oy}, {ax + hb, baseY + oy}, {ax - hb, baseY + oy}};
        path.reset();
        path.moveTo((float) ((P[2][0] + P[0][0]) / 2), (float) ((P[2][1] + P[0][1]) / 2));
        for (int i = 0; i < 3; i++) {
            double[] A = P[i], B = P[(i + 1) % 3], Pv = P[(i + 2) % 3];
            double ux1 = Pv[0] - A[0], uy1 = Pv[1] - A[1], l1 = Math.hypot(ux1, uy1);
            double ux2 = B[0] - A[0], uy2 = B[1] - A[1], l2 = Math.hypot(ux2, uy2);
            ux1 /= l1; uy1 /= l1; ux2 /= l2; uy2 /= l2;
            double cos = clamp(ux1 * ux2 + uy1 * uy2, -0.999999, 0.999999);
            double tanHalf = Math.sqrt((1 - cos) / (1 + cos));
            double d = r / tanHalf;
            double th = Math.acos(cos), phi = Math.PI - th;
            double k = 4.0 / 3.0 * Math.tan(phi / 4) * r;
            double t1x = A[0] + ux1 * d, t1y = A[1] + uy1 * d, t2x = A[0] + ux2 * d, t2y = A[1] + uy2 * d;
            path.lineTo((float) t1x, (float) t1y);
            path.cubicTo((float) (t1x - ux1 * k), (float) (t1y - uy1 * k), (float) (t2x - ux2 * k), (float) (t2y - uy2 * k), (float) t2x, (float) t2y);
        }
        path.close();
        fill(color, 1);
        c.drawPath(path, p);
    }

    private void sparkle(Canvas c, double x, double y, double s) {
        if (s <= 0) return;
        path.reset();
        path.moveTo((float) x, (float) (y - s));
        path.quadTo((float) x, (float) y, (float) (x + s), (float) y);
        path.quadTo((float) x, (float) y, (float) x, (float) (y + s));
        path.quadTo((float) x, (float) y, (float) (x - s), (float) y);
        path.quadTo((float) x, (float) y, (float) x, (float) (y - s));
        path.close();
        c.drawPath(path, p);
    }

    private int named(String n) {
        if ("acc2".equals(n)) return col.acc2;
        if ("deep".equals(n)) return col.deep;
        return col.accent;
    }

    // ---------- 繪製 ----------
    @Override protected void onDraw(Canvas c) {
        density = getContext().getResources().getDisplayMetrics().density;
        double w = getWidth() / density, h = getHeight() / density;
        if (w <= 0 || h <= 0) return;
        if (w != lastW || h != lastH) build(w, h);
        double t = (System.nanoTime() - t0) / 1e9;
        c.save();
        c.scale(density, density);
        if (morning) drawMorning(c, w, h, t); else drawNight(c, w, h, t);
        drawCard(c, w, h, t);
        c.restore();
    }

    private void drawMorning(Canvas c, double w, double h, double t) {
        fill(mix(col.n1, col.sky, smooth(.1, 1.4, t)), 1);
        c.drawRect(0, 0, (float) w, (float) h, p);
        for (int k = 0; k < 3; k++) {
            double cw = U * (.26 - .03 * k), span = w + cw * 2;
            double x = (((k * .41 * w + t * (7 + k * 4)) % span) + span) % span - cw;
            capsule(c, x, h * (.12 + .1 * k + .05 * (k % 2)), cw, h * .045, col.soft, .75 * smooth(2.4, 3.4, t));
        }
        if (t >= 1.5) {
            double pr = outCubic(inv(1.5, 4.3, t)), sy = lerp(y0, y1, pr);
            disc(c, w / 2, sy, R * 2.6 * pr, col.accent, .07);
            disc(c, w / 2, sy, R * 1.8 * pr, col.accent, .1);
            disc(c, w / 2, sy, R, col.accent, 1);
            if (t > 4.3) {
                double u = ((t - 4.3) % 3.4) / 3.4;
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(2f);
                p.setColor(col.accent);
                p.setAlpha((int) Math.round(255 * .35 * (1 - u)));
                c.drawCircle((float) (w / 2), (float) sy, (float) (R * (1.1 + .6 * u)), p);
                p.setStyle(Paint.Style.FILL);
            }
        }
        for (Mt q : mts) {
            double o = (1 - outCubic(inv(q.d, q.d + 1.1, t))) * h * .6;
            mountain(c, q.x, q.ay, q.r, h * 1.6, named(q.col), o);
        }
    }

    private void drawNight(Canvas c, double w, double h, double t) {
        int N = 10;
        double bh = hz / N;
        fill(col.n1, 1);
        c.drawRect(0, 0, (float) w, (float) h, p);
        for (int k = 0; k < N; k++) {
            double pp = (double) k / (N - 1), a = smooth(.2 + k * .04, 2.8 + k * .04, t);
            int dusk = mix(col.n1, mix(col.n3, col.accent, .45), Math.pow(pp, 1.7));
            int night = mix(col.n1, col.n3, Math.pow(pp, 1.4) * .9);
            fill(mix(dusk, night, a), 1);
            c.drawRect(0, (float) (k * bh), (float) w, (float) (k * bh + bh + 1), p);
        }
        for (Star s : stars) {
            double ap = 3 + s.ph * .3;
            if (t < ap) continue;
            double u = spring(t - ap, 2.5, .5), tw = .8 + .2 * Math.sin(t * s.fr + s.ph);
            fill(col.star, .5 + .5 * tw);
            sparkle(c, s.x, s.y, s.s * u * tw * 1.8);
        }
        double pm = outCubic(inv(1, 4, t)), my = lerp(hz + R * 1.7, h * .26, pm);
        disc(c, w / 2, my, R * 2.4, col.moon, .05 * pm);
        disc(c, w / 2, my, R * 1.6, col.moon, .08 * pm);
        crescent(c, w / 2, my, R, col.moon);
        double o = (1 - outCubic(inv(.3, 1.5, t))) * h * .2;
        int mid = mix(col.n4, col.n5, .45);
        for (Isl is : islands) mountain(c, is.x, is.ay, is.r, is.baseY, is.dark ? col.n5 : mid, o);
        fill(col.n4, 1);
        c.drawRect(0, (float) hz, (float) w, (float) h, p);
        for (int k = 0; k < 6; k++) {
            double ap = 3.4 + k * .12;
            if (t < ap) continue;
            double u = spring(t - ap, 2.2, .55);
            double bw = 2 * R * (1.1 - .13 * k) * (1 + .14 * Math.sin(t * 1.7 + k * .9)) * u;
            double ox = Math.sin(t * 1.1 + k * 1.3) * R * .12 - R * .12;
            capsule(c, w / 2 - bw / 2 + ox, hz + (k + 1) * dy, bw, h * .013, col.moon, (.9 - .12 * k) * Math.min(1, u * 1.4));
        }
    }

    /** 中間那張字卡:時間到了(cardAt)才淡入,同時從下面 6% 的位置浮上來。 */
    private void drawCard(Canvas c, double w, double h, double t) {
        double e = inv(cardAt, cardAt + .7, t);
        if (e <= 0) return;
        double a = e * e * (3 - 2 * e);
        double scale = cardSpace > 0 ? clamp(cardSpace / 128, .68, 1) : 1;
        double cw = Math.min(w * .76, 300), l1h = 27 * 1.35, l2h = 18 * 1.5 + 2;
        if (!morning) { l1h = 21 * 1.35; l2h = 21 * 1.5 + 2; }
        double ch = 40 + l1h + l2h;
        double cy = cardY + ch * .06 * (1 - a);
        c.save();
        c.translate((float) (w / 2), (float) cy);
        c.scale((float) scale, (float) scale);
        float hw = (float) (cw / 2), hh = (float) (ch / 2);
        if (morning) {
            for (int i = 3; i >= 1; i--) {   // 淡淡的陰影
                fill(0xFF1E1E1E, a * .05);
                rf.set(-hw - i * 2, -hh - i + 3, hw + i * 2, hh + i * 3 + 1);
                c.drawRoundRect(rf, 26 + i * 2, 26 + i * 2, p);
            }
            fill(0xFFFFFFFF, a);
        } else {
            fill(col.n3, a);
            rf.set(-hw, -hh, hw, hh);
            c.drawRoundRect(rf, 26, 26, p);
            fill(col.n5, a);
            rf.set(-hw + 1, -hh + 1, hw - 1, hh - 1);
            c.drawRoundRect(rf, 25, 25, p);
        }
        if (morning) {
            rf.set(-hw, -hh, hw, hh);
            c.drawRoundRect(rf, 26, 26, p);
        }
        p.setTextAlign(Paint.Align.CENTER);
        p.setFakeBoldText(true);
        double top = -hh + 20;
        float s1 = morning ? 27f : 21f, s2 = morning ? 18f : 21f;
        p.setTextSize(s1 * 1f);
        fill(morning ? 0xFF1A1A1A : col.moon, a);
        c.drawText(l1, 0f, (float) (top + baseline(s1, l1h)), p);
        p.setTextSize(s2);
        fill(morning ? col.accent : col.moon, a);
        c.drawText(l2, 0f, (float) (top + l1h + 2 + baseline(s2, s2 * 1.5)), p);
        p.setFakeBoldText(false);
        p.setTextAlign(Paint.Align.LEFT);
        c.restore();
    }

    /** 文字在一行高度 lineH 裡的基線位置(粗略置中)。 */
    private double baseline(float size, double lineH) {
        // 文字大小 size 的上緣約 -0.93*size、下緣約 +0.25*size
        double ascent = size * .93, descent = size * .25;
        return (lineH - (ascent + descent)) / 2 + ascent;
    }
}
