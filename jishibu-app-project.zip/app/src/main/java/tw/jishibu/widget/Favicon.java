package tw.jishibu.widget;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/** 書籤的網站小圖示(跟網頁版一樣用 Google 的 favicon 服務),載入失敗就不顯示。 */
final class Favicon {
    private Favicon() {}

    private static final Map<String, Bitmap> CACHE = new HashMap<>();

    static void load(final MainActivity a, final String domain, final ImageView into) {
        if (domain == null || domain.isEmpty()) return;
        Bitmap hit;
        synchronized (CACHE) { hit = CACHE.get(domain); }
        if (hit != null) { into.setImageBitmap(hit); return; }
        new Thread(new Runnable() {
            @Override public void run() {
                Bitmap bmp = null;
                try {
                    HttpURLConnection h = (HttpURLConnection) new URL("https://www.google.com/s2/favicons?domain=" + domain + "&sz=64").openConnection();
                    h.setConnectTimeout(6000);
                    h.setReadTimeout(8000);
                    InputStream in = h.getInputStream();
                    bmp = BitmapFactory.decodeStream(in);
                    in.close();
                    h.disconnect();
                } catch (Exception ignore) { }
                if (bmp == null) return;
                final Bitmap fin = bmp;
                synchronized (CACHE) { CACHE.put(domain, fin); }
                a.runOnUiThread(new Runnable() {
                    @Override public void run() { into.setImageBitmap(fin); }
                });
            }
        }).start();
    }
}
