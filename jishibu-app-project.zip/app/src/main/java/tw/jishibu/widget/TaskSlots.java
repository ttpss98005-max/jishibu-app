package tw.jishibu.widget;

import android.content.Context;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * 事項提醒(合併版,跟網頁版 buildTaskSlotContent 一樣):提醒時間相同的事項合成一則通知。
 * 只有一件、沒有延誤 → 「提醒：標題」+ 日期時間;其他 → 「提醒：N 項事項」,內容列出到期的和延誤的(延誤 = 已過時間、還沒完成、有開提醒)。
 * 最多列 8 項,其餘寫「還有 N 項…」。雲端提醒和手機本機鬧鐘共用這一份,內容一定相同。
 */
final class TaskSlots {
    private TaskSlots() {}

    static final int MAX_LINES = 8;

    /** 要提醒的事項:有日期、提醒開著、還沒完成。 */
    static List<JSONObject> remindList(List<JSONObject> tasks) {
        List<JSONObject> out = new ArrayList<>();
        if (tasks == null) return out;
        for (JSONObject t : tasks) {
            if (t == null || !t.optBoolean("reminder", false)) continue;
            if ("done".equals(Model.s(t, "status", ""))) continue;
            if (Model.taskDueMs(t) <= 0L) continue;
            out.add(t);
        }
        return out;
    }

    /** 到了 slotMs 這個時間,這件事算不算延誤:有時間的過了那個時間;只有日期的,過了那一天。 */
    static boolean lateAt(JSONObject t, long slotMs) {
        if (Model.isHm(Model.s(t, "dueTime", ""))) return Model.taskDueMs(t) < slotMs;
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(slotMs);
        return Model.s(t, "dueDate", "").compareTo(Model.ymd(c)) < 0;
    }

    /** 有哪些提醒時間(由早到晚、不重複)。 */
    static List<Long> times(List<JSONObject> list) {
        Set<Long> s = new LinkedHashSet<>();
        for (JSONObject t : list) s.add(Model.taskDueMs(t));
        List<Long> out = new ArrayList<>(s);
        Collections.sort(out);
        return out;
    }

    /** {標題, 內容};那個時間沒有事項回 null。 */
    static String[] content(long slotMs, List<JSONObject> list) {
        List<JSONObject> due = new ArrayList<>(), late = new ArrayList<>();
        for (JSONObject t : list) {
            long ms = Model.taskDueMs(t);
            if (ms == slotMs) due.add(t);
            else if (ms < slotMs && lateAt(t, slotMs)) late.add(t);
        }
        if (due.isEmpty()) return null;
        if (due.size() == 1 && late.isEmpty()) return new String[]{"提醒：" + Model.s(due.get(0), "title"), Model.fmtTaskWhen(due.get(0))};
        Collections.sort(late, new java.util.Comparator<JSONObject>() {
            @Override public int compare(JSONObject a, JSONObject b) { return Long.compare(Model.taskDueMs(a), Model.taskDueMs(b)); }
        });
        List<JSONObject> items = new ArrayList<>(due);
        items.addAll(late);
        StringBuilder sb = new StringBuilder(Model.fmtTaskWhen(due.get(0)));
        boolean lateHead = false;
        int shown = Math.min(items.size(), MAX_LINES);
        for (int i = 0; i < shown; i++) {
            JSONObject t = items.get(i);
            boolean isLate = i >= due.size();
            if (isLate && !lateHead) { sb.append("\n延誤"); lateHead = true; }
            sb.append("\n• ").append(Model.s(t, "title"));
            if (isLate) {
                String hm = Model.s(t, "dueTime", "");
                sb.append("（").append(Model.fmtDate(Model.s(t, "dueDate", ""))).append(Model.isHm(hm) ? " " + hm : "").append("）");
            }
        }
        if (items.size() > shown) sb.append("\n還有 ").append(items.size() - shown).append(" 項…");
        return new String[]{"提醒：" + items.size() + " 項事項", sb.toString()};
    }

    /** 雲端提醒文件的 id:同一個時間、同一個帳號只會有一份。 */
    static String docId(Context c, long slotMs) {
        return "slot_" + slotMs + "_" + Store.key(c).replaceAll("[^A-Za-z0-9_-]", "_");
    }
}
