package tw.jishibu.widget;

import android.content.Context;

/** 小工具用:同步一次(要在背景執行緒呼叫)。 */
final class Sync {
    private Sync() {}

    static boolean refresh(Context c) {
        if (!Store.linked(c)) return false;
        return Repo.syncNow(c);
    }
}
