package tw.jishibu.widget;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Random;

/**
 * 第一次用這個 Google 帳號登入、雲端還沒有記事簿時,建立一本全新的(內容跟網頁版 defaultData() 一樣)。
 * 網頁版也是這樣:新帳號登入就是一本空的記事簿,第一次存檔時才寫進雲端。
 */
final class NewAccount {
    private NewAccount() {}

    private static String uid() {
        return Long.toString(Math.abs(new Random().nextLong()), 36).substring(0, 8) + Long.toString(System.currentTimeMillis(), 36);
    }

    private static JSONObject cat(String id, String name, String color) throws Exception {
        return new JSONObject().put("id", id).put("name", name).put("color", color).put("deletable", false).put("paletteId", JSONObject.NULL);
    }

    private static JSONObject named(String id, String name) throws Exception {
        return new JSONObject().put("id", id).put("name", name).put("icon", id);
    }

    static String defaultJson() throws Exception {
        JSONObject d = new JSONObject();
        d.put("categories", new JSONArray().put(cat("work", "工作", "#2E4057")).put(cat("personal", "私人", "#7A5C82")));
        d.put("tasks", new JSONArray());
        d.put("bookmarks", new JSONArray()
                .put(new JSONObject().put("id", uid()).put("title", "Google 日曆").put("url", "https://calendar.google.com"))
                .put(new JSONObject().put("id", uid()).put("title", "Gmail").put("url", "https://mail.google.com")));
        d.put("habits", new JSONArray());
        d.put("habitLogs", new JSONObject());
        d.put("quickNotes", new JSONArray());
        d.put("dayRecaps", new JSONObject());
        d.put("lastAutoRecapDate", JSONObject.NULL);
        d.put("lastCatId", "overview");
        d.put("nightRecapDisabled", false);
        d.put("specialCelebrateDisabled", false);
        d.put("globalPaletteId", "p01");
        d.put("customPalettes", new JSONArray());
        d.put("expenses", new JSONArray());
        d.put("accounts", new JSONArray()
                .put(new JSONObject().put("id", "acc_bank").put("name", "銀行").put("type", "bank").put("opening", 0))
                .put(new JSONObject().put("id", "acc_cash").put("name", "現金").put("type", "cash").put("opening", 0)));
        d.put("expenseCategories", new JSONArray()
                .put(named("food", "餐飲")).put(named("transport", "交通")).put(named("shopping", "購物"))
                .put(named("entertainment", "娛樂")).put(named("home", "居家")).put(named("medical", "醫療")).put(named("other", "其他")));
        d.put("incomeCategories", new JSONArray()
                .put(named("salary", "薪資")).put(named("bonus", "獎金")).put(named("other_income", "其他")));
        d.put("categoryBudgets", new JSONObject());
        d.put("notifySettings", new JSONObject()
                .put("morning", new JSONObject().put("on", false).put("time", DailyNotify.MORNING_TIME))
                .put("night", new JSONObject().put("on", false).put("time", DailyNotify.NIGHT_TIME)));
        d.put("recurring", new JSONArray());
        d.put("payroll", new JSONObject()
                .put("baseSalary", 0).put("salaryDay", 5).put("payMonthOffset", 0).put("laborFee", 0).put("healthFee", 0)
                .put("healthDependents", 0).put("pensionSelfRate", 0).put("autoFrom", JSONObject.NULL).put("leaveDivisor", "workdays")
                .put("personalRule", new JSONObject().put("type", "halfpay").put("fixedAmount", 0))
                .put("sickRule", new JSONObject().put("type", "halfpay").put("fixedAmount", 0))
                .put("additions", new JSONArray()).put("deductions", new JSONArray()));
        d.put("leaveByMonth", new JSONObject());
        d.put("salaryRecorded", new JSONObject());
        d.put("specialDays", new JSONArray());
        d.put("tutorialSeen", new JSONObject());   // 新註冊的帳號:每個分頁第一次打開時自動跳出新手教學(舊帳號沒有這個欄位,不會自動跳)
        d.put("schemaVersion", Repo.SCHEMA);
        return d.toString();
    }
}
