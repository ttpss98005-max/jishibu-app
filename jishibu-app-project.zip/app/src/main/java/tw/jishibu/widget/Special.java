package tw.jishibu.widget;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 特別的日子(日期:節日/生日/紀念日;計算天數:在一起、養寵物…)。
 * 計算邏輯、文字、順序都照網頁版 specialsOn / specialStripItems / specialDetailHtml 等。
 * 資料在 specialDays: [{id, kind:'festival'|'count', name, date, yearly}]。
 */
final class Special {
    private Special() {}

    // ---------- 日期計算 ----------

    static boolean validYmd(String s) {
        if (s == null || s.length() != 10 || s.charAt(4) != '-' || s.charAt(7) != '-') return false;
        try {
            int y = Integer.parseInt(s.substring(0, 4)), m = Integer.parseInt(s.substring(5, 7)), d = Integer.parseInt(s.substring(8, 10));
            if (y < 1900 || y > 2200 || m < 1 || m > 12 || d < 1) return false;
            int[] back = Lunar.fromEpochDay(Lunar.epochDay(y, m, d));
            return back[0] == y && back[1] == m && back[2] == d;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    static int daysBetween(String a, String b) {
        return (int) (ymdEpoch(b) - ymdEpoch(a));
    }

    private static long ymdEpoch(String s) {
        return Lunar.epochDay(Integer.parseInt(s.substring(0, 4)), Integer.parseInt(s.substring(5, 7)), Integer.parseInt(s.substring(8, 10)));
    }

    static boolean isLeapYear(int y) { return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0; }

    static boolean sameMonthDay(String start, String date) {
        int sm = Integer.parseInt(start.substring(5, 7)), sd = Integer.parseInt(start.substring(8, 10));
        int y = Integer.parseInt(date.substring(0, 4)), m = Integer.parseInt(date.substring(5, 7)), d = Integer.parseInt(date.substring(8, 10));
        if (sm == 2 && sd == 29 && !isLeapYear(y)) return m == 2 && d == 28;
        return sm == m && sd == d;
    }

    static int counterN(JSONObject sd, String date) { return daysBetween(Model.s(sd, "date"), date) + 1; }

    // ---------- 年月天 ----------

    private static int monthDays(int y, int m) {   // m 是 1~12
        int[] d = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        return (m == 2 && isLeapYear(y)) ? 29 : d[m - 1];
    }

    /** 起算日加上 n 個月;日子超過那個月的天數就算到月底(1/31 起算,2 月底滿 1 個月)。 */
    static String addMonthsClamp(String s, int n) {
        int y = Integer.parseInt(s.substring(0, 4)), m = Integer.parseInt(s.substring(5, 7)), d = Integer.parseInt(s.substring(8, 10));
        int t = y * 12 + (m - 1) + n;
        int yy = Math.floorDiv(t, 12), mm = Math.floorMod(t, 12) + 1;
        return Model.ymd(yy, mm, Math.min(d, monthDays(yy, mm)));
    }

    /** 從起算日到某一天,滿了幾年、幾個月、再幾天 → {年, 月, 天}。 */
    static int[] elapsedYMD(String start, String day) {
        if (day.compareTo(start) < 0) return new int[]{0, 0, 0};
        int months = (Integer.parseInt(day.substring(0, 4)) - Integer.parseInt(start.substring(0, 4))) * 12
                + (Integer.parseInt(day.substring(5, 7)) - Integer.parseInt(start.substring(5, 7)));
        if (addMonthsClamp(start, months).compareTo(day) > 0) months--;
        int days = daysBetween(addMonthsClamp(start, months), day);
        return new int[]{months / 12, months % 12, days};
    }

    /** 計算天數要顯示的文字:天數 = 第 N 天;年月天 = X年Y月Z天(例如 5年11月10天);還沒開始一律「還有 N 天」。 */
    static String counterText(JSONObject sd, String day) { return counterText(Model.s(sd, "date"), "ymd".equals(Model.s(sd, "fmt")), day); }

    static String counterText(String start, boolean ymd, String day) {
        int n = daysBetween(start, day) + 1;
        if (n < 1) return "還有 " + (1 - n) + " 天";
        if (!ymd) return "第 " + n + " 天";
        int[] e = elapsedYMD(start, day);
        StringBuilder b = new StringBuilder();
        if (e[0] > 0) b.append(e[0]).append("年");
        if (e[1] > 0) b.append(e[1]).append("月");
        if (e[2] > 0 || b.length() == 0) b.append(e[2]).append("天");
        return b.toString();
    }

    // ---------- 排序:跟清單一樣,按「排序」才整理一次(整理完就是普通的順序,可以再拖動;之後新增、改日期都不會自己跑掉) ----------

    static final String[] SORT_MODES = {"default", "name", "date", "created"};
    static final String[] SORT_LABELS = {"預設", "名稱", "日期", "新增時間"};
    /** 每種排序的順序選項;預設沒有順序可選。 */
    static final String[][] SORT_DIRS = {null, {"正序", "倒序"}, {"最早在前", "最晚在前"}, {"最舊在前", "最新在前"}};
    /** 排序視窗裡目前選的(只是選項,不存起來)。 */
    private static int pickMode = 0;
    private static boolean pickDesc = false;

    /** 依選的方式排;同分的照原本順序。預設 = 計算天數在前,日期依下一次的遠近、已經過的排最後。 */
    static List<JSONObject> sortBy(List<JSONObject> in, final String mode, boolean desc) {
        final List<JSONObject> all = Model.list("specialDays");
        final java.text.Collator col = java.text.Collator.getInstance(java.util.Locale.TAIWAN);
        final int sgn = desc ? -1 : 1;
        final String today = Model.today();
        List<JSONObject> l = new ArrayList<>(in);
        Collections.sort(l, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject x, JSONObject y) {
                int c;
                if ("name".equals(mode)) c = col.compare(Model.s(x, "name"), Model.s(y, "name")) * sgn;
                else if ("date".equals(mode)) c = Integer.signum(Model.s(x, "date").compareTo(Model.s(y, "date"))) * sgn;
                else if ("created".equals(mode)) c = Long.compare(ListScreen.createdMs(x), ListScreen.createdMs(y)) * sgn;
                else c = Integer.compare(defaultKey(x, today), defaultKey(y, today));
                return c != 0 ? c : Integer.compare(all.indexOf(x), all.indexOf(y));
            }
        });
        return l;
    }

    private static int defaultKey(JSONObject sd, String today) {
        if (!isFestival(sd)) return -1;
        String nx = nextFestivalDate(sd, today);
        return nx != null ? daysBetween(today, nx) : 100000 + daysBetween(Model.s(sd, "date"), today);
    }

    /** 拖動或排序完成:看得到的幾個照新順序填回它們原本佔的位置(日期壞掉、看不到的維持不動)。 */
    static void saveOrder(MainActivity a, List<String> visible) {
        List<String> full = new ArrayList<>();
        for (JSONObject o : Model.list("specialDays")) full.add(Model.s(o, "id"));
        List<String> out = new ArrayList<>();
        int k = 0;
        for (String id : full) {
            if (visible.contains(id)) { if (k < visible.size()) out.add(visible.get(k++)); }
            else out.add(id);
        }
        if (!out.equals(full)) Repo.order(a, out, "specialDays");
    }

    /**
     * 舊版(2.47 以前)把排序方式存在 specialSort、一直自動套用;現在改成按「排序」才整理一次。
     * 資料裡還留著舊設定的話,就照它整理一次,然後把設定拿掉(網頁版載入時做一樣的事)。
     */
    static void migrateLegacySort(Context c) {
        JSONObject r = Repo.data();
        if (r == null || !r.has("specialSort") || Repo.sandbox()) return;
        String old = r.optString("specialSort", "");
        String mode = "name".equals(old) ? "name" : "date".equals(old) ? "date" : "new".equals(old) ? "created" : "default";
        List<String> ids = new ArrayList<>();
        for (JSONObject o : sortBy(Model.list("specialDays"), mode, "created".equals(mode))) ids.add(Model.s(o, "id"));
        Repo.order(c, ids, "specialDays");
        Repo.del(c, "specialSort");
    }

    static List<JSONObject> all() {
        List<JSONObject> r = new ArrayList<>();
        for (JSONObject o : Model.list("specialDays")) {
            if (validYmd(Model.s(o, "date"))) r.add(o);   // 日期壞掉的不拿來算(也不會刪掉它)
        }
        return r;
    }

    static boolean isFestival(JSONObject sd) { return "festival".equals(Model.s(sd, "kind")); }

    /** 某一天的特別日子:festivals(節日)、marks(起點/週年/整百天)。 */
    static final class Mark {
        JSONObject sd;
        String type;   // start / anniv / hundred
        int n;
        String text;
    }

    static final class On {
        final List<JSONObject> festivals = new ArrayList<>();
        final List<Mark> marks = new ArrayList<>();
    }

    static On on(String day) {
        On out = new On();
        for (JSONObject sd : all()) {
            String date = Model.s(sd, "date");
            if (isFestival(sd)) {
                boolean yearly = sd.optBoolean("yearly", true);
                boolean hit = yearly ? (day.compareTo(date) >= 0 && sameMonthDay(date, day)) : date.equals(day);
                if (hit) out.festivals.add(sd);
            } else {
                int n = counterN(sd, day);
                Mark mk = new Mark();
                mk.sd = sd;
                mk.n = n;
                String name = Model.s(sd, "name");
                if (n == 1) { mk.type = "start"; mk.text = name + " 起點"; out.marks.add(mk); }
                else if (n > 1 && sameMonthDay(date, day)) {
                    int yrs = Integer.parseInt(day.substring(0, 4)) - Integer.parseInt(date.substring(0, 4));
                    mk.type = "anniv"; mk.text = name + " " + yrs + " 週年"; out.marks.add(mk);
                } else if (n > 1 && n % 100 == 0) { mk.type = "hundred"; mk.text = name + " 第 " + n + " 天"; out.marks.add(mk); }
            }
        }
        return out;
    }

    /** 節日下一次是哪天(今天算);已過去的一次性節日回 null。 */
    static String nextFestivalDate(JSONObject sd, String today) {
        String date = Model.s(sd, "date");
        if (!sd.optBoolean("yearly", true)) return date.compareTo(today) >= 0 ? date : null;
        int y = Integer.parseInt(today.substring(0, 4)), m = Integer.parseInt(date.substring(5, 7)), d = Integer.parseInt(date.substring(8, 10));
        for (int yy = y; yy <= y + 1; yy++) {
            String c = Model.ymd(yy, m, (m == 2 && d == 29 && !isLeapYear(yy)) ? 28 : d);
            if (c.compareTo(today) >= 0 && c.compareTo(date) >= 0) return c;
        }
        return null;
    }

    /** 「日期」類(每年重複的才有):從那一天到今天已經滿了幾年,只放數字;不滿一年、還沒到、一次性的、計算天數的都是空字串。 */
    static String festYears(JSONObject sd, String today) {
        if (!isFestival(sd) || !sd.optBoolean("yearly", true)) return "";
        String date = Model.s(sd, "date");
        if (today.compareTo(date) < 0) return "";
        int y = elapsedYMD(date, today)[0];
        return y >= 1 ? String.valueOf(y) : "";
    }

    /** 每年的日期離「下一次」有多近,0~1(上一次到下一次之間走了幾成;還沒滿一年就從起算日算起;就是今天 = 1)。一次性、還沒到、計算天數回 -1(不畫條)。 */
    static float festProgress(JSONObject sd, String today) {
        if (!isFestival(sd) || !sd.optBoolean("yearly", true)) return -1f;
        String date = Model.s(sd, "date");
        if (today.compareTo(date) < 0) return -1f;
        String nx = nextFestivalDate(sd, today);
        if (nx == null) return -1f;
        if (nx.equals(today)) return 1f;
        int py = Integer.parseInt(nx.substring(0, 4)) - 1, m = Integer.parseInt(date.substring(5, 7)), d = Integer.parseInt(date.substring(8, 10));
        String prev = Model.ymd(py, m, (m == 2 && d == 29 && !isLeapYear(py)) ? 28 : d);
        if (prev.compareTo(date) < 0) prev = date;
        int span = daysBetween(prev, nx);
        if (span <= 0) return 1f;
        return Math.max(0f, Math.min(1f, daysBetween(prev, today) / (float) span));
    }

    static final class Item {
        JSONObject sd;
        int key;
        String num;
        String yr = "";
        float bar = -1f;
    }

    /** 最上面那一排:所有特別的日子,照「特別的日子」裡排好的順序。計算天數 = 今天第幾天;日期 = 下一次還有幾天(過了的顯示已過幾天)。 */
    static List<Item> stripItems() {
        String today = Model.today();
        List<Item> out = new ArrayList<>();
        for (JSONObject sd : all()) {
            Item it = new Item();
            it.sd = sd;
            if (!isFestival(sd)) {
                it.num = counterText(sd, today);
            } else {
                it.yr = festYears(sd, today);
                it.bar = festProgress(sd, today);
                String nx = nextFestivalDate(sd, today);
                if (nx != null) {
                    int dd = daysBetween(today, nx);
                    it.key = dd;
                    it.num = dd == 0 ? "就是今天" : "還有 " + dd + " 天";
                } else {
                    int past = daysBetween(Model.s(sd, "date"), today);
                    it.key = 100000 + past;
                    it.num = "已過 " + past + " 天";
                }
            }
            out.add(it);
        }
        return out;
    }

    /** 計算天數旁邊的小日曆圖示開關:亮 = 用「年月天」顯示。 */
    static View fmtToggle(final MainActivity a, JSONObject sd, int circleDp) {
        final String id = Model.s(sd, "id");
        return Ui.iconToggle(a, Icons.CAL_SMALL, circleDp, "ymd".equals(Model.s(sd, "fmt")), "用年月天顯示", new View.OnClickListener() {
            @Override public void onClick(View v) { toggleFmt(a, id); }
        });
    }

    static void toggleFmt(MainActivity a, String id) {
        JSONObject sd = find(id);
        if (sd == null || isFestival(sd)) return;
        try {
            if ("ymd".equals(Model.s(sd, "fmt"))) Repo.patch(a, new JSONObject(), new String[]{"fmt"}, "specialDays", id);
            else Repo.patch(a, new JSONObject().put("fmt", "ymd"), null, "specialDays", id);
        } catch (JSONException ignore) { }
        a.refreshCurrent();
    }

    // ---------- 畫面元件 ----------

    /** 月曆、週曆最上面:白底方塊,上名稱、下大大的天數;每年重複的日期最下面一行是細進度條(離下一次有多近)加已過幾年的數字。 */
    static View boxes(final MainActivity a) {
        LinearLayout col = Ui.col(a);
        List<Item> items = stripItems();
        List<View> cells = new ArrayList<>();
        for (final Item it : items) {
            LinearLayout b = Ui.col(a);
            b.setBackground(Ui.shape(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
            b.setPadding(Ui.dp(a, 13), Ui.dp(a, 10), Ui.dp(a, 13), Ui.dp(a, 10));
            boolean counter = !isFestival(it.sd);
            TextView name = Ui.tv(a, Model.s(it.sd, "name"), 11.5f, Ui.SOFT, false);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            if (counter) name.setPadding(0, 0, Ui.dp(a, 26), 0);       // 右上角留給年月天開關
            b.addView(name);
            b.addView(Ui.tv(a, it.num, 16, Ui.ACCENT, true));
            if (it.bar >= 0f || it.yr.length() > 0) b.addView(progRow(a, it), Ui.mw(a, 5));
            final String id = Model.s(it.sd, "id");
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openEdit(a, id, null); }
            });
            if (counter) {
                // 計算天數的方塊右上角有年月天小開關
                FrameLayout wrap = new FrameLayout(a);
                wrap.addView(b, new FrameLayout.LayoutParams(-1, -2));
                FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
                tp.topMargin = Ui.dp(a, 7);
                tp.rightMargin = Ui.dp(a, 8);
                wrap.addView(fmtToggle(a, it.sd, 24), tp);
                cells.add(wrap);
            } else {
                cells.add(b);
            }
        }
        TextView add = Ui.tv(a, items.isEmpty() ? "＋ 加入日期或計算天數" : "＋ 新增或管理", 12.5f, Ui.SOFT, true);
        add.setGravity(Gravity.CENTER);
        add.setMinimumHeight(Ui.dp(a, items.isEmpty() ? 46 : 52));
        add.setBackground(Ui.dashed(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openManage(a); }
        });
        if (items.isEmpty()) {
            col.addView(add, Ui.mw(a, 0));
        } else {
            cells.add(add);
            for (int i = 0; i < cells.size(); i += 2) {
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                for (int k = 0; k < 2; k++) {
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                    if (k == 1) lp.leftMargin = Ui.dp(a, 8);
                    if (i + k < cells.size()) row.addView(cells.get(i + k), lp);
                    else row.addView(new View(a), lp);
                }
                col.addView(row, Ui.mw(a, i == 0 ? 0 : 8));
            }
        }
        return col;
    }

    /** 方塊最下面一行:左邊細進度條,右邊已過幾年的數字(主色粗體)。 */
    private static View progRow(MainActivity a, Item it) {
        LinearLayout row = Ui.row(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(Ui.dp(a, 15));
        if (it.bar >= 0f) {
            LinearLayout track = new LinearLayout(a);
            track.setOrientation(LinearLayout.HORIZONTAL);
            track.setWeightSum(1000f);
            track.setBackground(Ui.shape(a, Ui.ACCENT_SOFT, 99, 0, 0));
            View fill = new View(a);
            fill.setBackground(Ui.shape(a, Ui.ACCENT, 99, 0, 0));
            track.addView(fill, new LinearLayout.LayoutParams(0, -1, Math.round(it.bar * 1000f)));
            track.setContentDescription("離下一次 " + Math.round(it.bar * 100) + "%");
            row.addView(track, new LinearLayout.LayoutParams(0, Ui.dp(a, 4), 1f));
        } else {
            row.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        }
        if (it.yr.length() > 0) {
            TextView y = Ui.tv(a, it.yr, 13, Ui.ACCENT, true);
            y.setContentDescription("已過 " + it.yr + " 年");
            row.addView(y, Ui.gap(a, 8));
        }
        return row;
    }

    /** 某一天詳細頁上方:當天的節日,以及每個計算天數那天是第幾天。 */
    static View detail(MainActivity a, String day) {
        On sp = on(day);
        LinearLayout box = Ui.col(a);
        int count = 0;
        for (JSONObject f : sp.festivals) {
            LinearLayout line = Ui.row(a);
            line.setBackground(Ui.shape(a, Ui.ACCENT_SOFT, 12, 0, 0));
            line.setPadding(Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8));
            line.addView(Ui.tv(a, Model.s(f, "name"), 12.5f, Ui.ACCENT, true));
            box.addView(line, Ui.mw(a, count++ == 0 ? 0 : 6));
        }
        for (JSONObject sd : all()) {
            if (isFestival(sd)) continue;
            int n = counterN(sd, day);
            Mark mk = null;
            for (Mark m : sp.marks) if (Model.s(m.sd, "id").equals(Model.s(sd, "id"))) mk = m;
            String badge = "";
            if (mk != null) {
                if ("start".equals(mk.type)) badge = "起點";
                else if ("anniv".equals(mk.type)) badge = (Integer.parseInt(day.substring(0, 4)) - Integer.parseInt(Model.s(sd, "date").substring(0, 4))) + " 週年";
                else badge = "整百天";
            }
            LinearLayout line = Ui.row(a);
            line.setBackground(Ui.shape(a, Ui.ACCENT_SOFT, 12, 0, 0));
            line.setPadding(Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8));
            line.addView(Ui.tv(a, Model.s(sd, "name"), 12.5f, Ui.CARD_INK, false));
            line.addView(Ui.tv(a, n >= 1 ? counterText(sd, day) : "還有 " + (1 - n) + " 天開始", 12.5f, Ui.ACCENT, true), Ui.gap(a, 8));
            if (!badge.isEmpty()) {
                View sp2 = new View(a);
                line.addView(sp2, new LinearLayout.LayoutParams(0, 1, 1f));
                line.addView(Ui.chip(a, badge, 10.5f, Ui.ON_ACCENT, Ui.ACCENT, true));
            }
            box.addView(line, Ui.mw(a, count++ == 0 ? 0 : 6));
        }
        if (count > 0) box.setPadding(0, Ui.dp(a, 10), 0, Ui.dp(a, 12));
        return box;
    }

    // ---------- 管理視窗 ----------

    /** 「特別的日子」清單視窗:右上角排序鈕,每列左邊三條線可長按拖動,點一列編輯,下方「＋ 新增」「取消」「完成」。 */
    static void openManage(final MainActivity a) {
        final Modal.Sheet s = Modal.sheet(a);
        // 這裡新增、修改、刪除、排序、拖動都是當下就存,所以按取消要還原成打開時的樣子
        final String snap = Money.arrStr("specialDays");
        s.box.addView(Ui.tv(a, "特別的日子", 16, Ui.CARD_INK, true));
        final LinearLayout sortBar = Ui.row(a);
        sortBar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        s.box.addView(sortBar, Ui.mw(a, 10));
        final LinearLayout list = Ui.col(a);
        s.box.addView(list, Ui.mw(a, 10));
        final Runnable[] render = new Runnable[1];
        render[0] = new Runnable() {
            @Override public void run() {
                list.removeAllViews();
                sortBar.removeAllViews();
                final List<JSONObject> sds = all();
                sortBar.setVisibility(sds.size() > 1 ? View.VISIBLE : View.GONE);
                if (sds.size() > 1) {
                    FrameLayout b = new FrameLayout(a);
                    b.setBackground(Ui.shape(a, Ui.CHIP_BG, 10, 0, 0));
                    b.setContentDescription("排序");
                    b.addView(Icons.line(a, Icons.SORT, 20, Ui.SOFT), new FrameLayout.LayoutParams(Ui.dp(a, 20), Ui.dp(a, 20), Gravity.CENTER));
                    b.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { openSortSheet(a, render[0]); }
                    });
                    sortBar.addView(b, new LinearLayout.LayoutParams(Ui.dp(a, 36), Ui.dp(a, 36)));
                }
                if (sds.isEmpty()) {
                    TextView e = Ui.tv(a, "還沒有特別的日子。\n按下方「＋ 新增」,可以加生日、紀念日,或是計算在一起、養寵物已經過了幾天。", 13.5f, Ui.SOFT, false);
                    e.setGravity(Gravity.CENTER);
                    e.setLineSpacing(0, 1.3f);
                    e.setPadding(Ui.dp(a, 8), Ui.dp(a, 18), Ui.dp(a, 8), Ui.dp(a, 18));
                    list.addView(e);
                    return;
                }
                String today = Model.today();
                for (final JSONObject sd : sds) {
                    String num, sub;
                    if (isFestival(sd)) {
                        String nx = nextFestivalDate(sd, today);
                        num = nx != null ? (daysBetween(today, nx) == 0 ? "今天" : "還有 " + daysBetween(today, nx) + " 天") : "已過";
                        sub = Model.s(sd, "date") + (sd.optBoolean("yearly", true) ? "・每年" : "");
                    } else {
                        num = counterText(sd, today);
                        sub = Model.s(sd, "date");
                    }
                    final String id = Model.s(sd, "id");
                    final LinearLayout row = Ui.row(a);
                    row.setTag(id);
                    row.setBackground(Ui.shape(a, Ui.TASK_BG, 14, Ui.BORDER, 1.5f));
                    row.setPadding(Ui.dp(a, 4), Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8));
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    // 左:長按拖動的把手(三條線),跟清單一樣
                    LinearLayout handle = Ui.col(a);
                    handle.setGravity(Gravity.CENTER);
                    handle.setPadding(Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 6));
                    handle.setContentDescription("長按拖曳排序");
                    for (int k = 0; k < 3; k++) {
                        View line = new View(a);
                        line.setBackground(Ui.shape(a, Ui.SOFT, 1, 0, 0));
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(a, 14), Math.max(2, Ui.dp(a, 2)));
                        if (k > 0) lp.topMargin = Ui.dp(a, 3);
                        handle.addView(line, lp);
                    }
                    handle.setOnTouchListener(new RowDrag(a, list, row, 8, 0, new RowDrag.Done() {
                        @Override public void on(List<String> ids) {
                            saveOrder(a, ids);
                            a.refreshCurrent();
                            render[0].run();
                        }
                    }));
                    row.addView(handle, new LinearLayout.LayoutParams(-2, -2));
                    // 右:點一下編輯(名稱、類型、日期、天數)
                    LinearLayout edit = Ui.row(a);
                    edit.setGravity(Gravity.CENTER_VERTICAL);
                    edit.setPadding(Ui.dp(a, 4), Ui.dp(a, 4), 0, Ui.dp(a, 4));
                    LinearLayout main = Ui.col(a);
                    TextView t = Ui.tv(a, Model.s(sd, "name"), 13.5f, Ui.CARD_INK, true);
                    t.setSingleLine(true);
                    t.setEllipsize(android.text.TextUtils.TruncateAt.END);
                    main.addView(t);
                    LinearLayout subRow = Ui.row(a);
                    subRow.setGravity(Gravity.CENTER_VERTICAL);
                    subRow.addView(Ui.chip(a, isFestival(sd) ? "日期" : "計算天數", 10.5f, Ui.ACCENT, Ui.ACCENT_SOFT, true));
                    subRow.addView(Ui.tv(a, sub, 11, Ui.SOFT, false), Ui.gap(a, 6));
                    main.addView(subRow, Ui.mw(a, 3));
                    edit.addView(main, new LinearLayout.LayoutParams(0, -2, 1f));
                    edit.addView(Ui.tv(a, num, 13, Ui.ACCENT, true), Ui.gap(a, 8));
                    edit.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { openEdit(a, id, render[0]); }
                    });
                    row.addView(edit, new LinearLayout.LayoutParams(0, -2, 1f));
                    LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(-1, -2);
                    rlp.bottomMargin = Ui.dp(a, 8);
                    list.addView(row, rlp);
                }
            }
        };
        render[0].run();
        LinearLayout actions = Ui.row(a);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        actions.addView(Ui.btnGhost(a, "＋ 新增", new View.OnClickListener() {
            @Override public void onClick(View v) { openEdit(a, null, render[0]); }
        }));
        actions.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        actions.addView(Ui.btnGhost(a, "取消", new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    if (!Money.arrStr("specialDays").equals(snap)) {
                        Repo.set(a, new JSONArray(snap), "specialDays");
                        a.refreshCurrent();
                    }
                } catch (JSONException ignore) { }
                s.dismiss();
            }
        }), Ui.gap(a, 8));
        actions.addView(Ui.btnPrimary(a, "完成", new View.OnClickListener() {
            @Override public void onClick(View v) { s.dismiss(); }
        }), Ui.gap(a, 8));
        s.box.addView(actions, Ui.mw(a, 22));
        s.dialog.show();
    }

    /** 排序視窗:選項(單選)+ 順序(預設沒有順序);按「排序」才整理一次,在「特別的日子」裡按「取消」會連排序一起還原。 */
    private static void openSortSheet(final MainActivity a, final Runnable afterSort) {
        final Modal.Sheet sh = Modal.sheet(a);
        pickMode = 0;
        pickDesc = false;
        TextView title = Ui.tv(a, "排序", 16, Ui.CARD_INK, true);
        title.setPadding(0, 0, 0, Ui.dp(a, 8));
        sh.box.addView(title);
        final LinearLayout body = Ui.col(a);
        sh.box.addView(body);
        fillSortBody(a, body);
        LinearLayout actions = Ui.row(a);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        actions.addView(Ui.btnGhost(a, "取消", new View.OnClickListener() {
            @Override public void onClick(View v) { sh.dismiss(); }
        }));
        actions.addView(Ui.btnPrimary(a, "排序", new View.OnClickListener() {
            @Override public void onClick(View v) {
                sh.dismiss();
                List<JSONObject> shown = all();
                if (shown.size() < 2) return;
                List<String> ids = new ArrayList<>();
                for (JSONObject o : sortBy(shown, SORT_MODES[pickMode], pickDesc)) ids.add(Model.s(o, "id"));
                saveOrder(a, ids);
                a.refreshCurrent();
                afterSort.run();
            }
        }), Ui.gap(a, 8));
        sh.box.addView(actions, Ui.mw(a, 22));
        sh.dialog.show();
    }

    private static void fillSortBody(final MainActivity a, final LinearLayout body) {
        body.removeAllViews();
        for (int i = 0; i < SORT_MODES.length; i++) {
            final int idx = i;
            boolean sel = i == pickMode;
            LinearLayout r = Ui.row(a);
            r.setPadding(Ui.dp(a, 4), Ui.dp(a, 12), Ui.dp(a, 4), Ui.dp(a, 12));
            FrameLayout rd = new FrameLayout(a);
            rd.setBackground(Ui.shape(a, 0xFFFFFFFF, 9, sel ? Ui.ACCENT : Ui.BORDER, 2));
            if (sel) {
                View dot = new View(a);
                dot.setBackground(Ui.shape(a, Ui.ACCENT, 5, 0, 0));
                rd.addView(dot, new FrameLayout.LayoutParams(Ui.dp(a, 10), Ui.dp(a, 10), Gravity.CENTER));
            }
            r.addView(rd, new LinearLayout.LayoutParams(Ui.dp(a, 18), Ui.dp(a, 18)));
            r.addView(Ui.tv(a, SORT_LABELS[i], 14, Ui.CARD_INK, true), Ui.gap(a, 12));
            r.setContentDescription(SORT_LABELS[i] + (sel ? ",已選" : ""));
            r.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { pickMode = idx; pickDesc = false; fillSortBody(a, body); }
            });
            body.addView(r, new LinearLayout.LayoutParams(-1, -2));
            if (i < SORT_MODES.length - 1) {
                View line = new View(a);
                line.setBackgroundColor(Ui.BORDER);
                body.addView(line, new LinearLayout.LayoutParams(-1, Math.max(1, Ui.dp(a, 1))));
            }
        }
        if (SORT_DIRS[pickMode] != null) {
            body.addView(Ui.tv(a, "順序", 12, Ui.SOFT, true), Ui.mw(a, 14));
            body.addView(Ui.pillTabs(a, SORT_DIRS[pickMode], pickDesc ? 1 : 0, new Ui.IntCb() {
                @Override public void on(int k) { pickDesc = k == 1; }
            }), Ui.wrap(a, 6));
        }
    }

    private static LinearLayout.LayoutParams wlp(MainActivity a, float leftDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.leftMargin = Ui.dp(a, leftDp);
        return p;
    }

    private static JSONObject find(String id) {
        if (id == null) return null;
        for (JSONObject o : Model.list("specialDays")) if (id.equals(Model.s(o, "id"))) return o;
        return null;
    }

    /** 新增/編輯視窗。afterChange 在存檔或刪除後呼叫(讓管理清單重畫),可為 null。 */
    static void openEdit(final MainActivity a, final String id, final Runnable afterChange) {
        final JSONObject sd = find(id);
        final String[] kind = {sd == null ? "festival" : Model.s(sd, "kind", "festival")};
        final Modal.Sheet s = Modal.sheet(a);
        s.box.addView(Ui.tv(a, sd != null ? "編輯特別的日子" : "新增特別的日子", 16, Ui.CARD_INK, true));

        // 類型
        final TextView kFestival = kindBtn(a, "日期"), kCount = kindBtn(a, "計算天數");
        LinearLayout kinds = Ui.row(a);
        kinds.addView(kFestival, new LinearLayout.LayoutParams(0, -2, 1f));
        kinds.addView(kCount, wlp(a, 8));
        LinearLayout kindBox = Ui.col(a);
        kindBox.addView(kinds);
        s.box.addView(Ui.field(a, "類型", kindBox));

        final android.widget.EditText name = Ui.input(a, "", sd == null ? "" : Model.s(sd, "name"));
        s.box.addView(Ui.field(a, "名稱", name));

        final String[] date = {sd == null ? Model.today() : Model.s(sd, "date", Model.today())};
        final Runnable[] onDate = {null};
        final TextView dateLabel = Ui.tv(a, "", 12, Ui.SOFT, true);
        final TextView dateBtn = Ui.tv(a, date[0], 13.5f, Ui.CARD_INK, false);
        dateBtn.setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10));
        dateBtn.setBackground(Ui.shape(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
        dateBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Modal.pickDate(a, date[0], new Modal.StrCb() {
                    @Override public void on(String d) { date[0] = d; dateBtn.setText(d); if (onDate[0] != null) onDate[0].run(); }
                });
            }
        });
        LinearLayout dateBox = Ui.col(a);
        dateBox.addView(dateLabel);
        dateBox.addView(dateBtn, Ui.mw(a, 6));
        dateBox.setLayoutParams(Ui.mw(a, 15));
        s.box.addView(dateBox);

        final LinearLayout yearlyRow = Ui.row(a);
        yearlyRow.addView(Ui.tv(a, "每年重複", 13, Ui.CARD_INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final View yearly = Ui.toggle(a, sd == null || sd.optBoolean("yearly", true), null);
        yearlyRow.addView(yearly);
        s.box.addView(yearlyRow, Ui.mw(a, 15));

        final Runnable update = new Runnable() {
            @Override public void run() {
                boolean fest = "festival".equals(kind[0]);
                paintKind(a, kFestival, fest);
                paintKind(a, kCount, !fest);
                name.setHint(fest ? "例如:媽媽生日、結婚紀念日" : "例如:在一起、養小白");
                dateLabel.setText(fest ? "哪一天" : "起算日");
                yearlyRow.setVisibility(fest ? View.VISIBLE : View.GONE);
            }
        };
        kFestival.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { kind[0] = "festival"; update.run(); }
        });
        kCount.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { kind[0] = "count"; update.run(); }
        });
        onDate[0] = update;
        update.run();

        LinearLayout actions = Ui.row(a);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        if (sd != null) {
            actions.addView(Ui.btnDanger(a, "刪除", new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Modal.confirm(a, "確定要刪除「" + Model.s(sd, "name") + "」嗎?", null, "刪除", true, new Runnable() {
                        @Override public void run() {
                            s.dismiss();
                            Repo.del(a, "specialDays", id);
                            a.refreshCurrent();
                            if (afterChange != null) afterChange.run();
                        }
                    });
                }
            }));
            actions.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        }
        actions.addView(Ui.btnGhost(a, "取消", new View.OnClickListener() {
            @Override public void onClick(View v) { s.dismiss(); }
        }));
        actions.addView(Ui.btnPrimary(a, "儲存", new View.OnClickListener() {
            @Override public void onClick(View v) {
                String nm = name.getText().toString().trim();
                if (nm.length() > 30) nm = nm.substring(0, 30);
                if (nm.isEmpty()) { Ui.toast(a, "請輸入名稱。"); return; }
                if (!validYmd(date[0])) { Ui.toast(a, "請選擇正確的日期。"); return; }
                boolean yr = "festival".equals(kind[0]) && Ui.isOn(yearly);
                try {
                    if (sd != null) {
                        JSONObject set = new JSONObject();
                        set.put("kind", kind[0]);
                        set.put("name", nm);
                        set.put("date", date[0]);
                        set.put("yearly", yr);
                        // 年月天是在月曆上的小開關切換的,編輯時保留原本的設定(改成「日期」類型才拿掉)
                        Repo.patch(a, set, "count".equals(kind[0]) ? null : new String[]{"fmt"}, "specialDays", id);
                    } else {
                        JSONObject item = new JSONObject();
                        item.put("id", Repo.newId());
                        item.put("kind", kind[0]);
                        item.put("name", nm);
                        item.put("date", date[0]);
                        item.put("yearly", yr);
                        Repo.add(a, item, -1, "specialDays");
                    }
                } catch (JSONException ignore) { }
                s.dismiss();
                a.refreshCurrent();
                if (afterChange != null) afterChange.run();
            }
        }), Ui.gap(a, 8));
        s.box.addView(actions, Ui.mw(a, 22));
        s.dialog.show();
    }

    private static TextView kindBtn(MainActivity a, String label) {
        TextView t = Ui.tv(a, label, 12.5f, Ui.SOFT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10));
        t.setSingleLine(true);
        return t;
    }

    private static void paintKind(MainActivity a, TextView t, boolean on) {
        t.setTextColor(on ? Ui.ON_ACCENT : Ui.SOFT);
        t.setBackground(on ? Ui.shape(a, Ui.ACCENT, 999, Ui.ACCENT, 1.5f) : Ui.shape(a, Ui.SURFACE, 999, Ui.BORDER, 1.5f));
    }
}
