package tw.jishibu.widget;

import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 特別的日子(日期:節日/生日/紀念日;計算天數:在一起、養寵物…)。
 * 計算邏輯、文字、順序都照網頁版 specialsOn / specialStripItems / specialDetailHtml 等。
 * 資料在 specialDays: [{id, kind:'festival'|'count', name, date, yearly}]。
 */
final class Special {
    private Special() {}

    // ---------- 日期計算 ----------

    static boolean validYmd(String s) {
        if (s == null || s.length() != 10 || s.charAt(4) != '-' || s.charAt(7) != '-') return false;
        try {
            int y = Integer.parseInt(s.substring(0, 4)), m = Integer.parseInt(s.substring(5, 7)), d = Integer.parseInt(s.substring(8, 10));
            if (y < 1900 || y > 2200 || m < 1 || m > 12 || d < 1) return false;
            int[] back = Lunar.fromEpochDay(Lunar.epochDay(y, m, d));
            return back[0] == y && back[1] == m && back[2] == d;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    static int daysBetween(String a, String b) {
        return (int) (ymdEpoch(b) - ymdEpoch(a));
    }

    private static long ymdEpoch(String s) {
        return Lunar.epochDay(Integer.parseInt(s.substring(0, 4)), Integer.parseInt(s.substring(5, 7)), Integer.parseInt(s.substring(8, 10)));
    }

    static boolean isLeapYear(int y) { return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0; }

    static boolean sameMonthDay(String start, String date) {
        int sm = Integer.parseInt(start.substring(5, 7)), sd = Integer.parseInt(start.substring(8, 10));
        int y = Integer.parseInt(date.substring(0, 4)), m = Integer.parseInt(date.substring(5, 7)), d = Integer.parseInt(date.substring(8, 10));
        if (sm == 2 && sd == 29 && !isLeapYear(y)) return m == 2 && d == 28;
        return sm == m && sd == d;
    }

    static int counterN(JSONObject sd, String date) { return daysBetween(Model.s(sd, "date"), date) + 1; }

    static List<JSONObject> all() {
        List<JSONObject> r = new ArrayList<>();
        for (JSONObject o : Model.list("specialDays")) {
            if (validYmd(Model.s(o, "date"))) r.add(o);   // 日期壞掉的不拿來算(也不會刪掉它)
        }
        return r;
    }

    static boolean isFestival(JSONObject sd) { return "festival".equals(Model.s(sd, "kind")); }

    /** 某一天的特別日子:festivals(節日)、marks(起點/週年/整百天)。 */
    static final class Mark {
        JSONObject sd;
        String type;   // start / anniv / hundred
        int n;
        String text;
    }

    static final class On {
        final List<JSONObject> festivals = new ArrayList<>();
        final List<Mark> marks = new ArrayList<>();
    }

    static On on(String day) {
        On out = new On();
        for (JSONObject sd : all()) {
            String date = Model.s(sd, "date");
            if (isFestival(sd)) {
                boolean yearly = sd.optBoolean("yearly", false);
                boolean hit = yearly ? (day.compareTo(date) >= 0 && sameMonthDay(date, day)) : date.equals(day);
                if (hit) out.festivals.add(sd);
            } else {
                int n = counterN(sd, day);
                Mark mk = new Mark();
                mk.sd = sd;
                mk.n = n;
                String name = Model.s(sd, "name");
                if (n == 1) { mk.type = "start"; mk.text = name + " 起點"; out.marks.add(mk); }
                else if (n > 1 && sameMonthDay(date, day)) {
                    int yrs = Integer.parseInt(day.substring(0, 4)) - Integer.parseInt(date.substring(0, 4));
                    mk.type = "anniv"; mk.text = name + " " + yrs + " 週年"; out.marks.add(mk);
                } else if (n > 1 && n % 100 == 0) { mk.type = "hundred"; mk.text = name + " 第 " + n + " 天"; out.marks.add(mk); }
            }
        }
        return out;
    }

    /** 節日下一次是哪天(今天算);已過去的一次性節日回 null。 */
    static String nextFestivalDate(JSONObject sd, String today) {
        String date = Model.s(sd, "date");
        if (!sd.optBoolean("yearly", false)) return date.compareTo(today) >= 0 ? date : null;
        int y = Integer.parseInt(today.substring(0, 4)), m = Integer.parseInt(date.substring(5, 7)), d = Integer.parseInt(date.substring(8, 10));
        for (int yy = y; yy <= y + 1; yy++) {
            String c = Model.ymd(yy, m, (m == 2 && d == 29 && !isLeapYear(yy)) ? 28 : d);
            if (c.compareTo(today) >= 0 && c.compareTo(date) >= 0) return c;
        }
        return null;
    }

    static final class Item {
        JSONObject sd;
        int key;
        String num;
    }

    /** 最上面那一排:計算天數(今天第幾天)→ 最近的日期 → 已過的。 */
    static List<Item> stripItems() {
        String today = Model.today();
        List<Item> counters = new ArrayList<>(), dates = new ArrayList<>();
        for (JSONObject sd : all()) {
            Item it = new Item();
            it.sd = sd;
            if (!isFestival(sd)) {
                int n = counterN(sd, today);
                it.num = n >= 1 ? "第 " + n + " 天" : "還有 " + (1 - n) + " 天";
                counters.add(it);
                continue;
            }
            String nx = nextFestivalDate(sd, today);
            if (nx != null) {
                int dd = daysBetween(today, nx);
                it.key = dd;
                it.num = dd == 0 ? "就是今天" : "還有 " + dd + " 天";
            } else {
                int past = daysBetween(Model.s(sd, "date"), today);
                it.key = 100000 + past;
                it.num = "已過 " + past + " 天";
            }
            dates.add(it);
        }
        Collections.sort(dates, new Comparator<Item>() {
            @Override public int compare(Item x, Item y) { return x.key - y.key; }
        });
        counters.addAll(dates);
        return counters;
    }

    // ---------- 畫面元件 ----------

    /** 月曆上方:小膠囊一排。 */
    static View strip(final MainActivity a) {
        Flow f = new Flow(a, 8, 8);
        List<Item> items = stripItems();
        if (items.isEmpty()) {
            f.addView(addPill(a, "＋ 加入日期或計算天數"));
        } else {
            for (final Item it : items) {
                LinearLayout chip = Ui.row(a);
                chip.setBackground(Ui.shape(a, Ui.ACCENT_SOFT, 999, 0, 0));
                chip.setPadding(Ui.dp(a, 13), Ui.dp(a, 6), Ui.dp(a, 13), Ui.dp(a, 6));
                TextView name = Ui.tv(a, Model.s(it.sd, "name"), 12, Ui.CARD_INK, false);
                name.setSingleLine(true);
                name.setEllipsize(android.text.TextUtils.TruncateAt.END);
                name.setMaxWidth(Ui.dp(a, 110));
                chip.addView(name);
                chip.addView(Ui.tv(a, it.num, 13, Ui.ACCENT, true), Ui.gap(a, 7));
                final String id = Model.s(it.sd, "id");
                chip.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { openEdit(a, id, null); }
                });
                f.addView(chip);
            }
            f.addView(addPill(a, "＋"));
        }
        return f;
    }

    private static TextView addPill(final MainActivity a, String text) {
        TextView t = Ui.tv(a, text, 12, Ui.SOFT, false);
        t.setPadding(Ui.dp(a, 13), Ui.dp(a, 6), Ui.dp(a, 13), Ui.dp(a, 6));
        t.setBackground(Ui.dashed(a, 0, 999, Ui.BORDER, 1.5f));
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openManage(a); }
        });
        return t;
    }

    /** 週曆上方:白底方塊,上名稱、下大大的天數。 */
    static View boxes(final MainActivity a) {
        LinearLayout col = Ui.col(a);
        List<Item> items = stripItems();
        List<View> cells = new ArrayList<>();
        for (final Item it : items) {
            LinearLayout b = Ui.col(a);
            b.setBackground(Ui.shape(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
            b.setPadding(Ui.dp(a, 13), Ui.dp(a, 10), Ui.dp(a, 13), Ui.dp(a, 10));
            TextView name = Ui.tv(a, Model.s(it.sd, "name"), 11.5f, Ui.SOFT, false);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            b.addView(name);
            b.addView(Ui.tv(a, it.num, 16, Ui.ACCENT, true));
            final String id = Model.s(it.sd, "id");
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openEdit(a, id, null); }
            });
            cells.add(b);
        }
        TextView add = Ui.tv(a, items.isEmpty() ? "＋ 加入日期或計算天數" : "＋ 新增或管理", 12.5f, Ui.SOFT, true);
        add.setGravity(Gravity.CENTER);
        add.setMinimumHeight(Ui.dp(a, items.isEmpty() ? 46 : 52));
        add.setBackground(Ui.dashed(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openManage(a); }
        });
        if (items.isEmpty()) {
            col.addView(add, Ui.mw(a, 0));
        } else {
            cells.add(add);
            for (int i = 0; i < cells.size(); i += 2) {
                LinearLayout row = new LinearLayout(a);
                row.setOrientation(LinearLayout.HORIZONTAL);
                for (int k = 0; k < 2; k++) {
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                    if (k == 1) lp.leftMargin = Ui.dp(a, 8);
                    if (i + k < cells.size()) row.addView(cells.get(i + k), lp);
                    else row.addView(new View(a), lp);
                }
                col.addView(row, Ui.mw(a, i == 0 ? 0 : 8));
            }
        }
        return col;
    }

    /** 某一天詳細頁上方:當天的節日,以及每個計算天數那天是第幾天。 */
    static View detail(MainActivity a, String day) {
        On sp = on(day);
        LinearLayout box = Ui.col(a);
        int count = 0;
        for (JSONObject f : sp.festivals) {
            LinearLayout line = Ui.row(a);
            line.setBackground(Ui.shape(a, Ui.ACCENT_SOFT, 12, 0, 0));
            line.setPadding(Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8));
            line.addView(Ui.tv(a, Model.s(f, "name"), 12.5f, Ui.ACCENT, true));
            box.addView(line, Ui.mw(a, count++ == 0 ? 0 : 6));
        }
        for (JSONObject sd : all()) {
            if (isFestival(sd)) continue;
            int n = counterN(sd, day);
            Mark mk = null;
            for (Mark m : sp.marks) if (Model.s(m.sd, "id").equals(Model.s(sd, "id"))) mk = m;
            String badge = "";
            if (mk != null) {
                if ("start".equals(mk.type)) badge = "起點";
                else if ("anniv".equals(mk.type)) badge = (Integer.parseInt(day.substring(0, 4)) - Integer.parseInt(Model.s(sd, "date").substring(0, 4))) + " 週年";
                else badge = "整百天";
            }
            LinearLayout line = Ui.row(a);
            line.setBackground(Ui.shape(a, Ui.ACCENT_SOFT, 12, 0, 0));
            line.setPadding(Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8));
            line.addView(Ui.tv(a, Model.s(sd, "name"), 12.5f, Ui.CARD_INK, false));
            line.addView(Ui.tv(a, n >= 1 ? "第 " + n + " 天" : "還有 " + (1 - n) + " 天開始", 12.5f, Ui.ACCENT, true), Ui.gap(a, 8));
            if (!badge.isEmpty()) {
                View sp2 = new View(a);
                line.addView(sp2, new LinearLayout.LayoutParams(0, 1, 1f));
                line.addView(Ui.chip(a, badge, 10.5f, Ui.ON_ACCENT, Ui.ACCENT, true));
            }
            box.addView(line, Ui.mw(a, count++ == 0 ? 0 : 6));
        }
        if (count > 0) box.setPadding(0, Ui.dp(a, 10), 0, Ui.dp(a, 12));
        return box;
    }

    // ---------- 管理視窗 ----------

    /** 「特別的日子」清單視窗:每列點了可編輯,下方「＋ 新增」「完成」。 */
    static void openManage(final MainActivity a) {
        final Modal.Sheet s = Modal.sheet(a);
        s.box.addView(Ui.tv(a, "特別的日子", 16, Ui.CARD_INK, true));
        final LinearLayout list = Ui.col(a);
        s.box.addView(list, Ui.mw(a, 10));
        final Runnable[] render = new Runnable[1];
        render[0] = new Runnable() {
            @Override public void run() {
                list.removeAllViews();
                List<JSONObject> sds = all();
                if (sds.isEmpty()) {
                    TextView e = Ui.tv(a, "還沒有特別的日子。\n按下方「＋ 新增」,可以加生日、紀念日,或是計算在一起、養寵物已經過了幾天。", 13.5f, Ui.SOFT, false);
                    e.setGravity(Gravity.CENTER);
                    e.setLineSpacing(0, 1.3f);
                    e.setPadding(Ui.dp(a, 8), Ui.dp(a, 18), Ui.dp(a, 8), Ui.dp(a, 18));
                    list.addView(e);
                    return;
                }
                String today = Model.today();
                List<JSONObject> sorted = new ArrayList<>(sds);
                Collections.sort(sorted, new Comparator<JSONObject>() {
                    @Override public int compare(JSONObject x, JSONObject y) {
                        return (isFestival(x) ? 1 : 0) - (isFestival(y) ? 1 : 0);
                    }
                });
                for (final JSONObject sd : sorted) {
                    String num, sub;
                    if (isFestival(sd)) {
                        String nx = nextFestivalDate(sd, today);
                        num = nx != null ? (daysBetween(today, nx) == 0 ? "今天" : "還有 " + daysBetween(today, nx) + " 天") : "已過";
                        sub = Model.s(sd, "date") + (sd.optBoolean("yearly", false) ? "・每年" : "");
                    } else {
                        int n = counterN(sd, today);
                        num = n >= 1 ? "第 " + n + " 天" : "還有 " + (1 - n) + " 天";
                        sub = "從 " + Model.s(sd, "date") + " 起算";
                    }
                    LinearLayout row = Ui.row(a);
                    row.setBackground(Ui.shape(a, Ui.TASK_BG, 14, Ui.BORDER, 1.5f));
                    row.setPadding(Ui.dp(a, 14), Ui.dp(a, 11), Ui.dp(a, 14), Ui.dp(a, 11));
                    row.addView(Ui.chip(a, isFestival(sd) ? "日期" : "計算天數", 10.5f, Ui.ACCENT, Ui.ACCENT_SOFT, true));
                    LinearLayout main = Ui.col(a);
                    TextView t = Ui.tv(a, Model.s(sd, "name"), 13.5f, Ui.CARD_INK, true);
                    t.setSingleLine(true);
                    t.setEllipsize(android.text.TextUtils.TruncateAt.END);
                    main.addView(t);
                    main.addView(Ui.tv(a, sub, 11, Ui.SOFT, false));
                    row.addView(main, wlp(a, 10));
                    row.addView(Ui.tv(a, num, 13, Ui.ACCENT, true));
                    final String id = Model.s(sd, "id");
                    row.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { openEdit(a, id, render[0]); }
                    });
                    list.addView(row, Ui.mw(a, 8));
                }
            }
        };
        render[0].run();
        LinearLayout actions = Ui.row(a);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        actions.addView(Ui.btnGhost(a, "＋ 新增", new View.OnClickListener() {
            @Override public void onClick(View v) { openEdit(a, null, render[0]); }
        }));
        actions.addView(Ui.btnPrimary(a, "完成", new View.OnClickListener() {
            @Override public void onClick(View v) { s.dismiss(); }
        }), Ui.gap(a, 8));
        s.box.addView(actions, Ui.mw(a, 22));
        s.dialog.show();
    }

    private static LinearLayout.LayoutParams wlp(MainActivity a, float leftDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
        p.leftMargin = Ui.dp(a, leftDp);
        return p;
    }

    private static JSONObject find(String id) {
        if (id == null) return null;
        for (JSONObject o : Model.list("specialDays")) if (id.equals(Model.s(o, "id"))) return o;
        return null;
    }

    /** 新增/編輯視窗。afterChange 在存檔或刪除後呼叫(讓管理清單重畫),可為 null。 */
    static void openEdit(final MainActivity a, final String id, final Runnable afterChange) {
        final JSONObject sd = find(id);
        final String[] kind = {sd == null ? "festival" : Model.s(sd, "kind", "festival")};
        final Modal.Sheet s = Modal.sheet(a);
        s.box.addView(Ui.tv(a, sd != null ? "編輯特別的日子" : "新增特別的日子", 16, Ui.CARD_INK, true));

        // 類型
        final TextView kFestival = kindBtn(a, "日期"), kCount = kindBtn(a, "計算天數");
        LinearLayout kinds = Ui.row(a);
        kinds.addView(kFestival, new LinearLayout.LayoutParams(0, -2, 1f));
        kinds.addView(kCount, wlp(a, 8));
        final TextView hint = Ui.hint(a, "");
        LinearLayout kindBox = Ui.col(a);
        kindBox.addView(kinds);
        kindBox.addView(hint);
        s.box.addView(Ui.field(a, "類型", kindBox));

        final android.widget.EditText name = Ui.input(a, "", sd == null ? "" : Model.s(sd, "name"));
        s.box.addView(Ui.field(a, "名稱", name));

        final String[] date = {sd == null ? Model.today() : Model.s(sd, "date", Model.today())};
        final TextView dateLabel = Ui.tv(a, "", 12, Ui.SOFT, true);
        final TextView dateBtn = Ui.tv(a, date[0], 13.5f, Ui.CARD_INK, false);
        dateBtn.setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10));
        dateBtn.setBackground(Ui.shape(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
        dateBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Modal.pickDate(a, date[0], new Modal.StrCb() {
                    @Override public void on(String d) { date[0] = d; dateBtn.setText(d); }
                });
            }
        });
        LinearLayout dateBox = Ui.col(a);
        dateBox.addView(dateLabel);
        dateBox.addView(dateBtn, Ui.mw(a, 6));
        dateBox.setLayoutParams(Ui.mw(a, 15));
        s.box.addView(dateBox);

        final LinearLayout yearlyRow = Ui.row(a);
        yearlyRow.addView(Ui.tv(a, "每年重複", 13, Ui.CARD_INK, false), new LinearLayout.LayoutParams(0, -2, 1f));
        final View yearly = Ui.toggle(a, sd == null || sd.optBoolean("yearly", true), null);
        yearlyRow.addView(yearly);
        s.box.addView(yearlyRow, Ui.mw(a, 15));

        final Runnable update = new Runnable() {
            @Override public void run() {
                boolean fest = "festival".equals(kind[0]);
                paintKind(a, kFestival, fest);
                paintKind(a, kCount, !fest);
                hint.setText(fest ? "生日、紀念日、節日。可以設定每年重複。" : "從起算日開始算第幾天,例如在一起、養寵物。起算日那天是第 1 天。");
                name.setHint(fest ? "例如:媽媽生日、結婚紀念日" : "例如:在一起、養小白");
                dateLabel.setText(fest ? "哪一天" : "起算日");
                yearlyRow.setVisibility(fest ? View.VISIBLE : View.GONE);
            }
        };
        kFestival.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { kind[0] = "festival"; update.run(); }
        });
        kCount.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { kind[0] = "count"; update.run(); }
        });
        update.run();

        LinearLayout actions = Ui.row(a);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        if (sd != null) {
            actions.addView(Ui.btnDanger(a, "刪除", new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Modal.confirm(a, "確定要刪除「" + Model.s(sd, "name") + "」嗎?", null, "刪除", true, new Runnable() {
                        @Override public void run() {
                            s.dismiss();
                            Repo.del(a, "specialDays", id);
                            a.refreshCurrent();
                            if (afterChange != null) afterChange.run();
                        }
                    });
                }
            }));
            actions.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        }
        actions.addView(Ui.btnGhost(a, "取消", new View.OnClickListener() {
            @Override public void onClick(View v) { s.dismiss(); }
        }));
        actions.addView(Ui.btnPrimary(a, "儲存", new View.OnClickListener() {
            @Override public void onClick(View v) {
                String nm = name.getText().toString().trim();
                if (nm.length() > 30) nm = nm.substring(0, 30);
                if (nm.isEmpty()) { Ui.toast(a, "請輸入名稱。"); return; }
                if (!validYmd(date[0])) { Ui.toast(a, "請選擇正確的日期。"); return; }
                boolean yr = "festival".equals(kind[0]) && Ui.isOn(yearly);
                try {
                    if (sd != null) {
                        JSONObject set = new JSONObject();
                        set.put("kind", kind[0]);
                        set.put("name", nm);
                        set.put("date", date[0]);
                        set.put("yearly", yr);
                        Repo.patch(a, set, null, "specialDays", id);
                    } else {
                        JSONObject item = new JSONObject();
                        item.put("id", Repo.newId());
                        item.put("kind", kind[0]);
                        item.put("name", nm);
                        item.put("date", date[0]);
                        item.put("yearly", yr);
                        Repo.add(a, item, -1, "specialDays");
                    }
                } catch (JSONException ignore) { }
                s.dismiss();
                a.refreshCurrent();
                if (afterChange != null) afterChange.run();
            }
        }), Ui.gap(a, 8));
        s.box.addView(actions, Ui.mw(a, 22));
        s.dialog.show();
    }

    private static TextView kindBtn(MainActivity a, String label) {
        TextView t = Ui.tv(a, label, 12.5f, Ui.SOFT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(a, 6), Ui.dp(a, 10), Ui.dp(a, 6), Ui.dp(a, 10));
        t.setSingleLine(true);
        return t;
    }

    private static void paintKind(MainActivity a, TextView t, boolean on) {
        t.setTextColor(on ? Ui.ON_ACCENT : Ui.SOFT);
        t.setBackground(on ? Ui.shape(a, Ui.ACCENT, 999, Ui.ACCENT, 1.5f) : Ui.shape(a, Ui.SURFACE, 999, Ui.BORDER, 1.5f));
    }
}
