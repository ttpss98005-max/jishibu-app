package tw.jishibu.widget;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * 通用的資料操作引擎。所有畫面的修改都表示成「操作」(JSON),套到整份資料上。
 *
 * 路徑 path 是一串字串,例如 ["tasks","abc123","title"]:
 *   遇到物件就用欄位名稱往下走;遇到陣列就找「id 等於這個字串」的那一項。
 *
 * 操作:
 *   set    path, value          把路徑上的值設成 value(中間缺的物件會自動補)
 *   del    path                 刪掉路徑上的值(物件欄位,或陣列裡 id 符合的那一項)
 *   add    path, item[, index]  在 path 指到的陣列加入 item;已有同 id 就略過(重複套用結果一樣)
 *   patch  path, set{}, unset[] 修改路徑上那個物件(或陣列裡那一項)的某幾個欄位
 *   order  path, ids[]          把陣列依 ids 的順序重排(沒列到的接在後面,不會少)
 *
 * 每個操作都是「設成某個狀態」,重複套用結果一樣。
 * 套用時會記錄「刻意減少」的資料量,讓寫入前的安全檢查知道哪些減少是使用者要的。
 * archives(網頁版壓縮收納的舊資料)不能用一般路徑改:要改收納的舊項目由 Archive 負責(只重新壓縮被動到的那一年)。
 */
final class Doc {
    private Doc() {}

    /** 一批操作套用下來,各個頂層欄位「刻意減少」了多少資料量。 */
    static final class Stats {
        final Map<String, Integer> removed = new HashMap<>();
        /** 這批操作有動到的收納年份(其他年份的壓縮包必須一個字元都不能變)。 */
        final java.util.Set<String> archiveTouched = new java.util.HashSet<>();
        void remove(String root, int n) {
            if (n <= 0) return;
            Integer cur = removed.get(root);
            removed.put(root, (cur == null ? 0 : cur) + n);
        }
    }

    /** 這個值裡面一共有多少個節點(用來比較資料量,不是位元組)。 */
    static int nodes(Object v) {
        if (v == null || v == JSONObject.NULL) return 1;
        if (v instanceof JSONObject) {
            JSONObject o = (JSONObject) v;
            int n = 1;
            Iterator<String> it = o.keys();
            while (it.hasNext()) n += nodes(o.opt(it.next()));
            return n;
        }
        if (v instanceof JSONArray) {
            JSONArray a = (JSONArray) v;
            int n = 1;
            for (int i = 0; i < a.length(); i++) n += nodes(a.opt(i));
            return n;
        }
        return 1;
    }

    private static int idxOf(JSONArray a, String id) {
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && id.equals(Model.s(o, "id"))) return i;
        }
        return -1;
    }

    /** 往下走一步。找不到回 null。 */
    private static Object child(Object node, String seg) {
        if (node instanceof JSONObject) {
            Object v = ((JSONObject) node).opt(seg);
            return v;
        }
        if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            int i = idxOf(a, seg);
            return i < 0 ? null : a.opt(i);
        }
        return null;
    }

    private static String[] path(JSONObject op) {
        JSONArray p = op.optJSONArray("path");
        if (p == null || p.length() == 0) return null;
        String[] r = new String[p.length()];
        for (int i = 0; i < r.length; i++) r[i] = p.optString(i);
        return r;
    }

    /** 走到 path[0..n-1] 的節點;createObjects 為真時,缺的物件欄位會補成 {}。 */
    private static Object walk(JSONObject root, String[] p, int n, boolean create) throws JSONException {
        Object node = root;
        for (int i = 0; i < n; i++) {
            Object next = child(node, p[i]);
            if (next == null || next == JSONObject.NULL) {
                if (create && node instanceof JSONObject) {
                    JSONObject made = new JSONObject();
                    ((JSONObject) node).put(p[i], made);
                    next = made;
                } else {
                    return null;
                }
            } else if (create && i == 1 && "habitLogs".equals(p[0]) && next instanceof JSONArray && isLegacyDayList((JSONArray) next) && node instanceof JSONObject) {
                // 很舊的習慣紀錄格式:只存打過卡的日期字串。要往下寫時先轉成 {日期:true}
                JSONArray old = (JSONArray) next;
                JSONObject conv = new JSONObject();
                for (int k = 0; k < old.length(); k++) conv.put(old.optString(k), true);
                ((JSONObject) node).put(p[i], conv);
                next = conv;
            }
            node = next;
        }
        return node;
    }

    /** 把陣列 a 的內容換成 b 的內容(a 本身保留,別處的參照不會失效)。 */
    private static void replace(JSONArray a, JSONArray b) {
        while (a.length() > 0) a.remove(a.length() - 1);
        for (int k = 0; k < b.length(); k++) a.put(b.opt(k));
    }

    private static boolean isLegacyDayList(JSONArray a) {
        for (int i = 0; i < a.length(); i++) if (!(a.opt(i) instanceof String)) return false;
        return true;
    }

    private static void check(String[] p) throws JSONException {
        if (p == null) throw new JSONException("沒有路徑");
        if ("archives".equals(p[0])) throw new JSONException("不可以改動收納的舊資料");
    }

    /** 把一個操作套到資料上。路徑找不到時安靜略過(例如那一項已經被別的裝置刪掉)。 */
    static void apply(JSONObject root, JSONObject op, Stats st) throws JSONException {
        String kind = op.optString("op");
        String[] p = path(op);
        if ("set".equals(kind)) {
            check(p);
            Object parent = walk(root, p, p.length - 1, true);
            String last = p[p.length - 1];
            Object val = op.opt("value");
            if (val == null) val = JSONObject.NULL;
            Object old = child(parent, last);
            if (parent instanceof JSONObject) {
                ((JSONObject) parent).put(last, val);
            } else if (parent instanceof JSONArray) {
                JSONArray a = (JSONArray) parent;
                int i = idxOf(a, last);
                if (i < 0) return;
                a.put(i, val);
            } else {
                return;
            }
            if (st != null && old != null) st.remove(p[0], nodes(old) - nodes(val));
        } else if ("del".equals(kind)) {
            check(p);
            Object parent = walk(root, p, p.length - 1, false);
            String last = p[p.length - 1];
            Object old = child(parent, last);
            if (old == null) return;
            if (parent instanceof JSONObject) {
                ((JSONObject) parent).remove(last);
            } else if (parent instanceof JSONArray) {
                JSONArray a = (JSONArray) parent;
                int i = idxOf(a, last);
                if (i < 0) return;
                JSONArray na = new JSONArray();
                for (int k = 0; k < a.length(); k++) if (k != i) na.put(a.opt(k));
                replace(a, na);
            }
            if (st != null) st.remove(p[0], nodes(old));
        } else if ("add".equals(kind)) {
            check(p);
            Object node = walk(root, p, p.length, true);
            JSONObject item = op.optJSONObject("item");
            if (item == null) return;
            if (!(node instanceof JSONArray)) {
                if (node instanceof JSONObject && ((JSONObject) node).length() == 0 && p.length >= 1) {
                    // 剛剛自動補出來的空物件其實應該是陣列(例如全新的欄位)
                    Object parent = walk(root, p, p.length - 1, false);
                    if (parent instanceof JSONObject) {
                        JSONArray na = new JSONArray();
                        ((JSONObject) parent).put(p[p.length - 1], na);
                        node = na;
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
            JSONArray a = (JSONArray) node;
            String id = Model.s(item, "id");
            if (!id.isEmpty() && idxOf(a, id) >= 0) return;
            int index = op.optInt("index", -1);
            if (index < 0 || index >= a.length()) {
                a.put(item);
            } else {
                JSONArray na = new JSONArray();
                for (int k = 0; k < a.length(); k++) {
                    if (k == index) na.put(item);
                    na.put(a.opt(k));
                }
                replace(a, na);
            }
        } else if ("patch".equals(kind)) {
            check(p);
            Object node = walk(root, p, p.length, false);
            if (!(node instanceof JSONObject)) return;
            JSONObject o = (JSONObject) node;
            JSONObject set = op.optJSONObject("set");
            if (set != null) {
                Iterator<String> it = set.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    Object old = o.opt(k);
                    Object nv = set.opt(k);
                    o.put(k, nv);
                    if (st != null && old != null) st.remove(p[0], nodes(old) - nodes(nv));
                }
            }
            JSONArray unset = op.optJSONArray("unset");
            if (unset != null) {
                for (int i = 0; i < unset.length(); i++) {
                    String k = unset.optString(i);
                    Object old = o.opt(k);
                    if (old != null) {
                        o.remove(k);
                        if (st != null) st.remove(p[0], nodes(old));
                    }
                }
            }
        } else if ("order".equals(kind)) {
            check(p);
            Object node = walk(root, p, p.length, false);
            JSONArray ids = op.optJSONArray("ids");
            if (!(node instanceof JSONArray) || ids == null) return;
            JSONArray a = (JSONArray) node;
            JSONArray out = new JSONArray();
            boolean[] used = new boolean[a.length()];
            for (int i = 0; i < ids.length(); i++) {
                int k = idxOf(a, ids.optString(i));
                if (k >= 0 && !used[k]) { used[k] = true; out.put(a.opt(k)); }
            }
            for (int k = 0; k < a.length(); k++) if (!used[k]) out.put(a.opt(k));
            replace(a, out);
        }
    }

    /**
     * 寫入前的安全檢查。before = 套用前(雲端最新版),after = 套用後。
     * 任何頂層欄位不見了、或資料量比「刻意減少的量」更少,就回傳原因(null 表示通過)。
     */
    static String guard(JSONObject before, JSONObject after, Stats st) {
        Iterator<String> it = before.keys();
        while (it.hasNext()) {
            String k = it.next();
            if ("archives".equals(k)) {
                String bad = guardArchives(before.optJSONObject(k), after.optJSONObject(k), st);
                if (bad != null) return bad;
                continue;
            }
            if (!after.has(k)) return "欄位「" + k + "」不見了";
            int b = nodes(before.opt(k)), a = nodes(after.opt(k));
            Integer rm = st == null ? null : st.removed.get(k);
            int allowed = rm == null ? 0 : rm;
            if (a < b - allowed) return "「" + k + "」的資料量從 " + b + " 變成 " + a + ",超過預期";
        }
        if (after.has("archives") && !before.has("archives")) return "憑空多出收納的舊資料";
        return null;
    }

    /** 收納的舊資料:沒被動到的年份必須完全一樣;被動到的年份可以變,但資料量不能比「刻意減少的量」更少,也不能憑空多出年份。 */
    private static String guardArchives(JSONObject b, JSONObject a, Stats st) {
        if (b == null) b = new JSONObject();
        if (a == null) a = new JSONObject();
        int before = 0, after = 0;
        Iterator<String> it = a.keys();
        while (it.hasNext()) if (!b.has(it.next())) return "收納的舊資料多出新的年份";
        it = b.keys();
        while (it.hasNext()) {
            String y = it.next();
            boolean touched = st != null && st.archiveTouched.contains(y);
            boolean same = a.has(y) && sameJson(b.opt(y), a.opt(y));
            if (same) continue;
            if (!touched) return "收納的舊資料被改動";
            try {
                before += Archive.items(new JSONObject(Backup.gunzip(b.optString(y))));
                if (a.has(y)) after += Archive.items(new JSONObject(Backup.gunzip(a.optString(y))));
            } catch (Exception e) {
                return "收納的舊資料解不開";
            }
        }
        Integer rm = st == null ? null : st.removed.get("archives");
        int allowed = rm == null ? 0 : rm;
        if (after < before - allowed) return "收納的舊資料量從 " + before + " 變成 " + after + ",超過預期";
        return null;
    }

    private static boolean sameJson(Object a, Object b) {
        return String.valueOf(a).equals(String.valueOf(b));
    }
}
