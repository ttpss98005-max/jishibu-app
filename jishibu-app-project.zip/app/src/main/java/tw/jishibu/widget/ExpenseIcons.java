package tw.jishibu.widget;

import android.content.Context;

import java.util.HashMap;
import java.util.Map;

/** 記帳用的圖示(網頁版 ICONS,SVG 原樣照抄)與預設分類。 */
final class ExpenseIcons {
    private ExpenseIcons() {}

    private static final Map<String, String> MAP = new HashMap<>();
    static {
        MAP.put("food", "<path d=\"M5 3v5a2 2 0 0 0 4 0V3M7 10v11\"/><path d=\"M17 21V3c-2.2 1.2-3.5 3.8-3.5 7 0 1.6 1.4 3 3.5 3\"/>");
        MAP.put("transport", "<rect x=\"5\" y=\"3.5\" width=\"14\" height=\"13\" rx=\"2.2\"/><path d=\"M5 10.5h14M8 16.5V19M16 16.5V19\"/><circle cx=\"9\" cy=\"13.6\" r=\"1\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"15\" cy=\"13.6\" r=\"1\" fill=\"currentColor\" stroke=\"none\"/>");
        MAP.put("shopping", "<path d=\"M5 8h14l-1 12H6L5 8z\"/><path d=\"M9 8V6.5a3 3 0 0 1 6 0V8\"/>");
        MAP.put("entertainment", "<rect x=\"3\" y=\"8\" width=\"18\" height=\"10\" rx=\"4\"/><path d=\"M8 11v4M6 13h4\"/><circle cx=\"15.5\" cy=\"12\" r=\"1\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"17.5\" cy=\"14.3\" r=\"1\" fill=\"currentColor\" stroke=\"none\"/>");
        MAP.put("home", "<path d=\"M4 11l8-7 8 7\"/><path d=\"M6 10v10h12V10\"/><path d=\"M10 20v-5h4v5\"/>");
        MAP.put("medical", "<rect x=\"2.5\" y=\"8.5\" width=\"19\" height=\"7\" rx=\"3.5\" transform=\"rotate(-45 12 12)\"/><path d=\"M12 8.5v7\" transform=\"rotate(-45 12 12)\"/>");
        MAP.put("other", "<circle cx=\"6\" cy=\"12\" r=\"1.5\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"12\" cy=\"12\" r=\"1.5\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"18\" cy=\"12\" r=\"1.5\" fill=\"currentColor\" stroke=\"none\"/>");
        MAP.put("salary", "<rect x=\"3\" y=\"6.5\" width=\"18\" height=\"11\" rx=\"2\"/><circle cx=\"12\" cy=\"12\" r=\"2.4\"/><circle cx=\"6.5\" cy=\"9.6\" r=\".9\" fill=\"currentColor\" stroke=\"none\"/><circle cx=\"17.5\" cy=\"14.4\" r=\".9\" fill=\"currentColor\" stroke=\"none\"/>");
        MAP.put("bonus", "<rect x=\"4\" y=\"10.5\" width=\"16\" height=\"9.5\" rx=\"1.5\"/><rect x=\"3\" y=\"7\" width=\"18\" height=\"3.5\" rx=\"1\"/><path d=\"M12 7v13\"/><path d=\"M12 7c-1-3-4.5-3-4.5-1s3 2 4.5 1zM12 7c1-3 4.5-3 4.5-1s-3 2-4.5 1z\"/>");
        MAP.put("other_income", "<circle cx=\"12\" cy=\"12\" r=\"8.5\"/><path d=\"M12 8v8M8 12h8\"/>");
        MAP.put("scale", "<path d=\"M12 4v16M7 20h10\"/><path d=\"M5 7.5h14\"/><path d=\"M5 7.5l-2.5 6a3 3 0 0 0 5 0L5 7.5zM19 7.5l-2.5 6a3 3 0 0 0 5 0L19 7.5z\"/>");
        MAP.put("bank", "<path d=\"M3 9l9-5 9 5\"/><path d=\"M5.5 9v8.5M10 9v8.5M14 9v8.5M18.5 9v8.5\"/><path d=\"M3 20h18\"/>");
        MAP.put("wallet", "<path d=\"M4 8V6.5A1.5 1.5 0 0 1 5.5 5H17v3\"/><rect x=\"3.5\" y=\"8\" width=\"17\" height=\"11.5\" rx=\"2\"/><circle cx=\"16.5\" cy=\"13.7\" r=\"1\" fill=\"currentColor\" stroke=\"none\"/>");
        MAP.put("pet", "<circle cx=\"8\" cy=\"7\" r=\"1.8\"/><circle cx=\"16\" cy=\"7\" r=\"1.8\"/><circle cx=\"5\" cy=\"12\" r=\"1.8\"/><circle cx=\"19\" cy=\"12\" r=\"1.8\"/><path d=\"M12 13c-3 0-5.5 2-5.5 4.5S9 20 12 20s5.5-.5 5.5-2.5S15 13 12 13z\"/>");
        MAP.put("travel", "<path d=\"M3 13l18-7-7 18-2.5-7.5L3 13z\"/>");
        MAP.put("education", "<path d=\"M3 6.5c3-1.5 6-1.5 9 0v12c-3-1.5-6-1.5-9 0v-12z\"/><path d=\"M21 6.5c-3-1.5-6-1.5-9 0v12c3-1.5 6-1.5 9 0v-12z\"/>");
        MAP.put("utility", "<path d=\"M13 2 4 14h6l-1 8 9-12h-6l1-8z\" fill=\"currentColor\" stroke=\"none\"/>");
        MAP.put("gift", "<rect x=\"4\" y=\"9.5\" width=\"16\" height=\"10\" rx=\"1.5\"/><rect x=\"3\" y=\"6.5\" width=\"18\" height=\"3.5\" rx=\"1\"/><path d=\"M12 6.5v13\"/><path d=\"M12 6.5c-1-3-4.5-3-4.5-1s3 2 4.5 1zM12 6.5c1-3 4.5-3 4.5-1s-3 2-4.5 1z\"/>");
        MAP.put("transfer", "<path d=\"M3 8h14M13 4l4 4-4 4\"/><path d=\"M21 16H7M11 12l-4 4 4 4\"/>");
    }

    static String svg(String key) {
        String s = MAP.get(key);
        return s != null ? s : MAP.get("other");
    }

    static SvgIcon icon(Context c, String key, int sizeDp, int color) {
        return Icons.line(c, svg(key), sizeDp, color);
    }

    /** 新增分類時可選的圖示。 */
    static final String[] CHOICES = {"food", "transport", "shopping", "entertainment", "home", "medical", "pet", "travel", "education", "utility", "gift", "other"};
}
