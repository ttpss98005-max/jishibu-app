package tw.jishibu.widget;

/** 跟記事簿網頁用同一個 Firebase 專案(這兩個值本來就寫在網頁裡,不是祕密)。 */
final class Config {
    static final String API_KEY = "AIzaSyBeztpgvYaM-ehRP0rh-qKwuY2Xs3_sNWI";
    static final String PROJECT_ID = "notebook-app-509000";
    private Config() {}
}
