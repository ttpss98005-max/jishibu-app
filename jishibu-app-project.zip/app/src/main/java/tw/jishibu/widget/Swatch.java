package tw.jishibu.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** 配色卡上方的三色條(背景/文字/強調色,強調色占 32%),網頁版 .palette-swatch。 */
final class Swatch extends View {
    private final int bg, ink, accent;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int heightPx, radiusPx;

    Swatch(Context c, int bg, int ink, int accent) {
        super(c);
        this.bg = bg;
        this.ink = ink;
        this.accent = accent;
        heightPx = Ui.dp(c, 28);
        radiusPx = Ui.dp(c, 10);
    }

    @Override protected void onMeasure(int w, int h) {
        setMeasuredDimension(MeasureSpec.getSize(w), heightPx);
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        RectF all = new RectF(0, 0, w, h);
        Path clip = new Path();
        clip.addRoundRect(all, radiusPx, radiusPx, Path.Direction.CW);
        c.save();
        c.clipPath(clip);
        p.setStyle(Paint.Style.FILL);
        float seg = w * 0.34f;
        p.setColor(bg);
        c.drawRect(0, 0, seg, h, p);
        p.setColor(ink);
        c.drawRect(seg, 0, seg * 2, h, p);
        p.setColor(accent);
        c.drawRect(seg * 2, 0, w, h, p);
        c.restore();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f);
        p.setColor(0x0F000000);
        c.drawRoundRect(new RectF(0.5f, 0.5f, w - 0.5f, h - 0.5f), radiusPx, radiusPx, p);
    }
}
