package tw.jishibu.widget;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

/**
 * 月曆的一週:第 0 列是日期格(7 欄),下面 lanes 列是時段方塊(每列固定高)。
 * 子元件用 LP 指定從第幾欄起、佔幾欄、從第幾列到第幾列(不含)。沒有時段的日期格可以一路往下加長,把空白填滿。
 * 欄寬 = 整行寬 / 7,每格左右各留 3dp(跟星期列對齊)。
 */
final class WeekGrid extends ViewGroup {
    static final class LP extends ViewGroup.LayoutParams {
        final int c0, span, r0, r1;
        LP(int c0, int span, int r0, int r1) {
            super(-1, -1);
            this.c0 = c0; this.span = span; this.r0 = r0; this.r1 = r1;
        }
    }

    private final int lanes, row0H, laneH, vgap, side;

    WeekGrid(Context c, int lanes, float row0Dp) {
        super(c);
        this.lanes = lanes;
        this.row0H = Ui.dp(c, row0Dp);
        this.laneH = Ui.dp(c, 22);
        this.vgap = Ui.dp(c, 5);
        this.side = Ui.dp(c, 3);
    }

    private int rowTop(int r) { return r == 0 ? 0 : row0H + vgap + (r - 1) * (laneH + vgap); }

    private int rowBottom(int r) { return r == 0 ? row0H : rowTop(r) + laneH; }

    @Override protected boolean checkLayoutParams(ViewGroup.LayoutParams p) { return p instanceof LP; }

    @Override protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        float pitch = w / 7f;
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            LP lp = (LP) v.getLayoutParams();
            int cw = Math.round((lp.c0 + lp.span) * pitch - side) - Math.round(lp.c0 * pitch + side);
            int ch = rowBottom(lp.r1 - 1) - rowTop(lp.r0);
            v.measure(MeasureSpec.makeMeasureSpec(Math.max(0, cw), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(Math.max(0, ch), MeasureSpec.EXACTLY));
        }
        setMeasuredDimension(w, rowBottom(lanes));
    }

    @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
        float pitch = (r - l) / 7f;
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            LP lp = (LP) v.getLayoutParams();
            int x0 = Math.round(lp.c0 * pitch + side), x1 = Math.round((lp.c0 + lp.span) * pitch - side);
            v.layout(x0, rowTop(lp.r0), x1, rowBottom(lp.r1 - 1));
        }
    }
}
