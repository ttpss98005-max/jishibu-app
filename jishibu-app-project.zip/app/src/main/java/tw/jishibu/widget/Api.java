package tw.jishibu.widget;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/** 用網頁同一個帳號的登入憑證,直接讀寫 Firestore(REST,不需要任何外部套件)。 */
final class Api {
    private Api() {}

    static final class Doc {
        final String value;
        final String updateTime;
        Doc(String value, String updateTime) { this.value = value; this.updateTime = updateTime; }
    }

    /** 寫入時雲端資料已經被別人改過。 */
    static final class Conflict extends IOException {
        Conflict(String m) { super(m); }
    }

    private static String http(String method, String url, String body, String contentType,
                               String bearer, String referer) throws IOException {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        try {
            h.setConnectTimeout(10000);
            h.setReadTimeout(20000);
            h.setRequestMethod(method);
            if (referer != null && !referer.isEmpty()) h.setRequestProperty("Referer", referer);
            if (bearer != null) h.setRequestProperty("Authorization", "Bearer " + bearer);
            if (body != null) {
                h.setDoOutput(true);
                h.setRequestProperty("Content-Type", contentType);
                OutputStream os = h.getOutputStream();
                os.write(body.getBytes("UTF-8"));
                os.close();
            }
            int code = h.getResponseCode();
            InputStream in = code >= 400 ? h.getErrorStream() : h.getInputStream();
            String text = "";
            if (in != null) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                in.close();
                text = bo.toString("UTF-8");
            }
            if (code >= 400) {
                String snip = text.length() > 300 ? text.substring(0, 300) : text;
                throw new IOException("HTTP " + code + " " + snip);
            }
            return text;
        } finally {
            h.disconnect();
        }
    }

    /** 取得有效的 ID token;快過期就用 refresh token 換新的。 */
    static String idToken(Context c) throws Exception {
        String tok = Store.idToken(c);
        if (!tok.isEmpty() && System.currentTimeMillis() < Store.idExp(c) - 60000L) return tok;
        String body = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(Store.refreshToken(c), "UTF-8");
        String res = http("POST", "https://securetoken.googleapis.com/v1/token?key=" + Config.API_KEY,
                body, "application/x-www-form-urlencoded", null, Store.origin(c));
        JSONObject o = new JSONObject(res);
        String id = o.getString("id_token");
        long secs = Long.parseLong(o.optString("expires_in", "3600"));
        Store.saveToken(c, id, System.currentTimeMillis() + secs * 1000L, o.optString("refresh_token", ""));
        return id;
    }

    /** Google 登入拿到的 ID token 換成 Firebase 登入憑證。回傳 {idToken, refreshToken, email, expiresInSeconds}。 */
    static String[] signInWithGoogle(String googleIdToken, String origin) throws Exception {
        JSONObject b = new JSONObject();
        b.put("postBody", "id_token=" + URLEncoder.encode(googleIdToken, "UTF-8") + "&providerId=google.com");
        b.put("requestUri", "http://localhost");
        b.put("returnIdpCredential", true);
        b.put("returnSecureToken", true);
        String res = http("POST", "https://identitytoolkit.googleapis.com/v1/accounts:signInWithIdp?key=" + Config.API_KEY,
                b.toString(), "application/json", null, origin);
        JSONObject o = new JSONObject(res);
        return new String[]{o.getString("idToken"), o.getString("refreshToken"), o.optString("email", ""), o.optString("expiresIn", "3600")};
    }

    /** 這個資料位置在雲端有沒有資料(不存在回 false,其他錯誤丟出例外)。 */
    static boolean docExists(String idToken, String key, String origin) throws Exception {
        String url = "https://firestore.googleapis.com/v1/projects/" + Config.PROJECT_ID
                + "/databases/(default)/documents/userdata/" + URLEncoder.encode(key, "UTF-8");
        try {
            http("GET", url, null, null, idToken, origin);
            return true;
        } catch (IOException e) {
            String m = String.valueOf(e.getMessage());
            if (m.contains("HTTP 404") || m.contains("NOT_FOUND")) return false;
            throw e;
        }
    }

    private static String docName(Context c) {
        return "projects/" + Config.PROJECT_ID + "/databases/(default)/documents/userdata/" + Store.key(c);
    }

    /** 讀取記事簿那份資料(JSON 文字)和它的更新時間。 */
    static Doc getDoc(Context c) throws Exception {
        String id = idToken(c);
        String url = "https://firestore.googleapis.com/v1/projects/" + Config.PROJECT_ID
                + "/databases/(default)/documents/userdata/" + URLEncoder.encode(Store.key(c), "UTF-8");
        String res = http("GET", url, null, null, id, Store.origin(c));
        JSONObject o = new JSONObject(res);
        String v = o.getJSONObject("fields").getJSONObject("value").getString("stringValue");
        return new Doc(v, o.optString("updateTime", ""));
    }

    /**
     * 寫回資料。只有在雲端文件還停在 updateTime 那個版本時才會成功(否則丟出 Conflict),
     * 這樣不會蓋掉網頁版或別台手機剛存的內容。backupLabel 不是 null 時,同一個動作裡順便把寫入前的版本備份到 history。
     * 回傳新的 updateTime。
     */
    static String commit(Context c, String newValue, String updateTime, String backupLabel, String backupValue) throws Exception {
        String id = idToken(c);
        String name = docName(c);
        JSONArray writes = new JSONArray();
        if (backupLabel != null) {
            JSONObject f = new JSONObject();
            f.put("value", new JSONObject().put("stringValue", backupValue));
            f.put("backedUpAt", new JSONObject().put("integerValue", String.valueOf(System.currentTimeMillis())));
            f.put("label", new JSONObject().put("stringValue", backupLabel));
            writes.put(new JSONObject().put("update", new JSONObject().put("name", name + "/history/" + backupLabel).put("fields", f)));
        }
        JSONObject mf = new JSONObject().put("value", new JSONObject().put("stringValue", newValue));
        JSONObject w = new JSONObject();
        w.put("update", new JSONObject().put("name", name).put("fields", mf));
        w.put("updateMask", new JSONObject().put("fieldPaths", new JSONArray().put("value")));
        w.put("currentDocument", new JSONObject().put("updateTime", updateTime));
        writes.put(w);
        String body = new JSONObject().put("writes", writes).toString();
        String url = "https://firestore.googleapis.com/v1/projects/" + Config.PROJECT_ID + "/databases/(default)/documents:commit";
        String res;
        try {
            res = http("POST", url, body, "application/json", id, Store.origin(c));
        } catch (IOException e) {
            String m = String.valueOf(e.getMessage());
            if (m.contains("FAILED_PRECONDITION") || m.contains("ABORTED") || m.contains("HTTP 409")) throw new Conflict(m);
            throw e;
        }
        JSONObject r = new JSONObject(res);
        JSONArray wr = r.optJSONArray("writeResults");
        if (wr != null && wr.length() > 0) return wr.getJSONObject(wr.length() - 1).optString("updateTime", "");
        return "";
    }

    /** 直接送一批 Firestore 寫入(用 commit,所以更新、刪除都用 POST)。 */
    static void commitWrites(Context c, JSONArray writes) throws Exception {
        String id = idToken(c);
        String body = new JSONObject().put("writes", writes).toString();
        String url = "https://firestore.googleapis.com/v1/projects/" + Config.PROJECT_ID + "/databases/(default)/documents:commit";
        http("POST", url, body, "application/json", id, Store.origin(c));
    }

    /** 完整名稱:projects/.../documents/<集合>/<文件>。 */
    static String docPath(String collection, String docId) {
        return "projects/" + Config.PROJECT_ID + "/databases/(default)/documents/" + collection + "/" + docId;
    }

    /** 整份覆蓋(跟網頁版的 set 一樣)。fields 用 Firestore 的值格式。 */
    static void setDoc(Context c, String collection, String docId, JSONObject fields) throws Exception {
        JSONArray w = new JSONArray();
        w.put(new JSONObject().put("update", new JSONObject().put("name", docPath(collection, docId)).put("fields", fields)));
        commitWrites(c, w);
    }

    static void deleteDoc(Context c, String collection, String docId) throws Exception {
        JSONArray w = new JSONArray();
        w.put(new JSONObject().put("delete", docPath(collection, docId)));
        commitWrites(c, w);
    }

    static JSONObject str(String v) throws org.json.JSONException { return new JSONObject().put("stringValue", v); }
    static JSONObject integer(long v) throws org.json.JSONException { return new JSONObject().put("integerValue", String.valueOf(v)); }
    static JSONObject bool(boolean v) throws org.json.JSONException { return new JSONObject().put("booleanValue", v); }
    static JSONObject nul() throws org.json.JSONException { return new JSONObject().put("nullValue", JSONObject.NULL); }
}
