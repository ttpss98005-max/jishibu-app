package tw.jishibu.widget;

/** 桌面小工具:Notes(內容和更新都在 Widgets)。 */
public class NotesWidget extends Widgets.Base {
    @Override int kind() { return Widgets.NOTES; }
}
