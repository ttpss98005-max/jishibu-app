package tw.jishibu.widget;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 表單建構器:一欄一欄加,最後 view() 拿到整個表單的 View,值用各欄位回傳的 handle 讀。
 * 例:
 *   Form f = new Form(a);
 *   Form.Text title = f.text("標題", "", "輸入標題");
 *   Form.Pick cat = f.pick("分類", names, 0);
 *   Form.Date due = f.date("到期日", "");
 *   Modal.show(a, "新增事項", f.view(), "新增", () -> { ... title.get() ... return true; });
 */
final class Form {
    private final Activity a;
    private final LinearLayout box;

    Form(Activity a) {
        this.a = a;
        box = Ui.col(a);
    }

    View view() { return box; }

    void add(View v) { box.addView(v); }

    // ---- 欄位 ----

    static final class Text {
        final EditText edit;
        Text(EditText e) { edit = e; }
        String get() { return edit.getText().toString().trim(); }
        double num(double def) {
            try { return Double.parseDouble(get()); } catch (NumberFormatException e) { return def; }
        }
    }

    Text text(String label, String value, String hint) {
        EditText e = Ui.input(a, hint, value);
        box.addView(Ui.field(a, label, e));
        return new Text(e);
    }

    Text multiline(String label, String value, String hint, int lines) {
        EditText e = Ui.multiline(a, hint, value, lines);
        box.addView(Ui.field(a, label, e));
        return new Text(e);
    }

    Text number(String label, String value, String hint, boolean decimal) {
        EditText e = Ui.numberInput(a, hint, value, decimal);
        box.addView(Ui.field(a, label, e));
        return new Text(e);
    }

    /** 日期欄:點了跳出日期選擇。get() 回 yyyy-MM-dd 或空字串。allowClear 為真時多一個「清除」。 */
    static final class Date {
        String value;
        TextView label;
        String get() { return value == null ? "" : value; }
    }

    Date date(String label, String value) {
        return date(label, value, "選擇日期", true);
    }

    Date date(String label, String value, final String emptyText, boolean allowClear) {
        final Date d = new Date();
        d.value = value == null ? "" : value;
        final TextView t = Ui.tv(a, d.value.isEmpty() ? emptyText : d.value, 13.5f, Ui.CARD_INK, false);
        t.setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10));
        t.setBackground(Ui.shape(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
        d.label = t;
        LinearLayout row = Ui.row(a);
        row.addView(t, Ui.weight(1));
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Modal.pickDate(a, d.value, new Modal.StrCb() {
                    @Override public void on(String s) { d.value = s; t.setText(s); }
                });
            }
        });
        if (allowClear) {
            row.addView(Ui.textBtn(a, "清除", new View.OnClickListener() {
                @Override public void onClick(View v) { d.value = ""; t.setText(emptyText); }
            }), Ui.gap(a, 6));
        }
        box.addView(Ui.field(a, label, row));
        return d;
    }

    /** 時間欄(HH:mm)。 */
    Date time(String label, String value) {
        final Date d = new Date();
        d.value = value == null ? "" : value;
        final TextView t = Ui.tv(a, d.value.isEmpty() ? "選擇時間" : d.value, 13.5f, Ui.CARD_INK, false);
        t.setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10));
        t.setBackground(Ui.shape(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
        d.label = t;
        LinearLayout row = Ui.row(a);
        row.addView(t, Ui.weight(1));
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Modal.pickTime(a, d.value, new Modal.StrCb() {
                    @Override public void on(String s) { d.value = s; t.setText(s); }
                });
            }
        });
        row.addView(Ui.textBtn(a, "清除", new View.OnClickListener() {
            @Override public void onClick(View v) { d.value = ""; t.setText("選擇時間"); }
        }), Ui.gap(a, 6));
        box.addView(Ui.field(a, label, row));
        return d;
    }

    /** 一個「時間」開關欄(跟事項的時間欄一樣):關著就是沒有提醒時間(get() 回空字串),打開預設 08:00。 */
    Date timeSwitch(String label, String value) {
        final Date d = new Date();
        final String[] last = { Model.isHm(value) ? value : "08:00" };
        final boolean[] on = { Model.isHm(value) };
        d.value = on[0] ? value : "";
        final LinearLayout col = Ui.col(a);
        final TextView val = Ui.tv(a, "", 13.5f, Ui.CARD_INK, false);
        val.setPadding(Ui.dp(a, 12), Ui.dp(a, 9), Ui.dp(a, 12), Ui.dp(a, 9));
        val.setBackground(Ui.shape(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
        final View sw = Ui.toggle(a, on[0], null);
        final Runnable paint = new Runnable() {
            @Override public void run() {
                d.value = on[0] ? last[0] : "";
                val.setText(on[0] ? last[0] : "選擇時間");
                col.setBackground(on[0] ? Ui.shape(a, Ui.ACCENT_SOFT, 14, 0, 0) : Ui.dashed(a, 0, 14, Ui.BORDER, 1.5f));
                col.setAlpha(on[0] ? 1f : 0.6f);
                Ui.setOn(sw, on[0]);
            }
        };
        setToggleCb(sw, new Ui.BoolCb() {
            @Override public void on(boolean v) { on[0] = v; paint.run(); }
        });
        val.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!on[0]) return;
                Modal.pickTime(a, last[0], new Modal.StrCb() {
                    @Override public void on(String s) { last[0] = s; paint.run(); }
                });
            }
        });
        fillCol(col, label, sw, val);
        LinearLayout both = Ui.row(a);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        l2.leftMargin = Ui.dp(a, 10);
        both.addView(col, l1);
        l2.height = 1;
        both.addView(new View(a), l2);
        both.setLayoutParams(Ui.mw(a, 15));
        box.addView(both);
        paint.run();
        return d;
    }

    /**
     * 事項的「日期 → 時間 → 提醒」:日期、時間左右並排,各有一個開關;日期開了才能開時間和提醒,
     * 日期一關,時間和提醒跟著關。提醒只畫一個鈴鐺圖示加開關。
     * 時間開了但只設日期的話,提醒會在當天早上 8:00。
     */
    static final class Dt {
        boolean dOn, tOn, rOn;
        String date = "", time = "";
        /** 存進資料的值:沒開就是空字串 / false。 */
        String dueDate() { return dOn ? date : ""; }
        String dueTime() { return dOn && tOn ? time : ""; }
        boolean reminder() { return dOn && rOn; }
    }

    Dt dateTime(String date, String time, boolean reminder) {
        final Dt d = new Dt();
        d.dOn = Model.isDay(date);
        d.date = d.dOn ? date : "";
        d.tOn = d.dOn && Model.isHm(time);
        d.time = d.tOn ? time : "";
        d.rOn = d.dOn && reminder;

        final LinearLayout dCol = Ui.col(a), tCol = Ui.col(a);
        final TextView dVal = Ui.tv(a, "", 13.5f, Ui.CARD_INK, false), tVal = Ui.tv(a, "", 13.5f, Ui.CARD_INK, false);
        for (TextView v : new TextView[]{dVal, tVal}) {
            v.setPadding(Ui.dp(a, 12), Ui.dp(a, 9), Ui.dp(a, 12), Ui.dp(a, 9));
            v.setBackground(Ui.shape(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
        }
        final View dSw = Ui.toggle(a, d.dOn, null), tSw = Ui.toggle(a, d.tOn, null), rSw = Ui.toggle(a, d.rOn, null);
        final LinearLayout rRow = Ui.row(a);

        final Runnable paint = new Runnable() {
            @Override public void run() {
                dVal.setText(d.date.isEmpty() ? "選擇日期" : d.date);
                tVal.setText(d.time.isEmpty() ? "選擇時間" : d.time);
                dCol.setBackground(d.dOn ? Ui.shape(a, Ui.ACCENT_SOFT, 14, 0, 0) : Ui.dashed(a, 0, 14, Ui.BORDER, 1.5f));
                tCol.setBackground(d.tOn ? Ui.shape(a, Ui.ACCENT_SOFT, 14, 0, 0) : Ui.dashed(a, 0, 14, Ui.BORDER, 1.5f));
                dCol.setAlpha(d.dOn ? 1f : 0.6f);
                tCol.setAlpha(d.tOn ? 1f : 0.6f);
                rRow.setAlpha(d.dOn ? 1f : 0.6f);
                Ui.setOn(dSw, d.dOn); Ui.setOn(tSw, d.tOn); Ui.setOn(rSw, d.rOn);
            }
        };
        Ui.BoolCb onDate = new Ui.BoolCb() {
            @Override public void on(boolean v) {
                d.dOn = v;
                if (v && d.date.isEmpty()) d.date = Model.today();
                if (!v) { d.tOn = false; d.rOn = false; }
                paint.run();
            }
        };
        Ui.BoolCb onTime = new Ui.BoolCb() {
            @Override public void on(boolean v) {
                if (v && !d.dOn) { paint.run(); return; }   // 日期沒開不能開時間
                d.tOn = v;
                if (v && d.time.isEmpty()) d.time = "08:00";
                paint.run();
            }
        };
        Ui.BoolCb onRem = new Ui.BoolCb() {
            @Override public void on(boolean v) {
                if (v && !d.dOn) { paint.run(); return; }   // 日期沒開不能開提醒
                d.rOn = v;
                paint.run();
            }
        };
        setToggleCb(dSw, onDate); setToggleCb(tSw, onTime); setToggleCb(rSw, onRem);

        dVal.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!d.dOn) return;
                Modal.pickDate(a, d.date, new Modal.StrCb() {
                    @Override public void on(String s) { d.date = s; paint.run(); }
                });
            }
        });
        tVal.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!d.tOn) return;
                Modal.pickTime(a, d.time, new Modal.StrCb() {
                    @Override public void on(String s) { d.time = s; paint.run(); }
                });
            }
        });

        fillCol(dCol, "日期", dSw, dVal);
        fillCol(tCol, "時間", tSw, tVal);
        LinearLayout both = Ui.row(a);
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        l2.leftMargin = Ui.dp(a, 10);
        both.addView(dCol, l1);
        both.addView(tCol, l2);
        both.setLayoutParams(Ui.mw(a, 15));
        box.addView(both);

        rRow.addView(Icons.line(a, Icons.BELL, 18, Ui.CARD_INK));
        rRow.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
        rRow.addView(rSw);
        rRow.setContentDescription("提醒");
        rRow.setLayoutParams(Ui.mw(a, 14));
        box.addView(rRow);
        paint.run();
        return d;
    }

    private void fillCol(LinearLayout col, String label, View sw, TextView val) {
        col.setPadding(Ui.dp(a, 12), Ui.dp(a, 12), Ui.dp(a, 12), Ui.dp(a, 12));
        LinearLayout head = Ui.row(a);
        head.addView(Ui.tv(a, label, 13, Ui.CARD_INK, true), Ui.weight(1));
        head.addView(sw);
        col.addView(head, new LinearLayout.LayoutParams(-1, -2));
        col.addView(val, Ui.mw(a, 10));
    }

    private static void setToggleCb(View sw, final Ui.BoolCb cb) { Ui.onToggle(sw, cb); }

    /** 下拉選一個。 */
    static final class Pick {
        int index;
        final List<String> labels = new ArrayList<>();
        TextView view;
        String get() { return index >= 0 && index < labels.size() ? labels.get(index) : ""; }
    }

    Pick pick(String label, String[] options, int selected) {
        final Pick p = new Pick();
        for (String s : options) p.labels.add(s);
        p.index = selected;
        final TextView t = Ui.tv(a, p.get() + "  ▾", 13.5f, Ui.CARD_INK, false);
        t.setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10));
        t.setBackground(Ui.shape(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
        p.view = t;
        final String lbl = label;
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Modal.choose(a, lbl, p.labels.toArray(new String[0]), p.index, new Ui.IntCb() {
                    @Override public void on(int i) { p.index = i; t.setText(p.get() + "  ▾"); }
                });
            }
        });
        box.addView(Ui.field(a, label, t));
        return p;
    }

    /** 一列「文字 + 開關」。 */
    static final class Switch {
        View toggle;
        boolean get() { return Ui.isOn(toggle); }
    }

    Switch toggle(String label, boolean on) {
        Switch s = new Switch();
        LinearLayout row = Ui.row(a);
        row.addView(Ui.tv(a, label, 13.5f, Ui.CARD_INK, false), Ui.weight(1));
        s.toggle = Ui.toggle(a, on, null);
        row.addView(s.toggle);
        row.setLayoutParams(Ui.mw(a, 15));
        box.addView(row);
        return s;
    }

    /** 顏色欄:一排色票,點選。get() 回 #RRGGBB。 */
    static final class ColorPick {
        String value;
        String get() { return value; }
    }

    static final String[] SWATCHES = {"#2E4057", "#7A5C82", "#3A6B5E", "#E0685A", "#E08A2C", "#D9A441", "#3F7C4A", "#2E6F9E", "#8B6BB5", "#D96C8C", "#8A5A34", "#6B6E76"};

    ColorPick color(String label, String value) {
        final ColorPick cp = new ColorPick();
        cp.value = value == null || value.isEmpty() ? SWATCHES[0] : value;
        final LinearLayout rows = Ui.row(a);
        final List<View> dots = new ArrayList<>();
        final int dot = Ui.dp(a, 28);
        for (final String hex : SWATCHES) {
            final View v = new View(a);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dot, dot);
            lp.rightMargin = Ui.dp(a, 6);
            v.setTag(hex);
            dots.add(v);
            rows.addView(v, lp);
        }
        final Runnable paint = new Runnable() {
            @Override public void run() {
                for (View v : dots) {
                    String hex = (String) v.getTag();
                    boolean sel = hex.equalsIgnoreCase(cp.value);
                    v.setBackground(Ui.shape(a, Theme.parse(hex), 14, sel ? Ui.CARD_INK : 0, 2.5f));
                }
            }
        };
        for (final View v : dots) {
            v.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View x) { cp.value = (String) v.getTag(); paint.run(); }
            });
        }
        paint.run();
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(rows);
        box.addView(Ui.field(a, label, hs));
        return cp;
    }
}
