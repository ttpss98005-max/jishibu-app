package tw.jishibu.widget;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.zip.GZIPOutputStream;

/**
 * 網頁版壓縮收納的舊資料(archives,約 3 個月以前的記帳、習慣打卡、每日回顧,按年份各一包)。
 *
 * 手機上看到的是解開後的副本,所以使用者可以直接修改/刪除舊資料;這裡負責把那個修改套到雲端的壓縮包裡:
 *   只解開「真的被動到」的那一年 → 套用修改 → 用跟網頁版完全一樣的格式(排序固定、打卡簡寫、gzip + base64)重新壓縮放回去。
 *   沒被動到的年份一個字元都不會變。解不開任何一包就整批不寫入(丟例外),不會用缺一塊的資料蓋掉雲端。
 */
final class Archive {
    private final JSONObject root;
    private final JSONObject arc;
    private final Map<String, JSONObject> chunks = new HashMap<>();
    private final Map<String, Boolean> dirty = new HashMap<>();

    Archive(JSONObject root) {
        this.root = root;
        this.arc = root.optJSONObject("archives");
    }

    boolean any() { return arc != null && arc.length() > 0; }

    private List<String> years() {
        List<String> ys = new ArrayList<>();
        Iterator<String> it = arc.keys();
        while (it.hasNext()) ys.add(it.next());
        Collections.sort(ys);
        return ys;
    }

    private JSONObject chunk(String y) throws Exception {
        JSONObject c = chunks.get(y);
        if (c == null) {
            c = new JSONObject(Backup.gunzip(arc.getString(y)));
            chunks.put(y, c);
        }
        return c;
    }

    private static boolean hasExpense(JSONArray a, String id) {
        for (int i = 0; a != null && i < a.length(); i++) {
            JSONObject e = a.optJSONObject(i);
            if (e != null && id.equals(Model.s(e, "id"))) return true;
        }
        return false;
    }

    /**
     * 如果這個操作的對象在收納的舊資料裡,就套到壓縮包裡。
     * 回傳 true = 已經完整處理,不用再套到主資料;false = 還要照一般方式套到主資料(對象不在收納檔,或兩邊都有)。
     */
    boolean tryApply(JSONObject op, Doc.Stats st) throws Exception {
        if (!any()) return false;
        String kind = Model.s(op, "op");
        if (!"set".equals(kind) && !"del".equals(kind) && !"patch".equals(kind)) return false;
        JSONArray p = op.optJSONArray("path");
        if (p == null || p.length() < 2) return false;
        String top = p.optString(0), id = p.optString(1);

        if ("expenses".equals(top)) {
            if (hasExpense(root.optJSONArray("expenses"), id)) return false;   // 主資料裡有就以主資料為準(跟網頁版一樣)
            for (String y : years()) {
                JSONObject c = chunk(y);
                if (hasExpense(c.optJSONArray("expenses"), id)) {
                    applyToChunk(y, c, op, st);
                    return true;
                }
            }
            return false;
        }
        if ("habitLogs".equals(top)) {
            if (p.length() == 2) {
                // 整個習慣被刪掉:收納檔裡這個習慣的打卡紀錄也一起刪,主資料照一般方式處理
                if ("del".equals(kind)) {
                    for (String y : years()) {
                        JSONObject c = chunk(y);
                        JSONObject hl = c.optJSONObject("habitLogs");
                        if (hl != null && hl.has(id)) applyToChunk(y, c, op, st);
                    }
                }
                return false;
            }
            String day = p.optString(2);
            JSONObject logs = root.optJSONObject("habitLogs");
            JSONObject mine = logs == null ? null : logs.optJSONObject(id);
            boolean inHot = mine != null && mine.has(day);
            for (String y : years()) {
                JSONObject c = chunk(y);
                JSONObject hl = c.optJSONObject("habitLogs");
                JSONObject days = hl == null ? null : hl.optJSONObject(id);
                if (days != null && days.has(day)) {
                    applyToChunk(y, c, op, st);
                    return !inHot;
                }
            }
            return false;
        }
        if ("dayRecaps".equals(top)) {
            JSONObject dr = root.optJSONObject("dayRecaps");
            boolean inHot = dr != null && dr.has(id);
            for (String y : years()) {
                JSONObject c = chunk(y);
                JSONObject cr = c.optJSONObject("dayRecaps");
                if (cr != null && cr.has(id)) {
                    applyToChunk(y, c, op, st);
                    return !inHot;
                }
            }
            return false;
        }
        return false;
    }

    private void applyToChunk(String y, JSONObject c, JSONObject op, Doc.Stats st) throws JSONException {
        Doc.Stats cs = new Doc.Stats();
        Doc.apply(c, op, cs);
        int removed = 0;
        for (Integer n : cs.removed.values()) removed += n;
        if (st != null) {
            st.remove("archives", removed);
            st.archiveTouched.add(y);
        }
        dirty.put(y, true);
    }

    /** 把被動到的年份重新壓縮放回 archives(其他年份不動)。 */
    void commit() throws Exception {
        for (String y : new ArrayList<>(dirty.keySet())) {
            JSONObject c = chunks.get(y);
            JSONObject sc = stable(c);
            if (sc.length() == 0) {
                arc.remove(y);   // 這一年的舊資料全部沒了:跟網頁版一樣不留空的包
            } else {
                arc.put(y, gzipB64(sc.toString()));
            }
        }
        if (arc != null && arc.length() == 0) root.remove("archives");
    }

    /** 跟網頁版 stableChunk 一樣:習慣依 id、日期排序並簡寫打卡;記帳依日期、id 排序;每日回顧依日期排序;空的不留。 */
    static JSONObject stable(JSONObject c) throws JSONException {
        JSONObject out = new JSONObject();
        JSONObject hl = c.optJSONObject("habitLogs");
        if (hl != null) {
            TreeMap<String, JSONObject> byHabit = new TreeMap<>();
            Iterator<String> hi = hl.keys();
            while (hi.hasNext()) {
                String hid = hi.next();
                JSONObject src = hl.optJSONObject(hid);
                if (src == null || src.length() == 0) continue;
                TreeMap<String, Object> days = new TreeMap<>();
                Iterator<String> di = src.keys();
                while (di.hasNext()) { String d = di.next(); days.put(d, compactLog(src.get(d))); }
                JSONObject o = new JSONObject();
                for (Map.Entry<String, Object> e : days.entrySet()) o.put(e.getKey(), e.getValue());
                byHabit.put(hid, o);
            }
            if (!byHabit.isEmpty()) {
                JSONObject o = new JSONObject();
                for (Map.Entry<String, JSONObject> e : byHabit.entrySet()) o.put(e.getKey(), e.getValue());
                out.put("habitLogs", o);
            }
        }
        JSONArray ex = c.optJSONArray("expenses");
        if (ex != null && ex.length() > 0) {
            List<JSONObject> l = new ArrayList<>();
            for (int i = 0; i < ex.length(); i++) { JSONObject e = ex.optJSONObject(i); if (e != null) l.add(e); }
            Collections.sort(l, new Comparator<JSONObject>() {
                @Override public int compare(JSONObject a, JSONObject b) {
                    int d = Model.s(a, "date").compareTo(Model.s(b, "date"));
                    return d != 0 ? d : Model.s(a, "id").compareTo(Model.s(b, "id"));
                }
            });
            JSONArray sorted = new JSONArray();
            for (JSONObject e : l) sorted.put(e);
            if (sorted.length() > 0) out.put("expenses", sorted);
        }
        JSONObject dr = c.optJSONObject("dayRecaps");
        if (dr != null && dr.length() > 0) {
            TreeMap<String, Object> m = new TreeMap<>();
            Iterator<String> ki = dr.keys();
            while (ki.hasNext()) { String k = ki.next(); m.put(k, dr.get(k)); }
            JSONObject o = new JSONObject();
            for (Map.Entry<String, Object> e : m.entrySet()) o.put(e.getKey(), e.getValue());
            out.put("dayRecaps", o);
        }
        return out;
    }

    /** 網頁版 compactHabitLogs:{"value":x,"checked":true} 且只有這兩個欄位 → 簡寫成 x。 */
    private static Object compactLog(Object e) {
        if (e instanceof JSONObject) {
            JSONObject o = (JSONObject) e;
            if (o.length() == 2 && o.optBoolean("checked", false) && o.has("checked") && o.opt("checked") instanceof Boolean && o.has("value")) {
                Object v = o.opt("value");
                if (Boolean.TRUE.equals(v) || (v instanceof Number && !Double.isNaN(((Number) v).doubleValue()) && !Double.isInfinite(((Number) v).doubleValue()))
                        || (v instanceof String && !((String) v).isEmpty())) return v;
            }
        }
        return e;
    }

    /** 一包舊資料裡「真正的項目」的資料量(不算外層的容器),給寫入前的安全檢查比較用。 */
    static int items(JSONObject c) {
        int n = 0;
        JSONObject hl = c.optJSONObject("habitLogs");
        if (hl != null) {
            Iterator<String> hi = hl.keys();
            while (hi.hasNext()) {
                JSONObject days = hl.optJSONObject(hi.next());
                if (days == null) continue;
                Iterator<String> di = days.keys();
                while (di.hasNext()) n += Doc.nodes(days.opt(di.next()));
            }
        }
        JSONArray ex = c.optJSONArray("expenses");
        for (int i = 0; ex != null && i < ex.length(); i++) n += Doc.nodes(ex.opt(i));
        JSONObject dr = c.optJSONObject("dayRecaps");
        if (dr != null) {
            Iterator<String> ki = dr.keys();
            while (ki.hasNext()) n += Doc.nodes(dr.opt(ki.next()));
        }
        return n;
    }

    static String gzipB64(String s) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        GZIPOutputStream gz = new GZIPOutputStream(bo);
        gz.write(s.getBytes("UTF-8"));
        gz.close();
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
    }
}
