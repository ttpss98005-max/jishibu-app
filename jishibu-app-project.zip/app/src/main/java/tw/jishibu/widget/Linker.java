package tw.jishibu.widget;

import android.content.Context;

/** 存下登入憑證(Google 登入用)。 */
final class Linker {
    private Linker() {}

    /** 存下登入憑證。換成另一個帳號時,舊帳號還沒同步的修改先另外存起來。 */
    static void finish(Context c, String rt, String key, String email, String origin) {
        boolean same = Store.linked(c) && key.equals(Store.key(c));
        if (!same) Repo.stashPending(c);   // 沒同步的修改另存成檔案(跟登出時一樣的做法),不直接丟掉
        Store.saveLink(c, rt, key, email, origin);
        if (!same) {
            Store.setPending(c, "[]");
            Store.setUpdateTime(c, "");
            Store.setBackupDay(c, "");
            Repo.clear(c);
        }
    }
}
