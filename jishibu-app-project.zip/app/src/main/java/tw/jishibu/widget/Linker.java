package tw.jishibu.widget;

import android.content.Context;
import android.util.Base64;

import org.json.JSONObject;

/** 解開網頁產生的連結碼,存下登入憑證。 */
final class Linker {
    private Linker() {}

    /** 成功回傳 null,失敗回傳錯誤訊息。 */
    static String link(Context c, String code) {
        try {
            String s = code.trim().replace(" ", "").replace("\n", "").replace("\r", "");
            while (s.length() % 4 != 0) s += "=";
            byte[] raw = Base64.decode(s, Base64.URL_SAFE | Base64.NO_WRAP);
            JSONObject o = new JSONObject(new String(raw, "UTF-8"));
            String rt = o.getString("t"), key = o.getString("k");
            if (rt.isEmpty() || key.isEmpty()) return "連結碼不完整";
            Store.saveLink(c, rt, key, o.optString("e", ""), o.optString("o", ""));
            Store.setPending(c, "[]");
            Store.setUpdateTime(c, "");
            Store.setBackupDay(c, "");
            Repo.clear(c);
            return null;
        } catch (Exception e) {
            return "連結碼不正確,請重新在網頁複製";
        }
    }
}
