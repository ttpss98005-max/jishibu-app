package tw.jishibu.widget;

import android.content.Context;
import android.graphics.PorterDuff;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

/**
 * 頂欄左上角的葉子 logo,顏色跟著目前的主題色(Ui.ACCENT)走,跟網頁版一樣:
 * 底層深一點的主題色葉子 + 上面一層漸層淡出的亮一點的葉子(做出左上亮、右下暗的漸層)+ 最上面白色葉脈。
 * 三張圖都是白色遮罩圖,上色用 setColorFilter,所以換主題時重建頂欄就會換色。
 */
final class Logo {
    private Logo() {}

    static View make(Context c) {
        FrameLayout box = new FrameLayout(c);
        box.setContentDescription("記事簿");
        layer(c, box, R.drawable.logo_leaf, Scene.mix(Ui.ACCENT, 0xFF000000, 0.28));
        layer(c, box, R.drawable.logo_light, Scene.mix(Ui.ACCENT, 0xFFFFFFFF, 0.20));
        layer(c, box, R.drawable.logo_vein, 0xFFFFFFFF);
        return box;
    }

    private static void layer(Context c, FrameLayout box, int res, int color) {
        ImageView iv = new ImageView(c);
        iv.setImageResource(res);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setColorFilter(color, PorterDuff.Mode.SRC_IN);
        box.addView(iv, new FrameLayout.LayoutParams(-1, -1));
    }
}
