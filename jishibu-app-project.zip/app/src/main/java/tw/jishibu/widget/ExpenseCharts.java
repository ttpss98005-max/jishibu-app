package tw.jishibu.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** 統計頁的兩張圖:分類佔比(圓環)和近 6 個月收支(長條),照網頁版的 SVG 比例畫。 */
final class ExpenseCharts {
    private ExpenseCharts() {}

    static final int[] PALETTE = {0xFFD98E73, 0xFF7FA67C, 0xFF6FA3C7, 0xFFD9B36A, 0xFFB38AC4, 0xFFE08A9E, 0xFF8FBF9F, 0xFFC7A27F, 0xFF7FC7C2, 0xFFC78FA8, 0xFFA3A5D9, 0xFFD9D973};

    /** 圓環:200x200 的畫布,半徑 70、線寬 30,從正上方開始順時針;中間是「本月支出」和總額。 */
    static final class Pie extends View {
        private final float[] pct;
        private final String totalText;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int sizePx;

        Pie(Context c, float[] percents, String totalText) {
            super(c);
            this.pct = percents;
            this.totalText = totalText;
            this.sizePx = Ui.dp(c, 180);
        }

        @Override protected void onMeasure(int w, int h) { setMeasuredDimension(sizePx, sizePx); }

        @Override protected void onDraw(Canvas c) {
            float k = sizePx / 200f;
            c.save();
            c.scale(k, k);
            RectF oval = new RectF(100 - 70, 100 - 70, 100 + 70, 100 + 70);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(30f);
            p.setStrokeCap(Paint.Cap.BUTT);
            float acc = 0f;
            for (int i = 0; i < pct.length; i++) {
                p.setColor(PALETTE[i % PALETTE.length]);
                float sweep = pct[i] / 100f * 360f;
                c.drawArc(oval, -90f + acc / 100f * 360f, sweep, false, p);
                acc += pct[i];
            }
            p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);
            p.setColor(Ui.SOFT);
            p.setTextSize(12f);
            c.drawText("本月支出", 100f, 96f, p);
            p.setColor(Ui.INK);
            p.setTextSize(16f);
            p.setFakeBoldText(true);
            c.drawText(totalText, 100f, 100f + 16f, p);
            p.setFakeBoldText(false);
            c.restore();
        }
    }

    /** 近 6 個月:每月一組(綠=收入、紅=支出),320x150 的畫布等比縮放到寬度。 */
    static final class Trend extends View {
        private final double[] income, expense;
        private final String[] labels;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int heightPx;

        Trend(Context c, double[] income, double[] expense, String[] labels) {
            super(c);
            this.income = income;
            this.expense = expense;
            this.labels = labels;
            this.heightPx = Ui.dp(c, 150);
        }

        @Override protected void onMeasure(int w, int h) { setMeasuredDimension(MeasureSpec.getSize(w), heightPx); }

        @Override protected void onDraw(Canvas c) {
            final float W = 320f, H = 150f, padL = 4f, padR = 4f, padT = 10f, padB = 20f;
            float vw = getWidth();
            if (vw <= 0) return;
            float s = vw / W;
            c.save();
            c.scale(s, heightPx / H);
            float innerH = H - padT - padB;
            int n = income.length;
            double max = 1;
            for (int i = 0; i < n; i++) max = Math.max(max, Math.max(income[i], expense[i]));
            float groupW = (W - padL - padR) / n;
            float barW = Math.min(16f, groupW / 3.2f);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1f);
            p.setColor(Ui.BORDER);
            c.drawLine(padL, padT + innerH, W - padR, padT + innerH, p);
            p.setStyle(Paint.Style.FILL);
            for (int i = 0; i < n; i++) {
                float gx = padL + i * groupW + groupW / 2f;
                float hInc = (float) (income[i] / max * innerH), hExp = (float) (expense[i] / max * innerH);
                p.setColor(0xFF3A8A5E);
                c.drawRoundRect(new RectF(gx - barW - 2, padT + innerH - hInc, gx - 2, padT + innerH), 2f, 2f, p);
                p.setColor(0xFFC0504D);
                c.drawRoundRect(new RectF(gx + 2, padT + innerH - hExp, gx + 2 + barW, padT + innerH), 2f, 2f, p);
                p.setColor(Ui.SOFT);
                p.setTextSize(9f);
                p.setTextAlign(Paint.Align.CENTER);
                c.drawText(labels[i], gx, H - 4f, p);
            }
            c.restore();
        }
    }
}
