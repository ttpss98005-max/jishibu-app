package tw.jishibu.widget;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** 鬧鐘時間到 → 跳出通知,然後把後面的提醒補排上去;開機後也會重排。 */
public class AlertReceiver extends BroadcastReceiver {
    static final String CHANNEL = "reminders";

    @Override
    public void onReceive(Context ctx, Intent in) {
        final Context c = ctx.getApplicationContext();
        String act = in == null ? null : in.getAction();
        try {
            if (LocalAlerts.ACTION.equals(act)) {
                if (!LocalAlerts.alreadyLogged(c, in.getStringExtra("id")))
                    show(c, in.getStringExtra("id"), in.getStringExtra("title"), in.getStringExtra("body"));
            }
        } catch (Throwable ignore) { }
        final PendingResult pr = goAsync();
        new Thread(new Runnable() {
            @Override public void run() {
                try { LocalAlerts.reschedule(c); } finally { pr.finish(); }
            }
        }).start();
    }

    static void show(Context c, String id, String title, String body) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "提醒", NotificationManager.IMPORTANCE_HIGH));
        }
        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title == null || title.isEmpty() ? "記事簿" : title)
                .setContentText(body == null ? "" : body)
                .setStyle(new Notification.BigTextStyle().bigText(body == null ? "" : body))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        nm.notify(id == null ? 0 : id.hashCode(), n);
    }
}
