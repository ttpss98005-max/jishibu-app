package tw.jishibu.widget;

import android.content.Context;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 畫面共用元件,樣式照網頁版:
 * 白色圓角卡片、膠囊按鈕(.btn-primary / .btn-ghost)、膠囊分頁(.pill-tabs)、底線分頁(.seg)、開關(.switch)、輸入欄(.field)。
 * 顏色由 Theme.apply 設定(跟著目前配色)。
 */
final class Ui {
    private Ui() {}

    // 顏色(Theme.apply 會換掉)
    static int BG = 0xFFFAFAFA, INK = 0xFF1A1A1A, SOFT = 0xFF6B6B6B, ACCENT = 0xFF3A6B5E, ACCENT_SOFT = 0xFFEAF1EF;
    static int SURFACE = 0xFFFFFFFF, CARD_INK = 0xFF1A1A1A, BORDER = 0xFFE4E4E4, DANGER = 0xFFE0685A;
    static int CHIP_BG = 0xFFF1F0EA, TASK_BG = 0xFFFDFDFB;
    static final int SUB_BG = 0xFFF9F8F4;
    static final int ON_ACCENT = 0xFFFFFFFF;

    static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    // ---------- 文字與版面 ----------

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), Typeface.BOLD);
        return t;
    }

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static GradientDrawable shape(Context c, int fill, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) g.setStroke(Math.max(1, dp(c, strokeDp)), stroke);
        return g;
    }

    /**
     * 卡片、輸入列的輕陰影。Android 的陰影比網頁的 box-shadow 又濃又硬,貼著邊緣看起來像多了一圈框;
     * 所以高度減半、陰影顏色調淡(Android 9 以上才能調色),接近網頁版柔和的陰影。
     */
    static void soft(View v, float elevDp) {
        v.setElevation(dp(v.getContext(), elevDp * 0.5f));
        if (android.os.Build.VERSION.SDK_INT >= 28) {
            v.setOutlineAmbientShadowColor(0xFFC8C8C8);
            v.setOutlineSpotShadowColor(0xFFB0B0B0);
        }
    }

    /** 虛線框(網頁的 dashed border)。 */
    static GradientDrawable dashed(Context c, int fill, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        g.setStroke(Math.max(1, dp(c, strokeDp)), stroke, dp(c, 5), dp(c, 3));
        return g;
    }

    /** 這個 View 的 LinearLayout 版面參數(還沒設過或型別不同時,換成新的,不會當機)。 */
    /** 從目前的父層拆下來(要換地方掛之前用)。 */
    static void detach(View v) {
        if (v != null && v.getParent() instanceof ViewGroup) ((ViewGroup) v.getParent()).removeView(v);
    }

    static LinearLayout.LayoutParams lp(View v) {
        ViewGroup.LayoutParams cur = v.getLayoutParams();
        if (cur instanceof LinearLayout.LayoutParams) return (LinearLayout.LayoutParams) cur;
        LinearLayout.LayoutParams n = cur == null ? new LinearLayout.LayoutParams(-2, -2) : new LinearLayout.LayoutParams(cur);
        v.setLayoutParams(n);
        return n;
    }

    static LinearLayout.LayoutParams mw(Context c, float topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(c, topDp);
        return p;
    }

    /** 寬度依內容、上方留白。 */
    static LinearLayout.LayoutParams wrap(Context c, float topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(c, topDp);
        return p;
    }

    static LinearLayout.LayoutParams weight(float w) {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
    }

    /** 左邊留白的 LayoutParams(橫排元件之間的間距)。 */
    static LinearLayout.LayoutParams gap(Context c, float leftDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.leftMargin = dp(c, leftDp);
        return p;
    }

    static View spacer(Context c, float heightDp) {
        View v = new View(c);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(c, heightDp)));
        return v;
    }

    /** 網頁版的 1px dotted 分隔線(細項之間)。 */
    static View dotLine(Context c) {
        final float w = Math.max(1f, dp(c, 1));
        View v = new View(c) {
            private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
            @Override protected void onDraw(android.graphics.Canvas cv) {
                p.setColor(BORDER);
                p.setStrokeWidth(w);
                p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
                float y = getHeight() / 2f;
                for (float x = w; x < getWidth() - w; x += w * 3f) cv.drawPoint(x, y, p);
            }
        };
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(2, dp(c, 2))));
        return v;
    }

    static View hline(Context c) {
        View v = new View(c);
        v.setBackgroundColor(BORDER);
        v.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(c, 1))));
        return v;
    }

    // ---------- 卡片 ----------

    /** 白色圓角卡片(直向),給設定區塊、記帳摘要之類。 */
    static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        l.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        l.setBackground(shape(c, SURFACE, 16, 0, 0));
        soft(l, 2);
        return l;
    }

    /** 網頁版的 .task 卡片:淡色底、1.5px 邊框、18px 圓角、輕陰影。 */
    static LinearLayout taskCard(Context c) {
        LinearLayout l = col(c);
        // 邊框畫在內容「上面」並把內容裁成圓角,細項那塊底色才不會蓋住邊框、卡片的框也不會跑掉
        l.setBackground(shape(c, TASK_BG, 18, 0, 0));
        l.setForeground(shape(c, 0, 18, BORDER, 1.5f));
        l.setClipToOutline(true);
        soft(l, 2);
        return l;
    }

    /** 設定頁的區塊標題(.setting-block h3)。 */
    static TextView blockTitle(Context c, String s) {
        TextView t = tv(c, s, 13, SOFT, true);
        t.setPadding(0, dp(c, 18), 0, dp(c, 10));
        return t;
    }

    static TextView hint(Context c, String s) {
        TextView t = tv(c, s, 11, SOFT, false);
        t.setPadding(0, dp(c, 4), 0, 0);
        t.setLineSpacing(0, 1.3f);
        return t;
    }

    static TextView section(Context c, String s) {
        TextView t = tv(c, s, 13, SOFT, true);
        t.setPadding(dp(c, 4), dp(c, 18), 0, dp(c, 6));
        return t;
    }

    static TextView empty(Context c, String s) {
        TextView t = tv(c, s, 14, SOFT, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(c, 40), 0, dp(c, 40));
        return t;
    }

    /** 小膠囊標籤(進度、日期、延誤之類)。 */
    static TextView chip(Context c, String s, float sp, int fg, int bg, boolean bold) {
        TextView t = tv(c, s, sp, fg, bold);
        t.setPadding(dp(c, 9), dp(c, 3), dp(c, 9), dp(c, 3));
        t.setBackground(shape(c, bg, 999, 0, 0));
        return t;
    }

    /** 加刪除線。 */
    static void strike(TextView t) { t.setPaintFlags(t.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG); }

    // ---------- 按鈕 ----------

    /** .btn-primary:實心膠囊。 */
    static TextView btnPrimary(Context c, String s, View.OnClickListener l) {
        TextView t = tv(c, s, 13.5f, ON_ACCENT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 22), dp(c, 11), dp(c, 22), dp(c, 11));
        t.setBackground(shape(c, ACCENT, 999, 0, 0));
        soft(t, 2);
        t.setOnClickListener(l);
        return t;
    }

    /** .btn-ghost:白底、細邊框膠囊。 */
    static TextView btnGhost(Context c, String s, View.OnClickListener l) {
        TextView t = tv(c, s, 12.5f, SOFT, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 18), dp(c, 9), dp(c, 18), dp(c, 9));
        t.setBackground(shape(c, SURFACE, 999, BORDER, 1.5f));
        t.setOnClickListener(l);
        return t;
    }

    /** 危險動作的 ghost 按鈕(紅字紅框)。 */
    static TextView btnDanger(Context c, String s, View.OnClickListener l) {
        TextView t = btnGhost(c, s, l);
        t.setTextColor(DANGER);
        t.setBackground(shape(c, SURFACE, 999, DANGER, 1.5f));
        return t;
    }

    /** .text-btn:純文字小按鈕(編輯、刪除、備註)。 */
    static TextView textBtn(Context c, String s, View.OnClickListener l) {
        TextView t = tv(c, s, 12.5f, SOFT, false);
        t.setPadding(dp(c, 6), dp(c, 6), dp(c, 6), dp(c, 6));
        t.setOnClickListener(l);
        return t;
    }


    // ---------- 分頁 ----------

    interface IntCb { void on(int index); }

    /** .pill-tabs:灰色膠囊底,選中的是實心強調色。回傳的 view 可以用 setTag 之類自己更新,選擇時會回呼。 */
    static LinearLayout pillTabs(final Context c, final String[] labels, int selected, final IntCb cb) {
        final LinearLayout wrap = row(c);
        wrap.setPadding(dp(c, 4), dp(c, 4), dp(c, 4), dp(c, 4));
        wrap.setBackground(shape(c, CHIP_BG, 999, 0, 0));
        final TextView[] tabs = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView t = tv(c, labels[i], 13, i == selected ? ON_ACCENT : SOFT, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(dp(c, 20), dp(c, 9), dp(c, 20), dp(c, 9));
            t.setBackground(i == selected ? shape(c, ACCENT, 999, 0, 0) : null);
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    for (int k = 0; k < tabs.length; k++) {
                        tabs[k].setTextColor(k == idx ? ON_ACCENT : SOFT);
                        tabs[k].setBackground(k == idx ? shape(c, ACCENT, 999, 0, 0) : null);
                    }
                    if (cb != null) cb.on(idx);
                }
            });
            tabs[i] = t;
            wrap.addView(t);
        }
        return wrap;
    }

    /** .seg:底線式分頁(待處理 / 已完成)。selected = -1 代表都沒選中。 */
    static LinearLayout seg(final Context c, final String[] labels, int selected, final IntCb cb) {
        final LinearLayout wrap = row(c);
        final TextView[] tabs = new TextView[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView t = tv(c, labels[i], 13, i == selected ? ACCENT : SOFT, true);
            t.setPadding(dp(c, 4), dp(c, 8), dp(c, 4), dp(c, 10));
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { if (cb != null) cb.on(idx); }
            });
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (i > 0) p.leftMargin = dp(c, 24);
            tabs[i] = t;
            wrap.addView(t, p);
        }
        return wrap;
    }

    // ---------- 開關 ----------

    interface BoolCb { void on(boolean value); }

    /** .switch:38x22 的開關。 */
    static View toggle(Context c, boolean on, BoolCb cb) {
        return new ToggleView(c, on, cb);
    }

    static boolean isOn(View v) { return v instanceof ToggleView && ((ToggleView) v).on; }


    private static final class ToggleView extends View {
        boolean on;
        private final BoolCb cb;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int w, h;

        ToggleView(Context c, boolean on, BoolCb cb) {
            super(c);
            this.on = on;
            this.cb = cb;
            w = dp(c, 38);
            h = dp(c, 22);
            setMinimumWidth(w);
            setMinimumHeight(h);
            setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    ToggleView.this.on = !ToggleView.this.on;
                    invalidate();
                    if (ToggleView.this.cb != null) ToggleView.this.cb.on(ToggleView.this.on);
                }
            });
        }

        @Override protected void onMeasure(int a, int b) { setMeasuredDimension(w, h); }

        @Override protected void onDraw(android.graphics.Canvas c) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(on ? ACCENT : 0xFFDDDDDD);
            c.drawRoundRect(new android.graphics.RectF(0, 0, w, h), h / 2f, h / 2f, p);
            p.setColor(0xFFFFFFFF);
            float r = h * 9f / 22f, cx = on ? w - h / 2f : h / 2f;
            c.drawCircle(cx, h / 2f, r, p);
        }
    }

    // ---------- 輸入欄 ----------

    /** 網頁版 .field input 的樣子:1.5px 邊框、14px 圓角。 */
    static EditText input(Context c, String hint, String value) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setText(value == null ? "" : value);
        e.setTextSize(13.5f);
        e.setTextColor(CARD_INK);
        e.setHintTextColor(0xFFB5B5B5);
        e.setSingleLine(true);
        e.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        e.setBackground(shape(c, SURFACE, 14, BORDER, 1.5f));
        return e;
    }

    static EditText multiline(Context c, String hint, String value, int minLines) {
        EditText e = input(c, hint, value);
        e.setSingleLine(false);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        e.setMinLines(minLines);
        e.setGravity(Gravity.TOP);
        return e;
    }

    static EditText numberInput(Context c, String hint, String value, boolean decimal) {
        EditText e = input(c, hint, value);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | (decimal ? InputType.TYPE_NUMBER_FLAG_DECIMAL : 0));
        return e;
    }

    /** 欄位標題 + 欄位本體(.field)。 */
    static LinearLayout field(Context c, String label, View body) {
        LinearLayout f = col(c);
        f.addView(tv(c, label, 12, SOFT, true));
        LinearLayout.LayoutParams p = mw(c, 6);
        f.addView(body, p);
        f.setLayoutParams(mw(c, 15));
        return f;
    }

    // ---------- 提示 ----------

    static void toast(Context c, String m) {
        if (c instanceof MainActivity) ((MainActivity) c).flash(m);
        else Toast.makeText(c, m, Toast.LENGTH_SHORT).show();
    }

    /** 一個 App 取得 MainActivity(畫面都跑在裡面)。 */
    static MainActivity main(Context c) { return c instanceof MainActivity ? (MainActivity) c : null; }


    static void click(View v, Runnable r) {
        final Runnable rr = r;
        v.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View x) { rr.run(); } });
    }
}
