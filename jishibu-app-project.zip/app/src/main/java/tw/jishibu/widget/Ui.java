package tw.jishibu.widget;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** 畫面小工具:顏色、圓角卡片、文字、勾選圈、每一列事項。 */
final class Ui {
    private Ui() {}

    static int BG, CARD, INK, SOFT, LINE, ACCENT, ON_ACCENT, DANGER, ACCENT_SOFT;

    static void init(Context c) {
        boolean dark = (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        if (dark) {
            BG = 0xFF111614; CARD = 0xFF1C2421; INK = 0xFFECEFF1; SOFT = 0xFF9AA5AE; LINE = 0xFF2B3430;
            ACCENT = 0xFF4FD1A1; ON_ACCENT = 0xFF0B2B20; DANGER = 0xFFFF7A72; ACCENT_SOFT = 0xFF24382F;
        } else {
            BG = 0xFFF3F6F4; CARD = 0xFFFFFFFF; INK = 0xFF1F2937; SOFT = 0xFF6B7580; LINE = 0xFFE2E8E4;
            ACCENT = 0xFF2F9E78; ON_ACCENT = 0xFFFFFFFF; DANGER = 0xFFD8453D; ACCENT_SOFT = 0xFFE3F3EC;
        }
    }

    static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    static TextView tv(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(t.getTypeface(), Typeface.BOLD);
        return t;
    }

    static LinearLayout col(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    static GradientDrawable shape(Context c, int fill, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) g.setStroke(dp(c, strokeDp), stroke);
        return g;
    }

    static LinearLayout.LayoutParams mw(Context c, float topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(c, topDp);
        return p;
    }

    static LinearLayout.LayoutParams weight(float w) {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
    }

    /** 白色圓角卡片(直向)。 */
    static LinearLayout card(Context c) {
        LinearLayout l = col(c);
        l.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        l.setBackground(shape(c, CARD, 16, 0, 0));
        return l;
    }

    static TextView section(Context c, String s) {
        TextView t = tv(c, s, 13, SOFT, true);
        t.setPadding(dp(c, 4), dp(c, 18), 0, dp(c, 6));
        return t;
    }

    /** 圓形勾選圈。 */
    static TextView check(Context c, boolean done, int sizeDp) {
        TextView t = new TextView(c);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(sizeDp * 0.5f);
        if (done) {
            t.setBackground(shape(c, ACCENT, sizeDp, 0, 0));
            t.setText("✓");
            t.setTextColor(ON_ACCENT);
        } else {
            t.setBackground(shape(c, 0x00000000, sizeDp, SOFT, 2));
        }
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp));
        t.setLayoutParams(p);
        return t;
    }

    static TextView pill(Context c, String s, boolean filled) {
        TextView t = tv(c, s, 14, filled ? ON_ACCENT : ACCENT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(c, 16), dp(c, 9), dp(c, 16), dp(c, 9));
        t.setBackground(filled ? shape(c, ACCENT, 20, 0, 0) : shape(c, ACCENT_SOFT, 20, 0, 0));
        return t;
    }

    static void toast(Context c, String m) { Toast.makeText(c, m, Toast.LENGTH_SHORT).show(); }

    /** 一列事項:左邊勾選圈,中間標題與說明。點勾選圈就切換完成狀態。 */
    static View entryRow(final Activity a, final Model.Entry e, String subtitle, boolean overdue, final Runnable after) {
        LinearLayout r = row(a);
        r.setPadding(0, dp(a, 8), 0, dp(a, 8));
        TextView ck = check(a, e.done, 26);
        LinearLayout.LayoutParams cp = (LinearLayout.LayoutParams) ck.getLayoutParams();
        cp.rightMargin = dp(a, 12);
        r.addView(ck);

        LinearLayout mid = col(a);
        TextView title = tv(a, e.title.isEmpty() ? "(沒有標題)" : e.title, 16, e.done ? SOFT : INK, false);
        if (e.done) title.setPaintFlags(title.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        mid.addView(title);
        if (subtitle != null && !subtitle.isEmpty()) {
            mid.addView(tv(a, subtitle, 12, overdue ? DANGER : SOFT, false));
        }
        r.addView(mid, weight(1));

        boolean toggleable = e.kind.equals("task") || e.kind.equals("sub");
        if (toggleable) {
            ck.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    boolean nowDone = !e.done;
                    if (e.kind.equals("sub")) {
                        Repo.submit(a, Repo.op("op", "sub_done", "tid", e.tid, "sid", e.sid, "done", nowDone, "day", Model.today()));
                    } else {
                        Repo.submit(a, Repo.op("op", "task_done", "id", e.tid, "done", nowDone, "day", Model.today()));
                    }
                    if (after != null) after.run();
                }
            });
        } else {
            ck.setVisibility(View.INVISIBLE);
        }
        return r;
    }

    /** 事項的說明文字:分類、日期、時間。 */
    static String subtitleFor(Model.Entry e, String today) {
        StringBuilder s = new StringBuilder();
        if (e.kind.equals("sub") && !e.parent.isEmpty()) s.append(e.parent);
        if (e.kind.equals("task")) {
            String cn = Model.categoryName(e.catId);
            if (!cn.isEmpty()) s.append(cn);
        }
        if (e.kind.equals("count")) s.append(e.parent);
        if (e.kind.equals("special")) s.append("特別的日子");
        if (!e.date.isEmpty() && !e.date.equals(today) && !e.kind.equals("special") && !e.kind.equals("count")) {
            if (s.length() > 0) s.append(" · ");
            s.append(e.date.substring(5).replace('-', '/'));
        }
        if (!e.time.isEmpty()) {
            if (s.length() > 0) s.append(" · ");
            s.append(e.time);
        }
        return s.toString();
    }
}
