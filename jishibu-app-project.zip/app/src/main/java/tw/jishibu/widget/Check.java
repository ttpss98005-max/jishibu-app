package tw.jishibu.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** 圓形勾選框(網頁的 .check):未完成是白底灰框,完成是強調色實心加白色勾勾;按下完成時彈跳一下。 */
final class Check extends View {
    private boolean done;
    private final int size;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tick = new Path();

    Check(Context c, int sizeDp, boolean done) {
        super(c);
        this.done = done;
        this.size = Ui.dp(c, sizeDp);
        setMinimumWidth(size);
        setMinimumHeight(size);
    }

    void setDone(boolean d) { done = d; invalidate(); }

    @Override protected void onMeasure(int w, int h) { setMeasuredDimension(size, size); }

    @Override protected void onDraw(Canvas c) {
        float s = size, stroke = Math.max(2f, s * 2f / 22f);
        RectF r = new RectF(stroke / 2f, stroke / 2f, s - stroke / 2f, s - stroke / 2f);
        p.setStyle(Paint.Style.FILL);
        p.setColor(done ? Ui.ACCENT : 0xFFFFFFFF);
        c.drawOval(r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(stroke);
        p.setColor(done ? Ui.ACCENT : Ui.BORDER);
        c.drawOval(r, p);
        if (done) {
            p.setColor(0xFFFFFFFF);
            p.setStrokeWidth(Math.max(2f, s * 2.5f / 22f));
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeJoin(Paint.Join.ROUND);
            tick.reset();
            tick.moveTo(s * 0.29f, s * 0.52f);
            tick.lineTo(s * 0.44f, s * 0.67f);
            tick.lineTo(s * 0.72f, s * 0.35f);
            c.drawPath(tick, p);
        }
    }

    /** 彈跳:1 → 1.35 → 0.88 → 1,0.4 秒。 */
    void bounce() {
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(400);
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator va) {
                float t = (Float) va.getAnimatedValue(), k;
                if (t < 0.4f) k = 1f + 0.35f * (t / 0.4f);
                else if (t < 0.7f) k = 1.35f - 0.47f * ((t - 0.4f) / 0.3f);
                else k = 0.88f + 0.12f * ((t - 0.7f) / 0.3f);
                setScaleX(k);
                setScaleY(k);
            }
        });
        a.start();
    }
}
