package tw.jishibu.widget;

import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** 清單:所有事項,可依分類篩選,點開看細項。 */
final class TasksScreen extends Screen {
    private String catFilter = "";
    private boolean showDone = false;
    private final Set<String> expanded = new HashSet<>();

    TasksScreen(MainActivity a) { super(a); }

    @Override
    void build() {
        final String today = Model.today();
        LinearLayout head = Ui.row(a);
        head.addView(Ui.tv(a, "清單", 26, Ui.INK, true), Ui.weight(1));
        TextView add = Ui.pill(a, "＋ 新增", true);
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { Dialogs.addTask(a, "", again); }
        });
        head.addView(add);
        content.addView(head);

        // 分類篩選
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout chips = Ui.row(a);
        chips.addView(chip("全部", ""));
        for (JSONObject c : Model.categories()) chips.addView(chip(Model.s(c, "name", "?"), Model.s(c, "id")));
        hs.addView(chips);
        content.addView(hs, Ui.mw(a, 12));

        List<JSONObject> pending = new ArrayList<>(), done = new ArrayList<>();
        for (JSONObject t : Model.tasks()) {
            if (!catFilter.isEmpty() && !catFilter.equals(Model.s(t, "categoryId"))) continue;
            if ("done".equals(Model.s(t, "status"))) done.add(t); else pending.add(t);
        }
        Collections.sort(pending, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject x, JSONObject y) {
                String dx = Model.s(x, "dueDate", ""), dy = Model.s(y, "dueDate", "");
                if (dx.isEmpty()) dx = "9999-99-99";
                if (dy.isEmpty()) dy = "9999-99-99";
                return dx.compareTo(dy);
            }
        });

        if (pending.isEmpty()) {
            TextView n = Ui.tv(a, "這裡沒有待辦事項", 15, Ui.SOFT, false);
            n.setPadding(Ui.dp(a, 4), Ui.dp(a, 24), 0, 0);
            content.addView(n);
        }
        for (JSONObject t : pending) content.addView(taskCard(t, today), Ui.mw(a, 10));

        if (!done.isEmpty()) {
            TextView toggle = Ui.tv(a, showDone ? "隱藏已完成(" + done.size() + ")" : "顯示已完成(" + done.size() + ")", 14, Ui.ACCENT, true);
            toggle.setPadding(Ui.dp(a, 4), Ui.dp(a, 20), 0, Ui.dp(a, 4));
            toggle.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { showDone = !showDone; refresh(); }
            });
            content.addView(toggle);
            if (showDone) for (JSONObject t : done) content.addView(taskCard(t, today), Ui.mw(a, 10));
        }
    }

    private View chip(String name, final String id) {
        boolean sel = catFilter.equals(id);
        TextView t = Ui.tv(a, name, 14, sel ? Ui.ON_ACCENT : Ui.INK, sel);
        t.setPadding(Ui.dp(a, 14), Ui.dp(a, 7), Ui.dp(a, 14), Ui.dp(a, 7));
        t.setBackground(Ui.shape(a, sel ? Ui.ACCENT : Ui.CARD, 18, 0, 0));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, -2);
        p.rightMargin = Ui.dp(a, 8);
        t.setLayoutParams(p);
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { catFilter = id; refresh(); }
        });
        return t;
    }

    private View taskCard(JSONObject t, String today) {
        final Model.Entry e = Model.taskEntry(t);
        LinearLayout card = Ui.card(a);
        JSONArray subs = t.optJSONArray("subtasks");
        int subCount = subs == null ? 0 : subs.length();
        int subDone = 0;
        for (int i = 0; i < subCount; i++) {
            JSONObject s = subs.optJSONObject(i);
            if (s != null && "done".equals(Model.s(s, "status"))) subDone++;
        }
        boolean overdue = !e.done && Model.isDay(e.date) && e.date.compareTo(today) < 0;
        String sub = Ui.subtitleFor(e, today);
        if (!e.date.isEmpty() && e.date.equals(today)) sub = (sub.isEmpty() ? "" : sub + " · ") + "今天";
        if (subCount > 0) sub = (sub.isEmpty() ? "" : sub + " · ") + "細項 " + subDone + "/" + subCount;

        LinearLayout r = (LinearLayout) Ui.entryRow(a, e, sub, overdue, again);
        card.addView(r);
        final boolean open = expanded.contains(e.tid);
        if (subCount > 0) {
            r.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (expanded.contains(e.tid)) expanded.remove(e.tid); else expanded.add(e.tid);
                    refresh();
                }
            });
            r.addView(Ui.tv(a, open ? "▾" : "▸", 16, Ui.SOFT, false));
        }
        if (open && subs != null) {
            for (int i = 0; i < subs.length(); i++) {
                JSONObject s = subs.optJSONObject(i);
                if (s == null) continue;
                Model.Entry se = Model.subEntry(t, s);
                View row = Ui.entryRow(a, se, se.time.isEmpty() && se.date.isEmpty() ? "" : (se.date.isEmpty() ? "" : se.date.substring(5).replace('-', '/')) + (se.time.isEmpty() ? "" : " " + se.time), false, again);
                row.setPadding(Ui.dp(a, 38), Ui.dp(a, 8), 0, Ui.dp(a, 8));
                card.addView(row);
            }
        }
        return card;
    }
}
