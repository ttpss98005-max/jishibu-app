package tw.jishibu.widget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 手機本機的提醒通知:用系統鬧鐘排好「接下來要提醒的事」,到時間跳出通知,不用開 App、不靠網路。
 * 來源跟網頁版推播一樣:事項的提醒、習慣的提醒時間、早安/晚安。
 * 每次資料有變就整批重排(先取消舊的再排新的),所以刪除、改時間、打完卡都會跟著更新。
 */
final class LocalAlerts {
    private LocalAlerts() {}

    static final String ACTION = "tw.jishibu.widget.ALERT";
    private static final int MAX = 48;
    private static final int DAYS = 7;

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("jishibu_alerts", Context.MODE_PRIVATE);
    }

    static boolean enabled(Context c) { return sp(c).getBoolean("on", true); }

    static void setEnabled(Context c, boolean on) {
        sp(c).edit().putBoolean("on", on).apply();
        reschedule(c);
    }

    private static final class Item {
        final String id, title, body;
        final long at;
        Item(String id, String title, String body, long at) { this.id = id; this.title = title; this.body = body; this.at = at; }
    }

    /** 響的當下再確認一次:這個習慣那天已經打過卡就不用提醒了(id 的格式是 hab_習慣id_日期)。 */
    static boolean alreadyLogged(Context c, String id) {
        try {
            if (id == null || !id.startsWith("hab_") || id.length() < 15) return false;
            Repo.init(c);
            String day = id.substring(id.length() - 10);
            String hid = id.substring(4, id.length() - 11);
            return done(Model.logEntry(hid, day));
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean done(Object e) {
        if (e == null || e == JSONObject.NULL) return false;
        if (e instanceof Boolean) return (Boolean) e;
        if (e instanceof Number) return ((Number) e).doubleValue() != 0;
        if (e instanceof String) return !((String) e).isEmpty();
        return true;
    }

    private static List<Item> build(Context c, JSONObject data) {
        List<Item> r = new ArrayList<>();
        long now = System.currentTimeMillis();
        // 1. 事項的提醒(要有日期、提醒開著、還沒完成;只設日期沒設時間 → 當天早上 8:00)
        for (JSONObject t : Model.tasks()) {
            if (!t.optBoolean("reminder", false)) continue;
            if ("done".equals(Model.s(t, "status", ""))) continue;
            long at = Model.taskDueMs(t);
            if (at <= now) continue;
            r.add(new Item("task_" + Model.s(t, "id"), "提醒：" + Model.s(t, "title"), Model.fmtTaskWhen(t), at));
        }
        // 2. 習慣的每日提醒(今天已經打過卡的就不再提醒)
        String today = Model.today();
        for (JSONObject h : Model.habits()) {
            String rt = Model.s(h, "remindTime", "");
            if (rt.length() < 5) continue;
            for (int i = 0; i < DAYS; i++) {
                String day = Model.addDays(today, i);
                if (!Model.habitScheduledOn(h, day)) continue;
                long at;
                try { at = DailyNotify.dueAt(day, rt); } catch (Exception e) { continue; }
                if (at <= now) continue;
                if (i == 0 && done(Model.logEntry(Model.s(h, "id"), day))) continue;
                r.add(new Item("hab_" + Model.s(h, "id") + "_" + day, "習慣提醒：" + Model.s(h, "name"), "今天還沒打卡喔", at));
            }
        }
        // 3. 早安 / 晚安
        String[] kinds = {"morning", "night"};
        for (String kind : kinds) {
            if (!DailyNotify.on(kind)) continue;
            String time = "morning".equals(kind) ? DailyNotify.MORNING_TIME : DailyNotify.NIGHT_TIME;
            for (int i = 0; i < DAYS; i++) {
                String day = Model.addDays(today, i);
                long at = DailyNotify.dueAt(day, time);
                if (at <= now) continue;
                String[] tb = DailyNotify.text(kind, day);
                r.add(new Item("daily_" + kind + "_" + day, tb[0], tb[1], at));
            }
        }
        Collections.sort(r, new Comparator<Item>() {
            @Override public int compare(Item a, Item b) { return Long.compare(a.at, b.at); }
        });
        return r;
    }

    private static PendingIntent pi(Context c, String id, String title, String body, int flags) {
        Intent in = new Intent(c, AlertReceiver.class);
        in.setAction(ACTION);
        in.setData(Uri.parse("jishibu://alert/" + id));
        in.putExtra("id", id);
        in.putExtra("title", title);
        in.putExtra("body", body);
        return PendingIntent.getBroadcast(c, 0, in, flags | PendingIntent.FLAG_IMMUTABLE);
    }

    /** 整批重排。不會丟例外。 */
    static synchronized void reschedule(Context ctx) {
        try {
            Context c = ctx.getApplicationContext();
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            SharedPreferences p = sp(c);
            // 先取消舊的
            try {
                JSONArray old = new JSONArray(p.getString("ids", "[]"));
                for (int i = 0; i < old.length(); i++) {
                    PendingIntent x = pi(c, old.getString(i), "", "", PendingIntent.FLAG_NO_CREATE);
                    if (x != null) { am.cancel(x); x.cancel(); }
                }
            } catch (Exception ignore) { }
            JSONArray ids = new JSONArray();
            Repo.init(c);
            JSONObject data = Repo.data();
            if (data != null && Store.linked(c) && enabled(c)) {
                List<Item> items;
                synchronized (Repo.lock()) { items = build(c, data); }
                boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
                int n = 0;
                for (Item it : items) {
                    if (n >= MAX) break;
                    PendingIntent x = pi(c, it.id, it.title, it.body, PendingIntent.FLAG_UPDATE_CURRENT);
                    try {
                        if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, it.at, x);
                        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, it.at, x);
                    } catch (SecurityException e) {
                        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, it.at, x);
                    }
                    ids.put(it.id);
                    n++;
                }
            }
            p.edit().putString("ids", ids.toString()).apply();
        } catch (Throwable ignore) { }
    }

    // ---------- 開發者工具用 ----------

    static boolean canExact(Context ctx) {
        try {
            AlarmManager am = (AlarmManager) ctx.getApplicationContext().getSystemService(Context.ALARM_SERVICE);
            return am != null && (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms());
        } catch (Throwable t) {
            return false;
        }
    }

    /** 目前已經排進系統鬧鐘的提醒數量。 */
    static int scheduledCount(Context ctx) {
        try { return new JSONArray(sp(ctx.getApplicationContext()).getString("ids", "[]")).length(); } catch (Exception e) { return 0; }
    }

    /** 接下來會響的提醒(最多 max 則),每則一行「月/日 時:分　標題」。 */
    static List<String> upcoming(Context ctx, int max) {
        List<String> out = new ArrayList<>();
        try {
            Context c = ctx.getApplicationContext();
            Repo.init(c);
            JSONObject data = Repo.data();
            if (data == null || !Store.linked(c) || !enabled(c)) return out;
            List<Item> items;
            synchronized (Repo.lock()) { items = build(c, data); }
            java.util.Calendar t = java.util.Calendar.getInstance();
            for (int i = 0; i < items.size() && i < max && i < MAX; i++) {
                Item it = items.get(i);
                t.setTimeInMillis(it.at);
                out.add(String.format(java.util.Locale.TAIWAN, "%d/%d %02d:%02d　%s", t.get(java.util.Calendar.MONTH) + 1,
                        t.get(java.util.Calendar.DAY_OF_MONTH), t.get(java.util.Calendar.HOUR_OF_DAY), t.get(java.util.Calendar.MINUTE), it.title));
            }
        } catch (Throwable ignore) { }
        return out;
    }

    /** 排一個 delayMs 後響的測試鬧鐘(走跟真正提醒同一條路)。回傳 true=精確鬧鐘,false=只能大約準時;排不進去回傳 null。 */
    static Boolean testAlarm(Context ctx, long delayMs) {
        try {
            Context c = ctx.getApplicationContext();
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return null;
            long at = System.currentTimeMillis() + delayMs;
            boolean exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms();
            PendingIntent x = pi(c, "devtest", "鬧鐘測試", "看到這則通知，代表 App 關掉後，系統鬧鐘也能準時叫醒它。", PendingIntent.FLAG_UPDATE_CURRENT);
            try {
                if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, x);
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, x);
            } catch (SecurityException e) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, x);
                exact = false;
            }
            return exact;
        } catch (Throwable t) {
            return null;
        }
    }
}
