package tw.jishibu.widget;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 新手教學(跟網頁版同一套 43 個步驟):在「真正的畫面」上亮起一個地方、說明一句話,按「幫我點」就真的點下去。
 * 為了不動到使用者的資料,教學開始時 Repo 會換成一份練習資料(Repo.enterSandbox),結束再換回來;
 * 練習期間不排隊、不同步、不存檔、不排通知。
 * 只有「新註冊」的帳號(資料裡有 tutorialSeen)才會在每個分頁第一次打開時自動跳出;其他人從設定頁的「新手教學」手動看。
 */
final class Tutorial {
    private Tutorial() {}

    /** 分頁順序跟 MainActivity.TAB_* 一樣。 */
    static final String[] KEYS = {"habits", "list", "cal", "notes", "money", "settings"};
    static final String[] NAMES = {"習慣", "清單", "行事曆", "隨手記", "記帳", "設定"};

    /** 測試用:不量位置、不畫畫面,只走流程。 */
    static boolean headless = false;

    private static final Handler H = new Handler(Looper.getMainLooper());

    private static boolean running, chain;
    private static int tab, idx, token, origTab, aboveDialogs;
    private static String origCat = "overview";
    private static MainActivity act;
    private static List<Step> steps = new ArrayList<>();
    private static Overlay overlay;
    private static final boolean[] seen = new boolean[6];

    private static int firstTab;
    private static Runnable autoTick;
    private static int autoTries, autoTab;

    // ------------------------------------------------------------------ 步驟

    private interface Finder { View find(); }
    private interface Pred { boolean ok(View v); }

    private static final class Step {
        final String title, text;
        final Finder target;
        final boolean info, card;
        Runnable after;
        Step(String title, String text, Finder target, boolean info, boolean card) {
            this.title = title; this.text = text; this.target = target; this.info = info; this.card = card;
        }
        Step then(Runnable r) { after = r; return this; }
    }

    private static Step click(String title, String text, Finder f) { return new Step(title, text, f, false, false); }
    private static Step info(String title, String text, Finder f) { return new Step(title, text, f, true, false); }
    private static Step card(String tag, String title, String text) { return new Step(title, text, null, true, true); }

    private static Runnable fill(final int n, final String text) {
        return new Runnable() { @Override public void run() { fillEdit(n, text); } };
    }

    private static Runnable fills(final String... t) {
        return new Runnable() {
            @Override public void run() { for (int i = 0; i < t.length; i++) if (t[i] != null) fillEdit(i, t[i]); }
        };
    }

    /** 每一頁的步驟。 */
    static int stepCount(int t) { return stepsFor(t).size(); }

    private static List<Step> stepsFor(int t) {
        List<Step> s = new ArrayList<>();
        switch (t) {
            case MainActivity.TAB_HABITS:
                s.add(card("歡迎", "歡迎使用記事簿", "每個頁面第一次打開時，會帶你實際做一遍主要功能。\n用的是練習資料，不會動到你真正的記事簿。"));
                s.add(click("新增習慣", "想養成的習慣（喝水、運動、閱讀）從這裡新增。", button("＋ 新增習慣")).then(fill(0, "喝水")));
                s.add(info("輸入習慣名稱", "名稱幫你填好了「喝水」。還可以選記錄方式（打卡、時間、數量）和重複頻率，也能設每日提醒時間。", editor(0)));
                s.add(click("按「新增」", "習慣就加進清單了。", button("新增")));
                s.add(click("點圓圈打卡", "每天點一下圓圈打卡，會累積連續天數。", desc("打卡:喝水")));
                s.add(info("看統計", "打卡紀錄累積之後，到「統計」可以看趨勢圖。", button("統計")));
                s.add(info("想再看一次教學", "到右上角「設定」頁的「新手教學」，可以重看每一頁，或從頭完整看一遍。", desc("設定")));
                break;
            case MainActivity.TAB_LIST:
                s.add(click("新增事項", "要做的事從這裡新增。", button("＋ 新增事項")).then(fill(0, "買生日禮物")));
                s.add(info("輸入標題", "幫你填好了「買生日禮物」。可以選分類，也能設日期、時間和提醒。", editor(0)));
                s.add(click("按「儲存」", "事項就出現在清單裡了。", button("儲存")));
                s.add(info("收合與展開細項", "一件事可以拆成好幾個細項。點事項右邊的箭頭，可以收合或展開細項。", inCard("買生日禮物", descIn("收合細項", "展開細項"))));
                s.add(click("新增細項", "點「＋ 新增細項」。", inCard("買生日禮物", textIn("＋ 新增細項"))).then(fill(0, "挑禮物")));
                s.add(info("輸入細項名稱", "幫你填好了「挑禮物」。", editor(0)));
                s.add(click("按「儲存」", "細項就加好了，之後可以逐項勾掉。", button("儲存")));
                s.add(click("寫備註", "事項和細項右邊都有「備註」，可以記下想法或注意事項。", inCard("買生日禮物", textIn("備註"))).then(fill(0, "預算 500 元以內，下班順路買")));
                s.add(click("按「儲存」", "備註會顯示在事項下面。", button("儲存")));
                s.add(click("整理順序", "想照日期、名稱或新增時間排，按這裡。", desc("排序")));
                s.add(click("按「排序」", "清單依你選的方式整理一次。整理完就是普通順序：之後改日期、拖動、新增，都不會自己跑掉。按錯了 5 秒內可以「復原」。", button("排序")));
                s.add(info("長按拖動換順序", "每張卡左邊有三條線。按住一下再拖，想放哪裡就放哪裡。", inCard("買生日禮物", descIn("長按拖曳排序"))));
                s.add(click("切換分類", "點這裡在「總覽」和各個分類（工作、私人…）之間切換，清單和行事曆都適用。", button("總覽")));
                s.add(click("選「私人」", "畫面只留下「私人」分類的事項。想看全部，再選回「總覽」。", button("私人")));
                break;
            case MainActivity.TAB_CAL:
                s.add(info("切換日期", "左右箭頭換週（切到「月曆」就是換月份）。有事項的日子會有小點，也會顯示農曆。", calHeader()));
                s.add(click("加入特別的日子", "生日、紀念日，或是「在一起幾天」「養寵物幾天」，都可以記在這裡。", button("＋ 加入日期或計算天數")));
                s.add(click("按「＋ 新增」", "先看到目前有哪些特別的日子，再從這裡新增一個。", button("＋ 新增")).then(fill(0, "媽媽生日")));
                s.add(info("輸入名稱和日期", "幫你填好了「媽媽生日」。類型選「日期」是生日、節日；選「計算天數」會算已經過了第幾天。", editor(0)));
                s.add(click("按「儲存」", "媽媽生日就記進去了，月曆上會有小點。", button("儲存")));
                s.add(click("按「完成」", "當天打開 App，會有慶祝動畫。整百天、週年也會慶祝。", button("完成")));
                break;
            case MainActivity.TAB_NOTES:
                s.add(info("馬上輸入", "打開這一頁就能直接打字，寫完按傳送。幫你填好了「週末要記得買牛奶」。", inputBar()));
                s.add(click("按「傳送」", "便利貼會貼到牆上。", button("傳送")));
                s.add(click("移至清單或習慣", "便利貼右下角的「移至」，可以把它變成清單事項或習慣。", button("移至")).then(fill(0, "週末買牛奶")));
                s.add(click("按「確定」", "便利貼就搬進清單了，不用重打一次。", button("確定")));
                break;
            case MainActivity.TAB_EXPENSE:
                s.add(click("薪資設定", "先設定薪資，每月發薪日會自動記成一筆收入。", button("薪資設定")).then(fills("42000", "5")));
                s.add(info("填底薪和發薪日", "幫你填好了底薪 42,000、每月 5 號發。還能填勞保、健保、勞退自提和請假規則。", editor(0)));
                s.add(click("按「儲存」", "從發薪日開始，薪水會自動入帳。", button("儲存")));
                s.add(click("記一筆支出", "每一筆收入或支出，點「＋ 記一筆」。", button("＋ 記一筆")).then(fills("150", "午餐")));
                s.add(info("填金額", "上面可以選支出、收入或轉帳，再填金額、帳戶、分類和備註。這一筆是午餐 150 元。", editor(0)));
                s.add(click("按「儲存」", "本月支出會跟著增加。", button("儲存")));
                s.add(click("再記一筆收入", "收入的記法一樣，只是類型改選「收入」。", button("＋ 記一筆")).then(new Runnable() {
                    @Override public void run() {
                        View tabIncome = button("收入").find();
                        if (tabIncome != null) tabIncome.performClick();
                        fillEdit(0, "2000");
                        fillEdit(1, "年終獎金補發");
                    }
                }));
                s.add(click("按「儲存」", "本月收入增加了，也會算進結餘。", button("儲存")));
                break;
            default:
                s.add(info("開啟提醒通知", "打開後，事項到期、習慣提醒會在這支手機跳出通知。要準時，請在系統詢問時按「允許」。（練習時不會真的打開）", rowOf("通知提醒")));
                s.add(click("換配色", "整體配色風格可以換成你喜歡的顏色，整個 App 都會跟著換。", paletteCard(3)));
                s.add(info("資料備份", "隨時可以匯出備份檔。換手機或重要修改前，建議先備份一份。", label("資料備份")));
                s.add(info("想再看一次", "這裡可以重看每一頁的教學，或從頭完整看一遍。", desc("新手教學選單")));
                break;
        }
        return s;
    }

    // ------------------------------------------------------------------ 找畫面上的東西

    private static View parentView(View v) {
        Object p = v.getParent();
        return p instanceof View ? (View) p : null;
    }

    /** 往上找第一個有點擊事件的(自己也算)。 */
    private static View clickAnc(View v) {
        for (View x = v; x != null; x = parentView(x)) if (x.hasOnClickListeners()) return x;
        return null;
    }

    private static String txt(View v) {
        return (v instanceof TextView && !(v instanceof EditText)) ? ((TextView) v).getText().toString() : null;
    }

    private static View dfs(View v, Pred p) {
        if (v == null || v.getVisibility() != View.VISIBLE) return null;
        if (p.ok(v)) return v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = dfs(g.getChildAt(i), p);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static void collect(View v, Pred p, List<View> out) {
        if (v == null || v.getVisibility() != View.VISIBLE) return;
        if (p.ok(v)) out.add(v);
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) collect(g.getChildAt(i), p, out);
        }
    }

    /** 找東西的範圍:有視窗開著就只看最上面那個視窗,否則看整個主畫面。 */
    private static View scopeRoot() {
        List<Dialog> ds = Modal.openList();
        if (!ds.isEmpty()) {
            Dialog top = ds.get(ds.size() - 1);
            return top.getWindow() == null ? null : top.getWindow().getDecorView();
        }
        return act == null ? null : act.contentRoot();
    }

    private static View first(Pred p) { return dfs(scopeRoot(), p); }

    /** 按鈕:文字一樣、而且(自己或上層)按得下去的第一個。視窗標題之類只是文字的不會被選到。 */
    private static Finder button(final String text) {
        return new Finder() {
            @Override public View find() {
                View m = first(new Pred() { @Override public boolean ok(View v) { return text.equals(txt(v)) && clickAnc(v) != null; } });
                return m == null ? null : clickAnc(m);
            }
        };
    }

    /** 只是文字(說明用,不需要按得下去)。 */
    private static Finder label(final String text) {
        return new Finder() {
            @Override public View find() {
                return first(new Pred() { @Override public boolean ok(View v) { return text.equals(txt(v)); } });
            }
        };
    }

    /** 一整列(開關那種:文字在左、開關在右,文字的上一層就是那一列)。 */
    private static Finder rowOf(final String text) {
        return new Finder() {
            @Override public View find() {
                View t = label(text).find();
                return t == null ? null : parentView(t);
            }
        };
    }

    private static Finder desc(final String d) { return descAny(d); }

    private static Finder descAny(final String... ds) {
        return new Finder() {
            @Override public View find() {
                return first(new Pred() { @Override public boolean ok(View v) { return descMatch(v, ds); } });
            }
        };
    }

    private static boolean descMatch(View v, String[] ds) {
        CharSequence c = v.getContentDescription();
        if (c == null) return false;
        for (String d : ds) if (d.contentEquals(c)) return true;
        return false;
    }

    private static Pred descIn(final String... ds) {
        return new Pred() { @Override public boolean ok(View v) { return descMatch(v, ds); } };
    }

    private static Pred textIn(final String t) {
        return new Pred() { @Override public boolean ok(View v) { return t.equals(txt(v)) && clickAnc(v) != null; } };
    }

    /** 視窗裡(或畫面上)第 n 個輸入框。 */
    private static Finder editor(final int n) {
        return new Finder() {
            @Override public View find() { return nthEdit(n); }
        };
    }

    private static View nthEdit(int n) {
        List<View> l = new ArrayList<>();
        collect(scopeRoot(), new Pred() { @Override public boolean ok(View v) { return v instanceof EditText; } }, l);
        return n < l.size() ? l.get(n) : null;
    }

    private static void fillEdit(int n, String text) {
        View e = nthEdit(n);
        if (e instanceof TextView) ((TextView) e).setText(text);
    }

    private static View cardOf(View v) {
        for (View x = v; x != null; x = parentView(x)) if (x.getTag() instanceof String) return x;
        return null;
    }

    /** 事項(或習慣)那張卡片裡的某個東西。 */
    private static Finder inCard(final String title, final Pred p) {
        return new Finder() {
            @Override public View find() {
                View t = first(new Pred() { @Override public boolean ok(View v) { return title.equals(txt(v)) && cardOf(v) != null; } });
                if (t == null) return null;
                final View card = cardOf(t);
                View r = null;
                if (card instanceof ViewGroup) {
                    ViewGroup g = (ViewGroup) card;
                    for (int i = 0; i < g.getChildCount() && r == null; i++) r = dfs(g.getChildAt(i), p);
                }
                if (r == null) return null;
                View c = clickAnc(r);
                return c != null && c != card ? c : r;
            }
        };
    }

    /** 行事曆最上面那一列:左右箭頭 + 日期範圍(週曆是這一週,月曆是這個月)。 */
    private static Finder calHeader() {
        return new Finder() {
            @Override public View find() {
                View c = first(new Pred() { @Override public boolean ok(View v) { return v instanceof Chevron; } });
                return c == null ? null : parentView(c);
            }
        };
    }

    private static Finder inputBar() {
        return new Finder() {
            @Override public View find() {
                View e = nthEdit(0);
                return e == null ? null : parentView(e);
            }
        };
    }

    private static Finder paletteCard(final int n) {
        return new Finder() {
            @Override public View find() {
                List<Theme.Palette> all = Theme.all();
                if (all.size() <= n) return null;
                return button(all.get(n).name).find();
            }
        };
    }

    private static boolean usable(View v) {
        if (v == null || !v.isShown()) return false;
        return headless || (v.getWidth() > 0 && v.getHeight() > 0);
    }

    private static View resolve(Step s) {
        if (s.target == null) return null;
        try {
            View v = s.target.find();
            return usable(v) ? v : null;
        } catch (RuntimeException e) {
            return null;
        }
    }

    // ------------------------------------------------------------------ 練習資料

    private static String ymd(int offset) { return Model.addDays(Model.today(), offset); }

    private static JSONObject practiceData() {
        try {
            JSONObject d = new JSONObject(NewAccount.defaultJson());
            JSONArray cats = d.getJSONArray("categories");
            JSONArray swapped = new JSONArray();
            for (int i = cats.length() - 1; i >= 0; i--) swapped.put(cats.get(i));   // 私人放第一個:新增事項預設就是「私人」
            d.put("categories", swapped);
            JSONArray habits = new JSONArray();
            habits.put(new JSONObject().put("id", "p_h1").put("name", "早起喝水").put("type", "boolean").put("unit", "")
                    .put("remindTime", JSONObject.NULL).put("freq", "daily").put("weekdays", new JSONArray()).put("monthdays", new JSONArray()).put("createdAt", ymd(-8)));
            habits.put(new JSONObject().put("id", "p_h2").put("name", "閱讀").put("type", "boolean").put("unit", "")
                    .put("remindTime", JSONObject.NULL).put("freq", "daily").put("weekdays", new JSONArray()).put("monthdays", new JSONArray()).put("createdAt", ymd(-8)));
            d.put("habits", habits);
            JSONObject logs = new JSONObject();
            JSONObject l1 = new JSONObject(), l2 = new JSONObject();
            for (int n = 1; n <= 3; n++) l1.put(ymd(-n), new JSONObject().put("value", true).put("checked", true));
            for (int n = 1; n <= 5; n++) l2.put(ymd(-n), new JSONObject().put("value", true).put("checked", true));
            logs.put("p_h1", l1);
            logs.put("p_h2", l2);
            d.put("habitLogs", logs);
            d.put("tasks", new JSONArray().put(new JSONObject().put("id", "p_t0").put("categoryId", "work").put("title", "繳電話費")
                    .put("dueDate", ymd(4)).put("dueTime", "").put("reminder", false).put("status", "pending").put("subtasks", new JSONArray())));
            long now = System.currentTimeMillis();
            d.put("quickNotes", new JSONArray()
                    .put(new JSONObject().put("id", "p_n1").put("text", "想去的咖啡店\n・中山站那間").put("createdAt", now - 86400000L))
                    .put(new JSONObject().put("id", "p_n2").put("text", "書單：\n《小王子》").put("createdAt", now - 3600000L)));
            d.put("expenses", new JSONArray()
                    .put(new JSONObject().put("id", "p_e1").put("type", "expense").put("amount", 65).put("note", "早餐").put("date", ymd(0))
                            .put("accountId", "acc_bank").put("category", "food").put("createdAt", now - 7200000L))
                    .put(new JSONObject().put("id", "p_e2").put("type", "expense").put("amount", 30).put("note", "交通").put("date", ymd(0))
                            .put("accountId", "acc_bank").put("category", "transport").put("createdAt", now - 3600000L)));
            return d;
        } catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------------ 進出口

    static boolean active() { return running; }

    /** 設定頁 / 開發者工具:只看某一頁。 */
    static void play(MainActivity a, int t) { begin(a, t, false); }

    /** 從頭完整看一遍(習慣 → 設定)。 */
    static void playAll(MainActivity a) { begin(a, 0, true); }

    /** 開發者工具:當成新註冊,每一頁下次打開再自動跳出。 */
    static void resetSeen(MainActivity a) {
        if (running || Repo.data() == null) return;
        Repo.set(a, new JSONObject(), "tutorialSeen");
        a.flash("已重設，各頁下次打開會再自動跳出教學");
    }

    /** 畫面被系統收掉時:不要卡在練習資料上。 */
    static void abort(MainActivity a) {
        if (!running || act != a) return;
        running = false;
        token++;
        try { if (overlay != null) overlay.dismiss(); } catch (RuntimeException ignore) { }
        overlay = null;
        act = null;
        Repo.exitSandbox(a);
    }

    private static void begin(MainActivity a, int t, boolean ch) {
        if (running) return;
        if (!Store.linked(a) || Repo.data() == null) { a.flash("資料還沒載入，等一下再試"); return; }
        JSONObject practice = practiceData();
        if (practice == null || !Repo.enterSandbox(practice)) return;
        act = a;
        running = true;
        chain = ch;
        origTab = a.currentTab();
        origCat = a.catId();
        for (int i = 0; i < seen.length; i++) seen[i] = false;
        aboveDialogs = Modal.openList().size();
        firstTab = t;
        overlay = new Overlay(a);
        if (!headless) overlay.show();
        startTab(t);
    }

    private static void startTab(int t) {
        token++;
        tab = t;
        idx = 0;
        steps = stepsFor(t);
        if (t != firstTab) Repo.reseedSandbox(practiceData());
        act.tutorialReset(t, "overview");
        if (t == MainActivity.TAB_NOTES) fillEdit(0, "週末要記得買牛奶");
        render();
    }

    private static void mark(int t) { if (t >= 0 && t < seen.length) seen[t] = true; }

    private static void markAll() { for (int i = 0; i < seen.length; i++) seen[i] = true; }

    private static void finishPage(boolean skipped) {
        if (!running) return;
        final int t = tab;
        if (chain && skipped) { markAll(); close(true); return; }
        mark(t);
        if (chain) {
            if (t + 1 < KEYS.length) {
                token++;
                overlay.hideSpot();
                H.postDelayed(new Runnable() {
                    @Override public void run() { if (running && tab == t) startTab(t + 1); }
                }, 400);
                return;
            }
            markAll();
            close(true);
            return;
        }
        close(false);
    }

    private static void close(boolean toHabits) {
        running = false;
        token++;
        MainActivity a = act;
        try { if (overlay != null) overlay.dismiss(); } catch (RuntimeException ignore) { }
        overlay = null;
        act = null;
        Modal.dismissAll();
        Repo.exitSandbox(a);
        JSONObject d = Repo.data();
        if (d != null && d.optJSONObject("tutorialSeen") != null) {
            for (int i = 0; i < seen.length; i++) {
                if (seen[i] && !d.optJSONObject("tutorialSeen").optBoolean(KEYS[i], false)) Repo.set(a, Boolean.TRUE, "tutorialSeen", KEYS[i]);
            }
        }
        a.tutorialReset(toHabits ? MainActivity.TAB_HABITS : origTab, origCat);
    }

    // ------------------------------------------------------------------ 每一步

    private static void raise() {
        int n = Modal.openList().size();
        if (n > aboveDialogs && overlay != null && !headless) {
            overlay.dismiss();
            overlay.show();
        }
        aboveDialogs = n;
    }

    private static void render() {
        if (!running) return;
        final int my = ++token;
        final Step s = steps.get(idx);
        raise();
        overlay.hideSpot();
        if (s.card) {
            overlay.showCard(s);
            return;
        }
        final long t0 = SystemClock.uptimeMillis();
        Runnable poll = new Runnable() {
            @Override public void run() {
                if (!running || my != token) return;
                View v = resolve(s);
                if (v != null) { showStep(s, v, my); return; }
                if (SystemClock.uptimeMillis() - t0 > 3500) { advance(); return; }   // 找不到就略過這一步,不卡住
                H.postDelayed(this, 60);
            }
        };
        poll.run();
    }

    /**
     * 目標在螢幕上的框。不能只用 getLocationOnScreen:被旋轉過的 View(清單的展開箭頭轉了 90 度)
     * 它回傳的左上角會跑到對面去,洞就偏了一個身位。getGlobalVisibleRect 會把旋轉、縮放算進去。
     */
    static Rect screenRect(View v) {
        Rect vis = new Rect();
        int[] rl = new int[2];
        if (v.getGlobalVisibleRect(vis)) {
            View root = v.getRootView();
            root.getLocationOnScreen(rl);
            vis.offset(rl[0], rl[1]);
            return vis;
        }
        v.getLocationOnScreen(rl);
        return new Rect(rl[0], rl[1], rl[0] + v.getWidth(), rl[1] + v.getHeight());
    }

    private static void showStep(final Step s, View v, final int my) {
        boolean last = idx == steps.size() - 1;
        overlay.fill(s, NAMES[tab] + "頁　" + (idx + 1) + " / " + steps.size(), last ? "完成" : s.info ? "知道了" : "幫我點");
        if (headless) return;
        try { v.requestRectangleOnScreen(new Rect(0, 0, v.getWidth(), v.getHeight()), true); } catch (RuntimeException ignore) { }
        Runnable loop = new Runnable() {
            long lastKey = Long.MIN_VALUE, lastScroll = 0;
            @Override public void run() {
                if (!running || my != token) return;
                View cur = resolve(s);
                if (cur != null) {
                    // 目標在螢幕上的框、以及說明視窗自己的位置,任何一個變了都重新對一次
                    Rect sr = screenRect(cur);
                    int[] o = overlay == null ? new int[2] : overlay.origin();
                    long key = 17;
                    key = key * 31 + sr.left; key = key * 31 + sr.top; key = key * 31 + sr.right; key = key * 31 + sr.bottom;
                    key = key * 31 + o[0]; key = key * 31 + o[1];
                    if (key != lastKey && overlay != null && overlay.place(cur)) lastKey = key;
                    // 版面後來又動了、目標被捲到畫面外:再請它捲回來(最多每 0.4 秒一次)
                    long now = SystemClock.uptimeMillis();
                    if (now - lastScroll > 400) {
                        Rect vis = new Rect();
                        if (!cur.getGlobalVisibleRect(vis) || vis.height() < cur.getHeight() / 2) {
                            lastScroll = now;
                            try { cur.requestRectangleOnScreen(new Rect(0, 0, cur.getWidth(), cur.getHeight()), true); } catch (RuntimeException ignore) { }
                        }
                    }
                }
                H.postDelayed(this, 50);
            }
        };
        loop.run();
    }

    /** 按「幫我點」/「知道了」或直接點亮起來的地方。 */
    static void doStep() {
        if (!running) return;
        Step s = steps.get(idx);
        if (!s.info && !s.card) {
            View v = resolve(s);
            if (v != null) {
                try { v.performClick(); } catch (RuntimeException ignore) { }
            }
            if (s.after != null) {
                try { s.after.run(); } catch (RuntimeException ignore) { }
            }
        }
        advance();
    }

    private static void advance() {
        if (!running) return;
        token++;
        if (overlay != null) overlay.hideSpot();
        idx++;
        if (idx >= steps.size()) { finishPage(false); return; }
        H.postDelayed(new Runnable() { @Override public void run() { render(); } }, 260);
    }

    // ---- 給測試用 ----
    static int debugIdx() { return idx; }
    static int debugTab() { return tab; }
    static int debugSteps() { return steps.size(); }
    static boolean debugIsCard() { return running && steps.get(idx).card; }
    static boolean debugResolves() { return running && (steps.get(idx).card || resolve(steps.get(idx)) != null); }
    static String debugTitle() { return running ? steps.get(idx).title : ""; }

    /** 返回鍵 / 「略過」:這一頁(完整看一遍時是整個教學)不看了。 */
    static void skipPage() { finishPage(true); }

    // ------------------------------------------------------------------ 自動跳出(新註冊的帳號)

    private static boolean wantsAuto(int t) {
        JSONObject d = Repo.data();
        if (d == null || running) return false;
        JSONObject ts = d.optJSONObject("tutorialSeen");
        return ts != null && !ts.optBoolean(KEYS[t], false);
    }

    /** 切到某個分頁時呼叫:新註冊的帳號、這一頁還沒看過 → 稍等一下自動開始。 */
    static void onTab(final MainActivity a, final int t) {
        if (running || t < 0 || t >= KEYS.length || !wantsAuto(t)) return;
        if (autoTick != null) H.removeCallbacks(autoTick);
        autoTries = 0;
        autoTab = t;
        autoTick = new Runnable() {
            @Override public void run() {
                if (running || !wantsAuto(autoTab) || a.currentTab() != autoTab) return;
                if (Modal.anyOpen() || a.loginShowing()) {   // 有動畫或視窗開著:等它關掉再說
                    if (++autoTries < 40) H.postDelayed(this, 1500);
                    return;
                }
                begin(a, autoTab, false);
            }
        };
        H.postDelayed(autoTick, 700);
    }

    // ------------------------------------------------------------------ 畫面

    private static final class Dim extends View {
        private final Paint dimPaint = new Paint(Paint.ANTI_ALIAS_FLAG), ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        float l, t, r, b, rad;   // 亮起來的洞,用「螢幕座標」記;畫的時候才換成這個 View 自己的座標
        boolean hole, full;
        private final int[] loc = new int[2];

        Dim(Context c) {
            super(c);
            dimPaint.setColor(0xB8141414);
            ringPaint.setColor(0xFFFFFFFF);
            ringPaint.setStyle(Paint.Style.STROKE);
            ringPaint.setStrokeWidth(Ui.dp(c, 2.5f));
            rad = Ui.dp(c, 14);
        }

        void setHole(float l, float t, float r, float b) {
            this.l = l; this.t = t; this.r = r; this.b = b;
            hole = true; full = false;
            invalidate();
        }

        void clear() { hole = false; full = false; invalidate(); }

        void setFull() { hole = false; full = true; invalidate(); }

        @Override protected void onDraw(Canvas c) {
            if (full) { c.drawColor(0xB8141414); return; }
            if (!hole) return;
            getLocationOnScreen(loc);   // 視窗被系統邊緣(狀態列)推開多少,這裡每次畫都重新量,洞才不會偏
            Path p = new Path();
            p.setFillType(Path.FillType.EVEN_ODD);
            p.addRect(new RectF(0, 0, getWidth(), getHeight()), Path.Direction.CW);
            RectF h = new RectF(l - loc[0], t - loc[1], r - loc[0], b - loc[1]);
            p.addRoundRect(h, rad, rad, Path.Direction.CW);
            c.drawPath(p, dimPaint);
            c.drawRoundRect(h, rad, rad, ringPaint);
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_UP && hole) {
                float x = e.getRawX(), y = e.getRawY();
                if (x >= l && x <= r && y >= t && y <= b) doStep();
            }
            return true;   // 其他地方碰了沒反應,免得點到底下的東西
        }
    }

    private static final class Overlay extends Dialog {
        private final MainActivity a;
        private final FrameLayout root;
        private final Dim dim;
        private final LinearLayout tip;
        private final TextView prog, title, text, hint, next;
        private final int tipW;
        private boolean centered;

        Overlay(MainActivity a) {
            super(a);
            this.a = a;
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            root = new FrameLayout(a);
            dim = new Dim(a);
            root.addView(dim, new FrameLayout.LayoutParams(-1, -1));
            tipW = Math.min(a.getResources().getDisplayMetrics().widthPixels - Ui.dp(a, 32), Ui.dp(a, 340));

            tip = Ui.col(a);
            tip.setPadding(Ui.dp(a, 18), Ui.dp(a, 16), Ui.dp(a, 18), Ui.dp(a, 14));
            tip.setBackground(Ui.shape(a, 0xFFFFFFFF, 20, 0, 0));
            tip.setElevation(Ui.dp(a, 8));
            prog = Ui.tv(a, "", 11, Ui.SOFT, true);
            title = Ui.tv(a, "", 16, Ui.CARD_INK, true);
            text = Ui.tv(a, "", 13.5f, Ui.CARD_INK, false);
            text.setLineSpacing(0, 1.3f);
            hint = Ui.tv(a, "👆 點亮起來的地方", 12, Ui.ACCENT, true);
            tip.addView(prog);
            tip.addView(title, Ui.mw(a, 4));
            tip.addView(text, Ui.mw(a, 6));
            tip.addView(hint, Ui.mw(a, 8));
            LinearLayout btns = Ui.row(a);
            btns.setGravity(Gravity.CENTER_VERTICAL);
            btns.addView(Ui.btnGhost(a, "略過", new View.OnClickListener() {
                @Override public void onClick(View v) { skipPage(); }
            }));
            btns.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 1f));
            next = Ui.btnPrimary(a, "幫我點", new View.OnClickListener() {
                @Override public void onClick(View v) { doStep(); }
            });
            btns.addView(next);
            tip.addView(btns, Ui.mw(a, 12));
            FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(tipW, -2, Gravity.TOP | Gravity.START);
            root.addView(tip, tp);
            tip.setVisibility(View.GONE);

            setContentView(root);
            Window w = getWindow();
            if (w != null) {
                w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                w.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
                w.setGravity(Gravity.TOP | Gravity.START);
                w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                w.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
                w.setSoftInputMode(3);   // SOFT_INPUT_STATE_ALWAYS_HIDDEN:教學期間不要彈出鍵盤
            }
            setCancelable(false);
        }

        @Override public void onBackPressed() { skipPage(); }

        void hideSpot() {
            dim.clear();
            tip.setVisibility(View.GONE);
            centered = false;
        }

        /** 歡迎卡:全螢幕變暗、卡片放中間。 */
        void showCard(Step s) {
            prog.setText("歡迎");
            title.setText(s.title);
            text.setText(s.text);
            hint.setVisibility(View.GONE);
            next.setText("開始");
            dim.setFull();
            tip.setVisibility(View.VISIBLE);
            centered = true;
            if (headless) return;
            final int[] tries = {0};
            tip.post(new Runnable() {
                @Override public void run() {
                    if (!centered) return;
                    int W = dim.getWidth(), Hh = dim.getHeight();
                    if ((W <= 0 || Hh <= 0 || tip.getHeight() <= 0) && tries[0]++ < 40) { H.postDelayed(this, 30); return; }   // 還沒排好版面
                    tip.setTranslationX(Math.max(0, (W - tipW) / 2f));
                    tip.setTranslationY(Math.max(0, (Hh - tip.getHeight()) / 2f));
                }
            });
        }

        void fill(Step s, String progress, String go) {
            prog.setText(progress);
            title.setText(s.title);
            text.setText(s.text);
            hint.setVisibility(s.info ? View.GONE : View.VISIBLE);
            next.setText(go);
            tip.setVisibility(View.VISIBLE);
            centered = false;
        }

        /** 亮起來的洞對準 target,說明卡放在它上面或下面。 */
        int[] origin() {
            int[] o = new int[2];
            dim.getLocationOnScreen(o);
            return o;
        }

        boolean place(View target) {
            int[] o = origin();
            float pad = Ui.dp(a, 6);
            int W = dim.getWidth(), Hh = dim.getHeight();
            if (W <= 0 || Hh <= 0) return false;   // 視窗還沒排好版面,稍後再試
            Rect tr = screenRect(target);
            float sl = Math.max(o[0], tr.left - pad), st = Math.max(o[1], tr.top - pad);
            float sr = Math.min(o[0] + W, tr.right + pad), sb = Math.min(o[1] + Hh, tr.bottom + pad);
            dim.setHole(sl, st, sr, sb);
            // 以下是說明卡的位置,用 dim 自己的座標算
            float l = sl - o[0], tp = st - o[1], r = sr - o[0], b = sb - o[1];
            tip.measure(View.MeasureSpec.makeMeasureSpec(tipW, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(Hh, View.MeasureSpec.AT_MOST));
            int th = tip.getMeasuredHeight();
            float gap = Ui.dp(a, 12), edge = Ui.dp(a, 8);
            float topBelow = b + gap, topAbove = tp - gap - th, top;
            if ((tp + b) / 2 < Hh / 2f && topBelow + th <= Hh - edge) top = topBelow;
            else if (topAbove >= edge) top = topAbove;
            else if (topBelow + th <= Hh - edge) top = topBelow;
            else top = Hh - th - gap;
            float left = Math.min(Math.max((l + r) / 2f - tipW / 2f, Ui.dp(a, 16)), W - tipW - Ui.dp(a, 16));
            tip.setTranslationX(left);
            tip.setTranslationY(Math.max(edge, top));
            return true;
        }
    }
}
