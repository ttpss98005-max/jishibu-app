package tw.jishibu.widget;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * 「清單」分頁:事項卡片(主要事項 + 細項)。照網頁版 renderTaskList / toggleTask / openTaskModal / openSubModal 等。
 * 資料只讀 Repo.data(),修改一律走 Repo.set/del/add/patch(操作會排隊、安全地同步到雲端)。
 */
final class ListScreen extends ScrollScreen {
    /** 待處理 / 已完成 / 全部(再按一次同一個就變成全部)。 */
    static String filter = "pending";
    /** 事項是否展開細項(沒記錄 = 展開)。只存在記憶體,跟網頁版一樣。 */
    private static final Map<String, Boolean> expanded = new HashMap<>();

    ListScreen(MainActivity a) { super(a); }

    // ---------- 畫面 ----------

    @Override void build() {
        // 工具列:待處理 / 已完成 + 新增
        LinearLayout bar = Ui.row(a);
        String[] labels = {"待處理", "已完成"};
        int sel = "pending".equals(filter) ? 0 : "done".equals(filter) ? 1 : -1;
        LinearLayout seg = Ui.seg(a, labels, sel, new Ui.IntCb() {
            @Override public void on(int i) {
                String f = i == 0 ? "pending" : "done";
                filter = f.equals(filter) ? "all" : f;
                refresh();
            }
        });
        bar.addView(seg, Ui.weight(1));
        bar.addView(sortButton(), sortBtnLp());
        bar.addView(Ui.btnPrimary(a, "＋ 新增事項", new View.OnClickListener() {
            @Override public void onClick(View v) { openTaskModal(null); }
        }));
        content.addView(bar, Ui.mw(a, 0));
        content.addView(Ui.spacer(a, 16));

        List<JSONObject> list = visibleTasks();
        if (list.isEmpty()) {
            content.addView(Ui.empty(a, "目前沒有事項"));
            return;
        }
        final LinearLayout table = Ui.col(a);
        for (JSONObject t : list) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = Ui.dp(a, 12);
            table.addView(taskCard(t, table), lp);
        }
        content.addView(table, Ui.mw(a, 0));
    }

    // ---------- 排序:日期 / 名稱 / 新增時間;都不選就是自己拖動的順序(拖了就取消排序)。設定存在 taskSort,跟網頁版共用 ----------

    private static final String[] SORT_MODES = {"date", "name", "created"};
    private static final String[] SORT_LABELS = {"日期", "名稱", "新增時間"};
    private static final String[][] SORT_DIRS = {{"最早在前", "最晚在前"}, {"正序", "倒序"}, {"最舊在前", "最新在前"}};

    private static String sortMode() {
        JSONObject s = Repo.data().optJSONObject("taskSort");
        String m = s == null ? "" : s.optString("mode", "");
        for (String k : SORT_MODES) if (k.equals(m)) return m;
        return "manual";
    }

    private static boolean sortDesc() {
        JSONObject s = Repo.data().optJSONObject("taskSort");
        return s != null && "desc".equals(s.optString("dir", "asc"));
    }

    private void setSort(String mode, boolean desc) {
        try {
            Repo.set(a, new JSONObject().put("mode", mode).put("dir", desc ? "desc" : "asc"), "taskSort");
        } catch (JSONException ignore) { }
    }

    /** 新增時間:id 的最後 8 碼是建立當下的時間(base36);看不出來的(舊資料)當成最舊。 */
    static long createdMs(JSONObject t) {
        String id = Model.s(t, "id");
        if (id.length() < 13) return 0L;
        try {
            long ms = Long.parseLong(id.substring(id.length() - 8), 36);
            return (ms >= 1400000000000L && ms < 3200000000000L) ? ms : 0L;
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    /** 依目前的排序整理清單(都不選就照資料裡的順序);同分的照原本順序。 */
    static List<JSONObject> sortTasks(List<JSONObject> list, final String mode, boolean desc) {
        if ("manual".equals(mode)) return list;
        final int sgn = desc ? -1 : 1;
        final Map<JSONObject, Integer> pos = new HashMap<>();
        List<JSONObject> all = Model.tasks();
        for (int i = 0; i < all.size(); i++) pos.put(all.get(i), i);
        final java.text.Collator col = java.text.Collator.getInstance(Locale.TAIWAN);
        List<JSONObject> out = new ArrayList<>(list);
        Collections.sort(out, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject x, JSONObject y) {
                int c;
                if ("date".equals(mode)) {
                    long dx = Model.taskDueMs(x), dy = Model.taskDueMs(y);
                    if (dx == 0 && dy == 0) c = 0;
                    else if (dx == 0) return 1;          // 沒日期的永遠排在最後
                    else if (dy == 0) return -1;
                    else c = Long.compare(dx, dy) * sgn;
                } else if ("name".equals(mode)) {
                    c = col.compare(Model.s(x, "title"), Model.s(y, "title")) * sgn;
                } else {
                    c = Long.compare(createdMs(x), createdMs(y)) * sgn;
                }
                if (c != 0) return c;
                Integer px = pos.get(x), py = pos.get(y);
                return Integer.compare(px == null ? 0 : px, py == null ? 0 : py);
            }
        });
        return out;
    }

    private LinearLayout.LayoutParams sortBtnLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(Ui.dp(a, 36), Ui.dp(a, 36));
        p.rightMargin = Ui.dp(a, 8);
        return p;
    }

    private View sortButton() {
        boolean on = !"manual".equals(sortMode());
        FrameLayout b = new FrameLayout(a);
        b.setBackground(Ui.shape(a, on ? Ui.ACCENT_SOFT : Ui.CHIP_BG, 10, 0, 0));
        b.setContentDescription("排序");
        b.addView(Icons.line(a, Icons.SORT, 20, on ? Ui.ACCENT : Ui.SOFT),
                new FrameLayout.LayoutParams(Ui.dp(a, 20), Ui.dp(a, 20), Gravity.CENTER));
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openSortDialog(); }
        });
        return b;
    }

    private void openSortDialog() {
        final Modal.Sheet sh = Modal.sheet(a);
        TextView title = Ui.tv(a, "排序", 16, Ui.CARD_INK, true);
        title.setPadding(0, 0, 0, Ui.dp(a, 8));
        sh.box.addView(title);
        final LinearLayout body = Ui.col(a);
        sh.box.addView(body);
        fillSortBody(body);
        LinearLayout actions = Ui.row(a);
        actions.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        actions.addView(Ui.btnPrimary(a, "完成", new View.OnClickListener() {
            @Override public void onClick(View v) { sh.dismiss(); }
        }));
        sh.box.addView(actions, Ui.mw(a, 22));
        sh.dialog.show();
    }

    /** 選項(單選)+ 順序。再按一次已選的選項 = 取消,回到自己拖動的順序。 */
    private void fillSortBody(final LinearLayout body) {
        body.removeAllViews();
        final String cur = sortMode();
        boolean desc = sortDesc();
        for (int i = 0; i < SORT_MODES.length; i++) {
            final String m = SORT_MODES[i];
            boolean sel = m.equals(cur);
            LinearLayout r = Ui.row(a);
            r.setPadding(Ui.dp(a, 4), Ui.dp(a, 12), Ui.dp(a, 4), Ui.dp(a, 12));
            FrameLayout rd = new FrameLayout(a);
            rd.setBackground(Ui.shape(a, 0xFFFFFFFF, 9, sel ? Ui.ACCENT : Ui.BORDER, 2));
            if (sel) {
                View dot = new View(a);
                dot.setBackground(Ui.shape(a, Ui.ACCENT, 5, 0, 0));
                rd.addView(dot, new FrameLayout.LayoutParams(Ui.dp(a, 10), Ui.dp(a, 10), Gravity.CENTER));
            }
            r.addView(rd, new LinearLayout.LayoutParams(Ui.dp(a, 18), Ui.dp(a, 18)));
            r.addView(Ui.tv(a, SORT_LABELS[i], 14, Ui.CARD_INK, true), Ui.gap(a, 12));
            r.setContentDescription(SORT_LABELS[i] + (sel ? ",已選" : ""));
            r.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (m.equals(cur)) setSort("manual", false); else setSort(m, false);
                    refresh();
                    fillSortBody(body);
                }
            });
            body.addView(r, new LinearLayout.LayoutParams(-1, -2));
            if (i < SORT_MODES.length - 1) {
                View line = new View(a);
                line.setBackgroundColor(Ui.BORDER);
                body.addView(line, new LinearLayout.LayoutParams(-1, Math.max(1, Ui.dp(a, 1))));
            }
        }
        int mi = -1;
        for (int i = 0; i < SORT_MODES.length; i++) if (SORT_MODES[i].equals(cur)) mi = i;
        if (mi >= 0) {
            TextView lab = Ui.tv(a, "順序", 12, Ui.SOFT, true);
            body.addView(lab, Ui.mw(a, 14));
            final String mode = cur;
            body.addView(Ui.pillTabs(a, SORT_DIRS[mi], desc ? 1 : 0, new Ui.IntCb() {
                @Override public void on(int k) {
                    setSort(mode, k == 1);
                    refresh();
                }
            }), Ui.wrap(a, 6));
        }
    }

    /** 拖動完成:看得到的幾個事項照新順序填回它們原本佔的位置(看不到的別的分類、已完成維持不動);自己拖了就不再套用排序。 */
    private void saveOrder(List<String> visible) {
        List<String> full = new ArrayList<>();
        for (JSONObject t : Model.tasks()) full.add(Model.s(t, "id"));
        List<String> out = new ArrayList<>();
        int k = 0;
        for (String id : full) {
            if (visible.contains(id)) { if (k < visible.size()) out.add(visible.get(k++)); }
            else out.add(id);
        }
        if (!out.equals(full)) Repo.order(a, out, "tasks");
        if (!"manual".equals(sortMode())) setSort("manual", false);
        a.refreshCurrent();
    }

    private List<JSONObject> visibleTasks() {
        String cat = a.catId();
        List<JSONObject> out = new ArrayList<>();
        for (JSONObject t : Model.tasks()) {
            if (!"overview".equals(cat) && !cat.equals(Model.s(t, "categoryId"))) continue;
            boolean done = "done".equals(Model.s(t, "status"));
            if ("pending".equals(filter) && done) continue;
            if ("done".equals(filter) && !done) continue;
            out.add(t);
        }
        return sortTasks(out, sortMode(), sortDesc());
    }

    private View taskCard(final JSONObject t, LinearLayout table) {
        final String tid = Model.s(t, "id");
        final boolean done = "done".equals(Model.s(t, "status"));
        final JSONArray subs = t.optJSONArray("subtasks") == null ? new JSONArray() : t.optJSONArray("subtasks");
        int doneSub = 0;
        for (int i = 0; i < subs.length(); i++) {
            JSONObject s = subs.optJSONObject(i);
            if (s != null && "done".equals(Model.s(s, "status"))) doneSub++;
        }
        Boolean ex = expanded.get(tid);
        final boolean open = ex == null || ex;
        String due = Model.s(t, "dueDate", "");
        boolean overdue = Model.overdueTask(t);
        boolean hasBell = t.optBoolean("reminder", false) && !due.isEmpty();

        final LinearLayout card = Ui.taskCard(a);
        card.setTag(tid);
        if (done) card.setAlpha(0.7f);

        // 第一行固定:勾勾 + 標題 + (展開箭頭、備註、編輯、刪除);日期和進度放在標題下面一行,
        // 按鈕不會因為日期長短而換行(跟網頁一樣)
        LinearLayout head = Ui.row(a);
        head.setGravity(Gravity.TOP);
        head.setPadding(Ui.dp(a, 6), Ui.dp(a, 13), Ui.dp(a, 8), Ui.dp(a, 11));

        // 左:長按拖動的把手(三條線),跟習慣一樣
        LinearLayout handle = Ui.col(a);
        handle.setGravity(Gravity.CENTER);
        handle.setPadding(Ui.dp(a, 5), Ui.dp(a, 5), Ui.dp(a, 5), Ui.dp(a, 5));
        handle.setContentDescription("長按拖曳排序");
        for (int k = 0; k < 3; k++) {
            View line = new View(a);
            line.setBackground(Ui.shape(a, Ui.SOFT, 1, 0, 0));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(a, 14), Math.max(2, Ui.dp(a, 2)));
            if (k > 0) lp.topMargin = Ui.dp(a, 3);
            handle.addView(line, lp);
        }
        handle.setOnTouchListener(new RowDrag(a, table, card, 12, 2, new RowDrag.Done() {
            @Override public void on(List<String> visible) { saveOrder(visible); }
        }));
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(-2, -2);
        hlp.topMargin = Ui.dp(a, 1);
        hlp.rightMargin = Ui.dp(a, 8);
        head.addView(handle, hlp);

        final Check chk = new Check(a, 22, done);
        chk.setContentDescription("完成:" + Model.s(t, "title"));
        chk.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleTask(t, chk); }
        });
        LinearLayout.LayoutParams chkLp = new LinearLayout.LayoutParams(Ui.dp(a, 22), Ui.dp(a, 22));
        chkLp.rightMargin = Ui.dp(a, 12);
        head.addView(chk, chkLp);

        LinearLayout main = Ui.col(a);
        LinearLayout titleRow = new LinearLayout(a);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        if ("overview".equals(a.catId())) {
            JSONObject cat = Model.category(Model.s(t, "categoryId"));
            if (cat != null) {
                View dot = new View(a);
                dot.setBackground(Ui.shape(a, Theme.parse(Model.s(cat, "color", "#999999")), 8, 0, 0));
                LinearLayout.LayoutParams dotLp = new LinearLayout.LayoutParams(Ui.dp(a, 8), Ui.dp(a, 8));
                dotLp.topMargin = Ui.dp(a, 7);
                dotLp.rightMargin = Ui.dp(a, 8);
                titleRow.addView(dot, dotLp);
            }
        }
        TextView title = Ui.tv(a, Model.s(t, "title", ""), 14, done ? Ui.SOFT : Ui.CARD_INK, true);
        if (done) Ui.strike(title);
        titleRow.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        main.addView(titleRow, new LinearLayout.LayoutParams(-1, -2));

        if (subs.length() > 0 || !due.isEmpty()) {
            Flow meta = new Flow(a, 6, 6);
            if (subs.length() > 0) {
                meta.addView(Ui.chip(a, doneSub + "/" + subs.length(), 10.5f, Ui.ACCENT, Ui.ACCENT_SOFT, true));
            }
            if (!due.isEmpty()) {
                // 有設時間就連時間一起顯示;有開提醒,後面多一個同風格的鈴鐺(沒有文字)
                if (overdue) meta.addView(Ui.chipBell(a, "延誤 " + Model.fmtTaskWhen(t), 11, Ui.ON_ACCENT, Ui.DANGER, true, hasBell));
                else meta.addView(Ui.chipBell(a, Model.fmtTaskWhen(t), 11.5f, Ui.SOFT, Ui.CHIP_BG, false, hasBell));
            }
            LinearLayout.LayoutParams metaLp = new LinearLayout.LayoutParams(-1, -2);
            metaLp.topMargin = Ui.dp(a, 5);
            main.addView(meta, metaLp);
        }
        head.addView(main, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView arrow = Ui.tv(a, "▸", 11, Ui.SOFT, false);
        arrow.setGravity(Gravity.CENTER);
        arrow.setRotation(open ? 90 : 0);
        arrow.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(a, 26), Ui.dp(a, 26)));
        arrow.setContentDescription(open ? "收合細項" : "展開細項");
        arrow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { expanded.put(tid, !open); refresh(); }
        });

        String note = Model.s(t, "note", "");
        TextView noteBtn = Ui.textBtn(a, "備註", new View.OnClickListener() {
            @Override public void onClick(View v) { openNoteModal(tid, null); }
        });
        if (!note.isEmpty()) { noteBtn.setTextColor(Ui.ACCENT); noteBtn.setTypeface(noteBtn.getTypeface(), android.graphics.Typeface.BOLD); }
        // 箭頭、備註、鉛筆、叉叉固定一組,放在第一行最右邊
        LinearLayout acts = Ui.row(a);
        acts.addView(arrow);
        acts.addView(noteBtn);
        acts.addView(Ui.iconBtn(a, Icons.EDIT, 15, 5, Ui.SOFT, "編輯", new View.OnClickListener() {
            @Override public void onClick(View v) { openTaskModal(tid); }
        }));
        acts.addView(Ui.iconBtn(a, Icons.DEL, 15, 5, Ui.SOFT, "刪除", new View.OnClickListener() {
            @Override public void onClick(View v) { deleteTask(tid); }
        }));
        LinearLayout.LayoutParams actsLp = new LinearLayout.LayoutParams(-2, -2);
        actsLp.topMargin = Ui.dp(a, -3);
        head.addView(acts, actsLp);
        card.addView(head, new LinearLayout.LayoutParams(-1, -2));

        if (!note.isEmpty()) card.addView(notePreview(note, 34), previewLp(0));

        if (open) {
            LinearLayout box = Ui.col(a);
            box.setBackgroundColor(Ui.SUB_BG);
            box.setPadding(Ui.dp(a, 48), Ui.dp(a, 4), Ui.dp(a, 16), Ui.dp(a, 14));
            for (int i = 0; i < subs.length(); i++) {
                JSONObject s = subs.optJSONObject(i);
                if (s != null) box.addView(subRow(t, s), new LinearLayout.LayoutParams(-1, -2));
            }
            TextView add = Ui.tv(a, "＋ 新增細項", 12, Ui.ACCENT, true);
            add.setPadding(Ui.dp(a, 14), Ui.dp(a, 7), Ui.dp(a, 14), Ui.dp(a, 7));
            add.setBackground(Ui.shape(a, Ui.ACCENT_SOFT, 999, 0, 0));
            add.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openSubModal(tid, null); }
            });
            box.addView(add, Ui.wrap(a, 8));
            card.addView(box, new LinearLayout.LayoutParams(-1, -2));
        }
        return card;
    }

    private TextView notePreview(String note, float leftDp) {
        TextView n = Ui.tv(a, note, 12, Ui.SOFT, false);
        n.setPadding(Ui.dp(a, 12), Ui.dp(a, 7), Ui.dp(a, 12), Ui.dp(a, 7));
        n.setBackground(Ui.shape(a, Ui.SUB_BG, 10, 0, 0));
        return n;
    }

    private LinearLayout.LayoutParams previewLp(float extraLeft) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.leftMargin = Ui.dp(a, 34 + extraLeft);
        p.rightMargin = Ui.dp(a, 12);
        p.bottomMargin = Ui.dp(a, 4);
        return p;
    }

    private View subRow(final JSONObject t, final JSONObject s) {
        final String tid = Model.s(t, "id"), sid = Model.s(s, "id");
        final boolean done = "done".equals(Model.s(s, "status"));
        LinearLayout wrap = Ui.col(a);
        wrap.addView(Ui.dotLine(a));

        LinearLayout row = Ui.row(a);
        row.setPadding(0, Ui.dp(a, 9), 0, Ui.dp(a, 9));
        final Check chk = new Check(a, 15, done);
        chk.setContentDescription("完成:" + Model.s(s, "title"));
        chk.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleSub(tid, s, chk); }
        });
        LinearLayout.LayoutParams sChkLp = new LinearLayout.LayoutParams(Ui.dp(a, 15), Ui.dp(a, 15));
        sChkLp.rightMargin = Ui.dp(a, 10);
        row.addView(chk, sChkLp);
        TextView title = Ui.tv(a, Model.s(s, "title", ""), 13, done ? Ui.SOFT : Ui.CARD_INK, false);
        if (done) Ui.strike(title);
        row.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));

        String note = Model.s(s, "note", "");
        TextView noteBtn = Ui.textBtn(a, "備註", new View.OnClickListener() {
            @Override public void onClick(View v) { openNoteModal(tid, sid); }
        });
        if (!note.isEmpty()) { noteBtn.setTextColor(Ui.ACCENT); noteBtn.setTypeface(noteBtn.getTypeface(), android.graphics.Typeface.BOLD); }
        LinearLayout acts = Ui.row(a);
        acts.addView(noteBtn);
        acts.addView(Ui.iconBtn(a, Icons.EDIT, 15, 5, Ui.SOFT, "編輯", new View.OnClickListener() {
            @Override public void onClick(View v) { openSubModal(tid, sid); }
        }));
        acts.addView(Ui.iconBtn(a, Icons.DEL, 15, 5, Ui.SOFT, "刪除", new View.OnClickListener() {
            @Override public void onClick(View v) { deleteSub(tid, sid); }
        }));
        row.addView(acts);
        wrap.addView(row, new LinearLayout.LayoutParams(-1, -2));
        if (!note.isEmpty()) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.leftMargin = Ui.dp(a, 23);
            lp.bottomMargin = Ui.dp(a, 4);
            wrap.addView(notePreview(note, 0), lp);
        }
        return wrap;
    }

    // ---------- 資料操作 ----------

    private static JSONObject findTask(String id) {
        for (JSONObject t : Model.tasks()) if (id.equals(Model.s(t, "id"))) return t;
        return null;
    }

    private static JSONObject findSub(JSONObject t, String sid) {
        JSONArray subs = t == null ? null : t.optJSONArray("subtasks");
        if (subs == null) return null;
        for (int i = 0; i < subs.length(); i++) {
            JSONObject s = subs.optJSONObject(i);
            if (s != null && sid.equals(Model.s(s, "id"))) return s;
        }
        return null;
    }

    private static int indexOfTask(String id) {
        JSONObject d = Repo.data();
        JSONArray arr = d == null ? null : d.optJSONArray("tasks");
        if (arr == null) return -1;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && id.equals(Model.s(o, "id"))) return i;
        }
        return -1;
    }

    private static int indexOfSub(JSONObject t, String sid) {
        JSONArray subs = t == null ? null : t.optJSONArray("subtasks");
        if (subs == null) return -1;
        for (int i = 0; i < subs.length(); i++) {
            JSONObject s = subs.optJSONObject(i);
            if (s != null && sid.equals(Model.s(s, "id"))) return i;
        }
        return -1;
    }

    private static JSONObject copy(JSONObject o) {
        try { return new JSONObject(o.toString()); } catch (JSONException e) { return o; }
    }

    private void toggleTask(JSONObject t, Check chk) {
        boolean nowDone = !"done".equals(Model.s(t, "status"));
        JSONObject set = new JSONObject();
        try {
            set.put("status", nowDone ? "done" : "pending");
            set.put("completedAt", nowDone ? Model.today() : JSONObject.NULL);
        } catch (JSONException ignore) { }
        Repo.patch(a, set, null, "tasks", Model.s(t, "id"));
        Reminders.sync(a, t);   // 做完的事項不再提醒;改回未完成就把提醒補回去(t 已經是新狀態)
        chk.setDone(nowDone);
        if (nowDone) chk.bounce();
        // 讓彈跳動畫先播一下,再重畫(狀態文字、刪除線、篩選)
        scroll.postDelayed(new Runnable() {
            @Override public void run() { a.refreshCurrent(); }
        }, nowDone ? 420 : 0);
    }

    private void toggleSub(String tid, JSONObject s, Check chk) {
        boolean nowDone = !"done".equals(Model.s(s, "status"));
        JSONObject set = new JSONObject();
        try {
            set.put("status", nowDone ? "done" : "pending");
            set.put("completedAt", nowDone ? Model.today() : JSONObject.NULL);
        } catch (JSONException ignore) { }
        Repo.patch(a, set, null, "tasks", tid, "subtasks", Model.s(s, "id"));
        chk.setDone(nowDone);
        if (nowDone) chk.bounce();
        scroll.postDelayed(new Runnable() {
            @Override public void run() { a.refreshCurrent(); }
        }, nowDone ? 420 : 0);
    }

    private void deleteTask(final String tid) {
        final JSONObject t = findTask(tid);
        if (t == null) return;
        Modal.confirm(a, "確定要刪除此事項及其所有細項嗎?", null, "刪除", true, new Runnable() {
            @Override public void run() {
                final JSONObject removed = copy(t);
                final int idx = indexOfTask(tid);
                final String title = Model.s(t, "title");
                Reminders.remove(a, tid);
                Repo.del(a, "tasks", tid);
                a.refreshCurrent();
                a.undo("已刪除「" + title + "」", new Runnable() {
                    @Override public void run() {
                        Repo.add(a, removed, idx, "tasks");
                        Reminders.sync(a, removed);
                        a.refreshCurrent();
                    }
                });
            }
        });
    }

    private void deleteSub(final String tid, final String sid) {
        final JSONObject t = findTask(tid);
        final JSONObject s = findSub(t, sid);
        if (t == null || s == null) return;
        final JSONObject removed = copy(s);
        final int idx = indexOfSub(t, sid);
        Repo.del(a, "tasks", tid, "subtasks", sid);
        a.refreshCurrent();
        a.undo("已刪除「" + Model.s(removed, "title") + "」", new Runnable() {
            @Override public void run() {
                Repo.add(a, removed, idx, "tasks", tid, "subtasks");
                a.refreshCurrent();
            }
        });
    }

    // ---------- 視窗 ----------

    private void openNoteModal(final String tid, final String sid) {
        JSONObject t = findTask(tid);
        if (t == null) return;
        JSONObject target = sid == null ? t : findSub(t, sid);
        if (target == null) return;
        Form f = new Form(a);
        final Form.Text note = f.multiline("", Model.s(target, "note", ""), "寫點備註...", 4);
        Modal.show(a, "備註", f.view(), "儲存", new Modal.Ok() {
            @Override public boolean run() {
                String text = note.get();
                if (text.isEmpty()) {
                    // 網頁版存成 null
                    JSONObject set = new JSONObject();
                    try { set.put("note", JSONObject.NULL); } catch (JSONException ignore) { }
                    if (sid == null) Repo.patch(a, set, null, "tasks", tid);
                    else Repo.patch(a, set, null, "tasks", tid, "subtasks", sid);
                } else {
                    JSONObject set = new JSONObject();
                    try { set.put("note", text); } catch (JSONException ignore) { }
                    if (sid == null) Repo.patch(a, set, null, "tasks", tid);
                    else Repo.patch(a, set, null, "tasks", tid, "subtasks", sid);
                }
                a.refreshCurrent();
                return true;
            }
        });
    }

    private void openTaskModal(final String taskId) {
        final JSONObject task = taskId == null ? null : findTask(taskId);
        final List<JSONObject> cats = Model.categories();
        boolean showCat = "overview".equals(a.catId()) || task != null;
        Form f = new Form(a);
        Form.Pick catPick = null;
        if (showCat) {
            String[] names = new String[cats.size()];
            int sel = 0;
            for (int i = 0; i < cats.size(); i++) {
                names[i] = Model.s(cats.get(i), "name", "");
                if (task != null && Model.s(cats.get(i), "id").equals(Model.s(task, "categoryId"))) sel = i;
            }
            catPick = f.pick("歸類分類(必選)", names, sel);
        }
        final Form.Pick catF = catPick;
        final Form.Text title = f.text("標題", task == null ? "" : Model.s(task, "title", ""), "例如:完成季報");
        final Form.Dt dt = f.dateTime(task == null ? "" : Model.s(task, "dueDate", ""), task == null ? "" : Model.s(task, "dueTime", ""),
                task != null && task.optBoolean("reminder", false));
        Modal.show(a, task != null ? "編輯主要事項" : "新增主要事項", f.view(), "儲存", new Modal.Ok() {
            @Override public boolean run() {
                String ti = title.get();
                if (ti.isEmpty()) { Ui.toast(a, "請輸入標題"); return false; }
                String categoryId = a.catId();
                if (catF != null) {
                    if (cats.isEmpty() || catF.index < 0 || catF.index >= cats.size()) { Ui.toast(a, "請選擇歸類分類"); return false; }
                    categoryId = Model.s(cats.get(catF.index), "id");
                }
                if (task != null) {
                    JSONObject set = new JSONObject();
                    try {
                        set.put("title", ti); set.put("dueDate", dt.dueDate()); set.put("dueTime", dt.dueTime());
                        set.put("reminder", dt.reminder()); set.put("categoryId", categoryId);
                    } catch (JSONException ignore) { }
                    Repo.patch(a, set, null, "tasks", taskId);
                    Reminders.sync(a, task);   // task 已經是新內容
                } else {
                    JSONObject item = new JSONObject();
                    try {
                        item.put("id", Repo.newId());
                        item.put("categoryId", categoryId);
                        item.put("title", ti);
                        item.put("dueDate", dt.dueDate());
                        item.put("dueTime", dt.dueTime());
                        item.put("reminder", dt.reminder());
                        item.put("status", "pending");
                        item.put("subtasks", new JSONArray());
                    } catch (JSONException ignore) { }
                    Repo.add(a, item, -1, "tasks");
                    Reminders.sync(a, item);
                }
                a.refreshCurrent();
                return true;
            }
        });
    }

    private void openSubModal(final String tid, final String subId) {
        final JSONObject t = findTask(tid);
        if (t == null) return;
        final JSONObject s = subId == null ? null : findSub(t, subId);
        Form f = new Form(a);
        final Form.Text title = f.text("標題", s == null ? "" : Model.s(s, "title", ""), "例如:整理數據");
        Modal.show(a, s != null ? "編輯細項" : "新增細項", f.view(), "儲存", new Modal.Ok() {
            @Override public boolean run() {
                String ti = title.get();
                if (ti.isEmpty()) { Ui.toast(a, "請輸入標題"); return false; }
                if (s != null) {
                    JSONObject set = new JSONObject();
                    try { set.put("title", ti); } catch (JSONException ignore) { }
                    Repo.patch(a, set, null, "tasks", tid, "subtasks", subId);
                } else {
                    JSONObject item = new JSONObject();
                    try {
                        item.put("id", Repo.newId());
                        item.put("title", ti);
                        item.put("status", "pending");
                    } catch (JSONException ignore) { }
                    Repo.add(a, item, -1, "tasks", tid, "subtasks");
                    expanded.put(tid, true);
                }
                a.refreshCurrent();
                return true;
            }
        });
    }

    /** 搜尋點到某個事項前先設好:全部篩選、展開那一項(之後 MainActivity 會切分類並重畫)。 */
    static void prepareJump(String taskId) {
        filter = "all";
        expanded.put(taskId, true);
    }
}
