package tw.jishibu.widget;

import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 「清單」分頁:事項卡片(主要事項 + 細項)。照網頁版 renderTaskList / toggleTask / openTaskModal / openSubModal 等。
 * 資料只讀 Repo.data(),修改一律走 Repo.set/del/add/patch(操作會排隊、安全地同步到雲端)。
 */
final class ListScreen extends ScrollScreen {
    /** 待處理 / 已完成 / 全部(再按一次同一個就變成全部)。 */
    static String filter = "pending";
    /** 事項是否展開細項(沒記錄 = 展開)。只存在記憶體,跟網頁版一樣。 */
    private static final Map<String, Boolean> expanded = new HashMap<>();

    ListScreen(MainActivity a) { super(a); }

    // ---------- 畫面 ----------

    @Override void build() {
        // 工具列:待處理 / 已完成 + 新增
        LinearLayout bar = Ui.row(a);
        String[] labels = {"待處理", "已完成"};
        int sel = "pending".equals(filter) ? 0 : "done".equals(filter) ? 1 : -1;
        LinearLayout seg = Ui.seg(a, labels, sel, new Ui.IntCb() {
            @Override public void on(int i) {
                String f = i == 0 ? "pending" : "done";
                filter = f.equals(filter) ? "all" : f;
                refresh();
            }
        });
        bar.addView(seg, Ui.weight(1));
        bar.addView(Ui.btnPrimary(a, "＋ 新增事項", new View.OnClickListener() {
            @Override public void onClick(View v) { openTaskModal(null); }
        }));
        content.addView(bar, Ui.mw(a, 0));
        content.addView(Ui.spacer(a, 14));

        List<JSONObject> list = visibleTasks();
        if (list.isEmpty()) {
            content.addView(Ui.empty(a, "目前沒有事項"));
            return;
        }
        for (JSONObject t : list) {
            content.addView(taskCard(t), Ui.mw(a, 12));
        }
    }

    private List<JSONObject> visibleTasks() {
        String cat = a.catId();
        List<JSONObject> out = new ArrayList<>();
        for (JSONObject t : Model.tasks()) {
            if (!"overview".equals(cat) && !cat.equals(Model.s(t, "categoryId"))) continue;
            boolean done = "done".equals(Model.s(t, "status"));
            if ("pending".equals(filter) && done) continue;
            if ("done".equals(filter) && !done) continue;
            out.add(t);
        }
        return out;
    }

    private View taskCard(final JSONObject t) {
        final String tid = Model.s(t, "id");
        final boolean done = "done".equals(Model.s(t, "status"));
        final JSONArray subs = t.optJSONArray("subtasks") == null ? new JSONArray() : t.optJSONArray("subtasks");
        int doneSub = 0;
        for (int i = 0; i < subs.length(); i++) {
            JSONObject s = subs.optJSONObject(i);
            if (s != null && "done".equals(Model.s(s, "status"))) doneSub++;
        }
        Boolean ex = expanded.get(tid);
        final boolean open = ex == null || ex;
        String due = Model.s(t, "dueDate", "");
        boolean overdue = Model.overdueTask(t);
        boolean hasBell = t.optBoolean("reminder", false) && !due.isEmpty();

        LinearLayout card = Ui.taskCard(a);
        if (done) card.setAlpha(0.7f);

        Flow head = new Flow(a, 8, 6);
        head.setPadding(Ui.dp(a, 14), Ui.dp(a, 13), Ui.dp(a, 12), Ui.dp(a, 13));

        final Check chk = new Check(a, 22, done);
        chk.setContentDescription("完成:" + Model.s(t, "title"));
        chk.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleTask(t, chk); }
        });
        head.addView(chk);

        if ("overview".equals(a.catId())) {
            JSONObject cat = Model.category(Model.s(t, "categoryId"));
            if (cat != null) {
                View dot = new View(a);
                dot.setBackground(Ui.shape(a, Theme.parse(Model.s(cat, "color", "#999999")), 8, 0, 0));
                dot.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(a, 8), Ui.dp(a, 8)));
                head.addView(dot);
            }
        }

        TextView title = Ui.tv(a, Model.s(t, "title", ""), 14, done ? Ui.SOFT : Ui.CARD_INK, true);
        if (done) Ui.strike(title);
        head.addView(Flow.grow(title, 70));

        if (subs.length() > 0) {
            head.addView(Ui.chip(a, doneSub + "/" + subs.length(), 10.5f, Ui.ACCENT, Ui.ACCENT_SOFT, true));
        }
        if (!due.isEmpty()) {
            // 有設時間就連時間一起顯示;有開提醒,後面多一個同風格的鈴鐺(沒有文字)
            if (overdue) head.addView(Ui.chipBell(a, "延誤 " + Model.fmtTaskWhen(t), 11, Ui.ON_ACCENT, Ui.DANGER, true, hasBell));
            else head.addView(Ui.chipBell(a, Model.fmtTaskWhen(t), 11.5f, Ui.SOFT, Ui.CHIP_BG, false, hasBell));
        }

        TextView arrow = Ui.tv(a, "▸", 11, Ui.SOFT, false);
        arrow.setGravity(Gravity.CENTER);
        arrow.setRotation(open ? 90 : 0);
        arrow.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(a, 26), Ui.dp(a, 26)));
        arrow.setContentDescription(open ? "收合細項" : "展開細項");
        arrow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { expanded.put(tid, !open); refresh(); }
        });
        head.addView(arrow);

        String note = Model.s(t, "note", "");
        TextView noteBtn = Ui.textBtn(a, "備註", new View.OnClickListener() {
            @Override public void onClick(View v) { openNoteModal(tid, null); }
        });
        if (!note.isEmpty()) { noteBtn.setTextColor(Ui.ACCENT); noteBtn.setTypeface(noteBtn.getTypeface(), android.graphics.Typeface.BOLD); }
        // 備註、鉛筆、叉叉綁成一組,空間不夠時整組一起換行,不會拆開
        LinearLayout acts = Ui.row(a);
        acts.addView(noteBtn);
        acts.addView(Ui.iconBtn(a, Icons.EDIT, 15, 4, Ui.SOFT, "編輯", new View.OnClickListener() {
            @Override public void onClick(View v) { openTaskModal(tid); }
        }));
        acts.addView(Ui.iconBtn(a, Icons.DEL, 15, 4, Ui.SOFT, "刪除", new View.OnClickListener() {
            @Override public void onClick(View v) { deleteTask(tid); }
        }));
        head.addView(acts);
        card.addView(head, new LinearLayout.LayoutParams(-1, -2));

        if (!note.isEmpty()) card.addView(notePreview(note, 34), previewLp(0));

        if (open) {
            LinearLayout box = Ui.col(a);
            box.setBackgroundColor(Ui.SUB_BG);
            box.setPadding(Ui.dp(a, 48), Ui.dp(a, 4), Ui.dp(a, 16), Ui.dp(a, 14));
            for (int i = 0; i < subs.length(); i++) {
                JSONObject s = subs.optJSONObject(i);
                if (s != null) box.addView(subRow(t, s), new LinearLayout.LayoutParams(-1, -2));
            }
            TextView add = Ui.tv(a, "＋ 新增細項", 12, Ui.ACCENT, true);
            add.setPadding(Ui.dp(a, 14), Ui.dp(a, 7), Ui.dp(a, 14), Ui.dp(a, 7));
            add.setBackground(Ui.shape(a, Ui.ACCENT_SOFT, 999, 0, 0));
            add.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openSubModal(tid, null); }
            });
            box.addView(add, Ui.wrap(a, 8));
            card.addView(box, new LinearLayout.LayoutParams(-1, -2));
        }
        return card;
    }

    private TextView notePreview(String note, float leftDp) {
        TextView n = Ui.tv(a, note, 12, Ui.SOFT, false);
        n.setPadding(Ui.dp(a, 12), Ui.dp(a, 7), Ui.dp(a, 12), Ui.dp(a, 7));
        n.setBackground(Ui.shape(a, Ui.SUB_BG, 10, 0, 0));
        return n;
    }

    private LinearLayout.LayoutParams previewLp(float extraLeft) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.leftMargin = Ui.dp(a, 34 + extraLeft);
        p.rightMargin = Ui.dp(a, 12);
        p.bottomMargin = Ui.dp(a, 4);
        return p;
    }

    private View subRow(final JSONObject t, final JSONObject s) {
        final String tid = Model.s(t, "id"), sid = Model.s(s, "id");
        final boolean done = "done".equals(Model.s(s, "status"));
        LinearLayout wrap = Ui.col(a);
        wrap.addView(Ui.dotLine(a));

        Flow row = new Flow(a, 10, 6);
        row.setPadding(0, Ui.dp(a, 9), 0, Ui.dp(a, 9));
        final Check chk = new Check(a, 15, done);
        chk.setContentDescription("完成:" + Model.s(s, "title"));
        chk.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleSub(tid, s, chk); }
        });
        row.addView(chk);
        TextView title = Ui.tv(a, Model.s(s, "title", ""), 13, done ? Ui.SOFT : Ui.CARD_INK, false);
        if (done) Ui.strike(title);
        row.addView(Flow.grow(title, 70));

        String note = Model.s(s, "note", "");
        TextView noteBtn = Ui.textBtn(a, "備註", new View.OnClickListener() {
            @Override public void onClick(View v) { openNoteModal(tid, sid); }
        });
        if (!note.isEmpty()) { noteBtn.setTextColor(Ui.ACCENT); noteBtn.setTypeface(noteBtn.getTypeface(), android.graphics.Typeface.BOLD); }
        LinearLayout acts = Ui.row(a);
        acts.addView(noteBtn);
        acts.addView(Ui.iconBtn(a, Icons.EDIT, 14, 4, Ui.SOFT, "編輯", new View.OnClickListener() {
            @Override public void onClick(View v) { openSubModal(tid, sid); }
        }));
        acts.addView(Ui.iconBtn(a, Icons.DEL, 14, 4, Ui.SOFT, "刪除", new View.OnClickListener() {
            @Override public void onClick(View v) { deleteSub(tid, sid); }
        }));
        row.addView(acts);
        wrap.addView(row, new LinearLayout.LayoutParams(-1, -2));
        if (!note.isEmpty()) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.leftMargin = Ui.dp(a, 23);
            lp.bottomMargin = Ui.dp(a, 4);
            wrap.addView(notePreview(note, 0), lp);
        }
        return wrap;
    }

    // ---------- 資料操作 ----------

    private static JSONObject findTask(String id) {
        for (JSONObject t : Model.tasks()) if (id.equals(Model.s(t, "id"))) return t;
        return null;
    }

    private static JSONObject findSub(JSONObject t, String sid) {
        JSONArray subs = t == null ? null : t.optJSONArray("subtasks");
        if (subs == null) return null;
        for (int i = 0; i < subs.length(); i++) {
            JSONObject s = subs.optJSONObject(i);
            if (s != null && sid.equals(Model.s(s, "id"))) return s;
        }
        return null;
    }

    private static int indexOfTask(String id) {
        JSONObject d = Repo.data();
        JSONArray arr = d == null ? null : d.optJSONArray("tasks");
        if (arr == null) return -1;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && id.equals(Model.s(o, "id"))) return i;
        }
        return -1;
    }

    private static int indexOfSub(JSONObject t, String sid) {
        JSONArray subs = t == null ? null : t.optJSONArray("subtasks");
        if (subs == null) return -1;
        for (int i = 0; i < subs.length(); i++) {
            JSONObject s = subs.optJSONObject(i);
            if (s != null && sid.equals(Model.s(s, "id"))) return i;
        }
        return -1;
    }

    private static JSONObject copy(JSONObject o) {
        try { return new JSONObject(o.toString()); } catch (JSONException e) { return o; }
    }

    private void toggleTask(JSONObject t, Check chk) {
        boolean nowDone = !"done".equals(Model.s(t, "status"));
        JSONObject set = new JSONObject();
        try {
            set.put("status", nowDone ? "done" : "pending");
            set.put("completedAt", nowDone ? Model.today() : JSONObject.NULL);
        } catch (JSONException ignore) { }
        Repo.patch(a, set, null, "tasks", Model.s(t, "id"));
        Reminders.sync(a, t);   // 做完的事項不再提醒;改回未完成就把提醒補回去(t 已經是新狀態)
        chk.setDone(nowDone);
        if (nowDone) chk.bounce();
        // 讓彈跳動畫先播一下,再重畫(狀態文字、刪除線、篩選)
        scroll.postDelayed(new Runnable() {
            @Override public void run() { a.refreshCurrent(); }
        }, nowDone ? 420 : 0);
    }

    private void toggleSub(String tid, JSONObject s, Check chk) {
        boolean nowDone = !"done".equals(Model.s(s, "status"));
        JSONObject set = new JSONObject();
        try {
            set.put("status", nowDone ? "done" : "pending");
            set.put("completedAt", nowDone ? Model.today() : JSONObject.NULL);
        } catch (JSONException ignore) { }
        Repo.patch(a, set, null, "tasks", tid, "subtasks", Model.s(s, "id"));
        chk.setDone(nowDone);
        if (nowDone) chk.bounce();
        scroll.postDelayed(new Runnable() {
            @Override public void run() { a.refreshCurrent(); }
        }, nowDone ? 420 : 0);
    }

    private void deleteTask(final String tid) {
        final JSONObject t = findTask(tid);
        if (t == null) return;
        Modal.confirm(a, "確定要刪除此事項及其所有細項嗎?", null, "刪除", true, new Runnable() {
            @Override public void run() {
                final JSONObject removed = copy(t);
                final int idx = indexOfTask(tid);
                final String title = Model.s(t, "title");
                Reminders.remove(a, tid);
                Repo.del(a, "tasks", tid);
                a.refreshCurrent();
                a.undo("已刪除「" + title + "」", new Runnable() {
                    @Override public void run() {
                        Repo.add(a, removed, idx, "tasks");
                        Reminders.sync(a, removed);
                        a.refreshCurrent();
                    }
                });
            }
        });
    }

    private void deleteSub(final String tid, final String sid) {
        final JSONObject t = findTask(tid);
        final JSONObject s = findSub(t, sid);
        if (t == null || s == null) return;
        final JSONObject removed = copy(s);
        final int idx = indexOfSub(t, sid);
        Repo.del(a, "tasks", tid, "subtasks", sid);
        a.refreshCurrent();
        a.undo("已刪除「" + Model.s(removed, "title") + "」", new Runnable() {
            @Override public void run() {
                Repo.add(a, removed, idx, "tasks", tid, "subtasks");
                a.refreshCurrent();
            }
        });
    }

    // ---------- 視窗 ----------

    private void openNoteModal(final String tid, final String sid) {
        JSONObject t = findTask(tid);
        if (t == null) return;
        JSONObject target = sid == null ? t : findSub(t, sid);
        if (target == null) return;
        Form f = new Form(a);
        final Form.Text note = f.multiline("", Model.s(target, "note", ""), "寫點備註...", 4);
        Modal.show(a, "備註", f.view(), "儲存", new Modal.Ok() {
            @Override public boolean run() {
                String text = note.get();
                if (text.isEmpty()) {
                    // 網頁版存成 null
                    JSONObject set = new JSONObject();
                    try { set.put("note", JSONObject.NULL); } catch (JSONException ignore) { }
                    if (sid == null) Repo.patch(a, set, null, "tasks", tid);
                    else Repo.patch(a, set, null, "tasks", tid, "subtasks", sid);
                } else {
                    JSONObject set = new JSONObject();
                    try { set.put("note", text); } catch (JSONException ignore) { }
                    if (sid == null) Repo.patch(a, set, null, "tasks", tid);
                    else Repo.patch(a, set, null, "tasks", tid, "subtasks", sid);
                }
                a.refreshCurrent();
                return true;
            }
        });
    }

    private void openTaskModal(final String taskId) {
        final JSONObject task = taskId == null ? null : findTask(taskId);
        final List<JSONObject> cats = Model.categories();
        boolean showCat = "overview".equals(a.catId()) || task != null;
        Form f = new Form(a);
        Form.Pick catPick = null;
        if (showCat) {
            String[] names = new String[cats.size()];
            int sel = 0;
            for (int i = 0; i < cats.size(); i++) {
                names[i] = Model.s(cats.get(i), "name", "");
                if (task != null && Model.s(cats.get(i), "id").equals(Model.s(task, "categoryId"))) sel = i;
            }
            catPick = f.pick("歸類分類(必選)", names, sel);
        }
        final Form.Pick catF = catPick;
        final Form.Text title = f.text("標題", task == null ? "" : Model.s(task, "title", ""), "例如:完成季報");
        final Form.Dt dt = f.dateTime(task == null ? "" : Model.s(task, "dueDate", ""), task == null ? "" : Model.s(task, "dueTime", ""),
                task != null && task.optBoolean("reminder", false));
        Modal.show(a, task != null ? "編輯主要事項" : "新增主要事項", f.view(), "儲存", new Modal.Ok() {
            @Override public boolean run() {
                String ti = title.get();
                if (ti.isEmpty()) { Ui.toast(a, "請輸入標題"); return false; }
                String categoryId = a.catId();
                if (catF != null) {
                    if (cats.isEmpty() || catF.index < 0 || catF.index >= cats.size()) { Ui.toast(a, "請選擇歸類分類"); return false; }
                    categoryId = Model.s(cats.get(catF.index), "id");
                }
                if (task != null) {
                    JSONObject set = new JSONObject();
                    try {
                        set.put("title", ti); set.put("dueDate", dt.dueDate()); set.put("dueTime", dt.dueTime());
                        set.put("reminder", dt.reminder()); set.put("categoryId", categoryId);
                    } catch (JSONException ignore) { }
                    Repo.patch(a, set, null, "tasks", taskId);
                    Reminders.sync(a, task);   // task 已經是新內容
                } else {
                    JSONObject item = new JSONObject();
                    try {
                        item.put("id", Repo.newId());
                        item.put("categoryId", categoryId);
                        item.put("title", ti);
                        item.put("dueDate", dt.dueDate());
                        item.put("dueTime", dt.dueTime());
                        item.put("reminder", dt.reminder());
                        item.put("status", "pending");
                        item.put("subtasks", new JSONArray());
                    } catch (JSONException ignore) { }
                    Repo.add(a, item, -1, "tasks");
                    Reminders.sync(a, item);
                }
                a.refreshCurrent();
                return true;
            }
        });
    }

    private void openSubModal(final String tid, final String subId) {
        final JSONObject t = findTask(tid);
        if (t == null) return;
        final JSONObject s = subId == null ? null : findSub(t, subId);
        Form f = new Form(a);
        final Form.Text title = f.text("標題", s == null ? "" : Model.s(s, "title", ""), "例如:整理數據");
        Modal.show(a, s != null ? "編輯細項" : "新增細項", f.view(), "儲存", new Modal.Ok() {
            @Override public boolean run() {
                String ti = title.get();
                if (ti.isEmpty()) { Ui.toast(a, "請輸入標題"); return false; }
                if (s != null) {
                    JSONObject set = new JSONObject();
                    try { set.put("title", ti); } catch (JSONException ignore) { }
                    Repo.patch(a, set, null, "tasks", tid, "subtasks", subId);
                } else {
                    JSONObject item = new JSONObject();
                    try {
                        item.put("id", Repo.newId());
                        item.put("title", ti);
                        item.put("status", "pending");
                    } catch (JSONException ignore) { }
                    Repo.add(a, item, -1, "tasks", tid, "subtasks");
                    expanded.put(tid, true);
                }
                a.refreshCurrent();
                return true;
            }
        });
    }

    /** 搜尋點到某個事項前先設好:全部篩選、展開那一項(之後 MainActivity 會切分類並重畫)。 */
    static void prepareJump(String taskId) {
        filter = "all";
        expanded.put(taskId, true);
    }
}
