package tw.jishibu.widget;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/** 新增事項、習慣打卡的小視窗。 */
final class Dialogs {
    private Dialogs() {}

    private static String newId() {
        return Long.toString(Math.abs(new java.util.Random().nextLong()), 36).substring(0, 8)
                + Long.toString(System.currentTimeMillis(), 36);
    }

    /** 新增事項(標題、分類、日期)。defaultDate 可以是空字串。 */
    static void addTask(final Activity a, String defaultDate, final Runnable after) {
        LinearLayout box = Ui.col(a);
        box.setPadding(Ui.dp(a, 20), Ui.dp(a, 8), Ui.dp(a, 20), 0);

        final EditText title = new EditText(a);
        title.setHint("事項標題");
        title.setSingleLine(true);
        box.addView(title);

        final List<JSONObject> cats = Model.categories();
        List<String> names = new ArrayList<>();
        for (JSONObject c : cats) names.add(Model.s(c, "name", "?"));
        final Spinner sp = new Spinner(a);
        sp.setAdapter(new ArrayAdapter<>(a, android.R.layout.simple_spinner_dropdown_item, names));
        box.addView(sp, Ui.mw(a, 8));

        final String[] due = {Model.isDay(defaultDate) ? defaultDate : ""};
        final TextView dateBtn = Ui.pill(a, due[0].isEmpty() ? "選擇日期(可不選)" : due[0], false);
        box.addView(dateBtn, Ui.mw(a, 12));
        dateBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Calendar c = due[0].isEmpty() ? Calendar.getInstance() : Model.parse(due[0]);
                new DatePickerDialog(a, new DatePickerDialog.OnDateSetListener() {
                    @Override public void onDateSet(DatePicker view, int y, int m, int d) {
                        due[0] = Model.ymd(y, m + 1, d);
                        dateBtn.setText(due[0]);
                    }
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        new AlertDialog.Builder(a)
                .setTitle("新增事項")
                .setView(box)
                .setNegativeButton("取消", null)
                .setPositiveButton("新增", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String t = title.getText().toString().trim();
                        if (t.isEmpty()) { Ui.toast(a, "請輸入標題"); return; }
                        int pos = sp.getSelectedItemPosition();
                        String cat = pos >= 0 && pos < cats.size() ? cats.get(pos).optString("id") : "work";
                        Repo.submit(a, Repo.op("op", "task_add", "id", newId(), "title", t, "cat", cat, "due", due[0]));
                        if (after != null) after.run();
                    }
                })
                .show();
    }

    /** 點習慣的某一天:勾選類型直接切換,數量與時間類型跳出視窗輸入。 */
    static void habitTap(final Activity a, final JSONObject h, final String day, final Runnable after) {
        final String hid = Model.s(h, "id");
        String type = Model.s(h, "type", "boolean");
        boolean checked = Model.habitChecked(hid, day);
        if ("quantity".equals(type)) {
            final EditText in = new EditText(a);
            in.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            in.setText(Model.habitValueText(h, day));
            in.setHint("數量" + (Model.s(h, "unit").isEmpty() ? "" : "(" + Model.s(h, "unit") + ")"));
            LinearLayout box = Ui.col(a);
            box.setPadding(Ui.dp(a, 20), Ui.dp(a, 8), Ui.dp(a, 20), 0);
            box.addView(in);
            new AlertDialog.Builder(a)
                    .setTitle(Model.s(h, "name") + " " + Model.prettyDay(day))
                    .setView(box)
                    .setNegativeButton("取消", null)
                    .setNeutralButton("清除", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            Repo.submit(a, Repo.op("op", "habit_log", "hid", hid, "day", day, "mode", "clear"));
                            if (after != null) after.run();
                        }
                    })
                    .setPositiveButton("儲存", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            String s = in.getText().toString().trim();
                            if (s.isEmpty()) {
                                Repo.submit(a, Repo.op("op", "habit_log", "hid", hid, "day", day, "mode", "clear"));
                            } else {
                                try {
                                    double v = Double.parseDouble(s);
                                    Repo.submit(a, Repo.op("op", "habit_log", "hid", hid, "day", day, "mode", "num", "num", v));
                                } catch (NumberFormatException e) {
                                    Ui.toast(a, "請輸入數字");
                                    return;
                                }
                            }
                            if (after != null) after.run();
                        }
                    })
                    .show();
        } else if ("time".equals(type)) {
            int hh = 8, mm = 0;
            String cur = Model.habitValueText(h, day);
            if (cur.length() >= 5 && cur.charAt(2) == ':') {
                try { hh = Integer.parseInt(cur.substring(0, 2)); mm = Integer.parseInt(cur.substring(3, 5)); } catch (NumberFormatException ignore) { }
            }
            TimePickerDialog dlg = new TimePickerDialog(a, new TimePickerDialog.OnTimeSetListener() {
                @Override public void onTimeSet(TimePicker view, int hour, int minute) {
                    String s = String.format(java.util.Locale.US, "%02d:%02d", hour, minute);
                    Repo.submit(a, Repo.op("op", "habit_log", "hid", hid, "day", day, "mode", "str", "str", s));
                    if (after != null) after.run();
                }
            }, hh, mm, true);
            if (checked) {
                dlg.setButton(DialogInterface.BUTTON_NEUTRAL, "清除", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        Repo.submit(a, Repo.op("op", "habit_log", "hid", hid, "day", day, "mode", "clear"));
                        if (after != null) after.run();
                    }
                });
            }
            dlg.show();
        } else {
            Repo.submit(a, Repo.op("op", "habit_log", "hid", hid, "day", day, "mode", "bool", "checked", !checked));
            if (after != null) after.run();
        }
    }
}
