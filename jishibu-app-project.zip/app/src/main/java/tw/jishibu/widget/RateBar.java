package tw.jishibu.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** 達成率進度條(網頁版 .rate-bar-fill):0.8 秒由左長到目標。 */
final class RateBar extends View {
    private final int target;
    private final boolean over;   // 超過預算:改用紅色
    private float t = 0f;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean started = false;

    RateBar(Context c, int target) { this(c, target, false); }

    RateBar(Context c, int target, boolean over) { super(c); this.target = target; this.over = over; }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (started) return;
        started = true;
        ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(800);
        va.setInterpolator(new DecelerateInterpolator(2f));
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator an) { t = (Float) an.getAnimatedValue(); invalidate(); }
        });
        va.start();
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setColor(Ui.BORDER);
        c.drawRoundRect(new RectF(0, 0, w, h), h / 2f, h / 2f, p);
        float fw = w * Math.max(0, Math.min(100, target)) / 100f * t;
        if (fw > 0.5f) {
            p.setColor(over ? Ui.DANGER : Ui.ACCENT);
            c.drawRoundRect(new RectF(0, 0, Math.max(fw, h), h), h / 2f, h / 2f, p);
        }
    }
}
