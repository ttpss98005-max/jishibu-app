package tw.jishibu.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 桌面小工具:習慣、清單、隨手記、記帳。
 * 資料直接讀 App 裡同一份(Repo),每次同步完或改了東西就跟著更新;點一下開 App 對應的頁面。
 * 小工具只「讀」資料,不會寫,所以不可能弄壞你的資料。
 */
final class Widgets {
    private Widgets() {}

    static final int HABITS = 0, TASKS = 1, NOTES = 2, MONEY = 3;
    static final String ACTION_REFRESH = "tw.jishibu.widget.LIST_REFRESH";
    static final String EXTRA_TAB = "tab", EXTRA_COMPOSE = "compose", EXTRA_ENTRY = "entry";
    private static final int MAX_ROWS = 10;
    private static final int FLAGS = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;

    /** 一列要顯示的內容。 */
    static final class Row {
        String mark = "●", text = "", right = "";
        int markColor = R.color.accent, textColor = R.color.ink, rightColor = R.color.ink_soft;
    }

    /** 整個小工具要顯示的內容(跟畫面無關,方便測試)。 */
    static final class Content {
        String title = "", subtitle = "", empty = "";
        String[] sumLabel, sumValue;
        int[] sumColor;
        final List<Row> rows = new ArrayList<>();
    }

    static Class<?> providerClass(int kind) {
        switch (kind) {
            case HABITS: return HabitsWidget.class;
            case TASKS: return TasksWidget.class;
            case NOTES: return NotesWidget.class;
            default: return MoneyWidget.class;
        }
    }

    static int tabOf(int kind) {
        switch (kind) {
            case HABITS: return MainActivity.TAB_HABITS;
            case TASKS: return MainActivity.TAB_LIST;
            case NOTES: return MainActivity.TAB_NOTES;
            default: return MainActivity.TAB_EXPENSE;
        }
    }

    // ---------- 更新 ----------

    /** 四種小工具全部重畫(同步完、資料改了之後呼叫)。 */
    static void renderAll(Context ctx) {
        if (Repo.sandbox()) return;
        try {
            Context app = ctx.getApplicationContext();
            for (int k = 0; k <= MONEY; k++) render(app, k);
        } catch (Throwable ignore) { }
    }

    static void render(Context ctx, int kind) {
        AppWidgetManager m = AppWidgetManager.getInstance(ctx);
        int[] ids = m.getAppWidgetIds(new ComponentName(ctx, providerClass(kind)));
        if (ids == null || ids.length == 0) return;
        Repo.init(ctx);
        Content c = content(ctx, kind);
        for (int id : ids) m.updateAppWidget(id, build(ctx, kind, c, m.getAppWidgetOptions(id)));
    }

    private static int id(Context ctx, String name) {
        return ctx.getResources().getIdentifier(name, "id", ctx.getPackageName());
    }

    static RemoteViews build(Context ctx, int kind, Content c, Bundle opts) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_list);
        rv.setTextViewText(R.id.title, c.title);
        rv.setTextViewText(R.id.subtitle, c.subtitle);

        boolean sum = c.sumLabel != null;
        rv.setViewVisibility(R.id.summary, sum ? View.VISIBLE : View.GONE);
        if (sum) {
            for (int i = 0; i < 3; i++) {
                rv.setTextViewText(id(ctx, "sl_" + i), c.sumLabel[i]);
                rv.setTextViewText(id(ctx, "sv_" + i), c.sumValue[i]);
                rv.setTextColor(id(ctx, "sv_" + i), ctx.getResources().getColor(c.sumColor[i], null));
            }
        }

        int hDp = opts == null ? 0 : opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (hDp <= 0) hDp = 160;
        int fit = rowsThatFit(hDp, sum);
        int shown = Math.min(Math.min(fit, MAX_ROWS), c.rows.size());
        for (int i = 0; i < MAX_ROWS; i++) {
            int r = id(ctx, "r_" + i);
            if (i < shown) {
                Row row = c.rows.get(i);
                rv.setViewVisibility(r, View.VISIBLE);
                rv.setTextViewText(id(ctx, "mk_" + i), row.mark);
                rv.setTextColor(id(ctx, "mk_" + i), ctx.getResources().getColor(row.markColor, null));
                int tx = id(ctx, "tx_" + i);
                rv.setTextViewText(tx, row.text);
                rv.setTextColor(tx, ctx.getResources().getColor(row.textColor, null));
                int rt = id(ctx, "rt_" + i);
                rv.setTextViewText(rt, row.right);
                rv.setTextColor(rt, ctx.getResources().getColor(row.rightColor, null));
            } else {
                rv.setViewVisibility(r, View.GONE);
            }
        }
        boolean none = c.rows.isEmpty();
        rv.setViewVisibility(R.id.empty, none ? View.VISIBLE : View.GONE);
        rv.setTextViewText(R.id.empty, c.empty);
        int more = c.rows.size() - shown;
        rv.setViewVisibility(R.id.more, more > 0 ? View.VISIBLE : View.GONE);
        if (more > 0) rv.setTextViewText(R.id.more, "還有 " + more + " 項…");

        rv.setOnClickPendingIntent(R.id.root, openApp(ctx, kind, 0));
        if (kind == MONEY) {   // 摘要列的「收入」「支出」是兩顆按鈕:各自直接開對應的「記一筆」
            rv.setOnClickPendingIntent(id(ctx, "sc_0"), openApp(ctx, kind, 1));
            rv.setOnClickPendingIntent(id(ctx, "sc_1"), openApp(ctx, kind, 0));
        }
        Intent ri = new Intent(ctx, providerClass(kind)).setAction(ACTION_REFRESH);
        rv.setOnClickPendingIntent(R.id.btn_refresh, PendingIntent.getBroadcast(ctx, 100 + kind, ri, FLAGS));
        return rv;
    }

    /** 依小工具高度算最多放幾列(標題 + 邊距約 62dp,摘要列 44dp,每列 26dp,留一行給「還有 N 項」)。 */
    static int rowsThatFit(int hDp, boolean summary) {
        int avail = hDp - 62 - (summary ? 44 : 0) - 14;
        return Math.max(1, Math.min(MAX_ROWS, avail / 26));
    }

    /** entry:0 一般(記帳預設支出)、1 收入。 */
    private static PendingIntent openApp(Context ctx, int kind, int entry) {
        Intent i = new Intent(ctx, MainActivity.class);
        i.putExtra(EXTRA_ENTRY, entry);
        i.putExtra(EXTRA_TAB, tabOf(kind));
        // 隨手記、記帳:點一下就直接進入輸入(隨手記跳出鍵盤、記帳開「記一筆」)
        if (kind == NOTES || kind == MONEY) i.putExtra(EXTRA_COMPOSE, true);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(ctx, 200 + kind * 2 + (entry == 1 ? 1 : 0), i, FLAGS);
    }

    // ---------- 內容 ----------

    static Content content(Context ctx, int kind) {
        Content c = new Content();
        switch (kind) {
            case HABITS: c.title = "今日習慣"; break;
            case TASKS: c.title = "待辦清單"; break;
            case NOTES: c.title = "隨手記"; break;
            default: c.title = "記帳"; break;
        }
        if (!Store.linked(ctx)) {
            c.subtitle = "尚未登入";
            c.empty = "點這裡開啟記事簿,先登入";
            return c;
        }
        synchronized (Repo.lock()) {
            if (Repo.data() == null) {
                c.subtitle = Store.error(ctx).isEmpty() ? "更新中…" : "更新失敗";
                c.empty = Store.error(ctx).isEmpty() ? "資料載入中…" : Store.error(ctx);
                return c;
            }
            switch (kind) {
                case HABITS: habits(c); break;
                case TASKS: tasks(c); break;
                case NOTES: notes(c); break;
                default: money(c); break;
            }
        }
        return c;
    }

    private static void habits(Content c) {
        String today = Model.today();
        int total = 0, done = 0;
        List<Row> pending = new ArrayList<>(), finished = new ArrayList<>();
        for (JSONObject h : Model.habits()) {
            if (!Model.habitScheduledOn(h, today)) continue;
            total++;
            boolean on = Model.habitChecked(Model.s(h, "id"), today);
            Row r = new Row();
            r.mark = on ? "✓" : "○";
            r.markColor = on ? R.color.accent : R.color.ink_faint;
            r.text = Model.s(h, "name", "");
            r.textColor = on ? R.color.ink_soft : R.color.ink;
            int streak = on ? Model.habitStreak(h, today) : 0;
            if (streak > 0) r.right = "連續" + streak + "天";
            if (on) { done++; finished.add(r); } else pending.add(r);
        }
        c.subtitle = total == 0 ? "今天沒有要做的習慣" : "已完成 " + done + " / " + total;
        c.rows.addAll(pending);   // 還沒打卡的排前面
        c.rows.addAll(finished);
        c.empty = total == 0 ? "今天沒有要做的習慣" : "";
    }

    private static void tasks(Content c) {
        List<JSONObject> pend = new ArrayList<>();
        for (JSONObject t : Model.tasks()) if (!"done".equals(Model.s(t, "status"))) pend.add(t);
        // 有日期的依日期由近到遠(延誤的自然排最前面),沒日期的放最後;同一天維持原本順序
        Collections.sort(pend, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject a, JSONObject b) {
                String da = Model.isRangeTask(a) ? Model.s(a, "startDate", "") : Model.s(a, "dueDate", "");   // 時段照開始日排
                String db = Model.isRangeTask(b) ? Model.s(b, "startDate", "") : Model.s(b, "dueDate", "");
                boolean ea = da.isEmpty(), eb = db.isEmpty();
                if (ea != eb) return ea ? 1 : -1;
                return ea ? 0 : da.compareTo(db);
            }
        });
        int overdue = 0;
        for (JSONObject t : pend) {
            String due = Model.s(t, "dueDate", "");
            boolean od = Model.overdueTask(t);
            if (od) overdue++;
            Row r = new Row();
            r.mark = od ? "!" : "○";
            r.markColor = od ? R.color.sunday : R.color.ink_faint;
            JSONArray subs = t.optJSONArray("subtasks");
            String subText = "";
            if (subs != null && subs.length() > 0) {
                int d = 0;
                for (int i = 0; i < subs.length(); i++) {
                    JSONObject s = subs.optJSONObject(i);
                    if (s != null && "done".equals(Model.s(s, "status"))) d++;
                }
                subText = "  " + d + "/" + subs.length();
            }
            r.text = Model.s(t, "title", "") + subText;
            if (!due.isEmpty()) {
                r.right = Model.isRangeTask(t) ? Model.fmtTaskRange(t) : Model.fmtTaskWhen(t);
                if (od) r.rightColor = R.color.sunday;
            }
            c.rows.add(r);
        }
        c.subtitle = pend.isEmpty() ? "全部完成了" : pend.size() + " 項待處理" + (overdue > 0 ? "・" + overdue + " 項延誤" : "");
        c.empty = pend.isEmpty() ? "沒有待處理的事項" : "";
    }

    private static void notes(Content c) {
        List<JSONObject> list = Model.list("quickNotes");
        c.subtitle = (list.isEmpty() ? "還沒有便利貼" : "共 " + list.size() + " 張") + "・點一下直接輸入";
        for (int i = list.size() - 1; i >= 0; i--) {   // 新的在前面
            JSONObject n = list.get(i);
            String text = Model.s(n, "text", "").trim();
            int nl = text.indexOf('\n');
            if (nl >= 0) text = text.substring(0, nl);
            Row r = new Row();
            r.mark = "●";
            r.text = text;
            long ts = n.optLong("createdAt", 0);
            if (ts > 0) {
                Calendar t = Calendar.getInstance();
                t.setTimeInMillis(ts);
                r.right = (t.get(Calendar.MONTH) + 1) + "/" + t.get(Calendar.DAY_OF_MONTH);
            }
            c.rows.add(r);
        }
        c.empty = list.isEmpty() ? "牆上還沒有便利貼" : "";
    }

    private static void money(Content c) {
        Calendar now = Calendar.getInstance();
        String key = Money.monthKey(now.get(Calendar.YEAR), now.get(Calendar.MONTH) + 1);
        List<JSONObject> list = Money.forMonth(key);
        double income = 0, expense = 0;
        for (JSONObject e : list) {
            String t = Model.s(e, "type");
            double amt = Money.d(e, "amount");
            if ("income".equals(t)) income += amt; else if ("expense".equals(t)) expense += amt;
        }
        c.title = (now.get(Calendar.MONTH) + 1) + "月記帳";
        c.subtitle = (list.isEmpty() ? "這個月還沒有紀錄" : "本月 " + list.size() + " 筆") + "・點收入或支出直接記帳";
        c.sumLabel = new String[]{"＋ 收入", "－ 支出", "結餘"};
        c.sumValue = new String[]{Money.fmt(income), Money.fmt(expense), Money.fmt(income - expense)};
        c.sumColor = new int[]{R.color.income, R.color.sunday, R.color.ink};
        // 最近的在前面(日期新的在前;同一天後記的在前)
        List<JSONObject> sorted = new ArrayList<>(list);
        Collections.reverse(sorted);
        Collections.sort(sorted, new Comparator<JSONObject>() {
            @Override public int compare(JSONObject a, JSONObject b) { return Model.s(b, "date").compareTo(Model.s(a, "date")); }
        });
        for (JSONObject e : sorted) {
            String type = Model.s(e, "type");
            double amt = Money.d(e, "amount");
            Row r = new Row();
            String name;
            if ("adjust".equals(type)) name = "調整誤差";
            else if ("transfer".equals(type)) name = "轉帳";
            else {
                name = Model.s(e, "category");
                for (JSONObject cat : Money.list("income".equals(type) ? "incomeCategories" : "expenseCategories")) {
                    if (Model.s(cat, "id").equals(Model.s(e, "category"))) name = Model.s(cat, "name");
                }
            }
            String note = Model.s(e, "note");
            r.text = note.isEmpty() ? name : name + "・" + note;
            if ("income".equals(type)) { r.mark = "＋"; r.markColor = R.color.income; r.right = "+" + Money.fmt(amt); r.rightColor = R.color.income; }
            else if ("expense".equals(type)) { r.mark = "－"; r.markColor = R.color.sunday; r.right = "-" + Money.fmt(amt); r.rightColor = R.color.sunday; }
            else { r.mark = "⇄"; r.markColor = R.color.ink_soft; r.right = Money.fmt(amt); }
            c.rows.add(r);
        }
        c.empty = list.isEmpty() ? "這個月還沒有收支紀錄" : "";
    }

    // ---------- 共用的小工具元件 ----------

    /** 四個小工具共用的行為:被更新、點了重新整理就從 App 的資料重畫,資料太舊就背景同步一次。 */
    abstract static class Base extends AppWidgetProvider {
        abstract int kind();

        @Override public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
            render(ctx, kind());
            syncInBackground(ctx, goAsync(), 60_000L);
        }

        @Override public void onAppWidgetOptionsChanged(Context ctx, AppWidgetManager mgr, int id, Bundle opts) {
            render(ctx, kind());
        }

        @Override public void onReceive(Context ctx, Intent intent) {
            if (ACTION_REFRESH.equals(intent.getAction())) {
                syncInBackground(ctx, goAsync(), 0L);
                return;
            }
            super.onReceive(ctx, intent);
        }
    }

    static void syncInBackground(final Context ctx, final android.content.BroadcastReceiver.PendingResult pr, final long minGapMs) {
        final Context app = ctx.getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    Repo.init(app);
                    if (Store.linked(app) && System.currentTimeMillis() - Store.syncTs(app) >= minGapMs) {
                        Sync.refresh(app);   // 同步完會自己呼叫 renderAll
                    }
                    renderAll(app);
                } catch (Throwable ignore) {
                } finally {
                    if (pr != null) pr.finish();
                }
            }
        }).start();
    }

}
