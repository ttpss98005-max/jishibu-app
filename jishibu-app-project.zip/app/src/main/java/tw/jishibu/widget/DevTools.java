package tw.jishibu.widget;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * 開發者工具(網頁版 devToolsModal 的手機版):只有開發者帳號登入時,設定頁「帳戶」底下才有入口。
 * 動畫測試:立刻看早安 / 晚安動畫、重置「今天已顯示」的標記。
 * 通知測試:檢查通知狀態、立刻跳通知、排一個 1 分鐘後的系統鬧鐘、看已排入的通知、跳到系統設定。
 * 網頁版的「完整通知(經過雲端)」測試不放:這個 App 的提醒是手機本機的系統鬧鐘,不經過雲端通知。
 */
final class DevTools {
    private DevTools() {}

    static final String DEV_EMAIL = "ttpss98005@gmail.com";

    static boolean isDev(Context c) {
        return DEV_EMAIL.equalsIgnoreCase(Store.email(c).trim());
    }

    private static TextView group(MainActivity a, String s) {
        TextView t = Ui.tv(a, s, 12.5f, Ui.SOFT, true);
        t.setPadding(0, Ui.dp(a, 16), 0, Ui.dp(a, 2));
        return t;
    }

    static void open(final MainActivity a) {
        if (!isDev(a)) return;
        final Modal.Sheet sh = Modal.sheet(a);
        LinearLayout box = sh.box;
        box.addView(Ui.tv(a, "開發者工具", 16, Ui.CARD_INK, true));
        box.addView(Ui.hint(a, "這裡是開發、測試用的功能，只有開發者帳號看得到。"));

        // ---- 動畫測試 ----
        box.addView(group(a, "動畫測試"));
        box.addView(Ui.btnGhost(a, "立即觸發早安動畫", new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (Repo.data() == null) { a.flash("資料還沒載入"); return; }
                sh.dismiss();
                Recap.devMorning(a);
                a.flash("已手動觸發早安動畫");
            }
        }), Ui.mw(a, 8));
        box.addView(Ui.btnGhost(a, "立即觸發晚安動畫", new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (Repo.data() == null) { a.flash("資料還沒載入"); return; }
                sh.dismiss();
                Recap.devNight(a);
                a.flash("已手動觸發晚安動畫");
            }
        }), Ui.mw(a, 8));
        box.addView(Ui.btnGhost(a, "立即觸發慶祝動畫", new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (Repo.data() == null) { a.flash("資料還沒載入"); return; }
                sh.dismiss();
                Celebrate.dev(a);
                a.flash("已手動觸發慶祝動畫（今天沒有特別日子時用範例）");
            }
        }), Ui.mw(a, 8));
        box.addView(Ui.btnGhost(a, "重置今天的顯示標記", new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (Repo.data() == null) { a.flash("資料還沒載入"); return; }
                Recap.devReset(a);
                a.flash("已重置今天的顯示標記，重新打開 App 會再自動跳出一次");
            }
        }), Ui.mw(a, 8));
        box.addView(Ui.hint(a, "平常要等特定時間才會自動出現的動畫，可以在這裡直接看。觸發時這個視窗會先關掉。"));

        // ---- 新手教學 ----
        box.addView(group(a, "新手教學"));
        box.addView(Ui.btnGhost(a, "▶ 播放新手教學（從頭完整播一遍）", new View.OnClickListener() {
            @Override public void onClick(View v) {
                sh.dismiss();
                Tutorial.playAll(a);
            }
        }), Ui.mw(a, 8));
        box.addView(Ui.btnGhost(a, "重設各頁教學狀態（像新註冊，每頁會再自動跳出）", new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (Repo.data() == null) { a.flash("資料還沒載入"); return; }
                Tutorial.resetSeen(a);
            }
        }), Ui.mw(a, 8));

        // ---- 通知測試 ----
        box.addView(group(a, "通知測試"));
        final TextView out = Ui.tv(a, "", 12, Ui.CARD_INK, false);
        out.setLineSpacing(0, 1.35f);
        out.setPadding(0, Ui.dp(a, 10), 0, 0);
        out.setTextIsSelectable(true);

        box.addView(Ui.btnGhost(a, "檢查通知狀態", new View.OnClickListener() {
            @Override public void onClick(View v) { out.setText(status(a)); }
        }), Ui.mw(a, 8));
        box.addView(Ui.btnGhost(a, "測試通知（立刻跳出）", new View.OnClickListener() {
            @Override public void onClick(View v) {
                AlertReceiver.show(a, "devtest_now", "通知測試", "看到這則通知，代表這支手機可以顯示通知。");
                out.setText(Settings_notifyOk(a) ? "已送出，請看通知列。" : "已送出，但這個 App 的通知目前是關閉的，所以不會顯示。請按下面的「通知設定」打開。");
            }
        }), Ui.mw(a, 8));
        box.addView(Ui.btnGhost(a, "鬧鐘測試（1 分鐘後響）", new View.OnClickListener() {
            @Override public void onClick(View v) {
                Boolean exact = LocalAlerts.testAlarm(a, 60000L);
                if (exact == null) { out.setText("✗ 排不進系統鬧鐘。"); return; }
                Calendar t = Calendar.getInstance();
                t.add(Calendar.MINUTE, 1);
                out.setText(String.format(Locale.TAIWAN, "✓ 已排入 %02d:%02d 的測試鬧鐘（%s）。\n請現在把 App 關掉（從最近使用的 App 滑掉）並鎖螢幕，等一分鐘看有沒有準時跳出通知。",
                        t.get(Calendar.HOUR_OF_DAY), t.get(Calendar.MINUTE), exact ? "精確模式" : "大約模式，可能會晚幾分鐘"));
            }
        }), Ui.mw(a, 8));
        box.addView(Ui.btnGhost(a, "查看已排入的通知", new View.OnClickListener() {
            @Override public void onClick(View v) {
                List<String> l = LocalAlerts.upcoming(a, 15);
                StringBuilder s = new StringBuilder();
                s.append("已排入系統鬧鐘：").append(LocalAlerts.scheduledCount(a)).append(" 則");
                if (l.isEmpty()) s.append("\n（接下來沒有要響的提醒）");
                for (String x : l) s.append("\n").append(x);
                out.setText(s.toString());
            }
        }), Ui.mw(a, 8));
        box.addView(Ui.hint(a, "鬧鐘測試是看提醒會不會準時的最直接方法：App 開著時一定會響，要關掉 App 再等才有意義。"));

        // ---- 跳到系統設定 ----
        box.addView(group(a, "系統設定（提醒要準時，這三項要正確）"));
        box.addView(Ui.btnGhost(a, "通知設定", new View.OnClickListener() {
            @Override public void onClick(View v) {
                Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                i.putExtra(Settings.EXTRA_APP_PACKAGE, a.getPackageName());
                go(a, i, null);
            }
        }), Ui.mw(a, 8));
        box.addView(Ui.btnGhost(a, "電池設定（改成不受限制）", new View.OnClickListener() {
            @Override public void onClick(View v) {
                go(a, new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), appDetails(a));
            }
        }), Ui.mw(a, 8));
        box.addView(Ui.btnGhost(a, "鬧鐘與提醒（精確鬧鐘）", new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= 31) {
                    Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                    i.setData(Uri.parse("package:" + a.getPackageName()));
                    go(a, i, appDetails(a));
                } else {
                    a.flash("這個 Android 版本不需要另外設定");
                }
            }
        }), Ui.mw(a, 8));

        box.addView(out);

        box.addView(Ui.btnPrimary(a, "關閉", new View.OnClickListener() {
            @Override public void onClick(View v) { sh.dismiss(); }
        }), Ui.mw(a, 20));
        sh.dialog.show();
    }

    private static Intent appDetails(Context c) {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        i.setData(Uri.parse("package:" + c.getPackageName()));
        return i;
    }

    private static void go(MainActivity a, Intent first, Intent fallback) {
        try {
            a.startActivity(first);
            return;
        } catch (Throwable ignore) { }
        try {
            if (fallback != null) { a.startActivity(fallback); return; }
        } catch (Throwable ignore) { }
        a.flash("這支手機打不開這個設定頁，請手動到 設定 → 應用程式 → 記事簿");
    }

    private static boolean Settings_notifyOk(Context c) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            return nm != null && nm.areNotificationsEnabled();
        } catch (Throwable t) {
            return true;
        }
    }

    /** 一次列出會影響提醒準不準的所有狀態。 */
    static String status(Context c) {
        StringBuilder s = new StringBuilder();
        s.append(Store.linked(c) ? "✓ 已登入" : "✗ 尚未登入（沒有登入就不會排提醒）").append('\n');
        s.append(LocalAlerts.enabled(c) ? "✓ 「通知提醒」開關：開" : "✗ 「通知提醒」開關：關（到設定頁打開）").append('\n');
        s.append(Settings_notifyOk(c) ? "✓ 系統通知權限：允許" : "✗ 系統通知權限：已關閉（按「通知設定」打開）").append('\n');
        s.append(LocalAlerts.canExact(c) ? "✓ 精確鬧鐘：可用（會準時）" : "✗ 精確鬧鐘：不可用（只能大約準時，可能晚幾分鐘）").append('\n');
        boolean batt = true;
        try {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            batt = pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
        } catch (Throwable ignore) { }
        s.append(batt ? "✓ 電池：不受限制" : "△ 電池：有限制（系統省電可能讓提醒延遲，建議改成「不受限制」）").append('\n');
        s.append("已排入系統鬧鐘：").append(LocalAlerts.scheduledCount(c)).append(" 則\n");
        s.append("尚未送到雲端的排程：").append(Reminders.queued(c)).append(" 筆\n");
        s.append("手機：").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append("（Android ").append(Build.VERSION.RELEASE).append("）");
        s.append("\n※ 部分品牌（小米、OPPO、vivo、華為、三星）另外有自己的省電/自啟動設定，這裡偵測不到，請也到系統的「電池」或「應用程式啟動管理」檢查。");
        return s.toString();
    }
}
