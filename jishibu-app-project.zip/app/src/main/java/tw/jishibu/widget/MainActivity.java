package tw.jishibu.widget;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 記事簿 App 的主畫面骨架,版面照網頁版:
 *   頂欄(記事簿 / 同步提示 / 搜尋 / 設定)
 *   分類選單(只有「清單」「行事曆」分頁顯示)
 *   內容區(目前的分頁)
 *   底部導覽(習慣 / 清單 / 行事曆 / 隨手記 / 記帳)
 * 設定頁不在底部導覽,從右上角齒輪進入。
 */
public class MainActivity extends Activity {
    static final int TAB_HABITS = 0, TAB_LIST = 1, TAB_CAL = 2, TAB_NOTES = 3, TAB_EXPENSE = 4, TAB_SETTINGS = 5;

    private Screen[] screens;
    private int cur = -1, prevTab = TAB_LIST;
    private String catId = "overview";
    private boolean catLoaded = false;

    private FrameLayout rootFrame, frame, overlay;
    private LinearLayout topBar, catRow, bottomNav;
    private TextView badge, flashView, undoBar;
    private TextView catLabel;
    private View catDot;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable hideFlash, hideUndo;
    private Runnable undoAction;

    // ---------- 給各分頁用 ----------

    /** 目前選的分類 id("overview" = 總覽)。 */
    String catId() { return catId; }

    /** 切換分類(會記住、換配色、重畫目前分頁)。 */
    void setCategory(String id) {
        if (id == null || id.isEmpty()) id = "overview";
        if (id.equals(catId)) return;
        catId = id;
        Repo.set(this, id, "lastCatId");
        applyTheme();
    }

    /** 切到某個分頁。 */
    void go(int tab) { show(tab); }

    /** 搜尋點到事項:切到清單、它的分類、全部篩選、展開那一項。 */
    void jumpToTask(String categoryId, String taskId) {
        ListScreen.prepareJump(taskId);
        show(TAB_LIST);
        setCategory(categoryId);
        refreshCurrent();
    }

    int currentTab() { return cur; }

    /** 下方的小提示(圓角深色膠囊,約 2 秒消失)。 */
    void flash(String msg) {
        if (Modal.anyOpen()) {   // 有視窗開著時,底下的提示條會被蓋住,改用系統提示
            android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        flashView.setText(msg);
        flashView.setVisibility(View.VISIBLE);
        if (hideFlash != null) handler.removeCallbacks(hideFlash);
        hideFlash = new Runnable() { @Override public void run() { flashView.setVisibility(View.GONE); } };
        handler.postDelayed(hideFlash, 2200);
    }

    /** 底部的「已刪除 · 復原」提示條,5 秒內可以按復原。 */
    void undo(String msg, final Runnable onUndo) {
        undoAction = onUndo;
        undoBar.setText(msg + "    復原");
        undoBar.setVisibility(View.VISIBLE);
        if (hideUndo != null) handler.removeCallbacks(hideUndo);
        hideUndo = new Runnable() { @Override public void run() { undoBar.setVisibility(View.GONE); undoAction = null; } };
        handler.postDelayed(hideUndo, 5000);
    }

    /** 目前分頁重畫(例如資料剛改過)。 */
    void refreshCurrent() {
        if (cur >= 0) screens[cur].refresh();
        updateBadge();
    }

    // ---------- 存檔(匯出備份用) ----------

    interface UriCb { void on(Uri u); }
    private static final int REQ_SAVE = 701;
    private UriCb pendingSave;

    /** 開系統的「另存新檔」畫面,使用者選好位置後回呼。 */
    void saveFile(String name, String mime, UriCb cb) {
        pendingSave = cb;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(i, REQ_SAVE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_SAVE) {
            UriCb cb = pendingSave;
            pendingSave = null;
            if (cb != null && res == RESULT_OK && data != null && data.getData() != null) cb.on(data.getData());
        }
    }

    // ---------- 建立 ----------

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Repo.init(this);
        syncCatFromData();
        Theme.apply(Theme.effective(catId));

        screens = new Screen[]{
                new HabitsScreen(this), new ListScreen(this), new CalendarScreen(this),
                new NotesScreen(this), new ExpenseScreen(this), new SettingsScreen(this)};

        rootFrame = new FrameLayout(this);
        frame = new FrameLayout(this);
        overlay = new FrameLayout(this);
        buildChrome();
        buildOverlay();
        setContentView(rootFrame);

        show(Store.linked(this) ? TAB_LIST : TAB_SETTINGS);
        handle(getIntent());
    }

    private void syncCatFromData() {
        if (catLoaded) return;
        JSONObject d = Repo.data();
        if (d == null) return;
        catLoaded = true;
        String id = Model.s(d, "lastCatId", "overview");
        if (!"overview".equals(id) && Model.category(id) == null) id = "overview";
        catId = id;
    }

    /** 頂欄 + 分類列 + 內容 + 底部導覽。換配色時整組重建。 */
    private void buildChrome() {
        rootFrame.removeAllViews();
        LinearLayout col = Ui.col(this);
        col.setBackgroundColor(Ui.BG);

        topBar = Ui.row(this);
        topBar.setBackgroundColor(Ui.SURFACE);
        topBar.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12));
        TextView brand = Ui.tv(this, "記事簿", 16, Ui.CARD_INK, true);
        brand.setLetterSpacing(0.06f);
        topBar.addView(brand, Ui.weight(1));
        badge = Ui.tv(this, "尚未同步", 11.5f, 0xFFB23A3A, true);
        badge.setPadding(Ui.dp(this, 11), Ui.dp(this, 6), Ui.dp(this, 11), Ui.dp(this, 6));
        badge.setBackground(Ui.shape(this, 0xFFFBECEA, 999, 0, 0));
        badge.setVisibility(View.GONE);
        badge.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { syncNowAsync(true); }
        });
        topBar.addView(badge, Ui.gap(this, 0));
        topBar.addView(iconButton(Icons.SEARCH, new View.OnClickListener() {
            @Override public void onClick(View v) { Search.open(MainActivity.this); }
        }), Ui.gap(this, 8));
        topBar.addView(iconButton(Icons.GEAR, new View.OnClickListener() {
            @Override public void onClick(View v) { show(cur == TAB_SETTINGS ? prevTab : TAB_SETTINGS); }
        }), Ui.gap(this, 8));
        col.addView(topBar, new LinearLayout.LayoutParams(-1, -2));
        col.addView(Ui.hline(this));

        catRow = Ui.row(this);
        catRow.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), 0);
        LinearLayout pill = Ui.row(this);
        pill.setPadding(Ui.dp(this, 20), Ui.dp(this, 11), Ui.dp(this, 20), Ui.dp(this, 11));
        pill.setBackground(Ui.shape(this, Ui.ACCENT, 999, 0, 0));
        pill.setElevation(Ui.dp(this, 2));
        catDot = new View(this);
        catDot.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 9), Ui.dp(this, 9)));
        catDot.setBackground(Ui.shape(this, 0xFFFFFFFF, 9, 0, 0));
        pill.addView(catDot);
        catLabel = Ui.tv(this, "總覽", 13.5f, Ui.ON_ACCENT, true);
        pill.addView(catLabel, Ui.gap(this, 8));
        pill.addView(Ui.tv(this, "▾", 11, Ui.ON_ACCENT, false), Ui.gap(this, 6));
        pill.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openCategorySheet(); }
        });
        catRow.addView(pill);
        col.addView(catRow, new LinearLayout.LayoutParams(-1, -2));
        updateCatLabel();

        col.addView(frame, new LinearLayout.LayoutParams(-1, 0, 1f));

        View line = new View(this);
        line.setBackgroundColor(Ui.BORDER);
        col.addView(line, new LinearLayout.LayoutParams(-1, Math.max(2, Ui.dp(this, 1.5f))));
        bottomNav = Ui.row(this);
        bottomNav.setBackgroundColor(Ui.SURFACE);
        bottomNav.setPadding(Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 10), Ui.dp(this, 6));
        bottomNav.setElevation(Ui.dp(this, 4));
        col.addView(bottomNav, new LinearLayout.LayoutParams(-1, -2));
        rootFrame.addView(col, new FrameLayout.LayoutParams(-1, -1));
        rootFrame.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        if (getWindow() != null) {
            getWindow().setStatusBarColor(Ui.ACCENT);
            getWindow().setNavigationBarColor(Ui.SURFACE);
        }
        updateBottomNav();
        updateBadge();
    }

    private View iconButton(String svg, View.OnClickListener l) {
        FrameLayout f = new FrameLayout(this);
        f.setBackground(Ui.shape(this, Ui.CHIP_BG, 17, 0, 0));
        f.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 34)));
        SvgIcon ic = Icons.plain(this, svg, 19, Ui.SOFT);
        f.addView(ic, new FrameLayout.LayoutParams(Ui.dp(this, 19), Ui.dp(this, 19), Gravity.CENTER));
        f.setOnClickListener(l);
        return f;
    }

    private void buildOverlay() {
        overlay.removeAllViews();
        flashView = Ui.tv(this, "", 13, 0xFFFFFFFF, false);
        flashView.setGravity(Gravity.CENTER);
        flashView.setPadding(Ui.dp(this, 18), Ui.dp(this, 9), Ui.dp(this, 18), Ui.dp(this, 9));
        flashView.setBackground(Ui.shape(this, 0xF01A1A1A, 999, 0, 0));
        flashView.setVisibility(View.GONE);
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        fp.bottomMargin = Ui.dp(this, 90);
        overlay.addView(flashView, fp);

        undoBar = Ui.tv(this, "", 13, 0xFFFFFFFF, false);
        undoBar.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12));
        undoBar.setBackground(Ui.shape(this, Ui.INK, 14, 0, 0));
        undoBar.setElevation(Ui.dp(this, 6));
        undoBar.setVisibility(View.GONE);
        undoBar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Runnable r = undoAction;
                undoAction = null;
                undoBar.setVisibility(View.GONE);
                if (r != null) r.run();
            }
        });
        FrameLayout.LayoutParams up = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        up.bottomMargin = Ui.dp(this, 80);
        overlay.addView(undoBar, up);
    }

    /** 換配色:Ui 的顏色換掉,頂欄、導覽列重建,目前分頁重畫。 */
    void applyTheme() {
        Theme.apply(Theme.effective(catId));
        int keep = cur;
        buildChrome();
        frame.removeAllViews();
        if (keep >= 0) {
            frame.addView(screens[keep].view(), new FrameLayout.LayoutParams(-1, -1));
            updateChromeFor(keep);
            screens[keep].refresh();
        }
    }

    private void updateChromeFor(int tab) {
        catRow.setVisibility(tab == TAB_LIST || tab == TAB_CAL ? View.VISIBLE : View.GONE);
        updateBottomNav();
    }

    private void show(int tab) {
        if (cur == tab) return;
        if (cur >= 0) {
            screens[cur].onHide();
            if (cur != TAB_SETTINGS) prevTab = cur;
        }
        cur = tab;
        frame.removeAllViews();
        frame.addView(screens[tab].view(), new FrameLayout.LayoutParams(-1, -1));
        updateChromeFor(tab);
        screens[tab].onShow();
    }

    private void updateBottomNav() {
        if (bottomNav == null) return;
        bottomNav.removeAllViews();
        String[] svgs = {Icons.NAV_HABITS, Icons.NAV_LIST, Icons.NAV_CAL, Icons.NAV_NOTES, Icons.NAV_EXPENSE};
        String[] names = {"習慣", "清單", "行事曆", "隨手記", "記帳"};
        for (int i = 0; i < 5; i++) {
            final int tab = i;
            boolean on = cur == tab;
            FrameLayout item = new FrameLayout(this);
            item.setBackground(on ? Ui.shape(this, Ui.ACCENT_SOFT, 16, 0, 0) : null);
            SvgIcon ic = Icons.plain(this, svgs[i], 21, on ? Ui.ACCENT : Ui.SOFT);
            ic.setContentDescription(names[i]);
            item.addView(ic, new FrameLayout.LayoutParams(Ui.dp(this, 21), Ui.dp(this, 21), Gravity.CENTER));
            item.setPadding(0, Ui.dp(this, 11), 0, Ui.dp(this, 11));
            item.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { show(tab); }
            });
            bottomNav.addView(item, new LinearLayout.LayoutParams(0, -2, 1f));
        }
    }

    // ---------- 分類 ----------

    private void updateCatLabel() {
        String name = "總覽";
        int color = 0xFF6B6E76;
        if (!"overview".equals(catId)) {
            JSONObject c = Model.category(catId);
            if (c != null) { name = Model.s(c, "name", "?"); color = Theme.parse(Model.s(c, "color", "#6B6E76")); }
        }
        catLabel.setText(name);
    }

    private void openCategorySheet() {
        final Modal.Sheet s = Modal.sheet(this);
        s.box.addView(Ui.tv(this, "切換分類", 14, Ui.SOFT, true));
        List<String> ids = new ArrayList<>();
        ids.add("overview");
        List<JSONObject> cats = Model.categories();
        for (JSONObject c : cats) ids.add(Model.s(c, "id"));
        for (final String id : ids) {
            boolean over = "overview".equals(id);
            JSONObject c = over ? null : Model.category(id);
            String name = over ? "總覽" : Model.s(c, "name", "?");
            int color = over ? 0xFF6B6E76 : Theme.parse(Model.s(c, "color", "#6B6E76"));
            boolean sel = id.equals(catId);
            LinearLayout row = Ui.row(this);
            row.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
            if (sel) row.setBackground(Ui.shape(this, Ui.ACCENT_SOFT, 12, 0, 0));
            View dot = new View(this);
            dot.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 10), Ui.dp(this, 10)));
            dot.setBackground(Ui.shape(this, color, 10, 0, 0));
            row.addView(dot);
            row.addView(Ui.tv(this, name, 14, sel ? Ui.ACCENT : Ui.CARD_INK, sel), Ui.gap(this, 10));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { s.dismiss(); setCategory(id); }
            });
            s.box.addView(row, Ui.mw(this, 2));
        }
        TextView add = Ui.tv(this, "＋新增分類", 12.5f, Ui.SOFT, false);
        add.setGravity(Gravity.CENTER);
        add.setPadding(Ui.dp(this, 14), Ui.dp(this, 9), Ui.dp(this, 14), Ui.dp(this, 9));
        add.setBackground(Ui.shape(this, 0, 999, Ui.BORDER, 1.5f));
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { s.dismiss(); openAddCategory(); }
        });
        s.box.addView(add, Ui.mw(this, 10));
        s.dialog.show();
    }

    private void openAddCategory() {
        final Form f = new Form(this);
        final Form.Text name = f.text("分類名稱", "", "例如:家庭");
        final Form.ColorPick color = f.color("顏色", Form.SWATCHES[0]);
        List<Theme.Palette> pal = Theme.all();
        String[] names = new String[pal.size() + 1];
        names[0] = "跟隨整體配色";
        for (int i = 0; i < pal.size(); i++) names[i + 1] = pal.get(i).name;
        final Form.Pick pick = f.pick("專屬配色", names, 0);
        final List<Theme.Palette> palF = pal;
        Modal.show(this, "新增分類", f.view(), "新增", new Modal.Ok() {
            @Override public boolean run() {
                String n = name.get();
                if (n.isEmpty()) { flash("請輸入分類名稱"); return false; }
                JSONObject item = new JSONObject();
                try {
                    item.put("id", Repo.newId());
                    item.put("name", n);
                    item.put("color", color.get());
                    item.put("deletable", true);
                    item.put("paletteId", pick.index <= 0 ? JSONObject.NULL : palF.get(pick.index - 1).id);
                } catch (org.json.JSONException e) { return false; }
                Repo.add(MainActivity.this, item, -1, "categories");
                refreshCurrent();
                return true;
            }
        });
    }

    // ---------- 生命週期 ----------

    @Override
    protected void onResume() {
        super.onResume();
        Repo.setOnChange(new Runnable() {
            @Override public void run() {
                boolean first = !catLoaded;
                syncCatFromData();
                if (first && catLoaded && !"overview".equals(catId)) { applyTheme(); }
                else { updateCatLabel(); refreshCurrent(); }
                DailyNotify.sync(MainActivity.this, false);
                Recap.autoOnOpen(MainActivity.this);
            }
        });
        updateBadge();
        if (Store.linked(this)) syncNowAsync(false);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Repo.setOnChange(null);
        if (Repo.pendingCount() > 0) Repo.syncLater(this, 0);
    }

    @Override
    public void onBackPressed() {
        if (cur >= 0 && screens[cur].onBack()) return;
        if (cur == TAB_SETTINGS) { show(prevTab); return; }
        super.onBackPressed();
    }

    private void updateBadge() {
        if (badge == null) return;
        boolean bad = Store.linked(this) && Repo.pendingCount() > 0;
        badge.setVisibility(bad ? View.VISIBLE : View.GONE);
    }

    // ---------- 連結 / 同步 ----------

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
    }

    private void handle(Intent i) {
        Uri u = i == null ? null : i.getData();
        if (u != null && "jishibuwidget".equals(u.getScheme())) {
            String code = u.getQueryParameter("code");
            if (code != null && !code.isEmpty()) linkWith(code);
        }
    }

    /** 用連結碼連結帳號,成功後馬上同步。 */
    void linkWith(String code) {
        String err = Linker.link(this, code);
        if (err != null) { flash(err); return; }
        flash("已連結,正在載入資料…");
        show(TAB_LIST);
        syncNowAsync(false);
    }

    /** 背景同步,完成後更新畫面。 */
    void syncNowAsync(final boolean announce) {
        final android.content.Context app = getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                final boolean ok = Repo.syncNow(app);
                if (announce) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() { flash(ok ? "已同步" : "同步失敗:" + Repo.lastError()); }
                    });
                }
            }
        }).start();
    }
}
