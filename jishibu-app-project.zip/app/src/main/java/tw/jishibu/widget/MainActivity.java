package tw.jishibu.widget;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 記事簿 App 的主畫面骨架,版面照網頁版:
 *   頂欄(記事簿 / 同步提示 / 搜尋 / 設定)
 *   分類選單(只有「清單」「行事曆」分頁顯示)
 *   內容區(目前的分頁)
 *   底部導覽(習慣 / 清單 / 行事曆 / 隨手記 / 記帳)
 * 設定頁不在底部導覽,從右上角齒輪進入。
 */
public class MainActivity extends Activity {
    static final int TAB_HABITS = 0, TAB_LIST = 1, TAB_CAL = 2, TAB_NOTES = 3, TAB_EXPENSE = 4, TAB_SETTINGS = 5;

    private Screen[] screens;
    private int cur = -1, prevTab = TAB_LIST;
    private String catId = "overview";
    private boolean catLoaded = false;

    private FrameLayout rootFrame, frame, overlay;
    private LinearLayout topBar, catRow, bottomNav;
    private TextView badge, flashView, undoBar;
    private TextView catLabel;
    private View catDot;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LoginScreen login;
    private boolean loginOn;
    private Runnable hideFlash, hideUndo;
    private Runnable undoAction;

    // ---------- 給各分頁用 ----------

    /** 目前選的分類 id("overview" = 總覽)。 */
    String catId() { return catId; }

    /** 切換分類(會記住、換配色、重畫目前分頁)。 */
    void setCategory(String id) {
        if (id == null || id.isEmpty()) id = "overview";
        if (id.equals(catId)) return;
        catId = id;
        Repo.set(this, id, "lastCatId");
        applyTheme();
    }

    /** 切到某個分頁。 */
    void go(int tab) { show(tab); }

    /** 搜尋點到事項:切到清單、它的分類、全部篩選、展開那一項。 */
    void jumpToTask(String categoryId, String taskId) {
        ListScreen.prepareJump(taskId);
        show(TAB_LIST);
        setCategory(categoryId);
        refreshCurrent();
    }


    /** 下方的小提示(圓角深色膠囊,約 2 秒消失)。 */
    void flash(String msg) {
        if (Modal.anyOpen()) {   // 有視窗開著時,底下的提示條會被蓋住,改用系統提示
            android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        flashView.setText(msg);
        flashView.setVisibility(View.VISIBLE);
        if (hideFlash != null) handler.removeCallbacks(hideFlash);
        hideFlash = new Runnable() { @Override public void run() { flashView.setVisibility(View.GONE); } };
        handler.postDelayed(hideFlash, 2200);
    }

    /** 底部的「已刪除 · 復原」提示條,5 秒內可以按復原。 */
    void undo(String msg, final Runnable onUndo) {
        undoAction = onUndo;
        undoBar.setText(msg + "    復原");
        undoBar.setVisibility(View.VISIBLE);
        if (hideUndo != null) handler.removeCallbacks(hideUndo);
        hideUndo = new Runnable() { @Override public void run() { undoBar.setVisibility(View.GONE); undoAction = null; } };
        handler.postDelayed(hideUndo, 5000);
    }

    /** 目前分頁重畫(例如資料剛改過)。 */
    void refreshCurrent() {
        if (cur >= 0) screens[cur].refresh();
        updateBadge();
    }

    // ---------- 存檔(匯出備份用) ----------

    interface UriCb { void on(Uri u); }
    private static final int REQ_SAVE = 701;
    private UriCb pendingSave;

    /** 開系統的「另存新檔」畫面,使用者選好位置後回呼。 */
    void saveFile(String name, String mime, UriCb cb) {
        pendingSave = cb;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(i, REQ_SAVE);
    }

    private static final int REQ_OPEN = 702;
    private UriCb pendingOpen;

    /** 開系統的「選擇檔案」畫面,使用者選好檔案後回呼。 */
    void pickFile(UriCb cb) {
        pendingOpen = cb;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_OPEN);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OPEN) {
            UriCb cb = pendingOpen;
            pendingOpen = null;
            if (cb != null && res == RESULT_OK && data != null && data.getData() != null) cb.on(data.getData());
            return;
        }
        if (req == REQ_SAVE) {
            UriCb cb = pendingSave;
            pendingSave = null;
            if (cb != null && res == RESULT_OK && data != null && data.getData() != null) cb.on(data.getData());
        }
    }

    // ---------- 建立 ----------

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        CrashLog.install(getApplicationContext());
        Repo.init(this);
        syncCatFromData();
        Theme.apply(Theme.effective(catId));

        screens = new Screen[]{
                new HabitsScreen(this), new ListScreen(this), new CalendarScreen(this),
                new NotesScreen(this), new ExpenseScreen(this), new SettingsScreen(this)};

        rootFrame = new FrameLayout(this);
        frame = new FrameLayout(this);
        overlay = new FrameLayout(this);
        loginOn = !Store.linked(this);   // 還沒登入:一開就是登入畫面(跟網頁版一樣)
        if (loginOn) login = new LoginScreen(this);
        buildChrome();
        buildOverlay();
        setContentView(rootFrame);

        show(TAB_HABITS);
        handle(getIntent());
        rootFrame.post(new Runnable() { @Override public void run() { CrashLog.showIfAny(MainActivity.this); } });
    }

    private void syncCatFromData() {
        if (catLoaded) return;
        JSONObject d = Repo.data();
        if (d == null) return;
        catLoaded = true;
        String id = Model.s(d, "lastCatId", "overview");
        if (!"overview".equals(id) && Model.category(id) == null) id = "overview";
        catId = id;
    }

    /** 頂欄 + 分類列 + 內容 + 底部導覽。換配色時整組重建。 */
    private void buildChrome() {
        rootFrame.removeAllViews();
        // 換配色時整組重建:內容區和提示層還掛在舊的版面上,要先拆下來才能掛到新的(否則會當機)
        Ui.detach(frame);
        Ui.detach(overlay);
        if (login != null) Ui.detach(login);
        LinearLayout col = Ui.col(this);
        col.setBackgroundColor(Ui.BG);

        topBar = Ui.row(this);
        topBar.setBackgroundColor(Ui.SURFACE);
        topBar.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12));
        TextView brand = Ui.tv(this, "記事簿", 16, Ui.CARD_INK, true);
        brand.setLetterSpacing(0.06f);
        topBar.addView(brand, Ui.weight(1));
        badge = Ui.tv(this, "尚未同步", 11.5f, 0xFFB23A3A, true);
        badge.setPadding(Ui.dp(this, 11), Ui.dp(this, 6), Ui.dp(this, 11), Ui.dp(this, 6));
        badge.setBackground(Ui.shape(this, 0xFFFBECEA, 999, 0, 0));
        badge.setVisibility(View.GONE);
        badge.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (Repo.lastError().contains("資料太大")) {
                    Modal.alert(MainActivity.this, "資料量已滿", "資料量已超過雲端單一文件的上限，修改沒有存到雲端。請到「設定 → 資料備份」匯出備份，再刪除不需要的資料。");
                    return;
                }
                flash("目前沒有連上雲端，修改已暫存在手機，連線後會自動同步");
                syncNowAsync(false);
            }
        });
        topBar.addView(badge, Ui.gap(this, 0));
        topBar.addView(iconButton(Icons.SEARCH, new View.OnClickListener() {
            @Override public void onClick(View v) { Search.open(MainActivity.this); }
        }), Ui.gap(this, 8));
        topBar.addView(iconButton(Icons.GEAR, new View.OnClickListener() {
            @Override public void onClick(View v) { show(cur == TAB_SETTINGS ? prevTab : TAB_SETTINGS); }
        }), Ui.gap(this, 8));
        col.addView(topBar, new LinearLayout.LayoutParams(-1, -2));
        col.addView(Ui.hline(this));

        catRow = Ui.row(this);
        catRow.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), 0);
        LinearLayout pill = Ui.row(this);
        pill.setPadding(Ui.dp(this, 20), Ui.dp(this, 11), Ui.dp(this, 20), Ui.dp(this, 11));
        pill.setBackground(Ui.shape(this, Ui.ACCENT, 999, 0, 0));
        pill.setElevation(Ui.dp(this, 2));
        catDot = new View(this);
        catDot.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 9), Ui.dp(this, 9)));
        catDot.setBackground(Ui.shape(this, 0xFFFFFFFF, 9, 0, 0));
        pill.addView(catDot);
        catLabel = Ui.tv(this, "總覽", 13.5f, Ui.ON_ACCENT, true);
        pill.addView(catLabel, Ui.gap(this, 8));
        pill.addView(Ui.tv(this, "▾", 11, Ui.ON_ACCENT, false), Ui.gap(this, 6));
        pill.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openCategorySheet(); }
        });
        catRow.addView(pill);
        col.addView(catRow, new LinearLayout.LayoutParams(-1, -2));
        updateCatLabel();

        col.addView(frame, new LinearLayout.LayoutParams(-1, 0, 1f));

        View line = new View(this);
        line.setBackgroundColor(Ui.BORDER);
        col.addView(line, new LinearLayout.LayoutParams(-1, Math.max(2, Ui.dp(this, 1.5f))));
        bottomNav = Ui.row(this);
        bottomNav.setBackgroundColor(Ui.SURFACE);
        bottomNav.setPadding(Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 10), Ui.dp(this, 6));
        bottomNav.setElevation(Ui.dp(this, 4));
        col.addView(bottomNav, new LinearLayout.LayoutParams(-1, -2));
        rootFrame.addView(col, new FrameLayout.LayoutParams(-1, -1));
        if (loginOn && login != null) rootFrame.addView(login, new FrameLayout.LayoutParams(-1, -1));
        rootFrame.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        if (getWindow() != null) {
            getWindow().setStatusBarColor(Ui.ACCENT);
            getWindow().setNavigationBarColor(Ui.SURFACE);
        }
        updateBottomNav();
        updateBadge();
    }

    private View iconButton(String svg, View.OnClickListener l) {
        FrameLayout f = new FrameLayout(this);
        f.setBackground(Ui.shape(this, Ui.CHIP_BG, 17, 0, 0));
        f.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 34)));
        SvgIcon ic = Icons.plain(this, svg, 19, Ui.SOFT);
        f.addView(ic, new FrameLayout.LayoutParams(Ui.dp(this, 19), Ui.dp(this, 19), Gravity.CENTER));
        f.setOnClickListener(l);
        return f;
    }

    private void buildOverlay() {
        overlay.removeAllViews();
        flashView = Ui.tv(this, "", 13, 0xFFFFFFFF, false);
        flashView.setGravity(Gravity.CENTER);
        flashView.setPadding(Ui.dp(this, 18), Ui.dp(this, 9), Ui.dp(this, 18), Ui.dp(this, 9));
        flashView.setBackground(Ui.shape(this, 0xF01A1A1A, 999, 0, 0));
        flashView.setVisibility(View.GONE);
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        fp.bottomMargin = Ui.dp(this, 90);
        overlay.addView(flashView, fp);

        undoBar = Ui.tv(this, "", 13, 0xFFFFFFFF, false);
        undoBar.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12));
        undoBar.setBackground(Ui.shape(this, Ui.INK, 14, 0, 0));
        undoBar.setElevation(Ui.dp(this, 6));
        undoBar.setVisibility(View.GONE);
        undoBar.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Runnable r = undoAction;
                undoAction = null;
                undoBar.setVisibility(View.GONE);
                if (r != null) r.run();
            }
        });
        FrameLayout.LayoutParams up = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        up.bottomMargin = Ui.dp(this, 80);
        overlay.addView(undoBar, up);
    }

    /** 換配色:Ui 的顏色換掉,頂欄、導覽列重建,目前分頁重畫。 */
    void applyTheme() {
        Theme.apply(Theme.effective(catId));
        if (Store.linked(this)) LoginScreen.saveAccent(this, Ui.ACCENT);
        int keep = cur;
        buildChrome();
        frame.removeAllViews();
        if (keep >= 0) {
            frame.addView(screens[keep].view(), new FrameLayout.LayoutParams(-1, -1));
            updateChromeFor(keep);
            screens[keep].refresh();
        }
    }

    private void updateChromeFor(int tab) {
        catRow.setVisibility(tab == TAB_LIST || tab == TAB_CAL ? View.VISIBLE : View.GONE);
        updateBottomNav();
    }

    private void show(int tab) {
        if (cur == tab) return;
        if (cur >= 0) {
            screens[cur].onHide();
            if (cur != TAB_SETTINGS) prevTab = cur;
        }
        cur = tab;
        frame.removeAllViews();
        frame.addView(screens[tab].view(), new FrameLayout.LayoutParams(-1, -1));
        updateChromeFor(tab);
        screens[tab].onShow();
    }

    private void updateBottomNav() {
        if (bottomNav == null) return;
        bottomNav.removeAllViews();
        String[] svgs = {Icons.NAV_HABITS, Icons.NAV_LIST, Icons.NAV_CAL, Icons.NAV_NOTES, Icons.NAV_EXPENSE};
        String[] names = {"習慣", "清單", "行事曆", "隨手記", "記帳"};
        for (int i = 0; i < 5; i++) {
            final int tab = i;
            boolean on = cur == tab;
            FrameLayout item = new FrameLayout(this);
            item.setBackground(on ? Ui.shape(this, Ui.ACCENT_SOFT, 16, 0, 0) : null);
            SvgIcon ic = Icons.plain(this, svgs[i], 21, on ? Ui.ACCENT : Ui.SOFT);
            ic.setContentDescription(names[i]);
            item.addView(ic, new FrameLayout.LayoutParams(Ui.dp(this, 21), Ui.dp(this, 21), Gravity.CENTER));
            item.setPadding(0, Ui.dp(this, 11), 0, Ui.dp(this, 11));
            item.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { show(tab); }
            });
            bottomNav.addView(item, new LinearLayout.LayoutParams(0, -2, 1f));
        }
    }

    // ---------- 分類 ----------

    private void updateCatLabel() {
        String name = "總覽";
        int color = 0xFF6B6E76;
        if (!"overview".equals(catId)) {
            JSONObject c = Model.category(catId);
            if (c != null) { name = Model.s(c, "name", "?"); color = Theme.parse(Model.s(c, "color", "#6B6E76")); }
        }
        catLabel.setText(name);
    }

    private void openCategorySheet() {
        final Modal.Sheet s = Modal.sheet(this);
        s.box.addView(Ui.tv(this, "切換分類", 14, Ui.SOFT, true));
        List<String> ids = new ArrayList<>();
        ids.add("overview");
        List<JSONObject> cats = Model.categories();
        for (JSONObject c : cats) ids.add(Model.s(c, "id"));
        for (final String id : ids) {
            boolean over = "overview".equals(id);
            JSONObject c = over ? null : Model.category(id);
            String name = over ? "總覽" : Model.s(c, "name", "?");
            int color = over ? 0xFF6B6E76 : Theme.parse(Model.s(c, "color", "#6B6E76"));
            boolean sel = id.equals(catId);
            LinearLayout row = Ui.row(this);
            row.setPadding(Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
            if (sel) row.setBackground(Ui.shape(this, Ui.ACCENT_SOFT, 12, 0, 0));
            View dot = new View(this);
            dot.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 10), Ui.dp(this, 10)));
            dot.setBackground(Ui.shape(this, color, 10, 0, 0));
            row.addView(dot);
            row.addView(Ui.tv(this, name, 14, sel ? Ui.ACCENT : Ui.CARD_INK, sel), Ui.gap(this, 10));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { s.dismiss(); setCategory(id); }
            });
            s.box.addView(row, Ui.mw(this, 2));
        }
        TextView add = Ui.tv(this, "＋新增分類", 12.5f, Ui.SOFT, false);
        add.setGravity(Gravity.CENTER);
        add.setPadding(Ui.dp(this, 14), Ui.dp(this, 9), Ui.dp(this, 14), Ui.dp(this, 9));
        add.setBackground(Ui.shape(this, 0, 999, Ui.BORDER, 1.5f));
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { s.dismiss(); openAddCategory(); }
        });
        s.box.addView(add, Ui.mw(this, 10));
        s.dialog.show();
    }

    private void openAddCategory() {
        final Form f = new Form(this);
        final Form.Text name = f.text("分類名稱", "", "例如:家庭");
        final Form.ColorPick color = f.color("顏色", Form.SWATCHES[0]);
        List<Theme.Palette> pal = Theme.all();
        String[] names = new String[pal.size() + 1];
        names[0] = "跟隨整體配色";
        for (int i = 0; i < pal.size(); i++) names[i + 1] = pal.get(i).name;
        final Form.Pick pick = f.pick("專屬配色", names, 0);
        final List<Theme.Palette> palF = pal;
        Modal.show(this, "新增分類", f.view(), "新增", new Modal.Ok() {
            @Override public boolean run() {
                String n = name.get();
                if (n.isEmpty()) { flash("請輸入分類名稱"); return false; }
                JSONObject item = new JSONObject();
                try {
                    item.put("id", Repo.newId());
                    item.put("name", n);
                    item.put("color", color.get());
                    item.put("deletable", true);
                    item.put("paletteId", pick.index <= 0 ? JSONObject.NULL : palF.get(pick.index - 1).id);
                } catch (org.json.JSONException e) { return false; }
                Repo.add(MainActivity.this, item, -1, "categories");
                refreshCurrent();
                return true;
            }
        });
    }

    // ---------- 生命週期 ----------

    @Override
    protected void onResume() {
        super.onResume();
        Repo.setOnChange(new Runnable() {
            @Override public void run() {
                boolean fromPoll = polled;
                polled = false;
                int v = Repo.version();
                boolean changed = v != seenVersion;
                seenVersion = v;
                if (changed) {
                    boolean first = !catLoaded;
                    syncCatFromData();
                    if (first && catLoaded && !"overview".equals(catId)) { applyTheme(); }
                    else { updateCatLabel(); refreshCurrent(); }
                    rescheduleAlerts();
                }
                else if (!fromPoll && cur == TAB_SETTINGS) refreshCurrent();   // 設定頁的「上次同步」時間要更新
                updateBadge();
                checkSize();
                if (!fromPoll || changed) {
                    DailyNotify.sync(MainActivity.this, false);
                    if (!asked) { asked = true; askNotifyPermissionOnce(); }
                    Recap.autoOnOpen(MainActivity.this);
                }
            }
        });
        updateBadge();
        if (Store.linked(this)) syncNowAsync(false);
        handler.removeCallbacks(pollTick);
        handler.postDelayed(pollTick, POLL_MS);
    }

    // 網頁版是即時同步;這裡畫面開著時每 30 秒去看一次雲端有沒有新內容(沒變就不重畫,不會打斷輸入)
    private static final long POLL_MS = 30000L;
    private int seenVersion = -1;
    private boolean polled;
    private final Runnable pollTick = new Runnable() {
        @Override public void run() {
            if (Store.linked(MainActivity.this)) { polled = true; syncNowAsync(false); }
            handler.postDelayed(this, POLL_MS);
        }
    };

    private int sizeWarned;

    /** 資料量快滿了提醒一次(跟網頁版同樣的門檻和說法)。 */
    private void checkSize() {
        int b = Repo.cloudBytes();
        int lvl = b >= Backup.DANGER_BYTES ? 2 : b >= Backup.WARN_BYTES ? 1 : 0;
        if (lvl <= sizeWarned) return;
        sizeWarned = lvl;
        Modal.alert(this, lvl == 2 ? "資料量快到上限了" : "資料量提醒", lvl == 2
                ? "資料量已經快到雲端的上限了(約 " + Math.round(b / 1024f) + " KB / 1,000 KB)。超過之後就存不進去。請到「設定 → 資料備份」先匯出備份，再整理掉不需要的資料。"
                : "資料量已經用掉大約七成(約 " + Math.round(b / 1024f) + " KB / 1,000 KB)。建議到「設定 → 資料備份」匯出一份備份。");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Repo.setOnChange(null);
        handler.removeCallbacks(pollTick);
        rescheduleAlerts();
        if (Repo.pendingCount() > 0) Repo.syncLater(this, 0);
    }

    @Override
    public void onBackPressed() {
        if (loginOn) { finish(); return; }
        if (cur >= 0 && screens[cur].onBack()) return;
        if (cur == TAB_SETTINGS) { show(prevTab); return; }
        super.onBackPressed();
    }

    private void updateBadge() {
        if (badge == null) return;
        boolean bad = Store.linked(this) && Repo.pendingCount() > 0;
        String err = Repo.lastError();
        String text = "尚未同步";
        if (err.contains("資料太大")) text = "資料量已滿";
        else if (err.contains("Unable to resolve") || err.contains("UnknownHost") || err.contains("timed out")
                || err.contains("Failed to connect") || err.contains("Network") || err.contains("offline")) text = "離線中";
        badge.setText(text);
        badge.setVisibility(bad ? View.VISIBLE : View.GONE);
    }

    // ---------- 連結 / 同步 ----------

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
    }

    private void handle(Intent i) {
        Uri u = i == null ? null : i.getData();
        if (u != null && "jishibuwidget".equals(u.getScheme())) {
            String code = u.getQueryParameter("code");
            if (code != null && !code.isEmpty()) linkWith(code);
        }
    }

    /** 用連結碼連結帳號,成功後馬上同步。 */
    void linkWith(String code) {
        String err = Linker.link(this, code);
        if (err != null) { flash(err); return; }
        flash("已連結,正在載入資料…");
        leaveLogin();
        show(TAB_HABITS);
        syncNowAsync(false);
    }

    // ---------- 提醒通知 ----------

    private boolean asked;

    void rescheduleAlerts() {
        final android.content.Context app = getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() { LocalAlerts.reschedule(app); }
        }).start();
    }

    /** Android 13 以上要使用者同意才能跳通知。 */
    void askNotifyPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 77);
        }
    }

    /** 登入後第一次進來問一次;之後不再主動問(要重新開可以在設定頁開關提醒通知)。 */
    private void askNotifyPermissionOnce() {
        if (!Store.linked(this)) return;
        android.content.SharedPreferences p = getSharedPreferences("jishibu_alerts", MODE_PRIVATE);
        if (p.getBoolean("asked", false)) return;
        p.edit().putBoolean("asked", true).apply();
        askNotifyPermission();
    }

    // ---------- Google 登入 ----------

    private boolean googleBusy;

    /** 按「使用 Google 登入」:跳出系統帳號選擇器 → 換成 Firebase 憑證 → 確認雲端有這個帳號的資料 → 連結並同步。 */
    void googleLogin() {
        if (googleBusy) return;
        googleBusy = true;
        if (login != null) { login.setBusy(true); login.showNote(null); }
        GoogleSignIn.start(this, new GoogleSignIn.Done() {
            @Override public void ok(String idToken) { finishGoogle(idToken, null); }
            @Override public void fail(String message, String detail) {
                endGoogleBusy();
                if (detail == null) { flash(message); return; }
                showGoogleHelp(message, detail);
            }
        });
    }

    private void endGoogleBusy() {
        googleBusy = false;
        if (login != null) login.setBusy(false);
    }

    /** 登入成功:登入畫面淡出(0.5 秒),跟網頁版一樣。 */
    void leaveLogin() {
        if (!loginOn || login == null) return;
        loginOn = false;
        final LoginScreen l = login;
        login = null;
        l.setBusy(true);
        l.fadeOut(new Runnable() { @Override public void run() { Ui.detach(l); } });
    }

    /** 登出後:回到登入畫面。 */
    void showLogin() {
        if (loginOn) return;
        loginOn = true;
        login = new LoginScreen(this);
        applyTheme();
        login.fadeIn();
    }

    /** Google 登入沒成功時,說明可能的原因(最常見:Firebase 還沒登錄這支 App 的 SHA-1)。 */
    private void showGoogleHelp(String title, final String detail) {
        if (login != null) login.showNote(title);
        Modal.confirm(this, title, detail + "\n\n套件名稱:" + GoogleSignIn.PACKAGE + "\nSHA-1:" + GoogleSignIn.SHA1,
                "複製套件名稱和 SHA-1", false, new Runnable() {
            @Override public void run() {
                try {
                    android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("jishibu",
                            "套件名稱:" + GoogleSignIn.PACKAGE + "\nSHA-1:" + GoogleSignIn.SHA1));
                    flash("已複製");
                } catch (Exception e) { flash("複製失敗"); }
            }
        });
    }

    private void finishGoogle(final String googleToken, final String forcedOrigin) {
        flash("登入中…");
        final android.content.Context app = getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                final java.util.List<String> origins = new ArrayList<>();
                if (forcedOrigin != null) origins.add(forcedOrigin);
                else {
                    String saved = Store.siteOrigin(app);
                    if (saved != null && !saved.isEmpty()) origins.add(saved);
                    origins.add("https://notebook-app-509000.firebaseapp.com");
                    origins.add("https://notebook-app-509000.web.app");
                }
                String[] r = null;
                String used = null, lastErr = "";
                for (String o : origins) {
                    try { r = Api.signInWithGoogle(googleToken, o); used = o; break; }
                    catch (Exception e) { lastErr = String.valueOf(e.getMessage()); }
                }
                if (r == null) {
                    final String le = lastErr;
                    final boolean refererProblem = le.toLowerCase(java.util.Locale.ROOT).contains("referer")
                            || le.contains("HTTP 403");
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            endGoogleBusy();
                            if (refererProblem) askSiteUrl(googleToken);
                            else { if (login != null) login.showNote("Google 登入失敗"); Modal.alert(MainActivity.this, "Google 登入失敗", le); }
                        }
                    });
                    return;
                }
                try {
                    String email = r[2];
                    if (email.isEmpty()) throw new Exception("沒有取得信箱");
                    // 資料放在「userdata/<Firebase 使用者 ID>」(跟網頁版登入後用的位置相同),不是用信箱組出來的名字
                    String key = r[4];
                    if (key == null || key.isEmpty()) throw new Exception("沒有取得使用者代碼");
                    if (!Api.docExists(r[0], key, used)) {
                        final String em = email;
                        runOnUiThread(new Runnable() {
                            @Override public void run() {
                                endGoogleBusy();
                                Modal.alert(MainActivity.this, "雲端找不到這個帳號的記事簿",
                                        em + " 在網頁版還沒有資料。請確認選的是你平常在網頁版登入的那個 Google 帳號。");
                            }
                        });
                        return;
                    }
                    Linker.finish(app, r[1], key, email, used);
                    long secs = 3600;
                    try { secs = Long.parseLong(r[3]); } catch (Exception ignore) { }
                    Store.saveToken(app, r[0], System.currentTimeMillis() + secs * 1000L, null);
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            endGoogleBusy();
                            flash("已登入,正在載入資料…");
                            leaveLogin();
                            show(TAB_HABITS);
                            syncNowAsync(false);
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            endGoogleBusy();
                            Modal.alert(MainActivity.this, "登入沒有完成", String.valueOf(e.getMessage()));
                        }
                    });
                }
            }
        }).start();
    }

    /** 網站網址對不上時,請使用者貼上網頁版的網址(只問一次,之後會記住)。 */
    private void askSiteUrl(final String googleToken) {
        final android.widget.EditText box = Ui.input(this, "https://…", "");
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.addView(Ui.tv(this, "請貼上你平常開啟記事簿網頁的網址(瀏覽器網址列那一串),只需要輸入這一次。", 13, Ui.SOFT, false));
        body.addView(box, Ui.mw(this, 10));
        Modal.show(this, "輸入網頁版網址", body, "登入", new Modal.Ok() {
            @Override public boolean run() {
                String t = box.getText().toString().trim();
                if (!t.startsWith("http")) { flash("網址要以 https:// 開頭"); return false; }
                try {
                    Uri u = Uri.parse(t);
                    String o = u.getScheme() + "://" + u.getAuthority();
                    googleBusy = true;
                    if (login != null) login.setBusy(true);
                    finishGoogle(googleToken, o);
                    return true;
                } catch (Exception e) { flash("網址格式不正確"); return false; }
            }
        });
    }

    /** 背景同步,完成後更新畫面。 */
    void syncNowAsync(final boolean announce) {
        final android.content.Context app = getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                final boolean ok = Repo.syncNow(app);
                if (announce) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() { flash(ok ? "已同步" : "同步失敗:" + Repo.lastError()); }
                    });
                }
            }
        }).start();
    }
}
