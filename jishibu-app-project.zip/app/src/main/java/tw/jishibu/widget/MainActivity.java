package tw.jishibu.widget;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 記事簿 App:底部五個分頁。 */
public class MainActivity extends Activity {
    private Screen[] screens;
    private TextView[] tabs;
    private FrameLayout frame;
    private int cur = 0;
    private static final String[] NAMES = {"今天", "清單", "行事曆", "習慣", "設定"};

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        Repo.init(this);

        screens = new Screen[]{
                new TodayScreen(this), new TasksScreen(this), new CalendarScreen(this),
                new HabitsScreen(this), new SettingsScreen(this)};

        LinearLayout root = Ui.col(this);
        root.setBackgroundColor(Ui.BG);
        frame = new FrameLayout(this);
        root.addView(frame, new LinearLayout.LayoutParams(-1, 0, 1f));

        View line = new View(this);
        line.setBackgroundColor(Ui.LINE);
        root.addView(line, new LinearLayout.LayoutParams(-1, Ui.dp(this, 1)));

        LinearLayout bar = Ui.row(this);
        bar.setBackgroundColor(Ui.CARD);
        tabs = new TextView[NAMES.length];
        for (int i = 0; i < NAMES.length; i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(NAMES[i]);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(14);
            t.setPadding(0, Ui.dp(this, 14), 0, Ui.dp(this, 14));
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { show(idx); }
            });
            tabs[i] = t;
            bar.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);

        cur = Store.linked(this) ? 0 : 4;
        show(cur);
        handle(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Repo.setOnChange(new Runnable() {
            @Override public void run() { screens[cur].refresh(); }
        });
        screens[cur].refresh();
        if (Store.linked(this)) syncNowAsync(false);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Repo.setOnChange(null);
    }

    private void show(int i) {
        cur = i;
        frame.removeAllViews();
        frame.addView(screens[i].view(), new FrameLayout.LayoutParams(-1, -1));
        for (int k = 0; k < tabs.length; k++) {
            boolean sel = k == i;
            tabs[k].setTextColor(sel ? Ui.ACCENT : Ui.SOFT);
            tabs[k].setTypeface(null, sel ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        }
        screens[i].refresh();
    }

    private void handle(Intent i) {
        Uri u = i == null ? null : i.getData();
        if (u != null && "jishibuwidget".equals(u.getScheme())) {
            String code = u.getQueryParameter("code");
            if (code != null && !code.isEmpty()) linkWith(code);
        }
    }

    /** 用連結碼連結帳號,成功後馬上同步。 */
    void linkWith(String code) {
        String err = Linker.link(this, code);
        if (err != null) { Ui.toast(this, err); return; }
        Ui.toast(this, "已連結,正在載入資料…");
        show(0);
        syncNowAsync(false);
    }

    /** 背景同步,完成後更新畫面。 */
    void syncNowAsync(final boolean announce) {
        final android.content.Context app = getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                final boolean ok = Repo.syncNow(app);
                if (announce) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() { Ui.toast(MainActivity.this, ok ? "已同步" : "同步失敗,請看設定頁的說明"); }
                    });
                }
            }
        }).start();
    }
}
