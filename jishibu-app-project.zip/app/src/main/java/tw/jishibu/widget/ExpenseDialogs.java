package tw.jishibu.widget;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 記帳用到的各個視窗:記一筆、我的存款(帳戶)、調整誤差、分類設定、固定扣款、薪資設定、薪資明細。 */
final class ExpenseDialogs {
    private ExpenseDialogs() {}

    // ---------- 小零件 ----------

    static final class Drop {
        int index;
        final String[] names;
        TextView view;
        Drop(String[] names, int index) { this.names = names; this.index = index; }
        String get() { return index >= 0 && index < names.length ? names[index] : ""; }
    }

    interface Done { void run(); }

    static Drop drop(final MainActivity a, final String title, String[] names, int index, final Ui.IntCb cb) {
        final Drop d = new Drop(names, index);
        final TextView t = Ui.tv(a, d.get() + "  ▾", 13.5f, Ui.CARD_INK, false);
        t.setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10));
        t.setBackground(Ui.shape(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
        d.view = t;
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Modal.choose(a, title, d.names, d.index, new Ui.IntCb() {
                    @Override public void on(int i) {
                        d.index = i;
                        t.setText(d.get() + "  ▾");
                        if (cb != null) cb.on(i);
                    }
                });
            }
        });
        return d;
    }

    static EditText input(MainActivity a, String hint, String value, boolean number) {
        return number ? Ui.numberInput(a, hint, value, true) : Ui.input(a, hint, value);
    }

    /** 小一號的膠囊分頁(請假單位、週期之類)。 */
    static LinearLayout miniTabs(final MainActivity a, final String[] labels, int selected, float sp, int padH, int padV, final Ui.IntCb cb) {
        final LinearLayout wrap = Ui.row(a);
        wrap.setPadding(Ui.dp(a, 3), Ui.dp(a, 3), Ui.dp(a, 3), Ui.dp(a, 3));
        wrap.setBackground(Ui.shape(a, Ui.CHIP_BG, 999, 0, 0));
        final TextView[] tabs = new TextView[labels.length];
        final float spF = sp;
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView t = Ui.tv(a, labels[i], sp, i == selected ? Ui.ON_ACCENT : Ui.SOFT, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(Ui.dp(a, padH), Ui.dp(a, padV), Ui.dp(a, padH), Ui.dp(a, padV));
            t.setBackground(i == selected ? Ui.shape(a, Ui.ACCENT, 999, 0, 0) : null);
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    for (int k = 0; k < tabs.length; k++) {
                        tabs[k].setTextColor(k == idx ? Ui.ON_ACCENT : Ui.SOFT);
                        tabs[k].setBackground(k == idx ? Ui.shape(a, Ui.ACCENT, 999, 0, 0) : null);
                    }
                    if (cb != null) cb.on(idx);
                }
            });
            tabs[i] = t;
            wrap.addView(t);
        }
        return wrap;
    }

    private static TextView title(MainActivity a, String s) {
        TextView t = Ui.tv(a, s, 16, Ui.CARD_INK, true);
        t.setPadding(0, 0, 0, Ui.dp(a, 8));
        return t;
    }

    private static LinearLayout actions(MainActivity a, View... btns) {
        LinearLayout row = Ui.row(a);
        row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        for (int i = 0; i < btns.length; i++) row.addView(btns[i], i == 0 ? Ui.gap(a, 0) : Ui.gap(a, 8));
        row.setLayoutParams(Ui.mw(a, 22));
        return row;
    }

    private static View ghost(MainActivity a, String label, final Runnable r) {
        return Ui.btnGhost(a, label, new View.OnClickListener() {
            @Override public void onClick(View v) { r.run(); }
        });
    }

    private static View primary(MainActivity a, String label, final Runnable r) {
        return Ui.btnPrimary(a, label, new View.OnClickListener() {
            @Override public void onClick(View v) { r.run(); }
        });
    }

    /** 一列「名稱 + 金額 + 刪除」(固定扣款、薪資加項/扣款)。 */
    private static View itemRow(MainActivity a, CharSequence text, String small, final Runnable onDelete) {
        LinearLayout row = Ui.row(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(a, 12), Ui.dp(a, 9), Ui.dp(a, 12), Ui.dp(a, 9));
        row.setBackground(Ui.shape(a, Ui.TASK_BG, 12, Ui.BORDER, 1.5f));
        LinearLayout left = Ui.col(a);
        left.addView(Ui.tv(a, text.toString(), 13, Ui.CARD_INK, false));
        if (small != null && !small.isEmpty()) left.addView(Ui.tv(a, small, 11, Ui.SOFT, false));
        row.addView(left, Ui.weight(1));
        TextView del = Ui.tv(a, "刪除", 12, Ui.DANGER, false);
        del.setPadding(Ui.dp(a, 8), Ui.dp(a, 6), Ui.dp(a, 4), Ui.dp(a, 6));
        del.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onDelete.run(); }
        });
        row.addView(del);
        return row;
    }

    private static List<JSONObject> accounts() { return Money.list("accounts"); }

    private static String[] accountNames() {
        List<JSONObject> l = accounts();
        String[] r = new String[l.size()];
        for (int i = 0; i < r.length; i++) r[i] = Model.s(l.get(i), "name");
        return r;
    }

    private static int accountIndex(String id) {
        List<JSONObject> l = accounts();
        for (int i = 0; i < l.size(); i++) if (Model.s(l.get(i), "id").equals(id)) return i;
        return 0;
    }

    private static JSONObject newObj() { return new JSONObject(); }

    private static JSONObject put(JSONObject o, String k, Object v) {
        try { o.put(k, v); } catch (JSONException ignore) { }
        return o;
    }

    private static List<JSONObject> cats(String type) {
        return Money.list("income".equals(type) ? "incomeCategories" : "expenseCategories");
    }

    // ---------- 記一筆 ----------

    private static String curType;
    private static String curCatId;

    static void openExpense(final MainActivity a) { openExpense(a, 0); }

    /** startTab:0 支出、1 收入(從桌面小工具的「收入」「支出」按鈕進來時用)。 */
    static void openExpense(final MainActivity a, final int startTab) {
        final List<JSONObject> accs = accounts();
        if (accs.isEmpty()) { a.flash("還沒有帳戶，請先在「目前存款」新增一個"); return; }
        final Modal.Sheet s = Modal.sheet(a);
        s.box.addView(title(a, "記一筆"));

        curType = startTab == 1 ? "income" : "expense";
        final List<JSONObject> exCats = cats(curType);
        curCatId = exCats.isEmpty() ? "other" : Model.s(exCats.get(0), "id");

        final LinearLayout catField = Ui.col(a);
        final LinearLayout toField = Ui.col(a);
        final LinearLayout accField = Ui.col(a);
        final LinearLayout catGrid = Ui.col(a);

        final EditText amount = Ui.numberInput(a, "0", "", true);
        final String[] dateBox = {Model.today()};
        final EditText note = Ui.input(a, "備註（選填）", "");

        String lastId = ExpenseScreen.lastAccountId;
        int lastIdx = 0;
        for (int i = 0; i < accs.size(); i++) if (Model.s(accs.get(i), "id").equals(lastId)) lastIdx = i;
        final Drop from = drop(a, "帳戶", accountNames(), lastIdx, null);
        final Drop to = drop(a, "轉入帳戶", accountNames(), accs.size() > 1 ? (lastIdx == 0 ? 1 : 0) : 0, null);

        final Runnable paintGrid = new Runnable() {
            @Override public void run() {
                catGrid.removeAllViews();
                List<JSONObject> cs = cats(curType);
                LinearLayout row = null;
                for (int i = 0; i < cs.size(); i++) {
                    if (i % 4 == 0) {
                        row = Ui.row(a);
                        catGrid.addView(row, Ui.mw(a, i == 0 ? 0 : 8));
                    }
                    final JSONObject c = cs.get(i);
                    final String id = Model.s(c, "id");
                    boolean sel = id.equals(curCatId);
                    LinearLayout b = Ui.col(a);
                    b.setGravity(Gravity.CENTER_HORIZONTAL);
                    b.setPadding(Ui.dp(a, 4), Ui.dp(a, 8), Ui.dp(a, 4), Ui.dp(a, 8));
                    b.setBackground(Ui.shape(a, sel ? Ui.ACCENT_SOFT : 0xFFFFFFFF, 12, sel ? Ui.ACCENT : Ui.BORDER, 1.5f));
                    SvgIcon ic = ExpenseIcons.icon(a, Model.s(c, "icon", "other"), 20, sel ? Ui.ACCENT : Ui.SOFT);
                    b.addView(ic, new LinearLayout.LayoutParams(Ui.dp(a, 20), Ui.dp(a, 20)));
                    TextView nm = Ui.tv(a, Model.s(c, "name"), 11, Ui.CARD_INK, false);
                    nm.setSingleLine(true);
                    nm.setGravity(Gravity.CENTER);
                    b.addView(nm, Ui.mw(a, 4));
                    b.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            curCatId = id;
                            if (GRID_PAINT != null) GRID_PAINT.run();
                        }
                    });
                    row.addView(b, new LinearLayout.LayoutParams(0, -2, 1f));
                    Ui.lp(b).rightMargin = Ui.dp(a, 8);
                }
                // 補齊最後一列的空位,讓每格一樣寬
                if (row != null) {
                    int rest = (4 - cs.size() % 4) % 4;
                    for (int k = 0; k < rest; k++) {
                        View sp = new View(a);
                        row.addView(sp, new LinearLayout.LayoutParams(0, 1, 1f));
                        Ui.lp(sp).rightMargin = Ui.dp(a, 8);
                    }
                }
            }
        };
        GRID_PAINT = paintGrid;

        final Runnable applyType = new Runnable() {
            @Override public void run() {
                boolean transfer = "transfer".equals(curType);
                catField.setVisibility(transfer ? View.GONE : View.VISIBLE);
                toField.setVisibility(transfer ? View.VISIBLE : View.GONE);
                ((TextView) accField.getChildAt(0)).setText(transfer ? "轉出帳戶" : "帳戶");
                if (!transfer) {
                    List<JSONObject> cs = cats(curType);
                    curCatId = cs.isEmpty() ? "other" : Model.s(cs.get(0), "id");
                    paintGrid.run();
                }
            }
        };

        s.box.addView(miniTabs(a, new String[]{"支出", "收入", "轉帳"}, startTab == 1 ? 1 : 0, 13, 20, 9, new Ui.IntCb() {
            @Override public void on(int i) {
                curType = i == 0 ? "expense" : i == 1 ? "income" : "transfer";
                applyType.run();
            }
        }), Ui.mw(a, 4));
        s.box.addView(Ui.field(a, "金額", amount));
        accField.addView(Ui.tv(a, "帳戶", 12, Ui.SOFT, true));
        accField.addView(from.view, Ui.mw(a, 6));
        accField.setLayoutParams(Ui.mw(a, 15));
        s.box.addView(accField);
        toField.addView(Ui.tv(a, "轉入帳戶", 12, Ui.SOFT, true));
        toField.addView(to.view, Ui.mw(a, 6));
        toField.setLayoutParams(Ui.mw(a, 15));
        toField.setVisibility(View.GONE);
        s.box.addView(toField);
        catField.addView(Ui.tv(a, "分類", 12, Ui.SOFT, true));
        catField.addView(catGrid, Ui.mw(a, 6));
        catField.setLayoutParams(Ui.mw(a, 15));
        s.box.addView(catField);

        final TextView dateText = Ui.tv(a, dateBox[0], 13.5f, Ui.CARD_INK, false);
        dateText.setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10));
        dateText.setBackground(Ui.shape(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
        dateText.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Modal.pickDate(a, dateBox[0], new Modal.StrCb() {
                    @Override public void on(String d) { dateBox[0] = d; dateText.setText(d); }
                });
            }
        });
        s.box.addView(Ui.field(a, "日期", dateText));
        s.box.addView(Ui.field(a, "備註", note));
        paintGrid.run();

        s.box.addView(actions(a, ghost(a, "取消", new Runnable() {
            @Override public void run() { s.dismiss(); }
        }), primary(a, "儲存", new Runnable() {
            @Override public void run() {
                double amt = Money.n0(amount.getText().toString().trim());
                if (!(amt > 0)) { a.flash("請輸入金額"); return; }
                String day = dateBox[0].isEmpty() ? Model.today() : dateBox[0];
                String fromId = Model.s(accs.get(from.index), "id");
                boolean transfer = "transfer".equals(curType);
                String toId = transfer ? Model.s(accs.get(to.index), "id") : null;
                if (transfer && toId.equals(fromId)) { a.flash("轉出跟轉入帳戶不能是同一個"); return; }
                JSONObject item = newObj();
                put(item, "id", Repo.newId());
                put(item, "type", curType);
                put(item, "amount", Money.numObj(amt));
                put(item, "note", note.getText().toString().trim());
                put(item, "date", day);
                put(item, "accountId", fromId);
                put(item, "createdAt", System.currentTimeMillis());
                if (transfer) put(item, "toAccountId", toId); else put(item, "category", curCatId);
                ExpenseScreen.lastAccountId = fromId;
                Repo.add(a, item, -1, "expenses");
                s.dismiss();
                a.refreshCurrent();
                a.flash("已記一筆");
            }
        })));
        // 一打開就能輸入金額:游標放在金額欄、鍵盤自己跳出來
        if (s.dialog.getWindow() != null) {
            s.dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                    | android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        }
        s.dialog.show();
        amount.requestFocus();
    }

    private static Runnable GRID_PAINT;

    // ---------- 我的存款(帳戶) ----------

    static void openAccounts(final MainActivity a) {
        final Modal.Sheet s = Modal.sheet(a);
        s.box.addView(title(a, "我的存款"));
        final TextView total = Ui.tv(a, "", 14, Ui.CARD_INK, false);
        s.box.addView(total, Ui.mw(a, 0));
        final LinearLayout list = Ui.col(a);
        s.box.addView(list, Ui.mw(a, 10));

        // 新增帳戶
        LinearLayout add = Ui.col(a);
        add.addView(Ui.tv(a, "新增帳戶", 12, Ui.SOFT, true));
        LinearLayout r1 = Ui.row(a);
        final EditText name = Ui.input(a, "名稱，例如：郵局", "");
        r1.addView(name, Ui.weight(1));
        final Drop type = drop(a, "帳戶類型", new String[]{"銀行", "現金"}, 0, null);
        r1.addView(type.view, Ui.gap(a, 8));
        add.addView(r1, Ui.mw(a, 6));
        final EditText bal = Ui.numberInput(a, "目前餘額", "", true);
        add.addView(bal, Ui.mw(a, 8));
        add.addView(Ui.btnGhost(a, "新增帳戶", new View.OnClickListener() {
            @Override public void onClick(View v) {
                String n = name.getText().toString().trim();
                if (n.isEmpty()) { a.flash("請輸入帳戶名稱"); return; }
                JSONObject item = newObj();
                put(item, "id", Repo.newId());
                put(item, "name", n);
                put(item, "type", type.index == 1 ? "cash" : "bank");
                put(item, "opening", Money.numObj(Money.n0(bal.getText().toString().trim())));
                Repo.add(a, item, -1, "accounts");
                name.setText("");
                bal.setText("");
                a.refreshCurrent();
                paintAccounts(a, s, total, list);
                a.flash("已新增帳戶");
            }
        }), Ui.wrap(a, 8));
        add.setLayoutParams(Ui.mw(a, 14));
        s.box.addView(add);
        s.box.addView(actions(a, primary(a, "完成", new Runnable() {
            @Override public void run() { s.dismiss(); }
        })));
        paintAccounts(a, s, total, list);
        s.dialog.show();
    }

    private static void paintAccounts(final MainActivity a, final Modal.Sheet s, TextView total, final LinearLayout list) {
        final TextView totalF = total;
        total.setText("合計　" + Money.fmt(Money.totalBalance()));
        list.removeAllViews();
        for (final JSONObject acc : accounts()) {
            final String id = Model.s(acc, "id");
            LinearLayout row = Ui.row(a);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(a, 10), Ui.dp(a, 8), Ui.dp(a, 10), Ui.dp(a, 8));
            row.setBackground(Ui.shape(a, Ui.TASK_BG, 12, Ui.BORDER, 1.5f));
            row.addView(ExpenseIcons.icon(a, "cash".equals(Model.s(acc, "type")) ? "wallet" : "bank", 18, Ui.ACCENT),
                    new LinearLayout.LayoutParams(Ui.dp(a, 18), Ui.dp(a, 18)));
            final EditText nm = Ui.input(a, "", Model.s(acc, "name"));
            nm.setTextSize(13);
            nm.setPadding(Ui.dp(a, 8), Ui.dp(a, 6), Ui.dp(a, 8), Ui.dp(a, 6));
            nm.setBackground(Ui.shape(a, 0xFFFFFFFF, 10, Ui.BORDER, 1.5f));
            final String oldName = Model.s(acc, "name");
            nm.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override public void onFocusChange(View v, boolean has) {
                    if (has) return;
                    String n = nm.getText().toString().trim();
                    if (!n.isEmpty() && !n.equals(oldName)) {
                        Repo.patch(a, put(newObj(), "name", n), null, "accounts", id);
                        a.refreshCurrent();
                    } else if (n.isEmpty()) {
                        nm.setText(oldName);
                    }
                }
            });
            row.addView(nm, Ui.weight(1));
            Ui.lp(nm).leftMargin = Ui.dp(a, 8);
            double b = Money.balance(acc);
            TextView bt = Ui.tv(a, Money.fmt(b), 13, b < 0 ? 0xFFC0504D : Ui.CARD_INK, true);
            row.addView(bt, Ui.gap(a, 8));
            TextView adj = Ui.tv(a, "調整誤差", 11, Ui.CARD_INK, false);
            adj.setPadding(Ui.dp(a, 9), Ui.dp(a, 5), Ui.dp(a, 9), Ui.dp(a, 5));
            adj.setBackground(Ui.shape(a, Ui.CHIP_BG, 999, 0, 0));
            adj.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    openAdjust(a, id, new Done() {
                        @Override public void run() { paintAccounts(a, s, totalF, list); }
                    });
                }
            });
            row.addView(adj, Ui.gap(a, 8));
            TextView del = Ui.tv(a, "×", 15, Ui.DANGER, false);
            del.setPadding(Ui.dp(a, 8), Ui.dp(a, 4), Ui.dp(a, 4), Ui.dp(a, 4));
            del.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { deleteAccount(a, id, s, totalF, list); }
            });
            row.addView(del, Ui.gap(a, 4));
            list.addView(row, Ui.mw(a, 8));
        }
    }

    private static void deleteAccount(MainActivity a, String id, Modal.Sheet s, TextView total, LinearLayout list) {
        if (accounts().size() <= 1) { a.flash("至少要保留一個帳戶"); return; }
        boolean used = false;
        for (JSONObject e : Money.list("expenses")) if (Model.s(e, "accountId").equals(id) || Model.s(e, "toAccountId").equals(id)) used = true;
        for (JSONObject r : Money.list("recurring")) if (Model.s(r, "accountId").equals(id)) used = true;
        if (used) { a.flash("這個帳戶已有紀錄或固定扣款，無法刪除（可以直接改名）"); return; }
        Repo.del(a, "accounts", id);
        a.refreshCurrent();
        paintAccounts(a, s, total, list);
    }

    // ---------- 調整誤差 ----------

    static void openAdjust(final MainActivity a, final String accId, final Done after) {
        JSONObject acc = null;
        for (JSONObject x : accounts()) if (Model.s(x, "id").equals(accId)) acc = x;
        if (acc == null) return;
        final JSONObject accF = acc;
        final Modal.Sheet s = Modal.sheet(a);
        s.box.addView(title(a, "調整誤差"));
        s.box.addView(Ui.hint(a, Model.s(acc, "name") + "　系統記錄的餘額：" + Money.fmt(Money.balance(acc))));
        final EditText actual = Ui.numberInput(a, "0", "", true);
        actual.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL | android.text.InputType.TYPE_NUMBER_FLAG_SIGNED);
        final TextView preview = Ui.hint(a, "");
        LinearLayout f = Ui.field(a, "實際餘額（以銀行 App 或口袋裡實際的錢為準）", actual);
        f.addView(preview);
        s.box.addView(f);
        actual.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence x, int p, int q, int r) { }
            @Override public void onTextChanged(CharSequence x, int p, int q, int r) { }
            @Override public void afterTextChanged(Editable e) {
                String raw = actual.getText().toString().trim();
                if (raw.isEmpty()) { preview.setText(""); return; }
                double diff = Money.n0(raw) - Money.balance(accF);
                preview.setText(diff == 0 ? "沒有差額" : diff > 0 ? "多出來 " + Money.fmt(diff) + "，會記成一筆正向調整" : "不見了 " + Money.fmt(-diff) + "，會記成一筆負向調整");
            }
        });
        final EditText note = Ui.input(a, "例如：不明支出、找零", "");
        s.box.addView(Ui.field(a, "備註（選填）", note));
        s.box.addView(actions(a, ghost(a, "取消", new Runnable() {
            @Override public void run() { s.dismiss(); }
        }), primary(a, "儲存", new Runnable() {
            @Override public void run() {
                String raw = actual.getText().toString().trim();
                if (raw.isEmpty() || Double.isNaN(parse(raw))) { a.flash("請輸入實際餘額"); return; }
                double diff = Math.round((parse(raw) - Money.balance(accF)) * 100) / 100.0;
                if (diff == 0) { a.flash("沒有差額，不需要調整"); return; }
                JSONObject item = newObj();
                put(item, "id", Repo.newId());
                put(item, "type", "adjust");
                put(item, "amount", Money.numObj(diff));
                put(item, "category", "adjust");
                put(item, "note", note.getText().toString().trim());
                put(item, "date", Model.today());
                put(item, "accountId", accId);
                put(item, "createdAt", System.currentTimeMillis());
                Repo.add(a, item, -1, "expenses");
                s.dismiss();
                a.refreshCurrent();
                if (after != null) after.run();
                a.flash("已調整 " + Model.s(accF, "name") + " 誤差 " + (diff > 0 ? "+" : "-") + "$" + Money.num(Math.abs(diff)));
            }
        })));
        s.dialog.show();
    }

    private static double parse(String raw) {
        try { return Double.parseDouble(raw); } catch (NumberFormatException e) { return Double.NaN; }
    }

    // ---------- 分類設定 ----------

    private static String catType = "expense";
    private static String newIcon = "other";

    static void openCategories(final MainActivity a) {
        catType = "expense";
        newIcon = "other";
        final Modal.Sheet s = Modal.sheet(a);
        s.box.addView(title(a, "分類設定"));
        final LinearLayout list = Ui.col(a);
        final LinearLayout iconPicker = Ui.col(a);
        s.box.addView(miniTabs(a, new String[]{"支出分類", "收入分類"}, 0, 13, 20, 9, new Ui.IntCb() {
            @Override public void on(int i) {
                catType = i == 0 ? "expense" : "income";
                paintCatList(a, list);
            }
        }), Ui.mw(a, 4));
        s.box.addView(list, Ui.mw(a, 14));

        LinearLayout add = Ui.col(a);
        add.addView(Ui.tv(a, "新增分類", 12, Ui.SOFT, true));
        final EditText name = Ui.input(a, "分類名稱，例如：寵物", "");
        add.addView(name, Ui.mw(a, 6));
        add.addView(iconPicker, Ui.mw(a, 8));
        paintIconPicker(a, iconPicker);
        add.addView(Ui.btnGhost(a, "新增分類", new View.OnClickListener() {
            @Override public void onClick(View v) {
                String n = name.getText().toString().trim();
                if (n.isEmpty()) { a.flash("請輸入分類名稱"); return; }
                JSONObject item = newObj();
                put(item, "id", Repo.newId());
                put(item, "name", n);
                put(item, "icon", newIcon);
                Repo.add(a, item, -1, "income".equals(catType) ? "incomeCategories" : "expenseCategories");
                name.setText("");
                newIcon = "other";
                paintIconPicker(a, iconPicker);
                paintCatList(a, list);
                a.refreshCurrent();
                a.flash("已新增分類「" + n + "」");
            }
        }), Ui.wrap(a, 10));
        add.setLayoutParams(Ui.mw(a, 14));
        s.box.addView(add);
        s.box.addView(actions(a, primary(a, "完成", new Runnable() {
            @Override public void run() { s.dismiss(); }
        })));
        paintCatList(a, list);
        s.dialog.show();
    }

    private static void paintIconPicker(final MainActivity a, final LinearLayout box) {
        box.removeAllViews();
        String[] keys = ExpenseIcons.CHOICES;
        LinearLayout row = null;
        for (int i = 0; i < keys.length; i++) {
            if (i % 6 == 0) {
                row = Ui.row(a);
                box.addView(row, Ui.mw(a, i == 0 ? 0 : 6));
            }
            final String key = keys[i];
            boolean sel = key.equals(newIcon);
            FrameLayoutHolder h = new FrameLayoutHolder(a, key, sel);
            h.view.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    newIcon = key;
                    paintIconPicker(a, box);
                }
            });
            row.addView(h.view, new LinearLayout.LayoutParams(0, Ui.dp(a, 40), 1f));
            Ui.lp(h.view).rightMargin = Ui.dp(a, 6);
        }
    }

    private static final class FrameLayoutHolder {
        final android.widget.FrameLayout view;
        FrameLayoutHolder(MainActivity a, String key, boolean sel) {
            view = new android.widget.FrameLayout(a);
            view.setBackground(Ui.shape(a, sel ? Ui.ACCENT_SOFT : 0xFFFFFFFF, 10, sel ? Ui.ACCENT : Ui.BORDER, 1.5f));
            view.addView(ExpenseIcons.icon(a, key, 18, sel ? Ui.ACCENT : Ui.SOFT),
                    new android.widget.FrameLayout.LayoutParams(Ui.dp(a, 18), Ui.dp(a, 18), Gravity.CENTER));
        }
    }

    private static void paintCatList(final MainActivity a, final LinearLayout list) {
        list.removeAllViews();
        final String type = catType;
        final List<JSONObject> cs = cats(type);
        JSONObject budgets = Money.obj("categoryBudgets");
        for (final JSONObject c : cs) {
            final String id = Model.s(c, "id");
            LinearLayout row = Ui.row(a);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 8));
            row.addView(ExpenseIcons.icon(a, Model.s(c, "icon", "other"), 20, Ui.ACCENT), new LinearLayout.LayoutParams(Ui.dp(a, 20), Ui.dp(a, 20)));
            final EditText nm = Ui.input(a, "", Model.s(c, "name"));
            nm.setPadding(Ui.dp(a, 8), Ui.dp(a, 6), Ui.dp(a, 8), Ui.dp(a, 6));
            final String oldName = Model.s(c, "name");
            nm.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override public void onFocusChange(View v, boolean has) {
                    if (has) return;
                    String n = nm.getText().toString().trim();
                    if (!n.isEmpty() && !n.equals(oldName)) {
                        Repo.patch(a, put(newObj(), "name", n), null, "income".equals(type) ? "incomeCategories" : "expenseCategories", id);
                        a.refreshCurrent();
                    } else if (n.isEmpty()) {
                        nm.setText(oldName);
                    }
                }
            });
            row.addView(nm, Ui.weight(1));
            Ui.lp(nm).leftMargin = Ui.dp(a, 10);
            if ("expense".equals(type)) {
                double cur = Money.d(budgets, id);
                final EditText bud = Ui.numberInput(a, "預算", cur > 0 ? Money.num(cur).replace(",", "") : "", true);
                bud.setTextSize(12);
                bud.setGravity(Gravity.END);
                bud.setPadding(Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 6));
                final double curF = cur;
                bud.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override public void onFocusChange(View v, boolean has) {
                        if (has) return;
                        double n = Money.n0(bud.getText().toString().trim());
                        if (n == curF || (n <= 0 && curF <= 0)) return;
                        if (n > 0) Repo.set(a, Money.numObj(n), "categoryBudgets", id);
                        else Repo.del(a, "categoryBudgets", id);
                        a.refreshCurrent();
                    }
                });
                row.addView(bud, new LinearLayout.LayoutParams(Ui.dp(a, 62), -2));
                Ui.lp(bud).leftMargin = Ui.dp(a, 10);
            }
            TextView del = Ui.tv(a, "×", 15, Ui.DANGER, false);
            del.setPadding(Ui.dp(a, 10), Ui.dp(a, 4), Ui.dp(a, 4), Ui.dp(a, 4));
            del.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { deleteCategory(a, type, id, list); }
            });
            row.addView(del);
            list.addView(row);
            list.addView(Ui.hline(a));
        }
    }

    private static void deleteCategory(final MainActivity a, final String type, final String id, final LinearLayout list) {
        final List<JSONObject> cs = cats(type);
        if (cs.size() <= 1) { a.flash("至少要保留一個分類"); return; }
        Modal.confirm(a, "確定要刪除嗎？", "刪除後，原本用這個分類記的帳會改成「其他」，確定要刪除嗎？", "刪除", true, new Runnable() {
            @Override public void run() {
                String fbId = null;
                String want = "income".equals(type) ? "other_income" : "other";
                for (JSONObject c : cs) if (Model.s(c, "id").equals(want) && !want.equals(id)) fbId = want;
                if (fbId == null) for (JSONObject c : cs) if (!Model.s(c, "id").equals(id)) { fbId = Model.s(c, "id"); break; }
                if (fbId == null) return;
                for (JSONObject e : Money.list("expenses")) {
                    if (type.equals(Model.s(e, "type")) && id.equals(Model.s(e, "category"))) {
                        Repo.patch(a, put(newObj(), "category", fbId), null, "expenses", Model.s(e, "id"));
                    }
                }
                Repo.del(a, "income".equals(type) ? "incomeCategories" : "expenseCategories", id);
                if (Money.obj("categoryBudgets").has(id)) Repo.del(a, "categoryBudgets", id);
                paintCatList(a, list);
                a.refreshCurrent();
            }
        });
    }

    // ---------- 固定扣款 ----------

    private static String recFreq = "monthly";

    static void openRecurring(final MainActivity a) {
        final List<JSONObject> accs = accounts();
        if (accs.isEmpty()) { a.flash("還沒有帳戶"); return; }
        final List<JSONObject> exCats = cats("expense");
        if (exCats.isEmpty()) { a.flash("還沒有支出分類"); return; }
        recFreq = "monthly";
        final Modal.Sheet s = Modal.sheet(a);
        s.box.addView(title(a, "新增固定扣款"));
        final EditText name = Ui.input(a, "例如：房租、手機費", "");
        s.box.addView(Ui.field(a, "名稱", name));
        final EditText amount = Ui.numberInput(a, "0", "", true);
        s.box.addView(Ui.field(a, "金額", amount));
        final LinearLayout monthField = Ui.col(a), weekField = Ui.col(a);
        s.box.addView(Ui.field(a, "週期", miniTabs(a, new String[]{"每月", "每週"}, 0, 13, 20, 9, new Ui.IntCb() {
            @Override public void on(int i) {
                recFreq = i == 0 ? "monthly" : "weekly";
                monthField.setVisibility(i == 0 ? View.VISIBLE : View.GONE);
                weekField.setVisibility(i == 0 ? View.GONE : View.VISIBLE);
            }
        })));
        final EditText dom = Ui.numberInput(a, "例如：5", "", false);
        monthField.addView(Ui.field(a, "每月幾號（超過當月天數時扣在月底）", dom));
        s.box.addView(monthField);
        final Drop wd = drop(a, "每週星期幾", new String[]{"週日", "週一", "週二", "週三", "週四", "週五", "週六"}, Calendar_dow(), null);
        weekField.addView(Ui.field(a, "每週星期幾", wd.view));
        weekField.setVisibility(View.GONE);
        s.box.addView(weekField);
        String[] catNames = new String[exCats.size()];
        for (int i = 0; i < catNames.length; i++) catNames[i] = Model.s(exCats.get(i), "name");
        final Drop cat = drop(a, "分類", catNames, 0, null);
        s.box.addView(Ui.field(a, "分類", cat.view));
        final Drop acc = drop(a, "扣款帳戶", accountNames(), 0, null);
        s.box.addView(Ui.field(a, "扣款帳戶", acc.view));
        final String[] startBox = {Model.today()};
        final TextView startText = Ui.tv(a, startBox[0], 13.5f, Ui.CARD_INK, false);
        startText.setPadding(Ui.dp(a, 14), Ui.dp(a, 10), Ui.dp(a, 14), Ui.dp(a, 10));
        startText.setBackground(Ui.shape(a, Ui.SURFACE, 14, Ui.BORDER, 1.5f));
        startText.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Modal.pickDate(a, startBox[0], new Modal.StrCb() {
                    @Override public void on(String d) { startBox[0] = d; startText.setText(d); }
                });
            }
        });
        s.box.addView(Ui.field(a, "開始日期（之前的日期不會補記）", startText));
        s.box.addView(actions(a, ghost(a, "取消", new Runnable() {
            @Override public void run() { s.dismiss(); }
        }), primary(a, "儲存", new Runnable() {
            @Override public void run() {
                String n = name.getText().toString().trim();
                double amt = Money.n0(amount.getText().toString().trim());
                if (n.isEmpty()) { a.flash("請輸入名稱"); return; }
                if (!(amt > 0)) { a.flash("請輸入金額"); return; }
                int day;
                if ("monthly".equals(recFreq)) {
                    day = (int) Math.floor(Money.n0(dom.getText().toString().trim()));
                    if (!(day >= 1 && day <= 31)) { a.flash("請輸入每月幾號（1~31）"); return; }
                } else {
                    day = wd.index;
                }
                JSONObject item = newObj();
                put(item, "id", Repo.newId());
                put(item, "name", n);
                put(item, "amount", Money.numObj(amt));
                put(item, "freq", recFreq);
                put(item, "day", day);
                put(item, "category", Model.s(exCats.get(cat.index), "id"));
                put(item, "accountId", Model.s(accs.get(acc.index), "id"));
                put(item, "startDate", startBox[0].isEmpty() ? Model.today() : startBox[0]);
                put(item, "lastRun", "");
                Repo.add(a, item, -1, "recurring");
                s.dismiss();
                a.refreshCurrent();
                a.flash("已新增固定扣款");
            }
        })));
        s.dialog.show();
    }

    private static int Calendar_dow() { return java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK) - 1; }

    // ---------- 薪資設定 ----------

    static void openPayroll(final MainActivity a) {
        final Modal.Sheet s = Modal.sheet(a);
        final JSONObject p = Money.payroll();
        s.box.addView(title(a, "薪資試算設定"));

        final EditText base = Ui.numberInput(a, "0", numStr(Money.d(p, "baseSalary")), true);
        s.box.addView(Ui.field(a, "底薪", base));
        final EditText day = Ui.numberInput(a, "例如：5", numStr(Money.d(p, "salaryDay")), false);
        s.box.addView(Ui.field(a, "每月發薪日", day));
        s.box.addView(Ui.field(a, "薪資發放月份（這個月的薪水在哪個月發）", miniTabs(a, new String[]{"當月發", "次月發"},
                (int) Money.n0(p.opt("payMonthOffset")) == 1 ? 1 : 0, 13, 20, 9, new Ui.IntCb() {
                    @Override public void on(int i) {
                        Repo.patch(a, put(newObj(), "payMonthOffset", i), null, "payroll");
                        a.refreshCurrent();
                    }
                })));
        List<JSONObject> accs = accounts();
        final Drop payAcc = drop(a, "薪資入帳帳戶", accountNames(), accountIndex(Money.salaryAccountId()), null);
        if (!accs.isEmpty()) s.box.addView(Ui.field(a, "薪資入帳帳戶", payAcc.view));
        final EditText dep = Ui.numberInput(a, "0", numStr(Money.d(p, "healthDependents")), false);
        s.box.addView(Ui.field(a, "健保眷屬人數（0~3，超過 3 人以 3 人計）", dep));
        final EditText labor = Ui.numberInput(a, "0", numStr(Money.d(p, "laborFee")), true);
        final TextView laborHint = Ui.hint(a, "");
        LinearLayout lf = Ui.field(a, "勞保每月自付金額（依底薪級距自動帶入，可自行修改）", labor);
        lf.addView(laborHint);
        s.box.addView(lf);
        final EditText health = Ui.numberInput(a, "0", numStr(Money.d(p, "healthFee")), true);
        final TextView healthHint = Ui.hint(a, "");
        LinearLayout hf = Ui.field(a, "健保每月自付金額（依底薪級距自動帶入，可自行修改）", health);
        hf.addView(healthHint);
        s.box.addView(hf);
        final EditText pension = Ui.numberInput(a, "0", numStr(Money.d(p, "pensionSelfRate")), true);
        s.box.addView(Ui.field(a, "勞退自提（%，0 代表不自提，可填 1~6）", pension));

        final Runnable hints = new Runnable() {
            @Override public void run() {
                double sal = Money.n0(base.getText().toString().trim()), dp = Money.n0(dep.getText().toString().trim());
                long[] lb = Money.laborFee(sal), hl = Money.healthFee(sal, dp);
                laborHint.setText(lb[0] > 0 ? "勞保投保薪資級距 " + Money.num(lb[0]) + " 元" : "");
                healthHint.setText(hl[0] > 0 ? "健保投保金額級距 " + Money.num(hl[0]) + " 元，每人 " + Money.num(hl[1]) + " 元 × " + hl[2] + " 人" : "");
            }
        };
        hints.run();
        TextWatcher auto = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence x, int q, int w, int e) { }
            @Override public void onTextChanged(CharSequence x, int q, int w, int e) { }
            @Override public void afterTextChanged(Editable ed) {
                double sal = Money.n0(base.getText().toString().trim()), dp = Money.n0(dep.getText().toString().trim());
                long lf2 = Money.laborFee(sal)[1], hf2 = Money.healthFee(sal, dp)[3];
                labor.setText(lf2 > 0 ? String.valueOf(lf2) : "");
                health.setText(hf2 > 0 ? String.valueOf(hf2) : "");
                hints.run();
            }
        };
        base.addTextChangedListener(auto);
        dep.addTextChangedListener(auto);

        s.box.addView(Ui.field(a, "請假扣薪計算基準（每日薪資 = 底薪 ÷ 此基準）", miniTabs(a, new String[]{"工作天", "當月天數"},
                "workdays".equals(Model.s(p, "leaveDivisor")) ? 0 : 1, 13, 20, 9, new Ui.IntCb() {
                    @Override public void on(int i) {
                        Repo.patch(a, put(newObj(), "leaveDivisor", i == 0 ? "workdays" : "monthdays"), null, "payroll");
                        a.refreshCurrent();
                    }
                })));

        final EditText pFixed = Ui.numberInput(a, "固定扣款金額（每天）", numStr(Money.d(p.optJSONObject("personalRule"), "fixedAmount")), true);
        final EditText sFixed = Ui.numberInput(a, "固定扣款金額（每天）", numStr(Money.d(p.optJSONObject("sickRule"), "fixedAmount")), true);
        s.box.addView(ruleField(a, "事假扣薪方式", "personalRule", p.optJSONObject("personalRule"), pFixed));
        s.box.addView(ruleField(a, "病假扣薪方式", "sickRule", p.optJSONObject("sickRule"), sFixed));

        // 自訂加項 / 扣款
        final LinearLayout addList = Ui.col(a), dedList = Ui.col(a);
        s.box.addView(listField(a, "自訂加項（每月固定加給，例如全勤獎金、津貼）", "additions", addList, "+"));
        s.box.addView(listField(a, "自訂扣款項目（每月固定扣除）", "deductions", dedList, ""));

        s.box.addView(actions(a, ghost(a, "關閉", new Runnable() {
            @Override public void run() { s.dismiss(); }
        }), primary(a, "儲存", new Runnable() {
            @Override public void run() {
                JSONObject set = newObj();
                put(set, "baseSalary", Money.numObj(Money.n0(base.getText().toString().trim())));
                double sd = Money.n0(day.getText().toString().trim());
                if (sd == 0) sd = 1;
                put(set, "salaryDay", Money.numObj(Math.min(Math.max(sd, 1), 31)));
                put(set, "laborFee", Money.numObj(Money.n0(labor.getText().toString().trim())));
                put(set, "healthFee", Money.numObj(Money.n0(health.getText().toString().trim())));
                put(set, "healthDependents", Money.numObj(Math.min(Math.max(Math.floor(Money.n0(dep.getText().toString().trim())), 0), 3)));
                put(set, "pensionSelfRate", Money.numObj(Math.min(Math.max(Money.n0(pension.getText().toString().trim()), 0), 6)));
                List<JSONObject> as = accounts();
                put(set, "accountId", as.isEmpty() ? JSONObject.NULL : Model.s(as.get(payAcc.index), "id"));
                Repo.patch(a, set, null, "payroll");
                Repo.patch(a, put(newObj(), "fixedAmount", Money.numObj(Money.n0(pFixed.getText().toString().trim()))), null, "payroll", "personalRule");
                Repo.patch(a, put(newObj(), "fixedAmount", Money.numObj(Money.n0(sFixed.getText().toString().trim()))), null, "payroll", "sickRule");
                s.dismiss();
                a.refreshCurrent();
                a.flash("薪資設定已儲存");
            }
        })));
        paintPayItems(a, "additions", addList, "+");
        paintPayItems(a, "deductions", dedList, "");
        s.dialog.show();
    }

    private static String numStr(double v) {
        if (v == 0) return "";
        return v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v);
    }

    private static View ruleField(final MainActivity a, String label, final String key, JSONObject rule, final EditText fixed) {
        String t = Model.s(rule, "type", "halfpay");
        int sel = "fullpay".equals(t) ? 0 : "halfpay".equals(t) ? 1 : 2;
        LinearLayout box = Ui.col(a);
        box.addView(miniTabs(a, new String[]{"全薪", "半薪", "固定金額/天"}, sel, 13, 14, 9, new Ui.IntCb() {
            @Override public void on(int i) {
                Repo.patch(a, put(newObj(), "type", i == 0 ? "fullpay" : i == 1 ? "halfpay" : "fixed"), null, "payroll", key);
                fixed.setVisibility(i == 2 ? View.VISIBLE : View.GONE);
                a.refreshCurrent();
            }
        }));
        box.addView(fixed, Ui.mw(a, 8));
        fixed.setVisibility(sel == 2 ? View.VISIBLE : View.GONE);
        return Ui.field(a, label, box);
    }

    private static View listField(final MainActivity a, String label, final String key, final LinearLayout list, final String sign) {
        LinearLayout box = Ui.col(a);
        box.addView(list);
        LinearLayout r = Ui.row(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        final EditText nm = Ui.input(a, "項目名稱", "");
        final EditText amt = Ui.numberInput(a, "金額", "", true);
        r.addView(nm, Ui.weight(1));
        r.addView(amt, new LinearLayout.LayoutParams(Ui.dp(a, 90), -2));
        Ui.lp(amt).leftMargin = Ui.dp(a, 8);
        r.addView(Ui.btnGhost(a, "新增", new View.OnClickListener() {
            @Override public void onClick(View v) {
                String n = nm.getText().toString().trim();
                double x = Money.n0(amt.getText().toString().trim());
                if (n.isEmpty() || x == 0) { a.flash("請輸入項目名稱與金額"); return; }
                JSONObject item = newObj();
                put(item, "id", Repo.newId());
                put(item, "name", n);
                put(item, "amount", Money.numObj(x));
                Repo.add(a, item, -1, "payroll", key);
                nm.setText("");
                amt.setText("");
                paintPayItems(a, key, list, sign);
                a.refreshCurrent();
            }
        }), Ui.gap(a, 8));
        box.addView(r, Ui.mw(a, 8));
        return Ui.field(a, label, box);
    }

    private static void paintPayItems(final MainActivity a, final String key, final LinearLayout list, final String sign) {
        list.removeAllViews();
        JSONArray arr = Money.payroll().optJSONArray(key);
        if (arr == null) return;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject d = arr.optJSONObject(i);
            if (d == null) continue;
            final String id = Model.s(d, "id");
            list.addView(itemRow(a, Model.s(d, "name") + "　" + sign + "$" + Money.num(Money.n0(d.opt("amount"))), null, new Runnable() {
                @Override public void run() {
                    Repo.del(a, "payroll", key, id);
                    paintPayItems(a, key, list, sign);
                    a.refreshCurrent();
                }
            }), Ui.mw(a, 6));
        }
    }

    // ---------- 薪資明細(單筆) ----------

    private static final class Sd {
        String id, key;
        final List<String[]> adds = new ArrayList<>();    // {id, name}
        final List<Double> addAmt = new ArrayList<>();
        final List<String[]> items = new ArrayList<>();
        final List<Double> itemAmt = new ArrayList<>();
    }

    static void openSalaryDetail(final MainActivity a, String expenseId) {
        JSONObject found = null;
        for (JSONObject e : Money.list("expenses")) if (Model.s(e, "id").equals(expenseId)) found = e;
        if (found == null || !Money.isSalaryEntry(found)) return;
        final JSONObject e = found;
        final Sd sd = new Sd();
        sd.id = expenseId;
        sd.key = Money.salaryEntryKeyLoose(e);
        final Modal.Sheet s = Modal.sheet(a);
        s.box.addView(title(a, Integer.parseInt(sd.key.substring(5)) + "月薪資明細"));
        JSONObject dtSrc;
        try {
            dtSrc = e.optJSONObject("salaryDetail") != null ? e.optJSONObject("salaryDetail") : Money.defaultDetail(sd.key, Money.d(e, "amount"));
        } catch (JSONException ex) { return; }
        String date = Model.s(e, "date");
        s.box.addView(Ui.hint(a, date.substring(5).replace('-', '/') + " 入帳・" + Money.accountName(Model.s(e, "accountId")) + "・目前 " + Money.fmt(Money.d(e, "amount"))
                + (e.optJSONObject("salaryDetail") != null ? "" : "（這筆原本沒有明細，先依目前的薪資設定帶入）")));

        final EditText fBase = amtRow(a, s.box, "底薪", dtSrc.optDouble("base", 0));
        s.box.addView(sec(a, "加項（獎金、津貼等）"));
        final LinearLayout addsBox = Ui.col(a);
        s.box.addView(addsBox);
        final TextView net = Ui.tv(a, "", 19, Ui.CARD_INK, true);
        final Runnable[] repaint = new Runnable[1];
        final EditText[] fixed = new EditText[5];
        final String[] fixedLabels = {"勞保", "健保", "勞退自提", "事假扣款", "病假扣款"};
        final String[] fixedKeys = {"labor", "health", "pension", "personal", "sick"};
        final LinearLayout itemsBox = Ui.col(a);

        // 載入現有加項/扣款
        loadNamed(dtSrc.optJSONArray("additions"), sd.adds, sd.addAmt);
        loadNamed(dtSrc.optJSONArray("items"), sd.items, sd.itemAmt);

        final Runnable updateNet = new Runnable() {
            @Override public void run() {
                net.setText(Money.fmt(readNet(fBase, fixed, sd)));
            }
        };
        final Runnable paintLists = new Runnable() {
            @Override public void run() {
                paintSdList(a, addsBox, sd.adds, sd.addAmt, updateNetRef);
                paintSdList(a, itemsBox, sd.items, sd.itemAmt, updateNetRef);
                updateNetRef.run();
            }
        };
        updateNetRef = updateNet;
        repaintRef = paintLists;

        // 新增加項
        s.box.addView(addRow(a, "加項名稱", new NamedAdd() {
            @Override public void add(String name, double amt) {
                sd.adds.add(new String[]{Repo.newId(), name});
                sd.addAmt.add(amt);
                paintLists.run();
            }
        }));
        s.box.addView(sec(a, "扣款"));
        for (int i = 0; i < 5; i++) fixed[i] = amtRow(a, s.box, fixedLabels[i], dtSrc.optDouble(fixedKeys[i], 0));
        s.box.addView(itemsBox);
        s.box.addView(addRow(a, "其他扣款名稱", new NamedAdd() {
            @Override public void add(String name, double amt) {
                sd.items.add(new String[]{Repo.newId(), name});
                sd.itemAmt.add(amt);
                paintLists.run();
            }
        }));
        final TextWatcher tw = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence x, int q, int w, int r) { }
            @Override public void onTextChanged(CharSequence x, int q, int w, int r) { }
            @Override public void afterTextChanged(Editable ed) { updateNet.run(); }
        };
        fBase.addTextChangedListener(tw);
        for (EditText f : fixed) f.addTextChangedListener(tw);

        LinearLayout netRow = Ui.row(a);
        netRow.setGravity(Gravity.CENTER_VERTICAL);
        netRow.setPadding(0, Ui.dp(a, 12), 0, 0);
        netRow.addView(Ui.tv(a, "實領　", 14, Ui.CARD_INK, false));
        netRow.addView(net);
        s.box.addView(netRow, Ui.mw(a, 14));
        paintLists.run();

        s.box.addView(actions(a, ghost(a, "依設定重算", new Runnable() {
            @Override public void run() {
                try {
                    JSONObject dt = Money.defaultDetail(sd.key, Money.d(e, "amount"));
                    fBase.setText(numStr(dt.optDouble("base", 0)));
                    for (int i = 0; i < 5; i++) fixed[i].setText(numStr(dt.optDouble(fixedKeys[i], 0)));
                    sd.adds.clear(); sd.addAmt.clear(); sd.items.clear(); sd.itemAmt.clear();
                    loadNamed(dt.optJSONArray("additions"), sd.adds, sd.addAmt);
                    loadNamed(dt.optJSONArray("items"), sd.items, sd.itemAmt);
                    paintLists.run();
                    a.flash("已依目前的薪資設定與該月請假重新帶入，記得按儲存");
                } catch (JSONException ex) { /* 忽略 */ }
            }
        }), ghost(a, "取消", new Runnable() {
            @Override public void run() { s.dismiss(); }
        }), primary(a, "儲存", new Runnable() {
            @Override public void run() {
                JSONObject dt = readDetail(fBase, fixed, fixedKeys, sd);
                double netV = Math.round(Money.detailNet(dt) * 100) / 100.0;
                if (netV < 0) { a.flash("實領金額不能是負的，請檢查各項扣款"); return; }
                JSONObject set = newObj();
                put(set, "salaryDetail", dt);
                put(set, "amount", Money.numObj(netV));
                if (Model.s(e, "salaryMonth").isEmpty()) put(set, "salaryMonth", sd.key);
                Repo.patch(a, set, null, "expenses", sd.id);
                Repo.set(a, true, "salaryRecorded", sd.key);
                s.dismiss();
                a.refreshCurrent();
                a.flash("已更新這筆薪水：" + Money.fmt(netV));
            }
        })));
        s.dialog.show();
    }

    private static Runnable updateNetRef, repaintRef;

    private interface NamedAdd { void add(String name, double amt); }

    private static void loadNamed(JSONArray src, List<String[]> names, List<Double> amts) {
        if (src == null) return;
        for (int i = 0; i < src.length(); i++) {
            JSONObject o = src.optJSONObject(i);
            if (o == null) continue;
            names.add(new String[]{Repo.newId(), Model.s(o, "name")});
            amts.add(Money.n0(o.opt("amount")));
        }
    }

    private static TextView sec(MainActivity a, String t) {
        TextView v = Ui.tv(a, t, 12, Ui.SOFT, true);
        v.setPadding(0, Ui.dp(a, 12), 0, Ui.dp(a, 6));
        return v;
    }

    private static EditText amtRow(MainActivity a, LinearLayout box, String label, double v) {
        LinearLayout row = Ui.row(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(Ui.tv(a, label, 13, Ui.CARD_INK, false), Ui.weight(1));
        EditText e = Ui.numberInput(a, "", numStr(v), true);
        e.setGravity(Gravity.END);
        row.addView(e, new LinearLayout.LayoutParams(Ui.dp(a, 120), -2));
        row.addView(new View(a), new LinearLayout.LayoutParams(Ui.dp(a, 22), 1));
        box.addView(row, Ui.mw(a, 8));
        return e;
    }

    private static View addRow(final MainActivity a, String hint, final NamedAdd cb) {
        LinearLayout r = Ui.row(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        final EditText nm = Ui.input(a, hint, "");
        final EditText amt = Ui.numberInput(a, "金額", "", true);
        r.addView(nm, Ui.weight(1));
        r.addView(amt, new LinearLayout.LayoutParams(Ui.dp(a, 80), -2));
        Ui.lp(amt).leftMargin = Ui.dp(a, 8);
        r.addView(Ui.btnGhost(a, "新增", new View.OnClickListener() {
            @Override public void onClick(View v) {
                String n = nm.getText().toString().trim();
                double x = Money.n0(amt.getText().toString().trim());
                if (n.isEmpty() || x == 0) { a.flash("請輸入項目名稱與金額"); return; }
                cb.add(n, x);
                nm.setText("");
                amt.setText("");
            }
        }), Ui.gap(a, 8));
        r.setLayoutParams(Ui.mw(a, 6));
        return r;
    }

    private static void paintSdList(final MainActivity a, LinearLayout box, final List<String[]> names, final List<Double> amts, final Runnable onChange) {
        box.removeAllViews();
        for (int i = 0; i < names.size(); i++) {
            final int idx = i;
            LinearLayout row = Ui.row(a);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(Ui.tv(a, names.get(i)[1], 13, Ui.CARD_INK, false), Ui.weight(1));
            EditText e = Ui.numberInput(a, "", numStr(amts.get(i)), true);
            e.setGravity(Gravity.END);
            e.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence x, int q, int w, int r) { }
                @Override public void onTextChanged(CharSequence x, int q, int w, int r) { }
                @Override public void afterTextChanged(Editable ed) {
                    if (idx < amts.size()) amts.set(idx, Money.n0(ed.toString().trim()));
                    onChange.run();
                }
            });
            row.addView(e, new LinearLayout.LayoutParams(Ui.dp(a, 120), -2));
            TextView x = Ui.tv(a, "×", 15, Ui.DANGER, false);
            x.setGravity(Gravity.CENTER);
            x.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    names.remove(idx);
                    amts.remove(idx);
                    if (repaintRef != null) repaintRef.run();
                }
            });
            row.addView(x, new LinearLayout.LayoutParams(Ui.dp(a, 22), -2));
            box.addView(row, Ui.mw(a, 8));
        }
    }

    private static JSONObject readDetail(EditText base, EditText[] fixed, String[] keys, Sd sd) {
        JSONObject r = newObj();
        put(r, "base", Money.numObj(Money.n0(base.getText().toString().trim())));
        for (int i = 0; i < keys.length; i++) put(r, keys[i], Money.numObj(Money.n0(fixed[i].getText().toString().trim())));
        put(r, "additions", named(sd.adds, sd.addAmt));
        put(r, "items", named(sd.items, sd.itemAmt));
        return r;
    }

    private static JSONArray named(List<String[]> names, List<Double> amts) {
        JSONArray a = new JSONArray();
        for (int i = 0; i < names.size(); i++) a.put(put(put(newObj(), "name", names.get(i)[1]), "amount", Money.numObj(amts.get(i))));
        return a;
    }

    private static double readNet(EditText base, EditText[] fixed, Sd sd) {
        String[] keys = {"labor", "health", "pension", "personal", "sick"};
        return Money.detailNet(readDetail(base, fixed, keys, sd));
    }
}
