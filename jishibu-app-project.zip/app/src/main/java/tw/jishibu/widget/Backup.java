package tw.jishibu.widget;

import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.zip.GZIPInputStream;

/**
 * 資料量統計與匯出備份檔(網頁版 renderDataInfo / exportBackup)。
 * 這裡全部是「只讀」:不會改到手機或雲端上的資料。
 */
final class Backup {
    private Backup() {}

    static final int WARN_BYTES = 700 * 1024, DANGER_BYTES = 900 * 1024, BLOCK_BYTES = 1000 * 1024;

    static int utf8(String s) {
        try { return s.getBytes("UTF-8").length; } catch (Exception e) { return s.length() * 3; }
    }

    static final class Info {
        int bytes;
        List<String> archiveYears = new ArrayList<>();
        String topParts = "";
    }

    /** 目前整份資料的大小(就是雲端文件的大小)和占最多的幾項。 */
    static Info info(String dataJson) throws Exception {
        JSONObject d = new JSONObject(dataJson);
        Info r = new Info();
        r.bytes = utf8(dataJson);
        JSONObject arc = d.optJSONObject("archives");
        if (arc != null) {
            Iterator<String> it = arc.keys();
            List<String> ys = new ArrayList<>();
            while (it.hasNext()) ys.add(it.next());
            java.util.Collections.sort(ys);
            r.archiveYears = ys;
        }
        String[][] labels = {{"expenses", "記帳"}, {"habitLogs", "習慣打卡紀錄"}, {"tasks", "事項"}, {"quickNotes", "隨手記"}, {"dayRecaps", "每日回顧"}};
        int[] n = new int[labels.length];
        int total = 0;
        for (int i = 0; i < labels.length; i++) {
            Object v = d.opt(labels[i][0]);
            n[i] = v == null ? 0 : utf8(String.valueOf(v));
            total += n[i];
        }
        if (total == 0) total = 1;
        // 由大到小排,只列占 1% 以上的前三名
        Integer[] order = {0, 1, 2, 3, 4};
        final int[] nn = n;
        java.util.Arrays.sort(order, new java.util.Comparator<Integer>() {
            @Override public int compare(Integer x, Integer y) { return nn[y] - nn[x]; }
        });
        StringBuilder sb = new StringBuilder();
        int shown = 0;
        for (int k = 0; k < order.length && shown < 3; k++) {
            int i = order[k];
            if (n[i] <= 0) continue;
            int pct = Math.round(n[i] * 100f / total);
            if (pct < 1) continue;
            if (sb.length() > 0) sb.append("、");
            sb.append(labels[i][1]).append(' ').append(pct).append('%');
            shown++;
        }
        r.topParts = sb.toString();
        return r;
    }

    /**
     * 備份檔內容。網頁版匯出的是「完整展開」的資料,所以這裡把收納(archives)的舊資料解開併進去再匯出,
     * 檔案格式跟網頁版一樣({app, schemaVersion, exportedAt, email, data}),網頁版可以直接還原。
     * 原本手機上的資料不會被改到(在複本上處理)。解不開收納檔就丟出錯誤,不會產生缺一塊的備份。
     */
    static String exportJson(String dataJson, String email) throws Exception {
        JSONObject copy = new JSONObject(dataJson);
        inflate(copy);
        JSONObject payload = new JSONObject();
        payload.put("app", "jishibu");
        payload.put("schemaVersion", Repo.SCHEMA);
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        payload.put("exportedAt", f.format(new Date()));
        payload.put("email", email == null || email.isEmpty() ? JSONObject.NULL : email);
        payload.put("data", copy);
        return payload.toString();
    }

    static String fileName() { return "記事簿備份-" + Model.today() + ".json"; }

    private static String gunzip(String b64) throws Exception {
        byte[] raw = Base64.decode(b64, Base64.DEFAULT);
        GZIPInputStream in = new GZIPInputStream(new ByteArrayInputStream(raw));
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    /** 網頁版 inflateArchives:把壓縮檔裡的舊資料併回主資料(只補「缺的」,不蓋掉現有的)。 */
    private static void inflate(JSONObject obj) throws Exception {
        JSONObject arc = obj.optJSONObject("archives");
        if (arc == null) { obj.remove("archives"); return; }
        Iterator<String> it = arc.keys();
        while (it.hasNext()) {
            String y = it.next();
            JSONObject ch = new JSONObject(gunzip(arc.getString(y)));
            JSONObject hl = ch.optJSONObject("habitLogs");
            if (hl != null) {
                JSONObject logs = obj.optJSONObject("habitLogs");
                if (logs == null) { logs = new JSONObject(); obj.put("habitLogs", logs); }
                Iterator<String> hi = hl.keys();
                while (hi.hasNext()) {
                    String hid = hi.next();
                    JSONObject dst = logs.optJSONObject(hid);
                    if (dst == null) { dst = new JSONObject(); logs.put(hid, dst); }
                    JSONObject src = hl.getJSONObject(hid);
                    Iterator<String> di = src.keys();
                    while (di.hasNext()) {
                        String day = di.next();
                        if (!dst.has(day)) dst.put(day, src.get(day));
                    }
                }
            }
            JSONArray ex = ch.optJSONArray("expenses");
            if (ex != null) {
                JSONArray cur = obj.optJSONArray("expenses");
                if (cur == null) cur = new JSONArray();
                Set<String> have = new HashSet<>();
                for (int i = 0; i < cur.length(); i++) {
                    JSONObject e = cur.optJSONObject(i);
                    if (e != null) have.add(Model.s(e, "id"));
                }
                JSONArray out = new JSONArray();
                for (int i = 0; i < ex.length(); i++) {
                    JSONObject e = ex.optJSONObject(i);
                    if (e != null && !have.contains(Model.s(e, "id"))) out.put(e);
                }
                for (int i = 0; i < cur.length(); i++) out.put(cur.get(i));
                obj.put("expenses", out);
            }
            JSONObject dr = ch.optJSONObject("dayRecaps");
            if (dr != null) {
                JSONObject cur = obj.optJSONObject("dayRecaps");
                if (cur == null) { cur = new JSONObject(); obj.put("dayRecaps", cur); }
                Iterator<String> ki = dr.keys();
                while (ki.hasNext()) {
                    String k = ki.next();
                    if (!cur.has(k)) cur.put(k, dr.get(k));
                }
            }
        }
        obj.remove("archives");
    }
}
