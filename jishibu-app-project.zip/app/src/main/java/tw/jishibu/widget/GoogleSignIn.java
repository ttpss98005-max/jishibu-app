package tw.jishibu.widget;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import java.util.concurrent.Executor;

/** 原生 Google 登入:跳出系統的帳號選擇器,拿到 Google 的 ID token(跟網頁版同一個 Google 用戶端)。 */
final class GoogleSignIn {
    private GoogleSignIn() {}

    /** 跟網頁版登入用的是同一個網路用戶端 ID(不是祕密,本來就寫在網頁裡)。 */
    static final String WEB_CLIENT_ID = "826476371547-f1omvto42ta1s5t7knkph573a74cm89i.apps.googleusercontent.com";

    static final String PACKAGE = "tw.jishibu.widget";
    /** 這支 App 固定用的簽章(Firebase 專案要登錄這一個,Google 登入才會通)。 */
    static final String SHA1 = "1A:FA:F2:E8:3E:5B:AD:AD:27:C4:95:F8:12:14:EF:DB:AC:87:AD:D4";

    interface Done {
        void ok(String idToken);
        /** message 是簡短說明;detail 不是 null 時,要跳出視窗說明原因和該怎麼辦。 */
        void fail(String message, String detail);
    }

    private static final String SETUP_HELP =
            "最常見的原因是:Firebase 專案還沒登錄這支 App。請到 Firebase 控制台 → 專案設定(齒輪)→ 你的應用程式 → 新增 Android 應用程式,"
            + "填入下面的套件名稱和 SHA-1,按「註冊應用程式」(後面的步驟都可以略過)。完成後等 5 分鐘再回來試一次。";

    static void start(Activity a, final Done cb) {
        final long t0 = System.currentTimeMillis();
        final Handler main = new Handler(Looper.getMainLooper());
        Executor ex = new Executor() {
            @Override public void execute(Runnable r) { main.post(r); }
        };
        try {
            CredentialManager cm = CredentialManager.create(a);
            GetSignInWithGoogleOption opt = new GetSignInWithGoogleOption.Builder(WEB_CLIENT_ID).build();
            GetCredentialRequest req = new GetCredentialRequest.Builder().addCredentialOption(opt).build();
            cm.getCredentialAsync(a, req, null, ex, new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                @Override public void onResult(GetCredentialResponse r) {
                    try {
                        Credential c = r.getCredential();
                        if (c instanceof CustomCredential
                                && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(c.getType())) {
                            GoogleIdTokenCredential g = GoogleIdTokenCredential.createFrom(((CustomCredential) c).getData());
                            cb.ok(g.getIdToken());
                        } else {
                            cb.fail("沒有拿到 Google 帳號資料", null);
                        }
                    } catch (Exception e) {
                        cb.fail("Google 登入資料解析失敗", String.valueOf(e.getMessage()));
                    }
                }

                @Override public void onError(GetCredentialException e) {
                    long took = System.currentTimeMillis() - t0;
                    if (e instanceof GetCredentialCancellationException) {
                        // 使用者真的按取消通常要好幾秒;一兩秒內就「被取消」,幾乎都是 Firebase 還沒登錄這支 App
                        if (took < 4000) cb.fail("Google 登入被中斷", "登入視窗很快就被關掉了。" + SETUP_HELP);
                        else cb.fail("已取消登入", null);
                    } else {
                        cb.fail("Google 登入失敗", "錯誤:" + e.getType() + "\n" + e.getMessage() + "\n\n"
                                + "請確認手機有登入 Google 帳號且網路正常。" + SETUP_HELP);
                    }
                }
            });
        } catch (Throwable t) {
            cb.fail("無法開啟 Google 登入", String.valueOf(t.getMessage()));
        }
    }
}
