package tw.jishibu.widget;

import android.graphics.Color;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 配色。跟網頁版一樣:20 組內建配色 + 自訂配色;各分類可以指定自己的配色,沒指定就跟整體。 */
final class Theme {
    private Theme() {}

    static final class Palette {
        final String id, name;
        final int bg, ink, accent;
        Palette(String id, String name, String bg, String ink, String accent) {
            this.id = id; this.name = name;
            this.bg = parse(bg); this.ink = parse(ink); this.accent = parse(accent);
        }
    }

    static int parse(String hex) {
        try { return Color.parseColor(hex); } catch (Exception e) { return 0xFF3A6B5E; }
    }

    static final Palette[] PRESETS = {
        new Palette("p01", "簡約白", "#FAFAFA", "#1A1A1A", "#3A6B5E"),
        new Palette("p02", "深夜黑", "#121212", "#EDEDED", "#D9A441"),
        new Palette("p03", "森林綠", "#F1F5F0", "#20302A", "#3F7C4A"),
        new Palette("p04", "海洋藍", "#EEF3F7", "#152B3D", "#2E6F9E"),
        new Palette("p05", "珊瑚粉", "#FDF1EF", "#3A2420", "#E0685A"),
        new Palette("p06", "薰衣草紫", "#F5F1F9", "#2E2438", "#8B6BB5"),
        new Palette("p07", "陽光橘", "#FFF6EA", "#3A2A12", "#E08A2C"),
        new Palette("p08", "莫蘭迪灰", "#F0EFEC", "#33312E", "#9A8F80"),
        new Palette("p09", "櫻花粉", "#FFF2F5", "#3A222A", "#D96C8C"),
        new Palette("p10", "竹林綠", "#F3F7F0", "#233022", "#6FA05A"),
        new Palette("p11", "咖啡棕", "#F7F1EA", "#2E2018", "#8A5A34"),
        new Palette("p12", "天空藍", "#EEF7FB", "#183440", "#3EA0C9"),
        new Palette("p13", "焦糖橘", "#FDF3E7", "#3A2410", "#C97A2E"),
        new Palette("p14", "靛藍夜", "#171C2E", "#E4E7F0", "#5C7CD9"),
        new Palette("p15", "薄荷綠", "#EEFAF5", "#173A2C", "#33A87A"),
        new Palette("p16", "玫瑰金", "#FBF0EE", "#3A2420", "#C98A7A"),
        new Palette("p17", "石墨黑", "#1A1A1E", "#E8E8EA", "#7A8CA3"),
        new Palette("p18", "奶油黃", "#FDF8E8", "#3A3418", "#C9A227"),
        new Palette("p19", "紫紅酒", "#F7EEF1", "#331C22", "#8F2E4A"),
        new Palette("p20", "極光藍綠", "#0F1E24", "#DCEFEF", "#3ECFC0"),
    };

    /** 內建 + 這份資料裡的自訂配色。 */
    static List<Palette> all() {
        List<Palette> r = new ArrayList<>();
        for (Palette p : PRESETS) r.add(p);
        JSONObject d = Repo.data();
        JSONArray cs = d == null ? null : d.optJSONArray("customPalettes");
        if (cs != null) {
            for (int i = 0; i < cs.length(); i++) {
                JSONObject o = cs.optJSONObject(i);
                if (o == null) continue;
                r.add(new Palette(Model.s(o, "id"), Model.s(o, "name", "自訂"), Model.s(o, "bg", "#FAFAFA"), Model.s(o, "ink", "#1A1A1A"), Model.s(o, "accent", "#3A6B5E")));
            }
        }
        return r;
    }

    static Palette byId(String id) {
        if (id == null || id.isEmpty()) return null;
        for (Palette p : all()) if (p.id.equals(id)) return p;
        return null;
    }

    /** 目前該用的配色:選了某個分類且那個分類有專屬配色就用它,否則用整體配色。catId 是 "overview" 代表總覽。 */
    static Palette effective(String catId) {
        Palette p = null;
        JSONObject d = Repo.data();
        if (d != null) {
            if (catId != null && !"overview".equals(catId)) {
                JSONObject c = Model.category(catId);
                if (c != null) p = byId(Model.s(c, "paletteId", ""));
            }
            if (p == null) p = byId(Model.s(d, "globalPaletteId", "p01"));
        }
        return p == null ? PRESETS[0] : p;
    }

    /** 套用配色到 Ui 的顏色。 */
    static void apply(Palette p) {
        Ui.BG = p.bg;
        Ui.INK = p.ink;
        Ui.ACCENT = p.accent;
        Ui.ACCENT_SOFT = blend(p.bg, p.accent, 0x22 / 255f);
        double lum = (0.2126 * Color.red(p.bg) + 0.7152 * Color.green(p.bg) + 0.0722 * Color.blue(p.bg)) / 255.0;
        Ui.SOFT = lum < 0.4 ? 0xFF7B7B7B : 0xFF6B6B6B;
        Ui.SURFACE = 0xFFFFFFFF;
        Ui.CARD_INK = 0xFF1A1A1A;
        Ui.BORDER = 0xFFE4E4E4;
        Ui.DANGER = 0xFFE0685A;
        Ui.CHIP_BG = 0xFFF1F0EA;
        Ui.TASK_BG = 0xFFFDFDFB;
    }

    /** a 疊上 b(透明度 t)後的不透明顏色。 */
    static int blend(int a, int b, float t) {
        int r = Math.round(Color.red(a) * (1 - t) + Color.red(b) * t);
        int g = Math.round(Color.green(a) * (1 - t) + Color.green(b) * t);
        int bl = Math.round(Color.blue(a) * (1 - t) + Color.blue(b) * t);
        return Color.rgb(r, g, bl);
    }
}
