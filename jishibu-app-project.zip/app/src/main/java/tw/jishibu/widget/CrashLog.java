package tw.jishibu.widget;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.View;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * 當機記錄:App 當機時把錯誤原因存下來,下次打開時顯示,可以一鍵複製貼給開發者。
 * 只存在手機裡,不會自己傳到任何地方。
 */
final class CrashLog {
    private CrashLog() {}

    private static File file(Context c) { return new File(c.getApplicationContext().getFilesDir(), "crash.txt"); }

    private static boolean installed;

    static synchronized void install(final Context c) {
        if (installed) return;
        installed = true;
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread t, Throwable e) {
                try {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    String txt = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(new java.util.Date())
                            + "  執行緒:" + t.getName() + "\n" + sw;
                    FileOutputStream out = new FileOutputStream(file(c));
                    out.write(txt.getBytes("UTF-8"));
                    out.close();
                } catch (Throwable ignore) { }
                if (prev != null) prev.uncaughtException(t, e);
            }
        });
    }

    /** 上次當機過就跳出視窗顯示原因。 */
    static void showIfAny(final Activity a) {
        final File f = file(a);
        if (!f.exists()) return;
        String txt;
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] buf = new byte[(int) Math.min(f.length(), 6000)];
            int n = in.read(buf);
            in.close();
            txt = new String(buf, 0, Math.max(n, 0), "UTF-8");
        } catch (Exception e) {
            f.delete();
            return;
        }
        final String shown = txt;
        android.widget.LinearLayout box = Ui.col(a);
        TextView msg = Ui.tv(a, "上次記事簿異常關閉了。資料沒有受影響(所有修改都有先存好)。\n請按「複製」,把內容貼給開發者,就能找到原因:", 13, Ui.SOFT, false);
        msg.setLineSpacing(0, 1.3f);
        box.addView(msg);
        TextView body = Ui.tv(a, shown, 10.5f, Ui.CARD_INK, false);
        body.setTextIsSelectable(true);
        body.setPadding(Ui.dp(a, 10), Ui.dp(a, 10), Ui.dp(a, 10), Ui.dp(a, 10));
        body.setBackground(Ui.shape(a, Ui.CHIP_BG, 10, 0, 0));
        box.addView(body, Ui.mw(a, 10));
        TextView copy = Ui.btnPrimary(a, "複製錯誤內容", new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("crash", shown));
                    Ui.toast(a, "已複製");
                } catch (Exception ignore) { }
            }
        });
        box.addView(copy, Ui.mw(a, 12));
        Modal.show(a, "上次當機的原因", box, null, null);
        f.delete();
    }
}
