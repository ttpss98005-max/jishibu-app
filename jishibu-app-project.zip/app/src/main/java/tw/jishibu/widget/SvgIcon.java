package tw.jishibu.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 把網頁版用的 SVG 圖示(24x24 的 path / rect / circle / line,線條風格)原樣畫出來。
 * 用法:new SvgIcon(context, "<path d='M5 3v5...'/><circle .../>", 21, 色碼)
 * 支援:path(M L H V C S Q T A Z 大小寫)、rect(rx)、circle、line、polyline、transform="rotate(a cx cy)"、
 *      fill="currentColor"(實心)、stroke="none"、fill="none"。
 */
final class SvgIcon extends View {
    private static final class Shape {
        Path path = new Path();
        boolean fill, stroke = true;
        int fillColor, strokeColor;   // 0 = 用整體顏色(currentColor)
        float width = -1f;   // -1 = 用整體預設
    }

    private final List<Shape> shapes = new ArrayList<>();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int color;
    private float strokeW = 1.8f;
    private final int sizePx;

    private float vb = 24f;   // viewBox 邊長(一般圖示 24,心情臉 40)

    private final boolean rootStroke;   // true: 整體是 fill=none stroke=currentColor(記帳分類圖示那種);false: 整體沒設定(底部導覽那種,預設填滿)

    /** 線條風格(整體 fill="none" stroke="currentColor"),線寬 1.8。 */
    SvgIcon(Context c, String inner, int sizeDp, int color) { this(c, inner, sizeDp, color, 1.8f, true); }

    /** rootStroke=false:整體沒設定樣式,每個元素自己寫 fill/stroke(底部導覽、搜尋、設定圖示)。 */
    SvgIcon(Context c, String inner, int sizeDp, int color, float strokeWidth, boolean rootStroke) {
        super(c);
        this.color = color;
        this.strokeW = strokeWidth;
        this.rootStroke = rootStroke;
        this.sizePx = Ui.dp(c, sizeDp);
        parse(inner);
        setMinimumWidth(sizePx);
        setMinimumHeight(sizePx);
    }

    void setColor(int c) { color = c; invalidate(); }

    /** viewBox 不是 24 的圖(例如 40x40 的心情臉)。元素可以自己指定 #RRGGBB 顏色。 */
    static SvgIcon withBox(Context c, String inner, int sizeDp, float viewBox) {
        SvgIcon i = new SvgIcon(c, inner, sizeDp, 0xFF000000, 1.8f, false);
        i.vb = viewBox;
        return i;
    }

    private static int colorOf(String v) {
        if (v == null || !v.startsWith("#")) return 0;
        try {
            String h = v.substring(1);
            if (h.length() == 3) h = "" + h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
            return 0xFF000000 | (int) Long.parseLong(h, 16);
        } catch (Exception e) {
            return 0;
        }
    }

    // ---------- 解析 ----------
    private static final Pattern TAG = Pattern.compile("<(path|rect|circle|line|polyline|polygon)\\b([^>]*?)/?>");
    private static final Pattern ATTR = Pattern.compile("([a-zA-Z-]+)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')");

    private void parse(String inner) {
        Matcher m = TAG.matcher(inner == null ? "" : inner);
        while (m.find()) {
            String tag = m.group(1);
            java.util.Map<String, String> at = new java.util.HashMap<>();
            Matcher am = ATTR.matcher(m.group(2));
            while (am.find()) at.put(am.group(1), am.group(2) != null ? am.group(2) : am.group(3));
            Shape s = new Shape();
            String fill = at.get("fill"), stroke = at.get("stroke");
            s.fill = fill != null ? ("currentColor".equals(fill) || fill.startsWith("#")) : !rootStroke;
            s.stroke = stroke != null ? !"none".equals(stroke) : rootStroke;
            s.fillColor = colorOf(fill);
            s.strokeColor = colorOf(stroke);
            if (at.containsKey("stroke-width")) s.width = num(at.get("stroke-width"));
            if ("path".equals(tag)) {
                pathData(s.path, at.get("d"));
            } else if ("rect".equals(tag)) {
                float x = num(at.get("x")), y = num(at.get("y")), w = num(at.get("width")), h = num(at.get("height"));
                float rx = num(at.get("rx")), ry = at.containsKey("ry") ? num(at.get("ry")) : rx;
                if (rx > 0 || ry > 0) s.path.addRoundRect(new RectF(x, y, x + w, y + h), rx, ry, Path.Direction.CW);
                else s.path.addRect(new RectF(x, y, x + w, y + h), Path.Direction.CW);
            } else if ("circle".equals(tag)) {
                s.path.addCircle(num(at.get("cx")), num(at.get("cy")), num(at.get("r")), Path.Direction.CW);
            } else if ("line".equals(tag)) {
                s.path.moveTo(num(at.get("x1")), num(at.get("y1")));
                s.path.lineTo(num(at.get("x2")), num(at.get("y2")));
            } else {
                String pts = at.get("points");
                if (pts != null) {
                    float[] v = nums(pts);
                    for (int i = 0; i + 1 < v.length; i += 2) {
                        if (i == 0) s.path.moveTo(v[0], v[1]); else s.path.lineTo(v[i], v[i + 1]);
                    }
                    if ("polygon".equals(tag)) s.path.close();
                }
            }
            String tr = at.get("transform");
            if (tr != null && tr.startsWith("rotate")) {
                float[] v = nums(tr.substring(tr.indexOf('(') + 1, tr.indexOf(')')));
                android.graphics.Matrix mx = new android.graphics.Matrix();
                if (v.length >= 3) { mx.postTranslate(-v[1], -v[2]); mx.postRotate(v[0]); mx.postTranslate(v[1], v[2]); }
                else if (v.length >= 1) mx.postRotate(v[0]);
                s.path.transform(mx);
            }
            shapes.add(s);
        }
    }

    private static float num(String s) {
        if (s == null || s.isEmpty()) return 0f;
        try { return Float.parseFloat(s); } catch (NumberFormatException e) { return 0f; }
    }

    private static float[] nums(String s) {
        Matcher m = Pattern.compile("[-+]?(?:\\d*\\.\\d+|\\d+\\.?)(?:[eE][-+]?\\d+)?").matcher(s);
        List<Float> l = new ArrayList<>();
        while (m.find()) l.add(Float.parseFloat(m.group()));
        float[] r = new float[l.size()];
        for (int i = 0; i < r.length; i++) r[i] = l.get(i);
        return r;
    }

    /** SVG path 的 d 字串 → Android Path。 */
    static void pathData(Path p, String d) {
        if (d == null) return;
        Matcher m = Pattern.compile("([MmLlHhVvCcSsQqTtAaZz])([^MmLlHhVvCcSsQqTtAaZz]*)").matcher(d);
        float cx = 0, cy = 0, sx = 0, sy = 0, lcx = 0, lcy = 0;   // 目前點、子路徑起點、上一個控制點
        char prev = ' ';
        while (m.find()) {
            char cmd = m.group(1).charAt(0);
            float[] v = nums(m.group(2));
            boolean rel = Character.isLowerCase(cmd);
            char u = Character.toUpperCase(cmd);
            if (u == 'Z') { p.close(); cx = sx; cy = sy; prev = 'Z'; continue; }
            int step = u == 'M' || u == 'L' || u == 'T' ? 2 : u == 'H' || u == 'V' ? 1 : u == 'C' ? 6 : u == 'S' || u == 'Q' ? 4 : 7;
            boolean first = true;
            for (int i = 0; i + step <= v.length; i += step) {
                float ox = rel ? cx : 0, oy = rel ? cy : 0;
                switch (u) {
                    case 'M':
                        if (first) { cx = ox + v[i]; cy = oy + v[i + 1]; p.moveTo(cx, cy); sx = cx; sy = cy; }
                        else { cx = ox + v[i]; cy = oy + v[i + 1]; p.lineTo(cx, cy); }
                        prev = 'M'; break;
                    case 'L': cx = ox + v[i]; cy = oy + v[i + 1]; p.lineTo(cx, cy); prev = 'L'; break;
                    case 'H': cx = (rel ? cx : 0) + v[i]; p.lineTo(cx, cy); prev = 'L'; break;
                    case 'V': cy = (rel ? cy : 0) + v[i]; p.lineTo(cx, cy); prev = 'L'; break;
                    case 'C': {
                        float x1 = ox + v[i], y1 = oy + v[i + 1], x2 = ox + v[i + 2], y2 = oy + v[i + 3], x = ox + v[i + 4], y = oy + v[i + 5];
                        p.cubicTo(x1, y1, x2, y2, x, y); lcx = x2; lcy = y2; cx = x; cy = y; prev = 'C'; break;
                    }
                    case 'S': {
                        float x1 = prev == 'C' ? 2 * cx - lcx : cx, y1 = prev == 'C' ? 2 * cy - lcy : cy;
                        float x2 = ox + v[i], y2 = oy + v[i + 1], x = ox + v[i + 2], y = oy + v[i + 3];
                        p.cubicTo(x1, y1, x2, y2, x, y); lcx = x2; lcy = y2; cx = x; cy = y; prev = 'C'; break;
                    }
                    case 'Q': {
                        float x1 = ox + v[i], y1 = oy + v[i + 1], x = ox + v[i + 2], y = oy + v[i + 3];
                        p.quadTo(x1, y1, x, y); lcx = x1; lcy = y1; cx = x; cy = y; prev = 'Q'; break;
                    }
                    case 'T': {
                        float x1 = prev == 'Q' ? 2 * cx - lcx : cx, y1 = prev == 'Q' ? 2 * cy - lcy : cy;
                        float x = ox + v[i], y = oy + v[i + 1];
                        p.quadTo(x1, y1, x, y); lcx = x1; lcy = y1; cx = x; cy = y; prev = 'Q'; break;
                    }
                    case 'A': {
                        float x = ox + v[i + 5], y = oy + v[i + 6];
                        arc(p, cx, cy, v[i], v[i + 1], v[i + 2], v[i + 3] != 0, v[i + 4] != 0, x, y);
                        cx = x; cy = y; prev = 'A'; break;
                    }
                    default: break;
                }
                first = false;
            }
        }
    }

    /** SVG 圓弧(端點表示法)轉成幾段三次貝茲曲線。 */
    private static void arc(Path p, float x0, float y0, float rx, float ry, float rotDeg, boolean large, boolean sweep, float x1, float y1) {
        if (rx == 0 || ry == 0) { p.lineTo(x1, y1); return; }
        rx = Math.abs(rx); ry = Math.abs(ry);
        double phi = Math.toRadians(rotDeg), cp = Math.cos(phi), sp = Math.sin(phi);
        double dx = (x0 - x1) / 2.0, dy = (y0 - y1) / 2.0;
        double x1p = cp * dx + sp * dy, y1p = -sp * dx + cp * dy;
        double lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry);
        if (lam > 1) { double s = Math.sqrt(lam); rx *= s; ry *= s; }
        double num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p;
        double den = rx * rx * y1p * y1p + ry * ry * x1p * x1p;
        double co = den == 0 ? 0 : Math.sqrt(Math.max(0, num / den));
        if (large == sweep) co = -co;
        double cxp = co * rx * y1p / ry, cyp = -co * ry * x1p / rx;
        double cx = cp * cxp - sp * cyp + (x0 + x1) / 2.0, cy = sp * cxp + cp * cyp + (y0 + y1) / 2.0;
        double th1 = Math.atan2((y1p - cyp) / ry, (x1p - cxp) / rx);
        double th2 = Math.atan2((-y1p - cyp) / ry, (-x1p - cxp) / rx);
        double dth = th2 - th1;
        if (sweep && dth < 0) dth += 2 * Math.PI;
        else if (!sweep && dth > 0) dth -= 2 * Math.PI;
        int segs = (int) Math.ceil(Math.abs(dth) / (Math.PI / 2) - 1e-9);
        if (segs < 1) segs = 1;
        double delta = dth / segs, t = 4.0 / 3.0 * Math.tan(delta / 4);
        double a = th1;
        for (int i = 0; i < segs; i++) {
            double c1 = Math.cos(a), s1 = Math.sin(a), c2 = Math.cos(a + delta), s2 = Math.sin(a + delta);
            double e1x = c1 - t * s1, e1y = s1 + t * c1, e2x = c2 + t * s2, e2y = s2 - t * c2;
            p.cubicTo(pt(cx, cy, rx, ry, cp, sp, e1x, e1y, true), pt(cx, cy, rx, ry, cp, sp, e1x, e1y, false),
                    pt(cx, cy, rx, ry, cp, sp, e2x, e2y, true), pt(cx, cy, rx, ry, cp, sp, e2x, e2y, false),
                    pt(cx, cy, rx, ry, cp, sp, c2, s2, true), pt(cx, cy, rx, ry, cp, sp, c2, s2, false));
            a += delta;
        }
    }

    private static float pt(double cx, double cy, double rx, double ry, double cp, double sp, double ux, double uy, boolean xAxis) {
        double X = rx * ux, Y = ry * uy;
        return (float) (xAxis ? cp * X - sp * Y + cx : sp * X + cp * Y + cy);
    }

    // ---------- 繪製 ----------
    @Override
    protected void onMeasure(int w, int h) { setMeasuredDimension(sizePx, sizePx); }

    @Override
    protected void onDraw(Canvas c) {
        float k = sizePx / vb;
        c.save();
        c.scale(k, k);
        for (Shape s : shapes) {
            if (s.fill) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(s.fillColor != 0 ? s.fillColor : color);
                c.drawPath(s.path, paint);
            }
            if (s.stroke) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(s.width > 0 ? s.width : strokeW);
                paint.setStrokeCap(Paint.Cap.ROUND);
                paint.setStrokeJoin(Paint.Join.ROUND);
                paint.setColor(s.strokeColor != 0 ? s.strokeColor : color);
                c.drawPath(s.path, paint);
            }
        }
        c.restore();
    }

    /** 測試用:第 i 個形狀的路徑文字。 */
    String debugPath(int i) { return shapes.get(i).path.toString(); }
    int debugCount() { return shapes.size(); }
}
