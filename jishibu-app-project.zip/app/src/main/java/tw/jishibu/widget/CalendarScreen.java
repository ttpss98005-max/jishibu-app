package tw.jishibu.widget;

import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;
import java.util.List;

/** 行事曆:月曆格子,點某一天看那天的事項。 */
final class CalendarScreen extends Screen {
    private int offset = 0;
    private String selected = Model.today();

    CalendarScreen(MainActivity a) { super(a); }

    @Override
    void build() {
        final String today = Model.today();
        Calendar first = Calendar.getInstance();
        first.set(Calendar.DAY_OF_MONTH, 1);
        first.add(Calendar.MONTH, offset);
        final int viewMonth = first.get(Calendar.MONTH);

        // 標題列
        LinearLayout head = Ui.row(a);
        head.addView(navBtn("‹", -1));
        TextView title = Ui.tv(a, first.get(Calendar.YEAR) + "年" + (viewMonth + 1) + "月", 22, Ui.INK, true);
        title.setGravity(Gravity.CENTER);
        head.addView(title, Ui.weight(1));
        head.addView(navBtn("›", 1));
        content.addView(head);

        TextView todayBtn = Ui.pill(a, "回到今天", false);
        todayBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { offset = 0; selected = today; refresh(); }
        });
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
        tp.gravity = Gravity.CENTER_HORIZONTAL;
        tp.topMargin = Ui.dp(a, 6);
        content.addView(todayBtn, tp);

        // 週標題
        LinearLayout wk = Ui.row(a);
        String[] names = {"日", "一", "二", "三", "四", "五", "六"};
        for (int i = 0; i < 7; i++) {
            TextView t = Ui.tv(a, names[i], 12, i == 0 ? Ui.DANGER : Ui.SOFT, false);
            t.setGravity(Gravity.CENTER);
            wk.addView(t, Ui.weight(1));
        }
        content.addView(wk, Ui.mw(a, 14));

        // 格子
        LinearLayout grid = Ui.card(a);
        grid.setPadding(Ui.dp(a, 4), Ui.dp(a, 6), Ui.dp(a, 4), Ui.dp(a, 6));
        Calendar day = (Calendar) first.clone();
        day.add(Calendar.DAY_OF_MONTH, -(day.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY));
        for (int r = 0; r < 6; r++) {
            LinearLayout line = Ui.row(a);
            for (int c = 0; c < 7; c++) {
                final String ymd = Model.ymd(day);
                boolean inMonth = day.get(Calendar.MONTH) == viewMonth;
                int n = Model.entriesForDay(ymd).size();
                line.addView(cell(day.get(Calendar.DAY_OF_MONTH), ymd, inMonth, n > 0, c == 0, ymd.equals(today), ymd.equals(selected)), Ui.weight(1));
                day.add(Calendar.DAY_OF_MONTH, 1);
            }
            grid.addView(line);
        }
        content.addView(grid);

        // 選到的那天
        content.addView(Ui.section(a, Model.prettyDay(selected)));
        LinearLayout card = Ui.card(a);
        List<Model.Entry> list = Model.entriesForDay(selected);
        if (list.isEmpty()) {
            card.addView(Ui.tv(a, "這天沒有事項", 15, Ui.SOFT, false));
        } else {
            for (Model.Entry e : list) card.addView(Ui.entryRow(a, e, Ui.subtitleFor(e, selected), false, again));
        }
        content.addView(card);
        TextView add = Ui.pill(a, "＋ 在這天新增事項", true);
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { Dialogs.addTask(a, selected, again); }
        });
        content.addView(add, Ui.mw(a, 16));
    }

    private View navBtn(String s, final int delta) {
        TextView t = Ui.tv(a, s, 28, Ui.ACCENT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(a, 18), Ui.dp(a, 2), Ui.dp(a, 18), Ui.dp(a, 2));
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { offset += delta; refresh(); }
        });
        return t;
    }

    private View cell(int dayNum, final String ymd, boolean inMonth, boolean hasItems, boolean sunday, boolean isToday, boolean isSel) {
        LinearLayout c = Ui.col(a);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(0, Ui.dp(a, 3), 0, Ui.dp(a, 3));
        int color = !inMonth ? Ui.LINE : (sunday ? Ui.DANGER : Ui.INK);
        TextView t = Ui.tv(a, String.valueOf(dayNum), 15, color, isToday || isSel);
        t.setGravity(Gravity.CENTER);
        if (isToday) {
            t.setBackground(Ui.shape(a, Ui.ACCENT, 20, 0, 0));
            t.setTextColor(Ui.ON_ACCENT);
        } else if (isSel) {
            t.setBackground(Ui.shape(a, 0x00000000, 20, Ui.ACCENT, 2));
        }
        c.addView(t, new LinearLayout.LayoutParams(Ui.dp(a, 34), Ui.dp(a, 34)));
        TextView dot = Ui.tv(a, "●", 7, hasItems ? Ui.ACCENT : 0x00000000, false);
        dot.setGravity(Gravity.CENTER);
        c.addView(dot);
        c.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selected = ymd; refresh(); }
        });
        return c;
    }
}
