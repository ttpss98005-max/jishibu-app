package tw.jishibu.widget;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 「行事曆」分頁:週曆 / 月曆。照網頁版 renderCalendar / renderWeek / renderDayDetail。
 * 事項來源:事項的截止日(整天)與細項的時間;依目前分類與「待處理/已完成」篩選。
 */
final class CalendarScreen extends ScrollScreen {
    private static boolean weekMode = true;           // 網頁版預設是週曆
    private static int calY = -1, calM = -1;          // 月曆目前顯示的年月(M: 1–12)
    private static String weekStart = null;           // 週曆目前這週的星期日(yyyy-MM-dd)
    private static String selected = null;            // 月曆選到的日期

    private static final String[] DOW = {"日", "一", "二", "三", "四", "五", "六"};

    CalendarScreen(MainActivity a) { super(a); }

    /** 一筆行事曆項目。 */
    private static final class Item {
        String title, time, tag = "", rid = "", rs = "", re = "";
        int color;
        boolean done, isDate;
        String day() { return time.substring(0, 10); }
        String hm() { return !tag.isEmpty() ? tag : (isDate ? "截止" : (time.length() >= 16 ? time.substring(11, 16) : "00:00")); }
    }

    private List<Item> allItems() {
        List<Item> items = new ArrayList<>();
        String cat = a.catId();
        String filter = ListScreen.filter;
        for (JSONObject t : Model.tasks()) {
            if (!"overview".equals(cat) && !cat.equals(Model.s(t, "categoryId"))) continue;
            JSONObject c = Model.category(Model.s(t, "categoryId"));
            int color = c == null ? 0xFF999999 : Theme.parse(Model.s(c, "color", "#999999"));
            String due = Model.s(t, "dueDate", "");
            if (Model.isRangeTask(t)) {
                // 時段:範圍內每一天都列出來(開始 / 第 N 天 / 結束),結束那天有設時間就顯示時間
                String st = Model.s(t, "startDate"), dtm = Model.s(t, "dueTime", "");
                int n = Model.taskRangeDays(t);
                for (int i = 0; i < n; i++) {
                    boolean last = i == n - 1;
                    boolean hasT = last && Model.isHm(dtm);
                    Item it = new Item();
                    it.title = Model.s(t, "title");
                    it.time = Model.addDays(st, i) + "T" + (hasT ? dtm : "00:00");
                    it.color = color;
                    it.done = "done".equals(Model.s(t, "status"));
                    it.isDate = !hasT;
                    it.tag = i == 0 ? "開始" : (last ? "" : (i + 1) + "/" + n);
                    it.rid = Model.s(t, "id");
                    it.rs = st;
                    it.re = due;
                    items.add(it);
                }
                continue;
            }
            if (due.length() >= 10 && Model.isDay(due.substring(0, 10))) {
                String dt = Model.s(t, "dueTime", "");
                boolean hasTime = Model.isHm(dt);
                Item it = new Item();
                it.title = Model.s(t, "title");
                it.time = due.substring(0, 10) + "T" + (hasTime ? dt : "00:00");
                it.color = color;
                it.done = "done".equals(Model.s(t, "status"));
                it.isDate = !hasTime;   // 有設時間的顯示在那個時間;只有日期的顯示「截止」
                items.add(it);
            }
        }
        List<Item> out = new ArrayList<>();
        for (Item it : items) {
            if ("pending".equals(filter) && it.done) continue;
            if ("done".equals(filter) && !it.done) continue;
            out.add(it);
        }
        return out;
    }

    private static List<Item> onDay(List<Item> all, String day) {
        List<Item> r = new ArrayList<>();
        for (Item it : all) if (it.day().equals(day)) r.add(it);
        Collections.sort(r, new Comparator<Item>() {
            @Override public int compare(Item x, Item y) { return x.time.compareTo(y.time); }
        });
        return r;
    }

    // ---------- 畫面 ----------

    @Override void build() {
        if (calY < 0) {
            Calendar n = Calendar.getInstance();
            calY = n.get(Calendar.YEAR);
            calM = n.get(Calendar.MONTH) + 1;
        }
        if (weekStart == null) weekStart = sundayOf(Model.today());

        LinearLayout tabs = Ui.pillTabs(a, new String[]{"週曆", "月曆"}, weekMode ? 0 : 1, new Ui.IntCb() {
            @Override public void on(int i) { weekMode = i == 0; refresh(); }
        });
        content.addView(tabs, Ui.wrap(a, 0));
        content.addView(Ui.spacer(a, 14));
        if (weekMode) buildWeek(); else buildMonth();
    }

    private static String sundayOf(String day) {
        int dow = Lunar.dow(Integer.parseInt(day.substring(0, 4)), Integer.parseInt(day.substring(5, 7)), Integer.parseInt(day.substring(8, 10)));
        return Model.addDays(day, -dow);
    }

    private View navBtn(String s, View.OnClickListener l) {
        View t = new Chevron(a, "‹".equals(s), Ui.CARD_INK, 34);
        t.setBackground(Ui.shape(a, Ui.SURFACE, 16, Ui.BORDER, 1.5f));
        Ui.soft(t, 1);
        t.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(a, 34), Ui.dp(a, 34)));
        t.setOnClickListener(l);
        return t;
    }

    private View header(String title, View.OnClickListener prev, View.OnClickListener next) {
        LinearLayout h = Ui.row(a);
        h.addView(navBtn("‹", prev));
        TextView t = Ui.tv(a, title, 14.5f, Ui.INK, true);
        t.setGravity(Gravity.CENTER);
        h.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        h.addView(navBtn("›", next));
        return h;
    }

    // ---------- 月曆 ----------

    private void buildMonth() {
        final List<Item> items = allItems();
        content.addView(Special.boxes(a), Ui.mw(a, 0));
        content.addView(Ui.spacer(a, 16));
        content.addView(header(calY + "年 " + calM + "月", new View.OnClickListener() {
            @Override public void onClick(View v) { shiftMonth(-1); }
        }, new View.OnClickListener() {
            @Override public void onClick(View v) { shiftMonth(1); }
        }), Ui.mw(a, 0));
        content.addView(Ui.spacer(a, 14));

        // 星期列
        LinearLayout dow = Ui.row(a);
        for (String d : DOW) {
            TextView t = Ui.tv(a, d, 11, Ui.SOFT, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 6));
            dow.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        content.addView(dow, Ui.mw(a, 0));

        int startOffset = Lunar.dow(calY, calM, 1);
        Calendar mc = Calendar.getInstance();
        mc.clear();
        mc.set(calY, calM - 1, 1);
        int dim = mc.getActualMaximum(Calendar.DAY_OF_MONTH);
        String today = Model.today();
        int total = startOffset + dim;
        int rows = (total + 6) / 7;

        // 時段:每個事項一個(照網頁版 renderCalendar:一週最多 3 層,最長的放最下面,放不下的退回小點)
        final java.util.LinkedHashMap<String, Item> spans = new java.util.LinkedHashMap<>();
        for (Item it : items) if (!it.rid.isEmpty() && !spans.containsKey(it.rid)) spans.put(it.rid, it);
        final java.util.Map<String, java.util.Set<String>> coveredBy = new java.util.HashMap<>();
        for (int r = 0; r < rows; r++) content.addView(monthWeek(r, startOffset, dim, spans, coveredBy, items, today), Ui.mw(a, 0));

        TextView note = Ui.tv(a, "農曆與節日僅供參考,國定假日以政府公告為準", 10.5f, Ui.SOFT, false);
        content.addView(note, Ui.mw(a, 10));

        // 當日事項
        LinearLayout detail = Ui.col(a);
        detail.setPadding(0, Ui.dp(a, 16), 0, 0);
        LinearLayout.LayoutParams dlp = Ui.mw(a, 20);
        content.addView(Ui.hline(a), dlp);
        buildDetail(detail, items);
        content.addView(detail, new LinearLayout.LayoutParams(-1, -2));
    }

    /** 一週裡的一個時段片段:a..b 是這週的欄(0–6),cl / cr = 從上週接來 / 接到下週。 */
    private static final class Seg {
        Item it; int a, b, lane = -1, len; boolean cl, cr;
    }

    private View monthWeek(int r, int startOffset, int dim, java.util.Map<String, Item> spans,
                           java.util.Map<String, java.util.Set<String>> coveredBy, List<Item> items, String today) {
        String[] dayAt = new String[7];
        for (int c = 0; c < 7; c++) {
            int d = r * 7 + c - startOffset + 1;
            dayAt[c] = (d >= 1 && d <= dim) ? Model.ymd(calY, calM, d) : null;
        }
        List<Seg> segs = new ArrayList<>();
        for (Item it : spans.values()) {
            int sa = -1, sb = -1;
            for (int c = 0; c < 7; c++) {
                if (dayAt[c] != null && dayAt[c].compareTo(it.rs) >= 0 && dayAt[c].compareTo(it.re) <= 0) { if (sa < 0) sa = c; sb = c; }
            }
            if (sa < 0) continue;
            Seg sg = new Seg();
            sg.it = it; sg.a = sa; sg.b = sb;
            sg.cl = it.rs.compareTo(dayAt[sa]) < 0;
            sg.cr = it.re.compareTo(dayAt[sb]) > 0;
            sg.len = Model.daysBetween(it.rs, it.re);
            segs.add(sg);
        }
        // 最長的優先、放最下面:先依總長度由長到短排,各自找第一個不重疊的層(最多 3 層),最後把層順序翻轉
        Collections.sort(segs, new Comparator<Seg>() {
            @Override public int compare(Seg x, Seg y) {
                if (x.len != y.len) return y.len - x.len;
                if (x.a != y.a) return x.a - y.a;
                return x.it.rid.compareTo(y.it.rid);
            }
        });
        List<List<Seg>> lanes = new ArrayList<>();
        for (Seg sg : segs) {
            int found = -1;
            for (int i = 0; i < lanes.size() && found < 0; i++) {
                boolean free = true;
                for (Seg o : lanes.get(i)) if (!(o.b < sg.a || o.a > sg.b)) { free = false; break; }
                if (free) found = i;
            }
            if (found < 0) {
                if (lanes.size() >= 3) continue;
                lanes.add(new ArrayList<Seg>());
                found = lanes.size() - 1;
            }
            lanes.get(found).add(sg);
            sg.lane = found;
        }
        int L = lanes.size();
        List<Seg> shown = new ArrayList<>();
        for (Seg sg : segs) if (sg.lane >= 0) { sg.lane = L - 1 - sg.lane; shown.add(sg); }
        for (Seg sg : shown) for (int c = sg.a; c <= sg.b; c++) {
            java.util.Set<String> set = coveredBy.get(dayAt[c]);
            if (set == null) { set = new java.util.HashSet<>(); coveredBy.put(dayAt[c], set); }
            set.add(sg.it.rid);
        }

        // 日期格:沒方塊的日子一路往下加長;有方塊的加長到第一個方塊上面。只佔第一列、又有小點 / 標記的,這一週就維持原高度
        boolean tightBusy = false;
        int[] endRow = new int[7];
        for (int c = 0; c < 7; c++) {
            if (dayAt[c] == null) continue;
            int min = -1;
            boolean any = false;
            for (Seg sg : shown) if (sg.a <= c && c <= sg.b) { any = true; if (min < 0 || sg.lane < min) min = sg.lane; }
            endRow[c] = any ? 1 + min : L + 1;
            if (endRow[c] == 1 && cellHasStuff(dayAt[c], items, coveredBy.get(dayAt[c]))) tightBusy = true;
        }
        boolean compact = L > 0 && !tightBusy;
        WeekGrid g = new WeekGrid(a, L, compact ? 46 : 66);
        for (int c = 0; c < 7; c++) {
            if (dayAt[c] == null) { g.addView(new View(a), new WeekGrid.LP(c, 1, 0, 1)); continue; }
            g.addView(dayCell(Integer.parseInt(dayAt[c].substring(8, 10)), items, today, coveredBy.get(dayAt[c])), new WeekGrid.LP(c, 1, 0, endRow[c]));
        }
        for (final Seg sg : shown) {
            Item it = sg.it;
            RangeBox box = new RangeBox(a, it.title, Model.fmtDate(it.rs) + "–" + Model.fmtDate(it.re), it.color, sg.cl, sg.cr, it.done);
            final String startDay = dayAt[sg.a];
            box.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { selected = startDay; refresh(); }
            });
            g.addView(box, new WeekGrid.LP(sg.a, sg.b - sg.a + 1, 1 + sg.lane, 2 + sg.lane));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(a, 3);
        lp.bottomMargin = Ui.dp(a, 3);
        g.setLayoutParams(lp);
        return g;
    }

    /** 這個日期格裡有沒有小點 / 休 / ★(有的話第一列不能縮短)。 */
    private boolean cellHasStuff(String day, List<Item> items, java.util.Set<String> covered) {
        for (Item it : onDay(items, day)) if (!(!it.rid.isEmpty() && covered != null && covered.contains(it.rid))) return true;
        int y = Integer.parseInt(day.substring(0, 4)), m = Integer.parseInt(day.substring(5, 7)), d = Integer.parseInt(day.substring(8, 10));
        if (Lunar.dayInfo(y, m, d).holiday) return true;
        return !Special.on(day).marks.isEmpty();
    }

    private void shiftMonth(int delta) {
        int m = calM + delta, y = calY;
        while (m < 1) { m += 12; y--; }
        while (m > 12) { m -= 12; y++; }
        calY = y;
        calM = m;
        refresh();
    }

    private View dayCell(final int d, List<Item> items, String today, java.util.Set<String> covered) {
        final String day = Model.ymd(calY, calM, d);
        boolean isToday = day.equals(today), isSel = day.equals(selected);
        Lunar.DayInfo info = Lunar.dayInfo(calY, calM, d);
        Special.On sp = Special.on(day);
        List<Item> dayItems = onDay(items, day);

        FrameLayout cell = new FrameLayout(a);
        cell.setBackground(isSel ? Ui.shape(a, Ui.ACCENT_SOFT, 16, Ui.ACCENT, 1.5f) : Ui.shape(a, Ui.TASK_BG, 16, Ui.BORDER, 1.5f));
        Ui.soft(cell, 1);
        LinearLayout col = Ui.col(a);
        col.setPadding(Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 6), Ui.dp(a, 4));

        TextView num = Ui.tv(a, String.valueOf(d), 11.5f, isToday ? Ui.ON_ACCENT : Ui.CARD_INK, isToday);
        num.setGravity(Gravity.CENTER);
        if (isToday) {
            num.setBackground(Ui.shape(a, Ui.ACCENT, 10, 0, 0));
            col.addView(num, new LinearLayout.LayoutParams(Ui.dp(a, 20), Ui.dp(a, 20)));
        } else {
            col.addView(num, new LinearLayout.LayoutParams(-2, Ui.dp(a, 20)));
        }

        String label = info.festival != null ? info.festival : info.lunarText;
        int color = info.festival != null ? Ui.DANGER : (info.holiday ? Ui.DANGER : Ui.SOFT);
        boolean bold = info.festival != null;
        if (!sp.festivals.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (JSONObject f : sp.festivals) { if (sb.length() > 0) sb.append("、"); sb.append(Model.s(f, "name")); }
            label = sb.toString();
            color = Ui.ACCENT;
            bold = true;
        }
        TextView lunar = Ui.tv(a, label, 9, color, bold);
        lunar.setSingleLine(true);
        lunar.setEllipsize(android.text.TextUtils.TruncateAt.END);
        col.addView(lunar, Ui.mw(a, 2));

        LinearLayout dots = Ui.row(a);
        List<Integer> seen = new ArrayList<>();
        for (Item it : dayItems) {
            if (!it.rid.isEmpty() && covered != null && covered.contains(it.rid)) continue;   // 已經畫成方塊的時段,不再畫小點
            if (seen.contains(it.color)) continue;
            seen.add(it.color);
            if (seen.size() > 4) break;
            View dot = new View(a);
            dot.setBackground(Ui.shape(a, it.color, 6, 0, 0));
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(Ui.dp(a, 6), Ui.dp(a, 6));
            dl.rightMargin = Ui.dp(a, 3);
            dots.addView(dot, dl);
        }
        col.addView(dots, Ui.mw(a, 5));
        cell.addView(col, new FrameLayout.LayoutParams(-1, -1));

        if (info.holiday) {
            TextView tag = Ui.tv(a, "休", 8, Ui.ON_ACCENT, false);
            tag.setPadding(Ui.dp(a, 3), 0, Ui.dp(a, 3), 0);
            tag.setBackground(Ui.shape(a, Ui.DANGER, 5, 0, 0));
            FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
            tp.topMargin = Ui.dp(a, 4);
            tp.rightMargin = Ui.dp(a, 4);
            cell.addView(tag, tp);
        }
        if (!sp.marks.isEmpty()) {
            TextView star = Ui.tv(a, "★", 10, Ui.ACCENT, false);
            FrameLayout.LayoutParams sp2 = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
            sp2.rightMargin = Ui.dp(a, 6);
            sp2.bottomMargin = Ui.dp(a, 5);
            cell.addView(star, sp2);
        }
        cell.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { selected = day; refresh(); }
        });
        return cell;
    }

    private void buildDetail(LinearLayout box, List<Item> all) {
        if (selected == null) {
            box.addView(Ui.empty(a, "點選日期查看當日事項"));
            return;
        }
        int y = Integer.parseInt(selected.substring(0, 4)), m = Integer.parseInt(selected.substring(5, 7)), d = Integer.parseInt(selected.substring(8, 10));
        Lunar.DayInfo info = Lunar.dayInfo(y, m, d);
        List<String> parts = new ArrayList<>();
        if (!info.lunarText.isEmpty()) parts.add(info.lunarText);
        if (info.festival != null) parts.add(info.festival);
        if (info.holiday) parts.add("放假");
        StringBuilder line = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) { if (i > 0) line.append(" · "); line.append(parts.get(i)); }

        LinearLayout h = Ui.row(a);
        h.addView(Ui.tv(a, m + "/" + d + " 的事項", 13.5f, Ui.INK, true));
        TextView il = Ui.tv(a, line.toString(), 11.5f, Ui.SOFT, false);
        h.addView(il, Ui.gap(a, 8));
        box.addView(h, Ui.mw(a, 0));
        box.addView(Ui.spacer(a, 10));
        View sp = Special.detail(a, selected);
        box.addView(sp, Ui.mw(a, 0));

        List<Item> items = onDay(all, selected);
        if (items.isEmpty()) {
            TextView e = Ui.empty(a, "當日無事項");
            e.setPadding(0, Ui.dp(a, 14), 0, Ui.dp(a, 14));
            box.addView(e);
            return;
        }
        for (Item it : items) box.addView(itemLine(it), Ui.mw(a, 6));
    }

    /** .item-line:左邊有分類顏色的細條。 */
    private View itemLine(Item it) {
        LinearLayout wrap = Ui.row(a);
        wrap.setBackground(Ui.shape(a, Ui.TASK_BG, 12, Ui.BORDER, 1.5f));
        View bar = new View(a);
        bar.setBackground(Ui.shape(a, it.color, 2, 0, 0));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(Ui.dp(a, 4), -1);
        bp.setMargins(Ui.dp(a, 1), Ui.dp(a, 6), 0, Ui.dp(a, 6));
        wrap.addView(bar, bp);
        TextView t = Ui.tv(a, it.hm() + "   " + it.title, 12.5f, Ui.CARD_INK, false);
        t.setPadding(Ui.dp(a, 10), Ui.dp(a, 9), Ui.dp(a, 12), Ui.dp(a, 9));
        wrap.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        return wrap;
    }

    // ---------- 週曆 ----------

    private void buildWeek() {
        List<Item> items = allItems();
        content.addView(Special.boxes(a), Ui.mw(a, 0));
        content.addView(Ui.spacer(a, 16));
        String end = Model.addDays(weekStart, 6);
        content.addView(header(Model.fmtDate(weekStart) + " - " + Model.fmtDate(end), new View.OnClickListener() {
            @Override public void onClick(View v) { weekStart = Model.addDays(weekStart, -7); refresh(); }
        }, new View.OnClickListener() {
            @Override public void onClick(View v) { weekStart = Model.addDays(weekStart, 7); refresh(); }
        }), Ui.mw(a, 0));
        content.addView(Ui.spacer(a, 16));

        String today = Model.today();
        for (int i = 0; i < 7; i++) {
            String day = Model.addDays(weekStart, i);
            content.addView(weekCol(i, day, items, today), Ui.mw(a, i == 0 ? 0 : 10));
        }
    }

    private View weekCol(int i, String day, List<Item> all, String today) {
        int y = Integer.parseInt(day.substring(0, 4)), m = Integer.parseInt(day.substring(5, 7)), d = Integer.parseInt(day.substring(8, 10));
        boolean isToday = day.equals(today);
        Lunar.DayInfo info = Lunar.dayInfo(y, m, d);
        Special.On sp = Special.on(day);

        LinearLayout col = Ui.col(a);
        col.setBackground(Ui.shape(a, Ui.TASK_BG, 16, Ui.BORDER, 1.5f));
        Ui.soft(col, 1);
        col.setPadding(Ui.dp(a, 9), Ui.dp(a, 9), Ui.dp(a, 9), Ui.dp(a, 9));

        LinearLayout head = Ui.row(a);
        head.setPadding(Ui.dp(a, 4), Ui.dp(a, 2), Ui.dp(a, 2), Ui.dp(a, 2));
        head.addView(Ui.tv(a, DOW[i] + " " + m + "/" + d, 11, isToday ? Ui.ACCENT : Ui.SOFT, true));
        if (info.holiday) {
            TextView tag = Ui.tv(a, "休", 8, Ui.ON_ACCENT, false);
            tag.setPadding(Ui.dp(a, 3), 0, Ui.dp(a, 3), 0);
            tag.setBackground(Ui.shape(a, Ui.DANGER, 5, 0, 0));
            head.addView(tag, Ui.gap(a, 6));
        }
        col.addView(head, Ui.mw(a, 0));

        List<TextView> tags = new ArrayList<>();
        for (JSONObject f : sp.festivals) tags.add(weekTag(Model.s(f, "name"), true));
        if (info.festival != null) tags.add(weekTag(info.festival, false));
        for (Special.Mark mk : sp.marks) tags.add(weekTag("★ " + mk.text, true));
        for (TextView t : tags) {
            LinearLayout.LayoutParams lp = Ui.mw(a, 0);
            lp.leftMargin = Ui.dp(a, 4);
            col.addView(t, lp);
        }
        col.addView(Ui.spacer(a, 8));

        List<Item> items = onDay(all, day);
        if (items.isEmpty()) {
            TextView no = Ui.tv(a, "無事項", 11, 0xFFD8D8D8, false);
            no.setGravity(Gravity.CENTER);
            no.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 6));
            col.addView(no, Ui.mw(a, 0));
        } else {
            for (Item it : items) col.addView(weekItem(it), Ui.mw(a, 6));
        }
        return col;
    }

    private TextView weekTag(String text, boolean accent) {
        TextView t = Ui.tv(a, text, 9.5f, accent ? Ui.ACCENT : Ui.SOFT, accent);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setPadding(0, 0, 0, Ui.dp(a, 4));
        return t;
    }

    private View weekItem(Item it) {
        LinearLayout row = Ui.row(a);
        row.setBackground(Ui.shape(a, Ui.CHIP_BG, 10, 0, 0));
        View bar = new View(a);
        bar.setBackground(Ui.shape(a, it.color, 2, 0, 0));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(Ui.dp(a, 3), -1);
        bp.setMargins(0, Ui.dp(a, 5), 0, Ui.dp(a, 5));
        row.addView(bar, bp);
        LinearLayout txt = Ui.col(a);
        txt.setPadding(Ui.dp(a, 8), Ui.dp(a, 6), Ui.dp(a, 8), Ui.dp(a, 6));
        txt.addView(Ui.tv(a, it.hm(), 10, Ui.SOFT, false));
        txt.addView(Ui.tv(a, it.title, 11, Ui.CARD_INK, false));
        row.addView(txt, new LinearLayout.LayoutParams(0, -2, 1f));
        return row;
    }
}
