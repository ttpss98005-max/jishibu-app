package tw.jishibu.widget;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** 從資料裡讀出畫面要用的東西(只讀,不改資料)。 */
final class Model {
    private Model() {}

    static final class Entry {
        String kind = "task";     // task | sub | special | count
        String title = "";
        String parent = "";       // 細項屬於哪個事項
        String date = "";
        String time = "";         // HH:mm
        boolean done;
        String tid = "", sid = "";
        String catId = "";
    }

    // ---------- 日期 ----------

    static String ymd(int y, int m, int d) { return String.format(Locale.US, "%04d-%02d-%02d", y, m, d); }

    static String ymd(Calendar c) { return ymd(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)); }

    static String today() { return ymd(Calendar.getInstance()); }

    static boolean isDay(String s) {
        return s != null && s.length() == 10 && s.charAt(4) == '-' && s.charAt(7) == '-'
                && Character.isDigit(s.charAt(0)) && Character.isDigit(s.charAt(9));
    }

    static Calendar parse(String day) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(Integer.parseInt(day.substring(0, 4)), Integer.parseInt(day.substring(5, 7)) - 1, Integer.parseInt(day.substring(8, 10)), 12, 0, 0);
        return c;
    }

    static String addDays(String day, int n) {
        Calendar c = parse(day);
        c.add(Calendar.DAY_OF_MONTH, n);
        return ymd(c);
    }

    private static final String[] WD = {"日", "一", "二", "三", "四", "五", "六"};

    static String weekday(String day) { return WD[parse(day).get(Calendar.DAY_OF_WEEK) - 1]; }

    /** 10月10日 週六 */
    static String prettyDay(String day) {
        Calendar c = parse(day);
        return (c.get(Calendar.MONTH) + 1) + "月" + c.get(Calendar.DAY_OF_MONTH) + "日 週" + WD[c.get(Calendar.DAY_OF_WEEK) - 1];
    }

    // ---------- 資料存取 ----------

    /** 取字串欄位。Android 的 optString 遇到 JSON null 會回傳 "null" 這四個字,這裡一律當成空的。 */
    static String s(JSONObject o, String k) { return s(o, k, ""); }
    static String s(JSONObject o, String k, String def) {
        if (o == null) return def;
        Object v = o.opt(k);
        if (v == null || v == JSONObject.NULL) return def;
        return v instanceof String ? (String) v : String.valueOf(v);
    }

    private static JSONArray arr(String key) {
        JSONObject d = Repo.data();
        JSONArray a = d == null ? null : d.optJSONArray(key);
        return a == null ? new JSONArray() : a;
    }

    static List<JSONObject> list(String key) {
        JSONArray a = arr(key);
        List<JSONObject> r = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null) r.add(o);
        }
        return r;
    }

    static List<JSONObject> tasks() { return list("tasks"); }
    static List<JSONObject> habits() { return list("habits"); }
    static List<JSONObject> categories() { return list("categories"); }

    static JSONObject category(String id) {
        for (JSONObject c : categories()) if (Model.s(c, "id").equals(id)) return c;
        return null;
    }

    static String categoryName(String id) {
        for (JSONObject c : categories()) if (Model.s(c, "id").equals(id)) return Model.s(c, "name", "");
        return "";
    }

    // ---------- 事項 ----------

    static Entry taskEntry(JSONObject t) {
        Entry e = new Entry();
        e.kind = "task";
        e.title = Model.s(t, "title", "");
        e.date = Model.s(t, "dueDate", "");
        e.done = "done".equals(Model.s(t, "status"));
        e.tid = Model.s(t, "id");
        e.catId = Model.s(t, "categoryId");
        return e;
    }

    static Entry subEntry(JSONObject t, JSONObject s) {
        Entry e = new Entry();
        e.kind = "sub";
        e.title = Model.s(s, "title", "");
        e.parent = Model.s(t, "title", "");
        String tm = Model.s(s, "time", "");
        if (tm.length() >= 10) e.date = tm.substring(0, 10);
        if (tm.length() >= 16) e.time = tm.substring(11, 16);
        e.done = "done".equals(Model.s(s, "status"));
        e.tid = Model.s(t, "id");
        e.sid = Model.s(s, "id");
        e.catId = Model.s(t, "categoryId");
        return e;
    }

    private static final Comparator<Entry> BY_DAY = new Comparator<Entry>() {
        @Override public int compare(Entry a, Entry b) {
            int ga = group(a), gb = group(b);
            if (ga != gb) return ga - gb;
            int c = a.date.compareTo(b.date);
            if (c != 0) return c;
            return a.time.compareTo(b.time);
        }
        private int group(Entry e) { return e.kind.equals("special") || e.kind.equals("count") ? 0 : (e.done ? 2 : 1); }
    };

    /** 某一天的所有事:當天到期的事項、當天的細項、特別的日子。 */
    static List<Entry> entriesForDay(String day) {
        List<Entry> r = new ArrayList<>();
        for (JSONObject t : tasks()) {
            if (day.equals(Model.s(t, "dueDate"))) r.add(taskEntry(t));
            JSONArray subs = t.optJSONArray("subtasks");
            if (subs == null) continue;
            for (int i = 0; i < subs.length(); i++) {
                JSONObject s = subs.optJSONObject(i);
                if (s != null && Model.s(s, "time", "").startsWith(day)) r.add(subEntry(t, s));
            }
        }
        for (Entry e : specialsOn(day)) r.add(e);
        Collections.sort(r, BY_DAY);
        return r;
    }

    /** 今天以前(含今天)還沒完成、有日期的事。過期的排在前面。 */
    static List<Entry> todoUpTo(String day) {
        List<Entry> r = new ArrayList<>();
        for (JSONObject t : tasks()) {
            String due = Model.s(t, "dueDate", "");
            if (isDay(due) && due.compareTo(day) <= 0 && !"done".equals(Model.s(t, "status"))) r.add(taskEntry(t));
            JSONArray subs = t.optJSONArray("subtasks");
            if (subs == null) continue;
            for (int i = 0; i < subs.length(); i++) {
                JSONObject s = subs.optJSONObject(i);
                if (s == null || "done".equals(Model.s(s, "status"))) continue;
                String tm = Model.s(s, "time", "");
                if (tm.length() >= 10 && isDay(tm.substring(0, 10)) && tm.substring(0, 10).compareTo(day) <= 0) r.add(subEntry(t, s));
            }
        }
        Collections.sort(r, BY_DAY);
        return r;
    }

    /** 這一天完成的事(依完成日)。 */
    static List<Entry> doneOn(String day) {
        List<Entry> r = new ArrayList<>();
        for (JSONObject t : tasks()) {
            if ("done".equals(Model.s(t, "status")) && day.equals(Model.s(t, "completedAt"))) r.add(taskEntry(t));
            JSONArray subs = t.optJSONArray("subtasks");
            if (subs == null) continue;
            for (int i = 0; i < subs.length(); i++) {
                JSONObject s = subs.optJSONObject(i);
                if (s != null && "done".equals(Model.s(s, "status")) && day.equals(Model.s(s, "completedAt"))) r.add(subEntry(t, s));
            }
        }
        return r;
    }

    static List<Entry> specialsOn(String day) {
        List<Entry> r = new ArrayList<>();
        for (JSONObject x : list("specialDays")) {
            String date = Model.s(x, "date", "");
            if (!isDay(date)) continue;
            String kind = Model.s(x, "kind");
            Entry e = new Entry();
            e.title = Model.s(x, "name", "");
            if ("festival".equals(kind)) {
                boolean yearly = x.optBoolean("yearly", true);
                boolean hit = yearly ? date.substring(5).equals(day.substring(5)) : date.equals(day);
                if (!hit) continue;
                e.kind = "special";
                e.date = day;
                r.add(e);
            } else if ("count".equals(kind) && day.compareTo(date) >= 0) {
                long days = (parse(day).getTimeInMillis() - parse(date).getTimeInMillis()) / 86400000L;
                e.kind = "count";
                e.parent = "第 " + (days + 1) + " 天";
                e.date = day;
                if (day.equals(today())) r.add(e);   // 計算天數只在「今天」顯示,不然每一天都會有
            }
        }
        return r;
    }

    // ---------- 習慣 ----------

    static boolean habitScheduledOn(JSONObject h, String day) {
        String f = Model.s(h, "freq", "daily");
        if (f.isEmpty() || "daily".equals(f)) return true;
        Calendar c = parse(day);
        if ("weekly".equals(f)) return contains(h.optJSONArray("weekdays"), c.get(Calendar.DAY_OF_WEEK) - 1);
        if ("monthly".equals(f)) return contains(h.optJSONArray("monthdays"), c.get(Calendar.DAY_OF_MONTH));
        return true;
    }

    private static boolean contains(JSONArray a, int v) {
        if (a == null) return false;
        for (int i = 0; i < a.length(); i++) if (a.optInt(i, -1) == v) return true;
        return false;
    }

    /** 那天那個習慣的打卡紀錄(可能是 true、數字、字串、物件)。沒有就回 null。 */
    private static Object logEntry(String hid, String day) {
        JSONObject d = Repo.data();
        JSONObject logs = d == null ? null : d.optJSONObject("habitLogs");
        if (logs == null) return null;
        Object cur = logs.opt(hid);
        if (cur instanceof JSONObject) {
            Object e = ((JSONObject) cur).opt(day);
            return e == JSONObject.NULL ? null : e;
        }
        if (cur instanceof JSONArray) return contains2((JSONArray) cur, day) ? Boolean.TRUE : null;
        return null;
    }

    private static boolean contains2(JSONArray a, String s) {
        for (int i = 0; i < a.length(); i++) if (s.equals(a.optString(i))) return true;
        return false;
    }

    static boolean habitChecked(String hid, String day) {
        Object e = logEntry(hid, day);
        if (e == null) return false;
        if (e instanceof JSONObject) {
            JSONObject o = (JSONObject) e;
            if (o.has("checked")) return o.optBoolean("checked", false);
            Object v = o.opt("value");
            return v != null && v != JSONObject.NULL && !"".equals(v) && !Boolean.FALSE.equals(v);
        }
        if (e instanceof Boolean) return (Boolean) e;
        if (e instanceof Number) return true;
        if (e instanceof String) return !((String) e).isEmpty();
        return false;
    }

    /** 數量或時間類型的習慣,打卡時填的值(文字)。 */
    static String habitValueText(JSONObject h, String day) {
        Object e = logEntry(Model.s(h, "id"), day);
        if (e == null || !habitChecked(Model.s(h, "id"), day)) return "";
        Object v = e;
        if (e instanceof JSONObject) v = ((JSONObject) e).opt("value");
        if (v instanceof Boolean || v == null || v == JSONObject.NULL) return "";
        if (v instanceof Number) {
            double dv = ((Number) v).doubleValue();
            return dv == Math.rint(dv) ? String.valueOf((long) dv) : String.valueOf(dv);
        }
        return String.valueOf(v);
    }

    /** 連續天數:這一天所屬的那一整段連續打卡有多長(沒排程的日子略過)。 */
    static int habitStreak(JSONObject h, String asOf) {
        String hid = Model.s(h, "id");
        if (!habitScheduledOn(h, asOf) || !habitChecked(hid, asOf)) return 0;
        int count = 1;
        String d = asOf;
        for (int g = 0; g < 3660; g++) {
            d = addDays(d, -1);
            if (!habitScheduledOn(h, d)) continue;
            if (!habitChecked(hid, d)) break;
            count++;
        }
        d = asOf;
        String today = today();
        for (int g = 0; g < 3660; g++) {
            d = addDays(d, 1);
            if (d.compareTo(today) > 0) break;
            if (!habitScheduledOn(h, d)) continue;
            if (!habitChecked(hid, d)) break;
            count++;
        }
        return count;
    }

    // ---------- 時間顯示(跟網頁版 fmtDate / fmtTime / isOverdue 一樣) ----------

    private static int num(String s, int from, int to, int def) {
        try { return Integer.parseInt(s.substring(from, to)); } catch (Exception e) { return def; }
    }

    /** "yyyy-MM-dd" 或 "yyyy-MM-ddTHH:mm" 轉成本地時間的毫秒。格式不對回 0。 */
    static long localMs(String t) {
        if (t == null || t.length() < 10 || !isDay(t.substring(0, 10))) return 0L;
        Calendar c = Calendar.getInstance();
        c.clear();
        int h = 0, mi = 0;
        if (t.length() >= 16) { h = num(t, 11, 13, 0); mi = num(t, 14, 16, 0); }
        c.set(num(t, 0, 4, 1970), num(t, 5, 7, 1) - 1, num(t, 8, 10, 1), h, mi, 0);
        return c.getTimeInMillis();
    }

    /** 12/5 */
    static String fmtDate(String d) {
        if (d == null || d.length() < 10 || !isDay(d.substring(0, 10))) return "未排定";
        return num(d, 5, 7, 0) + "/" + num(d, 8, 10, 0);
    }

    /** 12/5 08:30;沒有時間就「未排定」。 */
    static String fmtTime(String t) {
        if (t == null || t.length() < 10 || !isDay(t.substring(0, 10))) return "未排定";
        String hm = t.length() >= 16 ? t.substring(11, 16) : "00:00";
        return num(t, 5, 7, 0) + "/" + num(t, 8, 10, 0) + " " + hm;
    }

    static boolean overdueDate(String due, boolean done) {
        if (done || due == null || due.length() < 10 || !isDay(due.substring(0, 10))) return false;
        return localMs(due.substring(0, 10)) + 24L * 3600 * 1000 - 1000 < System.currentTimeMillis();
    }

    static boolean overdueTime(String t, boolean done) {
        if (done || t == null || t.length() < 10) return false;
        long ms = localMs(t);
        return ms > 0 && ms < System.currentTimeMillis();
    }
}
