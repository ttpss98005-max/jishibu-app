package tw.jishibu.widget;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** 從資料裡讀出畫面要用的東西(只讀,不改資料)。 */
final class Model {
    private Model() {}

    // ---------- 日期 ----------

    static String ymd(int y, int m, int d) { return String.format(Locale.US, "%04d-%02d-%02d", y, m, d); }

    static String ymd(Calendar c) { return ymd(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)); }

    static String today() { return ymd(Calendar.getInstance()); }

    static boolean isDay(String s) {
        return s != null && s.length() == 10 && s.charAt(4) == '-' && s.charAt(7) == '-'
                && Character.isDigit(s.charAt(0)) && Character.isDigit(s.charAt(9));
    }

    static Calendar parse(String day) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(Integer.parseInt(day.substring(0, 4)), Integer.parseInt(day.substring(5, 7)) - 1, Integer.parseInt(day.substring(8, 10)), 12, 0, 0);
        return c;
    }

    static String addDays(String day, int n) {
        Calendar c = parse(day);
        c.add(Calendar.DAY_OF_MONTH, n);
        return ymd(c);
    }




    // ---------- 資料存取 ----------

    /** 取字串欄位。Android 的 optString 遇到 JSON null 會回傳 "null" 這四個字,這裡一律當成空的。 */
    static String s(JSONObject o, String k) { return s(o, k, ""); }
    static String s(JSONObject o, String k, String def) {
        if (o == null) return def;
        Object v = o.opt(k);
        if (v == null || v == JSONObject.NULL) return def;
        return v instanceof String ? (String) v : String.valueOf(v);
    }

    private static JSONArray arr(String key) {
        JSONObject d = Repo.data();
        JSONArray a = d == null ? null : d.optJSONArray(key);
        return a == null ? new JSONArray() : a;
    }

    static List<JSONObject> list(String key) {
        JSONArray a = arr(key);
        List<JSONObject> r = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null) r.add(o);
        }
        return r;
    }

    static List<JSONObject> tasks() { return list("tasks"); }
    static List<JSONObject> habits() { return list("habits"); }
    static List<JSONObject> categories() { return list("categories"); }

    static JSONObject category(String id) {
        for (JSONObject c : categories()) if (Model.s(c, "id").equals(id)) return c;
        return null;
    }


    // ---------- 習慣 ----------

    static boolean habitScheduledOn(JSONObject h, String day) {
        String f = Model.s(h, "freq", "daily");
        if (f.isEmpty() || "daily".equals(f)) return true;
        Calendar c = parse(day);
        if ("weekly".equals(f)) return contains(h.optJSONArray("weekdays"), c.get(Calendar.DAY_OF_WEEK) - 1);
        if ("monthly".equals(f)) return contains(h.optJSONArray("monthdays"), c.get(Calendar.DAY_OF_MONTH));
        return true;
    }

    private static boolean contains(JSONArray a, int v) {
        if (a == null) return false;
        for (int i = 0; i < a.length(); i++) if (a.optInt(i, -1) == v) return true;
        return false;
    }

    /** 那天那個習慣的打卡紀錄(可能是 true、數字、字串、物件)。沒有就回 null。 */
    static Object logEntry(String hid, String day) {
        JSONObject d = Repo.data();
        JSONObject logs = d == null ? null : d.optJSONObject("habitLogs");
        if (logs == null) return null;
        Object cur = logs.opt(hid);
        if (cur instanceof JSONObject) {
            Object e = ((JSONObject) cur).opt(day);
            return e == JSONObject.NULL ? null : e;
        }
        if (cur instanceof JSONArray) return contains2((JSONArray) cur, day) ? Boolean.TRUE : null;
        return null;
    }

    private static boolean contains2(JSONArray a, String s) {
        for (int i = 0; i < a.length(); i++) if (s.equals(a.optString(i))) return true;
        return false;
    }

    static boolean habitChecked(String hid, String day) {
        Object e = logEntry(hid, day);
        if (e == null) return false;
        if (e instanceof JSONObject) {
            JSONObject o = (JSONObject) e;
            if (o.has("checked")) return o.optBoolean("checked", false);
            Object v = o.opt("value");
            return v != null && v != JSONObject.NULL && !"".equals(v) && !Boolean.FALSE.equals(v);
        }
        if (e instanceof Boolean) return (Boolean) e;
        if (e instanceof Number) return true;
        if (e instanceof String) return !((String) e).isEmpty();
        return false;
    }


    /** 連續天數:這一天所屬的那一整段連續打卡有多長(沒排程的日子略過)。 */
    static int habitStreak(JSONObject h, String asOf) {
        String hid = Model.s(h, "id");
        if (!habitScheduledOn(h, asOf) || !habitChecked(hid, asOf)) return 0;
        int count = 1;
        String d = asOf;
        for (int g = 0; g < 3660; g++) {
            d = addDays(d, -1);
            if (!habitScheduledOn(h, d)) continue;
            if (!habitChecked(hid, d)) break;
            count++;
        }
        d = asOf;
        String today = today();
        for (int g = 0; g < 3660; g++) {
            d = addDays(d, 1);
            if (d.compareTo(today) > 0) break;
            if (!habitScheduledOn(h, d)) continue;
            if (!habitChecked(hid, d)) break;
            count++;
        }
        return count;
    }

    // ---------- 時間顯示(跟網頁版 fmtDate / fmtTime / isOverdue 一樣) ----------

    private static int num(String s, int from, int to, int def) {
        try { return Integer.parseInt(s.substring(from, to)); } catch (Exception e) { return def; }
    }

    /** "yyyy-MM-dd" 或 "yyyy-MM-ddTHH:mm" 轉成本地時間的毫秒。格式不對回 0。 */
    static long localMs(String t) {
        if (t == null || t.length() < 10 || !isDay(t.substring(0, 10))) return 0L;
        Calendar c = Calendar.getInstance();
        c.clear();
        int h = 0, mi = 0;
        if (t.length() >= 16) { h = num(t, 11, 13, 0); mi = num(t, 14, 16, 0); }
        c.set(num(t, 0, 4, 1970), num(t, 5, 7, 1) - 1, num(t, 8, 10, 1), h, mi, 0);
        return c.getTimeInMillis();
    }

    /** 12/5 */
    static String fmtDate(String d) {
        if (d == null || d.length() < 10 || !isDay(d.substring(0, 10))) return "未排定";
        return num(d, 5, 7, 0) + "/" + num(d, 8, 10, 0);
    }

    /** 12/5 08:30;沒有時間就「未排定」。 */
    static String fmtTime(String t) {
        if (t == null || t.length() < 10 || !isDay(t.substring(0, 10))) return "未排定";
        String hm = t.length() >= 16 ? t.substring(11, 16) : "00:00";
        return num(t, 5, 7, 0) + "/" + num(t, 8, 10, 0) + " " + hm;
    }

    static boolean overdueDate(String due, boolean done) {
        if (done || due == null || due.length() < 10 || !isDay(due.substring(0, 10))) return false;
        return localMs(due.substring(0, 10)) + 24L * 3600 * 1000 - 1000 < System.currentTimeMillis();
    }

    static boolean overdueTime(String t, boolean done) {
        if (done || t == null || t.length() < 10) return false;
        long ms = localMs(t);
        return ms > 0 && ms < System.currentTimeMillis();
    }
}
