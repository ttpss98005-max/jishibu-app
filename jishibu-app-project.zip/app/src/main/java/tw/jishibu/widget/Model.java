package tw.jishibu.widget;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** 從資料裡讀出畫面要用的東西(只讀,不改資料)。 */
final class Model {
    private Model() {}

    // ---------- 日期 ----------

    static String ymd(int y, int m, int d) { return String.format(Locale.US, "%04d-%02d-%02d", y, m, d); }

    static String ymd(Calendar c) { return ymd(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)); }

    static String today() { return ymd(Calendar.getInstance()); }

    static boolean isDay(String s) {
        return s != null && s.length() == 10 && s.charAt(4) == '-' && s.charAt(7) == '-'
                && Character.isDigit(s.charAt(0)) && Character.isDigit(s.charAt(9));
    }

    static Calendar parse(String day) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(Integer.parseInt(day.substring(0, 4)), Integer.parseInt(day.substring(5, 7)) - 1, Integer.parseInt(day.substring(8, 10)), 12, 0, 0);
        return c;
    }

    static String addDays(String day, int n) {
        Calendar c = parse(day);
        c.add(Calendar.DAY_OF_MONTH, n);
        return ymd(c);
    }




    // ---------- 資料存取 ----------

    /** 取字串欄位。Android 的 optString 遇到 JSON null 會回傳 "null" 這四個字,這裡一律當成空的。 */
    static String s(JSONObject o, String k) { return s(o, k, ""); }
    static String s(JSONObject o, String k, String def) {
        if (o == null) return def;
        Object v = o.opt(k);
        if (v == null || v == JSONObject.NULL) return def;
        return v instanceof String ? (String) v : String.valueOf(v);
    }

    private static JSONArray arr(String key) {
        JSONObject d = Repo.data();
        JSONArray a = d == null ? null : d.optJSONArray(key);
        return a == null ? new JSONArray() : a;
    }

    static List<JSONObject> list(String key) {
        JSONArray a = arr(key);
        List<JSONObject> r = new ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null) r.add(o);
        }
        return r;
    }

    static List<JSONObject> tasks() { return list("tasks"); }
    static List<JSONObject> habits() { return list("habits"); }
    static List<JSONObject> categories() { return list("categories"); }

    static JSONObject category(String id) {
        for (JSONObject c : categories()) if (Model.s(c, "id").equals(id)) return c;
        return null;
    }


    // ---------- 習慣 ----------

    static boolean habitScheduledOn(JSONObject h, String day) {
        String f = Model.s(h, "freq", "daily");
        if (f.isEmpty() || "daily".equals(f)) return true;
        Calendar c = parse(day);
        if ("weekly".equals(f)) return contains(h.optJSONArray("weekdays"), c.get(Calendar.DAY_OF_WEEK) - 1);
        if ("monthly".equals(f)) return contains(h.optJSONArray("monthdays"), c.get(Calendar.DAY_OF_MONTH));
        return true;
    }

    private static boolean contains(JSONArray a, int v) {
        if (a == null) return false;
        for (int i = 0; i < a.length(); i++) if (a.optInt(i, -1) == v) return true;
        return false;
    }

    /** 那天那個習慣的打卡紀錄(可能是 true、數字、字串、物件)。沒有就回 null。 */
    static Object logEntry(String hid, String day) {
        JSONObject d = Repo.data();
        JSONObject logs = d == null ? null : d.optJSONObject("habitLogs");
        if (logs == null) return null;
        Object cur = logs.opt(hid);
        if (cur instanceof JSONObject) {
            Object e = ((JSONObject) cur).opt(day);
            return e == JSONObject.NULL ? null : e;
        }
        if (cur instanceof JSONArray) return contains2((JSONArray) cur, day) ? Boolean.TRUE : null;
        return null;
    }

    private static boolean contains2(JSONArray a, String s) {
        for (int i = 0; i < a.length(); i++) if (s.equals(a.optString(i))) return true;
        return false;
    }

    static boolean habitChecked(String hid, String day) {
        Object e = logEntry(hid, day);
        if (e == null) return false;
        if (e instanceof JSONObject) {
            JSONObject o = (JSONObject) e;
            if (o.has("checked")) return o.optBoolean("checked", false);
            Object v = o.opt("value");
            return v != null && v != JSONObject.NULL && !"".equals(v) && !Boolean.FALSE.equals(v);
        }
        if (e instanceof Boolean) return (Boolean) e;
        if (e instanceof Number) return true;
        if (e instanceof String) return !((String) e).isEmpty();
        return false;
    }


    /** 連續天數:這一天所屬的那一整段連續打卡有多長(沒排程的日子略過)。 */
    static int habitStreak(JSONObject h, String asOf) {
        String hid = Model.s(h, "id");
        if (!habitScheduledOn(h, asOf) || !habitChecked(hid, asOf)) return 0;
        int count = 1;
        String d = asOf;
        for (int g = 0; g < 3660; g++) {
            d = addDays(d, -1);
            if (!habitScheduledOn(h, d)) continue;
            if (!habitChecked(hid, d)) break;
            count++;
        }
        d = asOf;
        String today = today();
        for (int g = 0; g < 3660; g++) {
            d = addDays(d, 1);
            if (d.compareTo(today) > 0) break;
            if (!habitScheduledOn(h, d)) continue;
            if (!habitChecked(hid, d)) break;
            count++;
        }
        return count;
    }

    // ---------- 時間顯示(跟網頁版 fmtDate / isOverdue 一樣) ----------

    private static int num(String s, int from, int to, int def) {
        try { return Integer.parseInt(s.substring(from, to)); } catch (Exception e) { return def; }
    }

    /** "yyyy-MM-dd" 或 "yyyy-MM-ddTHH:mm" 轉成本地時間的毫秒。格式不對回 0。 */
    static long localMs(String t) {
        if (t == null || t.length() < 10 || !isDay(t.substring(0, 10))) return 0L;
        Calendar c = Calendar.getInstance();
        c.clear();
        int h = 0, mi = 0;
        if (t.length() >= 16) { h = num(t, 11, 13, 0); mi = num(t, 14, 16, 0); }
        c.set(num(t, 0, 4, 1970), num(t, 5, 7, 1) - 1, num(t, 8, 10, 1), h, mi, 0);
        return c.getTimeInMillis();
    }

    /** 12/5 */
    static String fmtDate(String d) {
        if (d == null || d.length() < 10 || !isDay(d.substring(0, 10))) return "未排定";
        return num(d, 5, 7, 0) + "/" + num(d, 8, 10, 0);
    }

    /** 日期欄顯示:今年的日期不寫年份(11/7),別年才寫(2027/1/3)。照網頁版 dateShowText。 */
    static String shortDay(String d) {
        if (d == null || !isDay(d)) return "";
        int y = num(d, 0, 4, 0);
        String md = num(d, 5, 7, 0) + "/" + num(d, 8, 10, 0);
        return y == java.util.Calendar.getInstance().get(java.util.Calendar.YEAR) ? md : y + "/" + md;
    }

    static boolean overdueDate(String due, boolean done) {
        if (done || due == null || due.length() < 10 || !isDay(due.substring(0, 10))) return false;
        return localMs(due.substring(0, 10)) + 24L * 3600 * 1000 - 1000 < System.currentTimeMillis();
    }

    // ---------- 事項的日期 / 時間 / 提醒(跟網頁版 taskDueMs / isOverdueTask / fmtTaskWhen 一樣) ----------

    /** "HH:mm"(00:00–23:59)。 */
    static boolean isHm(String t) {
        return t != null && t.matches("([01]\\d|2[0-3]):[0-5]\\d");
    }

    /** 事項到期的時間點(毫秒)。只有日期沒設時間 → 當天 08:00(提醒也是這個時間);沒有日期 → 0。 */
    static long taskDueMs(JSONObject t) {
        String d = s(t, "dueDate", "");
        if (d.length() < 10 || !isDay(d.substring(0, 10))) return 0L;
        String hm = s(t, "dueTime", "");
        return localMs(d.substring(0, 10) + "T" + (isHm(hm) ? hm : "08:00"));
    }

    /** 延誤:有設時間的,過了那個時間才算;只有日期的,過了那天才算。 */
    static boolean overdueTask(JSONObject t) {
        if ("done".equals(s(t, "status", ""))) return false;
        String d = s(t, "dueDate", "");
        if (d.length() < 10 || !isDay(d.substring(0, 10))) return false;
        if (isHm(s(t, "dueTime", ""))) {
            long ms = taskDueMs(t);
            return ms > 0 && ms < System.currentTimeMillis();
        }
        return overdueDate(d, false);
    }

    // ---------- 時段(跟網頁版 isRangeTask / taskRemindDates 一樣):事項可以有開始日 startDate → 結束日 dueDate ----------

    static final String[] REMIND_MODE_KEYS = {"daily", "start", "end", "both", "custom"};
    static final String[] REMIND_MODE_NAMES = {"每天", "開始日", "結束日", "開始與結束", "自訂"};
    static final int TASK_RANGE_MAX = 366, TASK_DAILY_HORIZON_DAYS = 14, TASK_CUSTOM_MAX = 60;

    static String remindModeName(String key) {
        for (int i = 0; i < REMIND_MODE_KEYS.length; i++) if (REMIND_MODE_KEYS[i].equals(key)) return REMIND_MODE_NAMES[i];
        return REMIND_MODE_NAMES[2];
    }

    /** 兩個 yyyy-MM-dd 差幾天(b - a)。 */
    static int daysBetween(String a, String b) {
        Calendar x = parse(a), y = parse(b);
        return (int) Math.round((y.getTimeInMillis() - x.getTimeInMillis()) / 86400000.0);
    }

    static boolean isRangeTask(JSONObject t) {
        if (t == null) return false;
        String st = s(t, "startDate", ""), du = s(t, "dueDate", "");
        return isDay(st) && isDay(du) && st.compareTo(du) < 0;
    }

    static int taskRangeDays(JSONObject t) { return isRangeTask(t) ? daysBetween(s(t, "startDate"), s(t, "dueDate")) + 1 : 1; }

    /** day 是時段的第幾天(第 1 天 = 開始日);不在時段裡或不是時段事項 → 0。 */
    static int taskRangeDayNo(JSONObject t, String day) {
        if (!isRangeTask(t) || day.compareTo(s(t, "startDate")) < 0 || day.compareTo(s(t, "dueDate")) > 0) return 0;
        return daysBetween(s(t, "startDate"), day) + 1;
    }

    /** 11/4 – 11/12 或 11/4 – 11/12 08:30 */
    static String fmtTaskRange(JSONObject t) {
        String hm = s(t, "dueTime", "");
        return fmtDate(s(t, "startDate")) + " – " + fmtDate(s(t, "dueDate")) + (isHm(hm) ? " " + hm : "");
    }

    /** 時段進行到哪(給卡片顯示):N 天後開始 / 第 i / n 天 / 今天結束;已完成、已過結束日、單日事項回空字串。 */
    static String rangeStatusText(JSONObject t) {
        if (!isRangeTask(t) || "done".equals(s(t, "status", ""))) return "";
        String today = today(), st = s(t, "startDate"), du = s(t, "dueDate");
        if (today.compareTo(st) < 0) return daysBetween(today, st) + " 天後開始";
        if (today.compareTo(du) > 0) return "";
        return today.equals(du) ? "今天結束" : "第 " + (daysBetween(st, today) + 1) + " / " + taskRangeDays(t) + " 天";
    }

    /** 時段進度 0~100(還沒開始 0、過了結束日 100)。 */
    static int rangePct(JSONObject t) {
        if (!isRangeTask(t) || "done".equals(s(t, "status", ""))) return 0;
        String today = today(), st = s(t, "startDate"), du = s(t, "dueDate");
        if (today.compareTo(st) < 0) return 0;
        if (today.compareTo(du) > 0) return 100;
        return (int) Math.round((daysBetween(st, today) + 1) * 100.0 / taskRangeDays(t));
    }

    /** 排序用的時間:時段事項照開始日排,其他照到期時間。 */
    static long taskSortMs(JSONObject t) {
        if (isRangeTask(t)) return localMs(s(t, "startDate"));
        return taskDueMs(t);
    }

    static String remindMode(JSONObject t) {
        String m = s(t, "remindMode", "end");
        for (String k : REMIND_MODE_KEYS) if (k.equals(m)) return m;
        return "end";
    }

    /** 這件事要在哪些日子提醒。單日事項 = 結束日那天;每天只排最近 14 天(之後每次同步會再往後補)。 */
    static List<String> taskRemindDates(JSONObject t) {
        List<String> out = new ArrayList<>();
        String due = s(t, "dueDate", "");
        if (!isDay(due)) return out;
        if (!isRangeTask(t)) { out.add(due); return out; }
        String st = s(t, "startDate"), m = remindMode(t);
        if ("end".equals(m)) out.add(due);
        else if ("start".equals(m)) out.add(st);
        else if ("both".equals(m)) { out.add(st); out.add(due); }
        else if ("custom".equals(m)) {
            JSONArray ds = t.optJSONArray("remindDates");
            java.util.TreeSet<String> set = new java.util.TreeSet<>();
            for (int i = 0; ds != null && i < ds.length(); i++) {
                String d = ds.optString(i, "");
                if (isDay(d) && d.compareTo(st) >= 0 && d.compareTo(due) <= 0) set.add(d);
            }
            out.addAll(set);
        } else {
            String today = today(), limit = addDays(today, TASK_DAILY_HORIZON_DAYS);
            String d = st.compareTo(today) > 0 ? st : today;
            for (; d.compareTo(due) <= 0 && d.compareTo(limit) <= 0; d = addDays(d, 1)) out.add(d);
        }
        return out;
    }

    /** 提醒時間(毫秒):沒設時間就是早上 8:00。 */
    static List<Long> taskRemindMsList(JSONObject t) {
        String hm = s(t, "dueTime", "");
        String tm = isHm(hm) ? hm : "08:00";
        List<Long> out = new ArrayList<>();
        for (String d : taskRemindDates(t)) { long ms = localMs(d + "T" + tm); if (ms > 0) out.add(ms); }
        return out;
    }

    /** 12/5 或 12/5 08:30 */
    static String fmtTaskWhen(JSONObject t) {
        String hm = s(t, "dueTime", "");
        return fmtDate(s(t, "dueDate", "")) + (isHm(hm) ? " " + hm : "");
    }
}
