package tw.jishibu.widget;

import android.app.AlertDialog;
import android.appwidget.AppWidgetManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Locale;

/** 設定:連結帳號、同步、放桌面小工具。 */
final class SettingsScreen extends Screen {
    private EditText codeBox;

    SettingsScreen(MainActivity a) { super(a); }

    @Override
    boolean needsData() { return false; }

    @Override
    void build() {
        content.addView(Ui.tv(a, "設定", 26, Ui.INK, true));

        // 狀態
        LinearLayout st = Ui.card(a);
        StringBuilder s = new StringBuilder();
        if (!Store.linked(a)) {
            s.append("尚未連結");
        } else {
            s.append("已連結 ").append(Store.email(a));
            long ts = Store.syncTs(a);
            if (ts > 0) {
                Calendar t = Calendar.getInstance();
                t.setTimeInMillis(ts);
                s.append(String.format(Locale.TAIWAN, "\n上次同步 %d/%d %02d:%02d", t.get(Calendar.MONTH) + 1,
                        t.get(Calendar.DAY_OF_MONTH), t.get(Calendar.HOUR_OF_DAY), t.get(Calendar.MINUTE)));
            }
            int p = Repo.pendingCount();
            if (p > 0) s.append("\n還有 ").append(p).append(" 筆變更尚未同步");
            String err = Repo.lastError().isEmpty() ? Store.error(a) : Repo.lastError();
            if (!err.isEmpty()) s.append("\n同步問題:").append(err);
        }
        st.addView(Ui.tv(a, s.toString(), 15, Ui.INK, false));
        content.addView(st, Ui.mw(a, 14));

        if (!Store.linked(a)) {
            LinearLayout how = Ui.card(a);
            how.addView(Ui.tv(a, "怎麼連結", 16, Ui.INK, true));
            how.addView(Ui.tv(a, "1. 用瀏覽器開啟記事簿網頁並登入\n2. 設定 → 桌面小工具 → 按「連結桌面小工具」\n   (沒有跳回這裡的話,按「複製連結碼」,回來貼在下面)", 14, Ui.SOFT, false), Ui.mw(a, 6));
            codeBox = new EditText(a);
            codeBox.setHint("在這裡貼上連結碼");
            codeBox.setMaxLines(3);
            how.addView(codeBox, Ui.mw(a, 8));
            TextView go = Ui.pill(a, "連結", true);
            go.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    String code = codeBox.getText().toString().trim();
                    if (code.isEmpty()) code = clipboard();
                    if (code.isEmpty()) { Ui.toast(a, "沒有連結碼,請先在網頁複製"); return; }
                    a.linkWith(code);
                }
            });
            how.addView(go, Ui.mw(a, 10));
            content.addView(how, Ui.mw(a, 12));
        } else {
            addBtn("立即同步", true, new View.OnClickListener() {
                @Override public void onClick(View v) { a.syncNowAsync(true); }
            });
        }

        addBtn("把月曆小工具放到桌面", false, new View.OnClickListener() {
            @Override public void onClick(View v) { pinWidget(); }
        });
        addBtn("開啟網頁版記事簿", false, new View.OnClickListener() {
            @Override public void onClick(View v) {
                String o = Store.origin(a);
                if (o.isEmpty()) { Ui.toast(a, "連結後才能開啟"); return; }
                a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(o)));
            }
        });
        if (Store.linked(a)) {
            addBtn("取消連結", false, new View.OnClickListener() {
                @Override public void onClick(View v) {
                    new AlertDialog.Builder(a)
                            .setMessage("取消連結後,這支手機上的資料副本會清掉(雲端資料不受影響)。確定嗎?")
                            .setNegativeButton("取消", null)
                            .setPositiveButton("取消連結", new DialogInterface.OnClickListener() {
                                @Override public void onClick(DialogInterface d, int w) {
                                    Store.clearLink(a);
                                    Repo.clear(a);
                                    CalendarWidget.renderAll(a);
                                    refresh();
                                }
                            }).show();
                }
            });
        }

        LinearLayout info = Ui.card(a);
        info.addView(Ui.tv(a, "第一版有哪些功能", 16, Ui.INK, true));
        info.addView(Ui.tv(a, "已經有:今天、清單(完成、新增事項)、行事曆、習慣打卡、桌面月曆小工具。\n\n"
                + "還沒有:記帳、隨手記、搜尋、書籤、統計、每日提醒與推播、編輯/刪除事項、新增習慣。這些請先用網頁版,兩邊資料會自動同步。", 14, Ui.SOFT, false), Ui.mw(a, 6));
        content.addView(info, Ui.mw(a, 18));
    }

    private void addBtn(String label, boolean filled, View.OnClickListener l) {
        TextView b = Ui.pill(a, label, filled);
        b.setOnClickListener(l);
        content.addView(b, Ui.mw(a, 12));
    }

    private String clipboard() {
        try {
            ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData d = cm.getPrimaryClip();
            if (d != null && d.getItemCount() > 0 && d.getItemAt(0).getText() != null) {
                return d.getItemAt(0).getText().toString().trim();
            }
        } catch (Exception ignore) { }
        return "";
    }

    private void pinWidget() {
        AppWidgetManager m = a.getSystemService(AppWidgetManager.class);
        if (m != null && m.isRequestPinAppWidgetSupported()) {
            m.requestPinAppWidget(new ComponentName(a, CalendarWidget.class), null, null);
        } else {
            Ui.toast(a, "請長按桌面空白處 → Widgets → 記事簿");
        }
    }
}
