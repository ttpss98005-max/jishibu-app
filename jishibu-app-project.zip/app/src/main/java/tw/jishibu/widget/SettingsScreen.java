package tw.jishibu.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.OutputStream;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * 設定頁(網頁版 view-settings):帳戶、推播、每日提醒、回顧小結、資料備份、書籤、配色。
 * 開發者工具:只有開發者帳號看得到(DevTools)。不做:「清除所有資料」(清除整份資料太危險,不放在手機版)。
 * 還原備份檔也不放在手機版:還原會整份取代資料,請用網頁版(手機版只做匯出)。
 */
final class SettingsScreen extends ScrollScreen {
    private TextView sizeText, archiveHint;
    private SizeBar sizeBar;
    private boolean exporting = false;

    SettingsScreen(MainActivity a) { super(a); }

    @Override boolean needsData() { return false; }

    @Override
    void refresh() {
        final int y = scroll.getScrollY();
        super.refresh();
        scroll.post(new Runnable() {
            @Override public void run() { scroll.scrollTo(0, y); }
        });
    }

    @Override
    void build() {
        boolean ready = Store.linked(a) && Repo.data() != null;
        accountBlock();
        if (ready) greetBlock();
        if (ready) {
            dailyBlock();
            summaryBlock();
            backupBlock();
            bookmarkBlock();
            paletteBlock();
            categoryPaletteBlock();
            content.addView(Ui.btnGhost(a, "重設為預設外觀", new View.OnClickListener() {
                @Override public void onClick(View v) { resetTheme(); }
            }), Ui.wrap(a, 22));
        }
        content.addView(Ui.spacer(a, 24));
    }

    // ---------- 共用小零件 ----------

    private LinearLayout toggleRow(String label, boolean on, Ui.BoolCb cb) {
        LinearLayout row = Ui.row(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView t = Ui.tv(a, label, 13, Ui.INK, false);
        row.addView(t, Ui.weight(1));
        row.addView(Ui.toggle(a, on, cb));
        return row;
    }

    // ---------- 帳戶 ----------

    private void accountBlock() {
        content.addView(Ui.blockTitle(a, "帳戶"));
        LinearLayout card = Ui.card(a);
        if (!Store.linked(a)) {
            card.addView(Ui.tv(a, "尚未登入", 13, Ui.CARD_INK, true));
            card.addView(Ui.tv(a, "用你在網頁版登入的同一個 Google 帳號登入,資料就會自動同步過來。", 12.5f, Ui.SOFT, false), Ui.mw(a, 6));
            card.addView(Ui.btnPrimary(a, "使用 Google 登入", new View.OnClickListener() {
                @Override public void onClick(View v) { a.googleLogin(); }
            }), Ui.mw(a, 12));
        } else {
            card.addView(Ui.tv(a, Store.email(a).isEmpty() ? "已連結" : Store.email(a), 13, Ui.CARD_INK, true));
            StringBuilder s = new StringBuilder();
            long ts = Store.syncTs(a);
            if (ts > 0) {
                Calendar t = Calendar.getInstance();
                t.setTimeInMillis(ts);
                s.append(String.format(Locale.TAIWAN, "上次同步 %d/%d %02d:%02d", t.get(Calendar.MONTH) + 1,
                        t.get(Calendar.DAY_OF_MONTH), t.get(Calendar.HOUR_OF_DAY), t.get(Calendar.MINUTE)));
            }
            int p = Repo.pendingCount();
            if (p > 0) s.append(s.length() > 0 ? "\n" : "").append("還有 ").append(p).append(" 筆變更尚未同步");
            String err = Repo.lastError().isEmpty() ? Store.error(a) : Repo.lastError();
            if (!err.isEmpty()) s.append(s.length() > 0 ? "\n" : "").append("同步問題:").append(err);
            if (s.length() > 0) card.addView(Ui.tv(a, s.toString(), 11.5f, Ui.SOFT, false), Ui.mw(a, 3));
            LinearLayout btns = Ui.row(a);
            btns.addView(Ui.btnGhost(a, "立即同步", new View.OnClickListener() {
                @Override public void onClick(View v) { a.syncNowAsync(true); }
            }));
            TextView out = Ui.tv(a, "登出／切換帳號", 11.5f, Ui.SOFT, false);
            out.setPadding(Ui.dp(a, 14), Ui.dp(a, 9), Ui.dp(a, 14), Ui.dp(a, 9));
            out.setBackground(Ui.shape(a, Ui.CHIP_BG, 999, 0, 0));
            out.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { logout(); }
            });
            btns.addView(out, Ui.gap(a, 8));
            card.addView(btns, Ui.mw(a, 12));
            if (DevTools.isDev(a)) {
                card.addView(Ui.btnGhost(a, "開發者工具", new View.OnClickListener() {
                    @Override public void onClick(View v) { DevTools.open(a); }
                }), Ui.mw(a, 14));
            }
        }
        content.addView(card, Ui.mw(a, 0));
    }

    private void logout() {
        if (Repo.pendingCount() > 0) {
            Modal.confirm(a, "還有變更沒有同步", "有 " + Repo.pendingCount() + " 筆變更還沒存到雲端。建議先按「立即同步」,成功後再登出。如果一直同步不了,也可以選「仍要登出」,這些變更會另存在手機裡但不會進到雲端。", "仍要登出", true, new Runnable() {
                @Override public void run() {
                    Repo.stashPending(a);
                    doLogout();
                }
            });
            return;
        }
        Modal.confirm(a, "要登出嗎？", "登出後,這支手機上的資料副本會清掉(雲端資料不受影響)。之後可以重新連結。", "登出", false, new Runnable() {
            @Override public void run() { doLogout(); }
        });
    }

    private void doLogout() {
        Store.clearLink(a);
        Repo.clear(a);
        LocalAlerts.reschedule(a);
        CalendarWidget.renderAll(a);
        Widgets.renderAll(a);
        a.showLogin();
    }

    // ---------- 推播 ----------

    private void greetBlock() {
        content.addView(Ui.blockTitle(a, "推播通知"));
        LinearLayout box = Ui.col(a);
        box.addView(toggleRow("這支手機的提醒通知", LocalAlerts.enabled(a), new Ui.BoolCb() {
            @Override public void on(boolean value) {
                LocalAlerts.setEnabled(a, value);
                if (value) a.askNotifyPermission();
                a.flash(value ? "已開啟提醒通知" : "已關閉提醒通知");
            }
        }));
        box.addView(Ui.hint(a, "待辦細項的提醒、習慣的提醒時間會直接在這支手機跳出通知，App 沒開也會響、不用網路。如果這支手機同時也裝了網頁版並開了推播，可能會收到兩次，到時關掉其中一邊即可。"));
        box.addView(toggleRow("早晚安推播", DailyNotify.greetOn(), new Ui.BoolCb() {
            @Override public void on(boolean value) {
                DailyNotify.setGreet(a, value);
                LocalAlerts.reschedule(a);
                if (value) a.askNotifyPermission();
                a.flash(value ? "已開啟早晚安推播" : "已關閉早晚安推播");
            }
        }), Ui.mw(a, 14));
        box.addView(Ui.hint(a, "早上 " + DailyNotify.label(DailyNotify.MORNING_TIME) + " 提醒今天的習慣，晚上 " + DailyNotify.label(DailyNotify.NIGHT_TIME) + " 提醒你回顧今天。"));
        content.addView(box, Ui.mw(a, 0));
    }

    // ---------- 每日提醒 ----------

    private void dailyBlock() {
        content.addView(Ui.blockTitle(a, "每日提醒"));
        JSONObject d = Repo.data();
        boolean briefOn = !Model.today().equals(Model.s(d, "dailyBriefDismissedDate"));
        LinearLayout box = Ui.col(a);

        LinearLayout row = Ui.row(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(Ui.tv(a, "今天顯示每日提醒", 13, Ui.INK, false), Ui.weight(1));
        TextView view = Ui.tv(a, "查看", 12.5f, Ui.ACCENT, true);
        view.setPadding(Ui.dp(a, 10), Ui.dp(a, 4), Ui.dp(a, 10), Ui.dp(a, 4));
        view.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { Recap.showBrief(a); }
        });
        row.addView(view);
        row.addView(Ui.toggle(a, briefOn, new Ui.BoolCb() {
            @Override public void on(boolean value) {
                if (value) Repo.set(a, JSONObject.NULL, "dailyBriefDismissedDate");
                else Repo.set(a, Model.today(), "dailyBriefDismissedDate");
            }
        }), Ui.gap(a, 10));
        box.addView(row);

        box.addView(toggleRow("早上自動顯示早安動畫", !d.optBoolean("morningGreetingDisabled", false), new Ui.BoolCb() {
            @Override public void on(boolean value) {
                Repo.set(a, !value, "morningGreetingDisabled");
                a.flash(value ? "已開啟早安動畫" : "已關閉早安動畫");
            }
        }), Ui.mw(a, 14));
        box.addView(toggleRow("晚上自動顯示回顧動畫", !d.optBoolean("nightRecapDisabled", false), new Ui.BoolCb() {
            @Override public void on(boolean value) {
                Repo.set(a, !value, "nightRecapDisabled");
                a.flash(value ? "已開啟晚上回顧動畫" : "已關閉晚上回顧動畫");
            }
        }), Ui.mw(a, 14));
        box.addView(toggleRow("特別的日子到了顯示慶祝動畫", !d.optBoolean("specialCelebrateDisabled", false), new Ui.BoolCb() {
            @Override public void on(boolean value) {
                Repo.set(a, !value, "specialCelebrateDisabled");
                a.flash(value ? "已開啟慶祝動畫" : "已關閉慶祝動畫");
            }
        }), Ui.mw(a, 14));
        content.addView(box, Ui.mw(a, 0));
    }

    // ---------- 回顧小結 ----------

    private void summaryBlock() {
        content.addView(Ui.blockTitle(a, "回顧小結"));
        LinearLayout row = Ui.row(a);
        row.addView(Ui.btnGhost(a, "本週小結", new View.OnClickListener() {
            @Override public void onClick(View v) { openSummary(0); }
        }));
        row.addView(Ui.btnGhost(a, "本月小結", new View.OnClickListener() {
            @Override public void onClick(View v) { openSummary(1); }
        }), Ui.gap(a, 8));
        content.addView(row, Ui.mw(a, 0));
    }

    private void openSummary(int range) {
        final Modal.Sheet s = Modal.sheet(a);
        final LinearLayout body = Ui.col(a);
        s.box.addView(Ui.pillTabs(a, new String[]{"本週", "本月"}, range, new Ui.IntCb() {
            @Override public void on(int i) { fillSummary(body, i); }
        }), Ui.mw(a, 0));
        s.box.addView(body, Ui.mw(a, 16));
        fillSummary(body, range);
        s.dialog.show();
    }

    private void fillSummary(LinearLayout body, int range) {
        body.removeAllViews();
        int days = range == 0 ? 7 : 30;
        String label = range == 0 ? "本週" : "本月";
        java.util.HashSet<String> window = new java.util.HashSet<>();
        for (int i = days - 1; i >= 0; i--) window.add(Model.addDays(Model.today(), -i));

        int completed = 0;
        for (JSONObject t : Model.tasks()) {
            if ("done".equals(Model.s(t, "status"))) completed++;
        }
        int notes = 0;
        for (JSONObject n : Model.list("quickNotes")) {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(n.optLong("createdAt", 0L));
            if (window.contains(Model.ymd(c))) notes++;
        }
        List<JSONObject> habits = Model.habits();
        int[] rates = new int[habits.size()];
        int sum = 0;
        for (int i = 0; i < habits.size(); i++) {
            int done = 0;
            for (String day : window) if (Model.habitChecked(Model.s(habits.get(i), "id"), day)) done++;
            rates[i] = Math.round(done * 100f / days);
            sum += rates[i];
        }
        int avg = habits.isEmpty() ? 0 : Math.round(sum / (float) habits.size());

        body.addView(Ui.tv(a, label + "小結", 18, Ui.CARD_INK, true));
        body.addView(countRow("完成了 ", String.valueOf(completed), " 項事項／細項"), Ui.mw(a, 16));
        body.addView(countRow("寫了 ", String.valueOf(notes), " 則隨手記"), Ui.mw(a, 10));
        if (!habits.isEmpty()) {
            body.addView(Ui.tv(a, "習慣平均達成率 " + avg + "%", 11, Ui.SOFT, true), Ui.mw(a, 18));
            for (int i = 0; i < habits.size(); i++) body.addView(rateRow(Model.s(habits.get(i), "name"), rates[i]), Ui.mw(a, i == 0 ? 8 : 9));
        }
    }

    private View countRow(String pre, String n, String post) {
        LinearLayout box = Ui.col(a);
        LinearLayout row = Ui.row(a);
        row.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 8));
        row.addView(Ui.tv(a, pre, 13.5f, Ui.CARD_INK, false));
        row.addView(Ui.tv(a, n, 13.5f, Ui.CARD_INK, true));
        row.addView(Ui.tv(a, post, 13.5f, Ui.CARD_INK, false));
        box.addView(row);
        box.addView(Ui.hline(a));
        return box;
    }

    private View rateRow(String label, int val) {
        LinearLayout row = Ui.row(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView l = Ui.tv(a, label, 11.5f, Ui.SOFT, false);
        l.setSingleLine(true);
        l.setEllipsize(TextUtils.TruncateAt.END);
        row.addView(l, new LinearLayout.LayoutParams(Ui.dp(a, 52), -2));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, Ui.dp(a, 8), 1f);
        bp.leftMargin = Ui.dp(a, 10);
        bp.rightMargin = Ui.dp(a, 10);
        row.addView(new RateBar(a, val), bp);
        TextView v = Ui.tv(a, val + "%", 11.5f, Ui.SOFT, false);
        v.setGravity(Gravity.END);
        row.addView(v, new LinearLayout.LayoutParams(Ui.dp(a, 40), -2));
        return row;
    }

    // ---------- 資料備份 ----------

    private final class SizeBar extends View {
        private float pct = 0f;
        private int color = Ui.ACCENT;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        SizeBar() { super(a); }

        void set(float target, int c) {
            color = c;
            ValueAnimator va = ValueAnimator.ofFloat(pct, target);
            va.setDuration(600);
            va.setInterpolator(new DecelerateInterpolator(2f));
            va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator an) { pct = (Float) an.getAnimatedValue(); invalidate(); }
            });
            va.start();
        }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFEDEDE8);
            c.drawRoundRect(new RectF(0, 0, w, h), h / 2f, h / 2f, p);
            float fw = w * Math.max(0f, Math.min(100f, pct)) / 100f;
            if (fw > 0.5f) {
                p.setColor(color);
                c.drawRoundRect(new RectF(0, 0, Math.max(fw, h), h), h / 2f, h / 2f, p);
            }
        }
    }

    private void backupBlock() {
        content.addView(Ui.blockTitle(a, "資料備份"));
        sizeText = Ui.tv(a, "目前資料量：計算中…", 13, Ui.INK, true);
        content.addView(sizeText, Ui.mw(a, 0));
        sizeBar = new SizeBar();
        content.addView(sizeBar, new LinearLayout.LayoutParams(-1, Ui.dp(a, 8)));
        Ui.lp(sizeBar).topMargin = Ui.dp(a, 8);
        archiveHint = Ui.hint(a, "");
        content.addView(archiveHint);
        content.addView(Ui.btnGhost(a, "匯出備份檔", new View.OnClickListener() {
            @Override public void onClick(View v) { exportBackup(); }
        }), Ui.wrap(a, 12));
        content.addView(Ui.btnGhost(a, "從備份檔還原", new View.OnClickListener() {
            @Override public void onClick(View v) { pickRestore(); }
        }), Ui.wrap(a, 8));
        content.addView(Ui.hint(a, "還原前，目前雲端的整份資料會先自動備份，不會直接消失。"), Ui.mw(a, 8));

        final String snap = Repo.data().toString();
        new Thread(new Runnable() {
            @Override public void run() {
                Backup.Info tmp = null;
                try { tmp = Backup.info(snap); } catch (Exception ignore) { }
                final Backup.Info info = tmp;
                a.runOnUiThread(new Runnable() {
                    @Override public void run() { showInfo(info); }
                });
            }
        }).start();
    }

    private void showInfo(Backup.Info info) {
        if (info == null || sizeText == null) return;
        int pct = Math.min(100, Math.round(info.bytes * 100f / Backup.BLOCK_BYTES));
        sizeText.setText("目前資料量：約 " + Math.round(info.bytes / 1024f) + " KB（雲端上限約 1,000 KB，用了 " + pct + "%）");
        int col = info.bytes >= Backup.DANGER_BYTES ? 0xFFC0504D : info.bytes >= Backup.WARN_BYTES ? 0xFFD9A441 : Ui.ACCENT;
        sizeBar.set(pct, col);
        if (info.archiveYears.isEmpty()) {
            archiveHint.setText("");
        } else {
            StringBuilder y = new StringBuilder();
            for (String s : info.archiveYears) { if (y.length() > 0) y.append("、"); y.append(s); }
            archiveHint.setText("已把 " + y + " 年的舊資料壓縮收納，查看時一樣正常。");
        }
    }

    private void exportBackup() {
        if (Repo.data() == null) return;
        a.saveFile(Backup.fileName(), "application/json", new MainActivity.UriCb() {
            @Override public void on(final Uri u) {
                if (exporting) return;
                exporting = true;
                final String snap = Repo.data() == null ? null : Repo.data().toString();   // 在主執行緒先取一份,背景只處理這份複本
                final String email = Store.email(a);
                if (snap == null) { exporting = false; return; }
                new Thread(new Runnable() {
                    @Override public void run() {
                        String msg;
                        try {
                            String json = Backup.exportJson(snap, email);
                            OutputStream os = a.getContentResolver().openOutputStream(u);
                            if (os == null) throw new Exception("無法寫入檔案");
                            os.write(json.getBytes("UTF-8"));
                            os.close();
                            msg = "已匯出備份檔";
                        } catch (Exception e) {
                            msg = "匯出失敗：" + (e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
                        }
                        final String m = msg;
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() { exporting = false; a.flash(m); }
                        });
                    }
                }).start();
            }
        });
    }

    // ---------- 從備份檔還原 ----------

    private boolean restoring;

    private void pickRestore() {
        if (restoring) return;
        if (!Store.linked(a) || Repo.data() == null) { a.flash("請先登入"); return; }
        a.pickFile(new MainActivity.UriCb() {
            @Override public void on(final Uri u) {
                restoring = true;
                new Thread(new Runnable() {
                    @Override public void run() {
                        Restore.Parsed parsed = null;
                        String err = null;
                        try {
                            java.io.InputStream in = a.getContentResolver().openInputStream(u);
                            if (in == null) throw new Exception("讀取檔案失敗，請再試一次");
                            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                            byte[] buf = new byte[16384];
                            int n, total = 0;
                            while ((n = in.read(buf)) > 0) {
                                total += n;
                                if (total > 8 * 1024 * 1024) throw new Exception("檔案太大，不像是記事簿的備份檔");
                                bo.write(buf, 0, n);
                            }
                            in.close();
                            parsed = Restore.read(bo.toString("UTF-8"));
                        } catch (Exception e) {
                            err = e.getMessage() == null ? "格式不正確" : e.getMessage();
                        }
                        final Restore.Parsed pp = parsed;
                        final String ee = err;
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() {
                                restoring = false;
                                if (ee != null) { Modal.alert(a, "這個檔案無法還原", ee + "。你目前的資料沒有任何變動。"); return; }
                                confirmRestore(pp);
                            }
                        });
                    }
                }).start();
            }
        });
    }

    private void confirmRestore(final Restore.Parsed p) {
        String when = "不明";
        if (!p.exportedAt.isEmpty()) {
            try {
                java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
                f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
                java.util.Date d = f.parse(p.exportedAt.substring(0, 19));
                when = new java.text.SimpleDateFormat("yyyy/M/d HH:mm", Locale.TAIWAN).format(d);
            } catch (Exception ignore) { }
        }
        String other = !p.email.isEmpty() && !Store.email(a).isEmpty() && !p.email.equals(Store.email(a))
                ? "\n注意：這份備份來自另一個帳號（" + p.email + "）。" : "";
        String msg = "備份內容（匯出時間 " + when + "）：事項 " + p.tasks + " 項、習慣 " + p.habits + " 個、記帳 " + p.expenses
                + " 筆、隨手記 " + p.quickNotes + " 則、每日回顧 " + p.dayRecaps + " 天。" + other
                + "\n\n還原會取代你現在所有的資料；目前的資料會先自動備份到雲端，不會直接消失。";
        Modal.confirm(a, "要用備份檔還原嗎？", msg, "還原", false, new Runnable() {
            @Override public void run() {
                restoring = true;
                a.flash("還原中…");
                final android.content.Context app = a.getApplicationContext();
                new Thread(new Runnable() {
                    @Override public void run() {
                        final String err = Restore.apply(app, p);
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() {
                                restoring = false;
                                if (err != null) { Modal.alert(a, "沒有還原", err + "。你目前的資料沒有任何變動。"); return; }
                                a.flash("已還原");
                                a.syncNowAsync(false);
                                a.refreshCurrent();
                                a.applyTheme();
                                LocalAlerts.reschedule(a);
                            }
                        });
                    }
                }).start();
            }
        });
    }

    // ---------- 書籤 ----------

    private static boolean safeUrl(String u) {
        String t = u == null ? "" : u.trim().toLowerCase(Locale.US);
        return t.startsWith("http:") || t.startsWith("https:") || t.startsWith("mailto:") || t.startsWith("tel:");
    }

    private void bookmarkBlock() {
        content.addView(Ui.blockTitle(a, "書籤"));
        Flow grid = new Flow(a, 12, 12);
        for (final JSONObject b : Model.list("bookmarks")) {
            final String id = Model.s(b, "id"), title = Model.s(b, "title"), url = Model.s(b, "url");
            FrameLayout card = new FrameLayout(a);
            card.setBackground(Ui.shape(a, 0xFFFFFFFF, 16, Ui.BORDER, 1.5f));
            Ui.soft(card, 2);
            LinearLayout row = Ui.row(a);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(a, 14), Ui.dp(a, 14), Ui.dp(a, 14), Ui.dp(a, 14));
            String domain = "";
            try { String h = Uri.parse(url).getHost(); domain = h == null ? "" : h; } catch (Exception ignore) { }
            if (!domain.isEmpty()) {
                ImageView ic = new ImageView(a);
                row.addView(ic, new LinearLayout.LayoutParams(Ui.dp(a, 18), Ui.dp(a, 18)));
                Ui.lp(ic).rightMargin = Ui.dp(a, 10);
                Favicon.load(a, domain, ic);
            }
            TextView tt = Ui.tv(a, title, 13, Ui.CARD_INK, true);
            tt.setSingleLine(true);
            tt.setEllipsize(TextUtils.TruncateAt.END);
            row.addView(tt, Ui.weight(1));
            card.addView(row, new FrameLayout.LayoutParams(-1, -2));
            final String openUrl = url;
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!safeUrl(openUrl)) { a.flash("這個網址無法開啟"); return; }
                    try { a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(openUrl.trim()))); }
                    catch (Exception e) { a.flash("找不到可以開啟的程式"); }
                }
            });
            TextView del = Ui.tv(a, "刪除", 11, Ui.SOFT, false);
            del.setPadding(Ui.dp(a, 8), Ui.dp(a, 6), Ui.dp(a, 8), Ui.dp(a, 6));
            del.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { deleteBookmark(id); }
            });
            card.addView(del, new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END));
            grid.addView(Flow.grow(card, 150));
        }
        TextView add = Ui.tv(a, "＋ 新增書籤", 12.5f, Ui.SOFT, false);
        add.setGravity(Gravity.CENTER);
        add.setMinimumHeight(Ui.dp(a, 50));
        add.setBackground(Ui.dashed(a, 0xFFFFFFFF, 16, Ui.BORDER, 1.5f));
        add.setPadding(Ui.dp(a, 14), Ui.dp(a, 14), Ui.dp(a, 14), Ui.dp(a, 14));
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openAddBookmark(); }
        });
        grid.addView(Flow.grow(add, 150));
        content.addView(grid, Ui.mw(a, 0));
    }

    private void openAddBookmark() {
        final Form f = new Form(a);
        final Form.Text title = f.text("名稱", "", "例如：我的網站");
        final Form.Text url = f.text("網址", "", "https://");
        Modal.show(a, "新增書籤", f.view(), "新增", new Modal.Ok() {
            @Override public boolean run() {
                String t = title.get(), u = url.get();
                if (t.isEmpty() || u.isEmpty()) { a.flash("請輸入名稱和網址"); return false; }
                if (!u.toLowerCase(Locale.US).startsWith("http://") && !u.toLowerCase(Locale.US).startsWith("https://")) u = "https://" + u;
                JSONObject item = new JSONObject();
                try {
                    item.put("id", Repo.newId());
                    item.put("title", t);
                    item.put("url", u);
                } catch (JSONException e) { return false; }
                Repo.add(a, item, -1, "bookmarks");
                a.refreshCurrent();
                return true;
            }
        });
    }

    private void deleteBookmark(String id) {
        List<JSONObject> all = Model.list("bookmarks");
        int idx = -1;
        for (int i = 0; i < all.size(); i++) if (Model.s(all.get(i), "id").equals(id)) idx = i;
        if (idx < 0) return;
        final JSONObject removed = all.get(idx);
        final int at = idx;
        Repo.del(a, "bookmarks", id);
        a.refreshCurrent();
        a.undo("已刪除書籤「" + Model.s(removed, "title") + "」", new Runnable() {
            @Override public void run() {
                Repo.add(a, removed, at, "bookmarks");
                a.refreshCurrent();
            }
        });
    }

    // ---------- 配色 ----------

    private void paletteBlock() {
        content.addView(Ui.blockTitle(a, "整體配色風格"));
        String sel = Model.s(Repo.data(), "globalPaletteId", "p01");
        Flow grid = new Flow(a, 12, 12);
        for (final Theme.Palette p : Theme.all()) {
            boolean on = p.id.equals(sel);
            FrameLayout wrap = new FrameLayout(a);
            LinearLayout card = Ui.col(a);
            card.setPadding(Ui.dp(a, 11), Ui.dp(a, 11), Ui.dp(a, 11), Ui.dp(a, 11));
            card.setBackground(Ui.shape(a, 0xFFFFFFFF, 16, on ? Ui.ACCENT : Ui.BORDER, on ? 2.5f : 1.5f));
            Ui.soft(card, 2);
            card.addView(new Swatch(a, p.bg, p.ink, p.accent), new LinearLayout.LayoutParams(-1, Ui.dp(a, 28)));
            TextView name = Ui.tv(a, p.name, 11.5f, Ui.CARD_INK, true);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            card.addView(name, Ui.mw(a, 9));
            wrap.addView(card, new FrameLayout.LayoutParams(-1, -2));
            if (on) {
                TextView ck = Ui.tv(a, "✓", 10, Ui.ON_ACCENT, true);
                ck.setGravity(Gravity.CENTER);
                ck.setBackground(Ui.shape(a, Ui.ACCENT, 9, 0, 0));
                FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(Ui.dp(a, 18), Ui.dp(a, 18), Gravity.TOP | Gravity.END);
                cp.topMargin = Ui.dp(a, 9);
                cp.rightMargin = Ui.dp(a, 9);
                wrap.addView(ck, cp);
            }
            wrap.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Repo.set(a, p.id, "globalPaletteId");
                    a.applyTheme();
                }
            });
            grid.addView(Flow.grow(wrap, 110));
        }
        LinearLayout add = Ui.col(a);
        add.setGravity(Gravity.CENTER);
        add.setMinimumHeight(Ui.dp(a, 76));
        add.setBackground(Ui.dashed(a, 0xFFFFFFFF, 16, Ui.BORDER, 1.5f));
        TextView plus = Ui.tv(a, "＋", 16, Ui.SOFT, false);
        plus.setGravity(Gravity.CENTER);
        plus.setBackground(Ui.shape(a, Ui.BORDER, 13, 0, 0));
        add.addView(plus, new LinearLayout.LayoutParams(Ui.dp(a, 26), Ui.dp(a, 26)));
        TextView addLabel = Ui.tv(a, "新增風格", 12, Ui.SOFT, false);
        addLabel.setGravity(Gravity.CENTER);
        add.addView(addLabel, Ui.mw(a, 7));
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openAddPalette(); }
        });
        grid.addView(Flow.grow(add, 110));
        content.addView(grid, Ui.mw(a, 0));
    }

    private static final String[] QUICK = {"#FFFFFF", "#FAFAFA", "#F1F5F0", "#FDF1EF", "#1A1A1A", "#121212", "#2E2438",
            "#3A6B5E", "#2E6F9E", "#E0685A", "#E08A2C", "#D9A441", "#8B6BB5", "#D96C8C", "#8A5A34", "#6B6E76"};

    /** 一個顏色欄:預覽色塊 + #RRGGBB 輸入 + 一排常用色。 */
    private EditText colorField(Form f, String label, String value) {
        final EditText e = Ui.input(a, "#RRGGBB", value);
        final View prev = new View(a);
        prev.setBackground(Ui.shape(a, Theme.parse(value), 8, Ui.BORDER, 1f));
        e.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int x, int y, int z) { }
            @Override public void onTextChanged(CharSequence s, int x, int y, int z) { }
            @Override public void afterTextChanged(Editable s) {
                String t = e.getText().toString().trim();
                if (t.matches("#[0-9A-Fa-f]{6}")) prev.setBackground(Ui.shape(a, Theme.parse(t), 8, Ui.BORDER, 1f));
            }
        });
        LinearLayout row = Ui.row(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(prev, new LinearLayout.LayoutParams(Ui.dp(a, 34), Ui.dp(a, 34)));
        row.addView(e, Ui.gap(a, 10));
        Ui.lp(e).width = 0;
        Ui.lp(e).weight = 1f;
        LinearLayout sw = Ui.row(a);
        for (final String hex : QUICK) {
            View dot = new View(a);
            dot.setBackground(Ui.shape(a, Theme.parse(hex), 12, Ui.BORDER, 1f));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(a, 24), Ui.dp(a, 24));
            lp.rightMargin = Ui.dp(a, 6);
            dot.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { e.setText(hex); }
            });
            sw.addView(dot, lp);
        }
        HorizontalScrollView hs = new HorizontalScrollView(a);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(sw);
        LinearLayout both = Ui.col(a);
        both.addView(row);
        both.addView(hs, Ui.mw(a, 8));
        f.add(Ui.field(a, label, both));
        return e;
    }

    private void openAddPalette() {
        final Form f = new Form(a);
        final Form.Text name = f.text("風格名稱", "", "例如：我的風格");
        final EditText bg = colorField(f, "背景顏色", "#FAFAFA");
        final EditText ink = colorField(f, "文字顏色", "#1A1A1A");
        final EditText accent = colorField(f, "強調色", "#3A6B5E");
        Modal.show(a, "新增自訂風格", f.view(), "新增", new Modal.Ok() {
            @Override public boolean run() {
                String n = name.get();
                if (n.isEmpty()) { a.flash("請輸入風格名稱"); return false; }
                String b = bg.getText().toString().trim(), i = ink.getText().toString().trim(), c = accent.getText().toString().trim();
                if (!b.matches("#[0-9A-Fa-f]{6}") || !i.matches("#[0-9A-Fa-f]{6}") || !c.matches("#[0-9A-Fa-f]{6}")) {
                    a.flash("顏色請輸入 # 加 6 碼，例如 #3A6B5E");
                    return false;
                }
                JSONObject item = new JSONObject();
                try {
                    item.put("id", "custom-" + Repo.newId());
                    item.put("name", n);
                    item.put("bg", b);
                    item.put("ink", i);
                    item.put("accent", c);
                } catch (JSONException e) { return false; }
                Repo.add(a, item, -1, "customPalettes");
                a.refreshCurrent();
                return true;
            }
        });
    }

    private void categoryPaletteBlock() {
        content.addView(Ui.blockTitle(a, "各分類專屬配色"));
        final List<Theme.Palette> all = Theme.all();
        final String[] names = new String[all.size() + 1];
        names[0] = "跟隨整體配色";
        for (int i = 0; i < all.size(); i++) names[i + 1] = all.get(i).name;
        for (final JSONObject c : Model.categories()) {
            final String cid = Model.s(c, "id");
            String pid = Model.s(c, "paletteId");
            int sel = 0;
            for (int i = 0; i < all.size(); i++) if (all.get(i).id.equals(pid)) sel = i + 1;
            final int selF = sel;
            LinearLayout row = Ui.row(a);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
            row.setBackground(Ui.shape(a, Ui.TASK_BG, 14, Ui.BORDER, 1.5f));
            row.addView(Ui.tv(a, Model.s(c, "name", "?"), 13, Ui.CARD_INK, false), Ui.weight(1));
            TextView pick = Ui.tv(a, names[sel] + "  ▾", 12.5f, Ui.CARD_INK, false);
            pick.setPadding(Ui.dp(a, 12), Ui.dp(a, 7), Ui.dp(a, 12), Ui.dp(a, 7));
            pick.setBackground(Ui.shape(a, Ui.SURFACE, 999, Ui.BORDER, 1.5f));
            pick.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Modal.choose(a, Model.s(c, "name", "?"), names, selF, new Ui.IntCb() {
                        @Override public void on(int i) { setCategoryPalette(cid, i == 0 ? null : all.get(i - 1).id); }
                    });
                }
            });
            row.addView(pick);
            content.addView(row, Ui.mw(a, 8));
        }
    }

    private void setCategoryPalette(String catId, String paletteId) {
        JSONObject set = new JSONObject();
        try { set.put("paletteId", paletteId == null ? JSONObject.NULL : paletteId); } catch (JSONException e) { return; }
        Repo.patch(a, set, null, "categories", catId);
        a.applyTheme();
    }

    private void resetTheme() {
        Repo.set(a, "p01", "globalPaletteId");
        for (JSONObject c : Model.categories()) {
            if (Model.s(c, "paletteId").isEmpty()) continue;
            setCategoryPaletteQuiet(Model.s(c, "id"));
        }
        a.applyTheme();
    }

    private void setCategoryPaletteQuiet(String catId) {
        JSONObject set = new JSONObject();
        try { set.put("paletteId", JSONObject.NULL); } catch (JSONException e) { return; }
        Repo.patch(a, set, null, "categories", catId);
    }
}
