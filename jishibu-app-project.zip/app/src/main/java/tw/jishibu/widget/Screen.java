package tw.jishibu.widget;

import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/** 每個分頁的共同基底:一個可捲動的內容區。 */
abstract class Screen {
    final MainActivity a;
    final ScrollView scroll;
    final LinearLayout content;
    final Runnable again = new Runnable() {
        @Override public void run() { refresh(); }
    };

    Screen(MainActivity a) {
        this.a = a;
        scroll = new ScrollView(a);
        scroll.setBackgroundColor(Ui.BG);
        scroll.setFillViewport(true);
        content = Ui.col(a);
        content.setPadding(Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 28));
        scroll.addView(content, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    View view() { return scroll; }

    void refresh() {
        content.removeAllViews();
        if (!needsData()) { build(); return; }
        if (!Store.linked(a)) {
            note("尚未連結。請到「設定」分頁,依照說明連結你的記事簿資料。");
            return;
        }
        if (Repo.data() == null) {
            String err = Repo.lastError().isEmpty() ? Store.error(a) : Repo.lastError();
            note(err.isEmpty() ? "載入中…" : "載入失敗:" + err + "\n\n到「設定」分頁可以重新同步。");
            return;
        }
        build();
    }

    boolean needsData() { return true; }

    abstract void build();

    void note(String s) {
        android.widget.TextView t = Ui.tv(a, s, 15, Ui.SOFT, false);
        t.setPadding(Ui.dp(a, 4), Ui.dp(a, 40), Ui.dp(a, 4), 0);
        content.addView(t);
    }
}
