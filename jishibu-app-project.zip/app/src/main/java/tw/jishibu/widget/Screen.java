package tw.jishibu.widget;

import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 每個分頁的基底。
 *   view()    這個分頁的根畫面(只建一次)
 *   onShow()  分頁被切換過來時呼叫(預設:refresh)
 *   onHide()  切走時呼叫(停動畫、停計時器)
 *   refresh() 資料變了(同步完成、自己改了東西、換分類、換配色):依 Repo.data() 重建畫面
 *   onBack()  按返回鍵時先問分頁,回 true 表示分頁自己處理了
 * 資料只從 Repo.data() 讀(唯讀!),要改一律用 Repo.set/del/add/patch/order。
 */
abstract class Screen {
    final MainActivity a;

    Screen(MainActivity a) { this.a = a; }

    abstract View view();
    abstract void refresh();
    void onShow() { refresh(); }
    void onHide() { }
    boolean onBack() { return false; }
}

/** 可捲動的內容區分頁(大部分分頁都用這個):子類別只要實作 build(),把畫面放進 content。 */
abstract class ScrollScreen extends Screen {
    final ScrollView scroll;
    final LinearLayout content;

    ScrollScreen(MainActivity a) {
        super(a);
        scroll = new ScrollView(a);
        scroll.setFillViewport(true);
        content = Ui.col(a);
        content.setPadding(Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 16), Ui.dp(a, 24));
        // Android 預設把內容裁在內距範圍內:卡片的陰影、邊緣會被一個看不見的方框切平,像多了一圈跟底色一樣的框。
        content.setClipToPadding(false);
        content.setClipChildren(false);
        scroll.addView(content, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    @Override View view() { return scroll; }

    /** 這個分頁需不需要雲端資料(設定頁不需要,連結要在那裡做)。 */
    boolean needsData() { return true; }

    private boolean rebuilding = false, rebuildAgain = false;

    /** 重畫。重畫到一半又被要求重畫時(輸入框失去焦點 → 自動存檔 → 又要重畫)不能重入,改成這次畫完再畫一次。 */
    @Override
    void refresh() {
        if (rebuilding) { rebuildAgain = true; return; }
        rebuilding = true;
        try {
            rebuild();
        } finally {
            rebuilding = false;
        }
        if (rebuildAgain) {
            rebuildAgain = false;
            scroll.post(new Runnable() { @Override public void run() { refresh(); } });
        }
    }

    private void rebuild() {
        scroll.setBackgroundColor(Ui.BG);
        content.removeAllViews();
        if (needsData()) {
            if (!Store.linked(a)) {
                note("尚未連結。請到右上角的「設定」,依照說明連結你的記事簿資料。");
                return;
            }
            if (Repo.data() == null) {
                String err = Repo.lastError().isEmpty() ? Store.error(a) : Repo.lastError();
                note(err.isEmpty() ? "載入中…" : "載入失敗:" + err + "\n\n到右上角的「設定」可以重新同步。");
                return;
            }
        }
        build();
    }

    abstract void build();

    void note(String s) {
        TextView t = Ui.tv(a, s, 15, Ui.SOFT, false);
        t.setPadding(Ui.dp(a, 4), Ui.dp(a, 40), Ui.dp(a, 4), 0);
        content.addView(t);
    }
}
