package tw.jishibu.widget;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

/**
 * 「隨手記」分頁:便利貼牆(被風輕輕吹動)、底部輸入列、貼上動畫、偶爾飄過的葉子(可以抓住再放開)、移至清單/習慣。
 * 資料 quickNotes: [{id, text, createdAt(毫秒)}],畫面上新的在最前面。照網頁版 renderQuickNoteWall / sendQuickNote / startLeafMotion 等。
 */
final class NotesScreen extends Screen {
    private static final int[] COLORS = {0xFFFFF8D6, 0xFFFFE9DC, 0xFFFFE0EC, 0xFFEEE6FF, 0xFFDDF1FF, 0xFFD8F6E1, 0xFFFFF0C7, 0xFFE3F8ED};

    private final FrameLayout root;
    private final ScrollView scroll;
    private final LinearLayout wall;
    private final FrameLayout leafLayer, animLayer;
    private final EditText input;
    private final List<NoteCard> cards = new ArrayList<>();
    private final List<Leaf> leaves = new ArrayList<>();
    private final Random rnd = new Random();
    private ValueAnimator ticker;
    private long startNs, lastNs;
    private boolean visible = false;
    private String enteringId = null;
    private Runnable leafTimer, animTimer;
    private JSONObject flyingNote;

    NotesScreen(MainActivity a) {
        super(a);
        root = new FrameLayout(a);
        scroll = new ScrollView(a);
        scroll.setFillViewport(true);
        scroll.setClipChildren(false);
        wall = Ui.col(a);
        wall.setClipChildren(false);
        wall.setPadding(Ui.dp(a, 20), Ui.dp(a, 18), Ui.dp(a, 20), Ui.dp(a, 110));
        scroll.addView(wall, new ViewGroup.LayoutParams(-1, -2));
        root.addView(scroll, new FrameLayout.LayoutParams(-1, -1));

        // 底部輸入列
        LinearLayout bar = Ui.row(a);
        bar.setBackground(Ui.shape(a, Ui.SURFACE, 20, Ui.BORDER, 1.5f));
        bar.setElevation(Ui.dp(a, 4));
        bar.setPadding(Ui.dp(a, 10), Ui.dp(a, 10), Ui.dp(a, 10), Ui.dp(a, 10));
        input = Ui.multiline(a, "隨手記點什麼...", "", 1);
        input.setTextSize(14);
        input.setMaxLines(5);
        bar.addView(input, new LinearLayout.LayoutParams(0, -2, 1f));
        bar.addView(Ui.btnPrimary(a, "傳送", new View.OnClickListener() {
            @Override public void onClick(View v) { send(); }
        }), Ui.gap(a, 10));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        bp.leftMargin = Ui.dp(a, 16);
        bp.rightMargin = Ui.dp(a, 16);
        bp.bottomMargin = Ui.dp(a, 10);
        root.addView(bar, bp);

        leafLayer = new FrameLayout(a);
        leafLayer.setClipChildren(true);
        root.addView(leafLayer, new FrameLayout.LayoutParams(-1, -1));

        animLayer = new FrameLayout(a);
        animLayer.setVisibility(View.GONE);
        animLayer.setClickable(true);
        root.addView(animLayer, new FrameLayout.LayoutParams(-1, -1));
    }

    @Override View view() { return root; }

    /** 從桌面小工具進來:游標放進輸入框並跳出鍵盤,可以馬上打字。 */
    void focusInput() {
        input.requestFocus();
        android.view.inputmethod.InputMethodManager im =
                (android.view.inputmethod.InputMethodManager) a.getSystemService(android.content.Context.INPUT_METHOD_SERVICE);
        if (im != null) im.showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
    }

    // ---------- 生命週期 ----------

    @Override void onShow() {
        visible = true;
        refresh();
        startTicker();
        scheduleLeaf();
    }

    @Override void onHide() {
        visible = false;
        stopTicker();
        if (leafTimer != null) root.removeCallbacks(leafTimer);
        leafTimer = null;
        leafLayer.removeAllViews();
        leaves.clear();
        if (animTimer != null) root.removeCallbacks(animTimer);
        animTimer = null;
        animLayer.setVisibility(View.GONE);
        animLayer.removeAllViews();
        flyingNote = null;
    }

    @Override boolean onBack() {
        if (animLayer.getVisibility() == View.VISIBLE) { skipAnim(); return true; }
        return false;
    }

    private void startTicker() {
        if (ticker != null) return;
        startNs = System.nanoTime();
        lastNs = startNs;
        ticker = ValueAnimator.ofFloat(0f, 1f);
        ticker.setDuration(1000);
        ticker.setRepeatCount(ValueAnimator.INFINITE);
        ticker.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator an) { tick(); }
        });
        ticker.start();
    }

    private void stopTicker() {
        if (ticker != null) { ticker.cancel(); ticker = null; }
    }

    private void tick() {
        long now = System.nanoTime();
        float t = (now - startNs) / 1e9f;
        float dt = Math.min((now - lastNs) / 1e9f, 0.05f);
        lastNs = now;
        for (NoteCard c : cards) c.setRotation(Sway.angle(c.variant, (t + c.delaySec) / Sway.PERIOD_SEC));
        for (int i = leaves.size() - 1; i >= 0; i--) {
            Leaf lf = leaves.get(i);
            if (!lf.step(dt)) { leafLayer.removeView(lf); leaves.remove(i); }
        }
    }

    // ---------- 牆 ----------

    @Override void refresh() {
        wall.removeAllViews();
        cards.clear();
        scroll.setBackgroundColor(Ui.BG);
        if (!Store.linked(a)) {
            wall.addView(Ui.tv(a, "尚未連結。請到右上角的「設定」,依照說明連結你的記事簿資料。", 15, Ui.SOFT, false));
            return;
        }
        if (Repo.data() == null) {
            String err = Repo.lastError().isEmpty() ? Store.error(a) : Repo.lastError();
            wall.addView(Ui.tv(a, err.isEmpty() ? "載入中…" : "載入失敗:" + err, 15, Ui.SOFT, false));
            return;
        }
        List<JSONObject> notes = Model.list("quickNotes");
        if (notes.isEmpty()) {
            wall.addView(Ui.empty(a, "牆上還沒有便利貼,寫點什麼吧"));
            return;
        }
        // 新的在前面
        List<JSONObject> rev = new ArrayList<>();
        for (int i = notes.size() - 1; i >= 0; i--) rev.add(notes.get(i));
        int screenW = a.getResources().getDisplayMetrics().widthPixels;
        int avail = screenW - Ui.dp(a, 40), gap = Ui.dp(a, 16), colW = Ui.dp(a, 150);
        int cols = Math.max(1, (avail + gap) / (colW + gap));
        int per = (rev.size() + cols - 1) / cols;
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setClipChildren(false);
        for (int c = 0; c < cols; c++) {
            LinearLayout col = Ui.col(a);
            col.setClipChildren(false);
            for (int i = c * per; i < Math.min(rev.size(), (c + 1) * per); i++) {
                col.addView(noteRow(rev.get(i)));
            }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (c > 0) lp.leftMargin = gap;
            row.addView(col, lp);
        }
        wall.addView(row, new LinearLayout.LayoutParams(-1, -2));
        enteringId = null;
    }

    static int hash31(String id) {
        int h = 0;
        for (int i = 0; i < id.length(); i++) h = (h * 31 + id.charAt(i)) % COLORS.length;
        return Math.abs(h);
    }

    static int hash17(String id) {
        int h = 0;
        for (int i = 0; i < id.length(); i++) h = (h * 17 + id.charAt(i)) % 1000;
        return Math.abs(h);
    }

    static int noteColor(String id) { return COLORS[hash31(id)]; }

    private View noteRow(JSONObject n) {
        String id = Model.s(n, "id");
        int hash = hash17(id);
        int variant = (hash % 6) + 1;
        float delay = (hash % 9) / 6f;       // 網頁版是 -((hash%9)/6) 秒:從一圈的中間開始
        int pct = 78 + (hash % 23);
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setClipChildren(false);
        NoteCard card = new NoteCard(a, n, variant, delay);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -2, pct);
        row.addView(card, cp);
        if (pct < 100) row.addView(new View(a), new LinearLayout.LayoutParams(0, 1, 100 - pct));
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.bottomMargin = Ui.dp(a, 16);
        row.setLayoutParams(rp);
        cards.add(card);
        if (id.equals(enteringId)) {
            card.setAlpha(0f);
            ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
            va.setDuration(500);
            final NoteCard fc = card;
            va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator an) { fc.setAlpha((Float) an.getAnimatedValue()); }
            });
            va.start();
        }
        return row;
    }

    /** 一張便利貼:頂端圖釘、右上角 ×、右下角「移至」、文字與時間;以頂端中點為軸心擺動。 */
    private final class NoteCard extends FrameLayout {
        final int variant;
        final float delaySec;

        NoteCard(Context c, final JSONObject n, int variant, float delaySec) {
            super(c);
            this.variant = variant;
            this.delaySec = delaySec;
            final String id = Model.s(n, "id");
            setClipChildren(false);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(noteColor(id));
            bg.setCornerRadius(Ui.dp(c, 4));
            setBackground(bg);
            setElevation(Ui.dp(c, 3));

            LinearLayout col = Ui.col(c);
            col.setPadding(Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14));
            TextView text = Ui.tv(c, Model.s(n, "text"), 13, 0xFF1A1A1A, false);
            text.setLineSpacing(0, 1.25f);
            col.addView(text, new LinearLayout.LayoutParams(-1, -2));
            Calendar cal = Calendar.getInstance();
            cal.setTimeInMillis(n.optLong("createdAt", 0L));
            String label = (cal.get(Calendar.MONTH) + 1) + "/" + cal.get(Calendar.DAY_OF_MONTH) + " "
                    + String.format(java.util.Locale.US, "%02d:%02d", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE));
            TextView time = Ui.tv(c, label, 10, 0x66000000, false);
            time.setPadding(0, 0, Ui.dp(c, 44), 0);
            col.addView(time, Ui.mw(c, 10));
            addView(col, new FrameLayout.LayoutParams(-1, -2));

            // 圖釘
            View pin = new View(c);
            GradientDrawable pg = new GradientDrawable();
            pg.setColor(0xFFD4D4CF);
            pg.setCornerRadius(Ui.dp(c, 6));
            pin.setBackground(pg);
            pin.setElevation(Ui.dp(c, 3));
            FrameLayout.LayoutParams pl = new FrameLayout.LayoutParams(Ui.dp(c, 11), Ui.dp(c, 11), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
            pl.topMargin = -Ui.dp(c, 5);
            addView(pin, pl);

            // 刪除
            TextView del = Ui.tv(c, "×", 15, 0x4D000000, false);
            del.setGravity(Gravity.CENTER);
            del.setContentDescription("刪除這則隨手記");
            FrameLayout.LayoutParams dl = new FrameLayout.LayoutParams(Ui.dp(c, 34), Ui.dp(c, 34), Gravity.TOP | Gravity.END);
            dl.topMargin = -Ui.dp(c, 4);
            dl.rightMargin = -Ui.dp(c, 2);
            del.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { deleteNote(id); }
            });
            addView(del, dl);

            // 移至
            TextView mv = Ui.tv(c, "移至", 11.5f, 0x80000000, false);
            mv.setPadding(Ui.dp(c, 8), Ui.dp(c, 3), Ui.dp(c, 8), Ui.dp(c, 3));
            GradientDrawable mg = new GradientDrawable();
            mg.setColor(0x14000000);
            mg.setCornerRadius(Ui.dp(c, 12));
            mv.setBackground(mg);
            FrameLayout.LayoutParams ml = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
            ml.bottomMargin = Ui.dp(c, 4);
            ml.rightMargin = Ui.dp(c, 6);
            mv.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openMove(id); }
            });
            addView(mv, ml);
        }

        @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            setPivotX(w / 2f);
            setPivotY(0f);
        }
    }

    // ---------- 新增 / 刪除 ----------

    private void send() {
        String text = input.getText().toString().trim();
        if (text.isEmpty()) return;
        JSONObject note = new JSONObject();
        try {
            note.put("id", Repo.newId());
            note.put("text", text);
            note.put("createdAt", System.currentTimeMillis());
        } catch (JSONException ignore) { }
        Repo.add(a, note, -1, "quickNotes");
        input.setText("");
        playStick(note);
    }

    /** 貼上動畫:便利貼從中間放大出現,0.5 秒落下縮小,0.9 秒後貼到牆上。 */
    private void playStick(JSONObject note) {
        flyingNote = note;
        animLayer.removeAllViews();
        animLayer.setAlpha(1f);
        animLayer.setVisibility(View.VISIBLE);
        final TextView fly = Ui.tv(a, Model.s(note, "text"), 13, 0xFF1A1A1A, false);
        fly.setPadding(Ui.dp(a, 14), Ui.dp(a, 14), Ui.dp(a, 14), Ui.dp(a, 14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(noteColor(Model.s(note, "id")));
        bg.setCornerRadius(Ui.dp(a, 4));
        fly.setBackground(bg);
        fly.setElevation(Ui.dp(a, 6));
        fly.setScaleX(1.3f);
        fly.setScaleY(1.3f);
        animLayer.addView(fly, new FrameLayout.LayoutParams(Ui.dp(a, 140), -2, Gravity.CENTER));
        final float drop = Ui.dp(a, 140);
        ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(500);
        va.setInterpolator(new OvershootInterpolator(1.4f));
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator an) {
                float t = (Float) an.getAnimatedValue();
                float s = 1.3f + (0.85f - 1.3f) * t;
                fly.setScaleX(s);
                fly.setScaleY(s);
                fly.setRotation(-4f * t);
                fly.setTranslationY(drop * t);
                fly.setAlpha(1f - 0.1f * Math.min(1f, t));
            }
        });
        va.start();
        animLayer.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { skipAnim(); }
        });
        if (animTimer != null) root.removeCallbacks(animTimer);
        animTimer = new Runnable() { @Override public void run() { skipAnim(); } };
        root.postDelayed(animTimer, 900);
    }

    private void skipAnim() {
        if (animTimer != null) { root.removeCallbacks(animTimer); animTimer = null; }
        if (animLayer.getVisibility() != View.VISIBLE) return;
        JSONObject note = flyingNote;
        flyingNote = null;
        if (note != null) enteringId = Model.s(note, "id");
        refresh();
        ValueAnimator va = ValueAnimator.ofFloat(1f, 0f);
        va.setDuration(400);
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator an) {
                float t = (Float) an.getAnimatedValue();
                animLayer.setAlpha(t);
                if (t <= 0f) { animLayer.setVisibility(View.GONE); animLayer.removeAllViews(); }
            }
        });
        va.start();
    }

    private void deleteNote(final String id) {
        JSONObject found = null;
        int at = -1, i = 0;
        for (JSONObject n : Model.list("quickNotes")) { if (id.equals(Model.s(n, "id"))) { found = n; at = i; } i++; }
        if (found == null) return;
        final int idx = at;
        final JSONObject removed;
        try { removed = new JSONObject(found.toString()); } catch (JSONException e) { return; }
        Repo.del(a, "quickNotes", id);
        refresh();
        a.undo("已刪除便利貼", new Runnable() {
            @Override public void run() {
                enteringId = id;
                Repo.add(a, removed, idx, "quickNotes");
                refresh();
            }
        });
    }

    // ---------- 移至 清單 / 習慣 ----------

    private void openMove(final String id) {
        JSONObject found = null;
        int at = -1, i = 0;
        for (JSONObject n : Model.list("quickNotes")) { if (id.equals(Model.s(n, "id"))) { found = n; at = i; } i++; }
        if (found == null) return;
        final JSONObject note = found;
        final int idx = at;
        final List<JSONObject> cats = Model.categories();
        String first = Model.s(note, "text").split("\n")[0];
        if (first.length() > 60) first = first.substring(0, 60);

        final int[] dest = {0};         // 0 清單 / 1 習慣
        final String[] htype = {"boolean"};
        int catSel = 0;
        for (int k = 0; k < cats.size(); k++) if (Model.s(cats.get(k), "id").equals(a.catId())) catSel = k;

        Form f = new Form(a);
        final LinearLayout listBox = Ui.col(a), habitBox = Ui.col(a);
        // 清單欄位
        String[] names = new String[cats.size()];
        for (int k = 0; k < names.length; k++) names[k] = Model.s(cats.get(k), "name", "");
        final Form.Pick[] catPick = new Form.Pick[1];
        final Form lf = new Form(a);
        catPick[0] = lf.pick("分類", names, catSel);
        final Form.Text title = lf.text("標題", first, "");
        final Form.Date due = lf.date("截止日期(可留空)", "");
        listBox.addView(lf.view());
        // 習慣欄位
        final Form hf = new Form(a);
        final Form.Text hname = hf.text("習慣名稱", first, "");
        final LinearLayout unitField = Ui.col(a);
        final EditText unit = Ui.input(a, "例如:公斤、公升、次", "");
        unitField.addView(Ui.field(a, "單位", unit));
        unitField.setVisibility(View.GONE);
        hf.add(Ui.field(a, "紀錄方式", Ui.pillTabs(a, new String[]{"打卡", "時間", "數量"}, 0, new Ui.IntCb() {
            @Override public void on(int k) {
                htype[0] = k == 0 ? "boolean" : k == 1 ? "time" : "quantity";
                unitField.setVisibility(k == 2 ? View.VISIBLE : View.GONE);
            }
        })));
        hf.add(unitField);
        habitBox.addView(hf.view());
        habitBox.setVisibility(View.GONE);

        f.add(Ui.pillTabs(a, new String[]{"清單", "習慣"}, 0, new Ui.IntCb() {
            @Override public void on(int k) {
                dest[0] = k;
                listBox.setVisibility(k == 0 ? View.VISIBLE : View.GONE);
                habitBox.setVisibility(k == 1 ? View.VISIBLE : View.GONE);
            }
        }));
        f.add(listBox);
        f.add(habitBox);

        Modal.show(a, "移至...", f.view(), "確定", new Modal.Ok() {
            @Override public boolean run() {
                final String createdTaskId, createdHabitId;
                try {
                    if (dest[0] == 0) {
                        String ti = title.get();
                        if (ti.isEmpty()) { Ui.toast(a, "請輸入標題"); return false; }
                        if (cats.isEmpty() || catPick[0].index < 0 || catPick[0].index >= cats.size()) { Ui.toast(a, "請選擇分類"); return false; }
                        JSONObject t = new JSONObject();
                        createdTaskId = Repo.newId();
                        createdHabitId = null;
                        t.put("id", createdTaskId);
                        t.put("categoryId", Model.s(cats.get(catPick[0].index), "id"));
                        t.put("title", ti);
                        t.put("dueDate", due.get());
                        t.put("status", "pending");
                        t.put("subtasks", new JSONArray());
                        Repo.add(a, t, -1, "tasks");
                    } else {
                        String nm = hname.get();
                        if (nm.isEmpty()) { Ui.toast(a, "請輸入習慣名稱"); return false; }
                        String un = "";
                        if ("quantity".equals(htype[0])) {
                            un = unit.getText().toString().trim();
                            if (un.isEmpty()) { Ui.toast(a, "請輸入數量單位"); return false; }
                        }
                        JSONObject h = new JSONObject();
                        createdHabitId = Repo.newId();
                        createdTaskId = null;
                        h.put("id", createdHabitId);
                        h.put("name", nm);
                        h.put("type", htype[0]);
                        h.put("unit", un);
                        h.put("remindTime", JSONObject.NULL);
                        h.put("createdAt", Model.today());
                        Repo.add(a, h, -1, "habits");
                    }
                } catch (JSONException e) {
                    return false;
                }
                final JSONObject removed;
                try { removed = new JSONObject(note.toString()); } catch (JSONException e) { return false; }
                Repo.del(a, "quickNotes", Model.s(note, "id"));
                refresh();
                a.undo("已移動便利貼", new Runnable() {
                    @Override public void run() {
                        enteringId = Model.s(removed, "id");
                        Repo.add(a, removed, idx, "quickNotes");
                        if (createdTaskId != null) Repo.del(a, "tasks", createdTaskId);
                        if (createdHabitId != null) Repo.del(a, "habits", createdHabitId);
                        a.refreshCurrent();
                    }
                });
                return true;
            }
        });
    }

    // ---------- 葉子 ----------

    private void scheduleLeaf() {
        if (!visible) return;
        if (leafTimer != null) root.removeCallbacks(leafTimer);
        long delay = (long) ((5 + rnd.nextFloat() * 5) * 1000);
        leafTimer = new Runnable() {
            @Override public void run() {
                if (!visible) return;
                spawnLeaf();
                scheduleLeaf();
            }
        };
        root.postDelayed(leafTimer, delay);
    }

    private void spawnLeaf() {
        if (leaves.size() >= 3) return;
        int w = leafLayer.getWidth(), h = leafLayer.getHeight();
        if (w <= 0 || h <= 0) return;
        Leaf lf = new Leaf(a);
        leafLayer.addView(lf, new FrameLayout.LayoutParams(lf.w, lf.h));
        lf.x = w - lf.w;
        lf.y = h * (0.05f + rnd.nextFloat() * 0.70f);
        lf.startMotion(true);
        leaves.add(lf);
    }

    /** 一片葉子:出現後一邊往下飄、一邊被風往左吹;可以按住抓著移動,放開後又繼續飄。物理照網頁版 startLeafMotion。 */
    private final class Leaf extends View {
        final int w, h;
        float x, y, vx, vy, rot, rotSpeed, targetVy, targetVx, elapsed;
        boolean caught, fadeIn;
        float grabDx, grabDy;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path body = new Path(), vein = new Path();

        Leaf(Context c) {
            super(c);
            w = Ui.dp(c, 26);
            h = Ui.dp(c, 18);
            float sx = w / 30f, sy = h / 20f;
            body.moveTo(2 * sx, 10 * sy);
            body.quadTo(8 * sx, 0, 28 * sx, 2 * sy);
            body.quadTo(22 * sx, 12 * sy, 15 * sx, 18 * sy);
            body.quadTo(6 * sx, 18 * sy, 2 * sx, 10 * sy);
            body.close();
            vein.moveTo(3 * sx, 10 * sy);
            vein.quadTo(14 * sx, 8 * sy, 27 * sx, 3 * sy);
            setOnTouchListener(new View.OnTouchListener() {
                @Override public boolean onTouch(View v, MotionEvent e) { return touch(e); }
            });
        }

        @Override protected void onMeasure(int a1, int b1) { setMeasuredDimension(w, h); }

        @Override protected void onDraw(Canvas c) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF8FAE7A);
            c.drawPath(body, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f, w / 26f));
            p.setColor(0x996E8F5C);
            c.drawPath(vein, p);
        }

        void startMotion(boolean fade) {
            caught = false;
            fadeIn = fade;
            elapsed = 0f;
            vx = 0f;
            vy = 0f;
            float d = getContext().getResources().getDisplayMetrics().density;
            targetVy = (16 + rnd.nextFloat() * 8) * d;
            targetVx = -((400 + rnd.nextFloat() * 100) / (6 + rnd.nextFloat() * 4)) * d;
            rotSpeed = (rnd.nextFloat() - 0.5f) * 40f;
            if (fade) setAlpha(0f);
            setTranslationX(x);
            setTranslationY(y);
        }

        /** 回傳 false 代表已完全離開畫面,要移除。 */
        boolean step(float dt) {
            if (caught) return true;
            elapsed += dt;
            vy += 6f * (targetVy - vy) * dt;
            float wind = (float) Math.min(1.0, Math.pow(elapsed / 1.6f, 4));
            vx += 1.2f * wind * (targetVx - vx) * dt;
            x += vx * dt;
            y += vy * dt;
            float groundY = leafLayer.getHeight() - h - 2;
            if (y >= groundY) y = groundY;
            rot += rotSpeed * dt;
            setTranslationX(x);
            setTranslationY(y);
            setRotation(rot);
            float diag = (float) Math.sqrt(w * w + h * h);
            float cx = x + w / 2f;
            float visL = Math.max(0f, cx - diag / 2f), visR = Math.min(leafLayer.getWidth(), cx + diag / 2f);
            float visW = Math.max(0f, visR - visL);
            if (visW <= 0f) return false;
            float fade = fadeIn ? Math.min(1f, elapsed / 0.4f) : 1f;
            setAlpha((visW / diag) * 0.85f * fade);
            return true;
        }

        boolean touch(MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    caught = true;
                    if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                    grabDx = e.getRawX() - x;
                    grabDy = e.getRawY() - y;
                    setRotation(0f);
                    setAlpha(1f);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (caught) {
                        x = e.getRawX() - grabDx;
                        y = e.getRawY() - grabDy;
                        setTranslationX(x);
                        setTranslationY(y);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (caught) startMotion(false);
                    return true;
                default:
                    return true;
            }
        }
    }
}
