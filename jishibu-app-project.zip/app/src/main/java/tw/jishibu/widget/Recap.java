package tw.jishibu.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * 早安(今天要做的事)與晚安(今天總結 + 心情)。流程、時間、文字、存檔欄位都照網頁版:
 * 早安時間 08:00~11:59 自動跳一次;晚安時間 21:00 起(到隔天 10 點前打開 App 也會補跳一次)。
 */
final class Recap {
    private Recap() {}

    static final int NIGHT_START_MINUTES = 21 * 60;
    static final int MORNING_START_MINUTES = 8 * 60;
    static final int MORNING_END_HOUR = 12;

    private static boolean autoDone = false;
    private static boolean pendingBrief = false;

    static boolean isNightStarted() {
        Calendar n = Calendar.getInstance();
        return n.get(Calendar.HOUR_OF_DAY) * 60 + n.get(Calendar.MINUTE) >= NIGHT_START_MINUTES;
    }

    static boolean isMorningStarted() {
        Calendar n = Calendar.getInstance();
        return n.get(Calendar.HOUR_OF_DAY) * 60 + n.get(Calendar.MINUTE) >= MORNING_START_MINUTES;
    }

    /** 這一天的「晚安時段」:當天 21:00 起,到隔天 05:00 前。 */
    static boolean nightWindowActive(String day) {
        String today = Model.today();
        if (today.equals(day) && isNightStarted()) return true;
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return today.equals(Model.addDays(day, 1)) && hour < 5;
    }

    private static String recapDateStr() { return isNightStarted() ? Model.today() : Model.addDays(Model.today(), -1); }

    private static String recapLabel() {
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return (isNightStarted() || hour < 4) ? "今天" : "昨天";
    }

    // ---------- 自動跳出(打開 App、資料載入後只跳一次) ----------

    static void autoOnOpen(MainActivity a) {
        if (autoDone) return;
        JSONObject d = Repo.data();
        if (d == null) return;
        autoDone = true;
        if (maybeNightRecap(a)) pendingBrief = true;
        else maybeDailyBrief(a);
    }

    private static boolean maybeNightRecap(MainActivity a) {
        JSONObject d = Repo.data();
        if (d == null || d.optBoolean("nightRecapDisabled", false)) return false;
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (!(isNightStarted() || hour < 10)) return false;
        String day = recapDateStr();
        if (day.equals(Model.s(d, "lastAutoRecapDate", ""))) return false;
        Repo.set(a, day, "lastAutoRecapDate");
        show(a, day, false, false);
        return true;
    }

    private static boolean maybeDailyBrief(MainActivity a) {
        JSONObject d = Repo.data();
        if (d == null || !isMorningStarted()) return false;
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String today = Model.today();
        boolean briefOff = today.equals(Model.s(d, "dailyBriefDismissedDate", ""));
        boolean greeting = hour < MORNING_END_HOUR && !d.optBoolean("morningGreetingDisabled", false)
                && !today.equals(Model.s(d, "morningGreetingShownDate", ""));
        if (briefOff && !greeting) return false;
        if (greeting) Repo.set(a, today, "morningGreetingShownDate");
        brief(a, greeting, briefOff);
        return true;
    }

    // ---------- 小工具 ----------

    private interface F { void on(float v); }

    private static ValueAnimator anim(long ms, final F f, final Runnable end) {
        ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
        va.setDuration(ms);
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator x) { f.on((Float) x.getAnimatedValue()); }
        });
        if (end != null) {
            va.addListener(new AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(Animator x) { end.run(); }
            });
        }
        va.start();
        return va;
    }

    private static void fade(final View v, final float from, final float to, long ms, Runnable end) {
        v.setAlpha(from);
        anim(ms, new F() { @Override public void on(float t) { v.setAlpha(from + (to - from) * t); } }, end);
    }

    private static Dialog full(MainActivity a, View content, Runnable onDismiss) {
        Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(content);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            w.setDimAmount(0f);
            w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        }
        Modal.track(d, onDismiss);
        return d;
    }

    private static int screenW(Context c) { return c.getResources().getDisplayMetrics().widthPixels; }

    /** 虛線(網頁版 border-bottom: 1px dotted)。 */
    private static final class DotLine extends View {
        private final Paint p = new Paint();
        DotLine(Context c) {
            super(c);
            p.setColor(Ui.BORDER);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(1f, Ui.dp(c, 1)));
            p.setPathEffect(new DashPathEffect(new float[]{Ui.dp(c, 1), Ui.dp(c, 2)}, 0f));
        }
        @Override protected void onMeasure(int w, int h) { setMeasuredDimension(MeasureSpec.getSize(w), Math.max(1, Ui.dp(getContext(), 1))); }
        @Override protected void onDraw(Canvas c) { c.drawLine(0, 0, getWidth(), 0, p); }
    }

    private static void section(Context c, LinearLayout box, String label, List<String> items, int labelColor, int itemColor) {
        LinearLayout s = Ui.col(c);
        TextView l = Ui.tv(c, label, 11, labelColor, true);
        l.setPadding(0, 0, 0, Ui.dp(c, 6));
        s.addView(l);
        for (String it : items) {
            TextView t = Ui.tv(c, it, 13.5f, itemColor, false);
            t.setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 8));
            s.addView(t);
            s.addView(new DotLine(c));
        }
        box.addView(s, Ui.mw(c, 0));
        box.addView(Ui.spacer(c, 14));
    }

    private static String str(JSONObject o, String k) { return Model.s(o, k, ""); }

    // ---------- 早安:今天要做的事 ----------

    /** 設定頁的「查看」:不播動畫,直接看今天要做的事。 */
    static void showBrief(MainActivity a) { brief(a, false, false); }

    private static void fillBrief(Context c, LinearLayout box, String day) {
        List<String> due = new ArrayList<>(), subs = new ArrayList<>(), habits = new ArrayList<>();
        for (JSONObject t : Model.tasks()) {
            if (!"done".equals(str(t, "status")) && !str(t, "dueDate").isEmpty() && str(t, "dueDate").compareTo(day) <= 0) due.add(str(t, "title"));
            JSONArray ss = t.optJSONArray("subtasks");
            if (ss == null) continue;
            for (int i = 0; i < ss.length(); i++) {
                JSONObject s = ss.optJSONObject(i);
                if (s == null || "done".equals(str(s, "status"))) continue;
                String tm = str(s, "time");
                if (tm.length() >= 10 && tm.substring(0, 10).equals(day)) subs.add(str(s, "title"));
            }
        }
        for (JSONObject h : Model.habits()) if (!Model.habitChecked(str(h, "id"), day)) habits.add(str(h, "name"));
        TextView title = Ui.tv(c, "今天要做的事", 18, Ui.CARD_INK, true);
        title.setPadding(0, 0, 0, Ui.dp(c, 16));
        box.addView(title);
        if (due.isEmpty() && subs.isEmpty() && habits.isEmpty()) {
            TextView e = Ui.tv(c, "今天沒有排定的事項，輕鬆的一天！", 13.5f, Ui.SOFT, false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(0, Ui.dp(c, 20), 0, Ui.dp(c, 20));
            box.addView(e, Ui.mw(c, 0));
            return;
        }
        if (!due.isEmpty()) section(c, box, "到期或逾期的事項", due, Ui.SOFT, Ui.CARD_INK);
        if (!subs.isEmpty()) section(c, box, "今天的細項", subs, Ui.SOFT, Ui.CARD_INK);
        if (!habits.isEmpty()) section(c, box, "今天還沒打卡的習慣", habits, Ui.SOFT, Ui.CARD_INK);
    }

    private static void brief(final MainActivity a, final boolean greeting, final boolean briefOff) {
        final FrameLayout root = new FrameLayout(a);
        root.setBackgroundColor(greeting ? Ui.ACCENT_SOFT : 0x59000000);
        final Dialog[] dref = new Dialog[1];
        final boolean[] closing = {false};
        final Runnable close = new Runnable() {
            @Override public void run() {
                if (closing[0]) return;
                closing[0] = true;
                fade(root, 1f, 0f, 500, new Runnable() { @Override public void run() { dref[0].dismiss(); } });
            }
        };
        root.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { close.run(); } });

        // 卡片(今天要做的事)
        final ScrollView sv = new ScrollView(a);
        LinearLayout card = Ui.col(a);
        card.setPadding(Ui.dp(a, 28), Ui.dp(a, 28), Ui.dp(a, 28), Ui.dp(a, 24));
        card.setBackground(Ui.shape(a, 0xFFFFFFFF, 24, 0, 0));
        card.setClickable(true);
        fillBrief(a, card, Model.today());
        card.addView(Ui.btnPrimary(a, "開始今天", new View.OnClickListener() {
            @Override public void onClick(View v) { close.run(); }
        }), Ui.mw(a, 2));
        TextView never = Ui.textBtn(a, "今天不再提醒", new View.OnClickListener() {
            @Override public void onClick(View v) {
                Repo.set(a, Model.today(), "dailyBriefDismissedDate");
                a.refreshCurrent();
                close.run();
            }
        });
        never.setGravity(Gravity.CENTER);
        card.addView(never, Ui.mw(a, 8));
        sv.addView(card, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        int cw = Math.min(Ui.dp(a, 340), screenW(a) - Ui.dp(a, 40));
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(cw, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER);
        clp.topMargin = Ui.dp(a, 20);
        clp.bottomMargin = Ui.dp(a, 20);

        final Scene[] scene = new Scene[1];
        if (greeting) {
            sv.setVisibility(View.GONE);
            root.addView(sv, clp);
            final Scene sc = new Scene(a, true, "早安！", "今天也加油");
            scene[0] = sc;
            root.addView(sc, new FrameLayout.LayoutParams(-1, -1));
            sc.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    sc.setClickable(false);
                    fade(sc, 1f, 0f, 500, new Runnable() {
                        @Override public void run() {
                            sc.stop();
                            sc.setVisibility(View.GONE);
                            if (briefOff) { dref[0].dismiss(); return; }
                            sv.setVisibility(View.VISIBLE);
                            fade(sv, 0f, 1f, 500, null);
                        }
                    });
                }
            });
        } else {
            root.addView(sv, clp);
            fade(sv, 0f, 1f, 500, null);
        }
        dref[0] = full(a, root, new Runnable() {
            @Override public void run() { if (scene[0] != null) scene[0].stop(); }
        });
        dref[0].show();
    }

    // ---------- 晚安:今天總結 + 心情 ----------

    private static void summary(Context c, LinearLayout box, String day) {
        List<String> done = new ArrayList<>(), undone = new ArrayList<>(), overdue = new ArrayList<>();
        for (JSONObject t : Model.tasks()) {
            String due = str(t, "dueDate");
            if ("done".equals(str(t, "status"))) {
                if (day.equals(str(t, "completedAt"))) done.add(str(t, "title"));
            } else if (!due.isEmpty() && due.compareTo(day) < 0) overdue.add(str(t, "title"));
            else if (due.equals(day)) undone.add(str(t, "title"));
            JSONArray ss = t.optJSONArray("subtasks");
            if (ss == null) continue;
            for (int i = 0; i < ss.length(); i++) {
                JSONObject s = ss.optJSONObject(i);
                if (s == null) continue;
                String tm = str(s, "time");
                if (tm.isEmpty() || tm.length() < 10 || !tm.substring(0, 10).equals(day)) continue;
                if ("done".equals(str(s, "status"))) done.add(str(s, "title")); else undone.add(str(s, "title"));
            }
        }
        String today = Model.today();
        String word = day.equals(recapDateStr()) ? recapLabel() : (day.equals(today) ? "今天" : (day.equals(Model.addDays(today, -1)) ? "昨天" : "當天"));
        if (done.isEmpty()) {
            LinearLayout s = Ui.col(c);
            TextView l = Ui.tv(c, word + "完成了", 11, Ui.SOFT, true);
            l.setPadding(0, 0, 0, Ui.dp(c, 6));
            s.addView(l);
            TextView t = Ui.tv(c, word + "沒有完成的項目", 13.5f, Ui.SOFT, false);
            t.setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 8));
            s.addView(t);
            s.addView(new DotLine(c));
            box.addView(s, Ui.mw(c, 0));
            box.addView(Ui.spacer(c, 14));
        } else section(c, box, word + "完成了", done, Ui.SOFT, Ui.CARD_INK);
        if (!undone.isEmpty()) section(c, box, "還沒做", undone, Ui.SOFT, Ui.CARD_INK);
        if (!overdue.isEmpty()) section(c, box, "已經延誤", overdue, Ui.DANGER, Ui.DANGER);
    }

    /** 背景會飄的小星星。 */
    private static final class Stars extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final long t0 = System.nanoTime();
        private ValueAnimator tick;
        // top%, left%, sizeDp, seconds, kind(1 = 右上漂, 2 = 左下漂)
        private final float[][] S = {{12, 18, 5, 7, 1}, {22, 78, 3, 9, 2}, {68, 12, 4, 8, 2}, {78, 82, 5, 10, 1}, {40, 50, 3, 6, 1}};
        Stars(Context c) { super(c); }
        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            tick = ValueAnimator.ofFloat(0f, 1f);
            tick.setDuration(1000);
            tick.setRepeatCount(ValueAnimator.INFINITE);
            tick.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator a) { invalidate(); }
            });
            tick.start();
        }
        @Override protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (tick != null) { tick.cancel(); tick = null; }
        }
        @Override protected void onDraw(Canvas c) {
            float d = getContext().getResources().getDisplayMetrics().density;
            double t = (System.nanoTime() - t0) / 1e9;
            for (float[] s : S) {
                double u = (t % s[3]) / s[3];
                double tri = 0.5 - 0.5 * Math.cos(u * Math.PI * 2);
                double dx = s[4] == 1 ? 8 * tri : -10 * tri, dy = s[4] == 1 ? -14 * tri : 10 * tri;
                double a0 = s[4] == 1 ? .4 : .5;
                p.setColor(0xFFFFFFFF);
                p.setAlpha((int) Math.round(255 * .55 * (a0 + (1 - a0) * tri)));
                float cx = getWidth() * s[1] / 100f + (float) dx * d + s[2] * d / 2f;
                float cy = getHeight() * s[0] / 100f + (float) dy * d + s[2] * d / 2f;
                c.drawCircle(cx, cy, s[2] * d / 2f, p);
            }
        }
    }

    static void show(final MainActivity a, final String day, final boolean manual, final boolean simple) {
        JSONObject data = Repo.data();
        if (data == null) { a.flash("資料還沒載入"); return; }
        final JSONObject existing = data.optJSONObject("dayRecaps") == null ? null : data.optJSONObject("dayRecaps").optJSONObject(day);
        final String[] mood = {existing == null ? null : Model.s(existing, "mood", "")};
        if (mood[0] != null && mood[0].isEmpty()) mood[0] = null;

        final Scene.C nc = Scene.derive(Ui.ACCENT);
        final FrameLayout root = new FrameLayout(a);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{nc.n2, nc.n1}));
        root.addView(new Stars(a), new FrameLayout.LayoutParams(-1, -1));

        final Dialog[] dref = new Dialog[1];
        final List<ValueAnimator> loops = new ArrayList<>();
        final Scene[] scene = new Scene[1];
        final boolean[] closing = {false};
        final Runnable closeNow = new Runnable() {
            @Override public void run() {
                if (closing[0]) return;
                closing[0] = true;
                fade(root, 1f, 0f, simple ? 500 : 1000, new Runnable() { @Override public void run() { dref[0].dismiss(); } });
            }
        };

        // 卡片
        final FrameLayout floater = new FrameLayout(a);
        final FrameLayout cardFrame = new FrameLayout(a);
        cardFrame.setBackground(Ui.shape(a, 0xFFFDFDFB, 26, 0, 0));
        cardFrame.setClickable(true);
        final LinearLayout inner = Ui.col(a);
        inner.setPadding(Ui.dp(a, 26), Ui.dp(a, 30), Ui.dp(a, 26), Ui.dp(a, 30));
        cardFrame.addView(inner, new FrameLayout.LayoutParams(-1, -2));

        // 第一步:總結
        final LinearLayout step1 = Ui.col(a);
        TextView t1 = Ui.tv(a, (manual ? "" : recapLabel()) + "總結", 18, Ui.CARD_INK, true);
        t1.setGravity(Gravity.CENTER);
        t1.setPadding(0, 0, 0, Ui.dp(a, 16));
        step1.addView(t1);
        summary(a, step1, day);
        // 第二步:心情
        final LinearLayout step2 = Ui.col(a);
        step2.setVisibility(View.GONE);
        TextView t2 = Ui.tv(a, "今天心情如何？", 18, Ui.CARD_INK, true);
        t2.setGravity(Gravity.CENTER);
        t2.setPadding(0, 0, 0, Ui.dp(a, 16));
        step2.addView(t2);
        LinearLayout moodRow = Ui.row(a);
        moodRow.setGravity(Gravity.CENTER);
        final String[] keys = {"bad", "ok", "good"};
        final String[] names = {"不好", "普通", "好"};
        final LinearLayout[] btns = new LinearLayout[3];
        final TextView[] labels = new TextView[3];
        final Runnable paint = new Runnable() {
            @Override public void run() {
                for (int i = 0; i < 3; i++) {
                    boolean sel = keys[i].equals(mood[0]);
                    btns[i].setBackground(Ui.shape(a, sel ? Ui.ACCENT_SOFT : Ui.CHIP_BG, 16, sel ? Ui.ACCENT : Ui.CHIP_BG, 2));
                    labels[i].setTextColor(sel ? Ui.INK : Ui.SOFT);
                }
            }
        };
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            final LinearLayout b = Ui.col(a);
            b.setGravity(Gravity.CENTER_HORIZONTAL);
            b.setPadding(Ui.dp(a, 16), Ui.dp(a, 14), Ui.dp(a, 16), Ui.dp(a, 14));
            b.addView(Mood.faceLarge(a, keys[i], 38), new LinearLayout.LayoutParams(Ui.dp(a, 38), Ui.dp(a, 38)));
            TextView lb = Ui.tv(a, names[i], 12, Ui.SOFT, true);
            lb.setPadding(0, Ui.dp(a, 8), 0, 0);
            b.addView(lb);
            btns[i] = b;
            labels[i] = lb;
            b.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    mood[0] = keys[idx];
                    paint.run();
                    anim(350, new F() {
                        @Override public void on(float t) {
                            float s = t < .45f ? 1f + .18f * (t / .45f) : t < .75f ? 1.18f - .24f * ((t - .45f) / .3f) : .94f + .06f * ((t - .75f) / .25f);
                            b.setScaleX(s); b.setScaleY(s);
                        }
                    }, null);
                }
            });
            moodRow.addView(b, idx == 0 ? new LinearLayout.LayoutParams(-2, -2) : Ui.gap(a, 10));
        }
        paint.run();
        step2.addView(moodRow, Ui.mw(a, 0));
        final EditText note = Ui.multiline(a, "想留下一段話嗎...（可留空）", existing == null ? "" : Model.s(existing, "note", ""), 3);
        step2.addView(note, Ui.mw(a, 16));

        // 存檔
        View.OnClickListener save = new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    JSONObject rec = new JSONObject();
                    rec.put("mood", mood[0] == null ? JSONObject.NULL : mood[0]);
                    rec.put("note", note.getText().toString().trim());
                    rec.put("createdAt", System.currentTimeMillis());
                    Repo.set(a, rec, "dayRecaps", day);
                } catch (Exception e) { a.flash("存檔失敗"); return; }
                a.refreshCurrent();
                if (simple) { closeNow.run(); return; }
                // 晚安畫面:卡片淡出 1 秒,接著海上新月淡入
                fade(floater, 1f, 0f, 1000, new Runnable() {
                    @Override public void run() {
                        floater.setVisibility(View.GONE);
                        Scene sc = new Scene(a, false, "晚安，今天的你", "又活下來了~");
                        scene[0] = sc;
                        root.addView(sc, new FrameLayout.LayoutParams(-1, -1));
                        sc.setOnClickListener(new View.OnClickListener() {
                            @Override public void onClick(View x) { closing[0] = false; closeNow.run(); }
                        });
                        fade(sc, 0f, 1f, 1000, null);
                    }
                });
            }
        };
        step2.addView(Ui.btnPrimary(a, "完成", save), Ui.mw(a, 18));

        // 繼續:第一步淡出(1 秒)→ 卡片高度慢慢變成第二步的高度,第二步淡入
        step1.addView(Ui.btnPrimary(a, "繼續", new View.OnClickListener() {
            @Override public void onClick(View v) {
                final int startH = cardFrame.getHeight();
                final FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) cardFrame.getLayoutParams();
                lp.height = startH;
                cardFrame.setLayoutParams(lp);
                fade(step1, 1f, 0f, 1000, new Runnable() {
                    @Override public void run() {
                        step1.setVisibility(View.GONE);
                        step2.setVisibility(View.VISIBLE);
                        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                        cardFrame.measure(View.MeasureSpec.makeMeasureSpec(cardFrame.getWidth(), View.MeasureSpec.EXACTLY),
                                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
                        final int endH = cardFrame.getMeasuredHeight();
                        lp.height = startH;
                        cardFrame.setLayoutParams(lp);
                        fade(step2, 0f, 1f, 1000, null);
                        anim(1000, new F() {
                            @Override public void on(float t) {
                                lp.height = (int) (startH + (endH - startH) * t);
                                cardFrame.setLayoutParams(lp);
                            }
                        }, new Runnable() {
                            @Override public void run() {
                                lp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                                cardFrame.setLayoutParams(lp);
                            }
                        });
                    }
                });
            }
        }), Ui.mw(a, 18));
        inner.addView(step1);
        inner.addView(step2);

        // 右上角關閉
        TextView x = Ui.tv(a, "×", 22, Ui.SOFT, false);
        x.setPadding(Ui.dp(a, 10), Ui.dp(a, 4), Ui.dp(a, 10), Ui.dp(a, 4));
        x.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { closeNow.run(); } });
        FrameLayout.LayoutParams xlp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        xlp.topMargin = Ui.dp(a, 8);
        xlp.rightMargin = Ui.dp(a, 8);
        cardFrame.addView(x, xlp);

        floater.addView(cardFrame, new FrameLayout.LayoutParams(-1, -2));
        int cw = Math.min(Ui.dp(a, 360), (int) (screenW(a) * .88f));
        root.addView(floater, new FrameLayout.LayoutParams(cw, -2, Gravity.CENTER));

        // 進場:0.8 秒由下浮上來並放大;之後輕輕上下漂浮
        final float rise = Ui.dp(a, 46), bob = Ui.dp(a, 9);
        floater.setAlpha(0f);
        anim(800, new F() {
            @Override public void on(float t) {
                float e = 1f - (1f - t) * (1f - t) * (1f - t);
                cardFrame.setAlpha(1f);
                floater.setAlpha(Math.min(1f, e * 1.3f));
                cardFrame.setTranslationY(rise * (1f - e));
                float s = .92f + .08f * e;
                cardFrame.setScaleX(s); cardFrame.setScaleY(s);
            }
        }, new Runnable() {
            @Override public void run() {
                ValueAnimator va = ValueAnimator.ofFloat(0f, 1f);
                va.setDuration(5500);
                va.setRepeatCount(ValueAnimator.INFINITE);
                va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    @Override public void onAnimationUpdate(ValueAnimator x) {
                        float u = (Float) x.getAnimatedValue();
                        floater.setTranslationY((float) (-bob * (0.5 - 0.5 * Math.cos(u * Math.PI * 2))));
                    }
                });
                va.start();
                loops.add(va);
            }
        });

        dref[0] = full(a, root, new Runnable() {
            @Override public void run() {
                for (ValueAnimator v : loops) v.cancel();
                if (scene[0] != null) scene[0].stop();
                if (pendingBrief) { pendingBrief = false; maybeDailyBrief(a); }
            }
        });
        dref[0].show();
    }
}
