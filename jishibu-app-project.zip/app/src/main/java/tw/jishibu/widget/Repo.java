package tw.jishibu.widget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * 資料層。手機上留一份完整資料(含這個 App 不認得的欄位),
 * 改動只記成很小的「操作」(完成某件事、打卡…),同步時把操作套到「雲端最新版」再寫回去。
 * 所以不會用舊資料蓋掉網頁版剛存的內容,也不會動到這個 App 不認得的欄位。
 */
final class Repo {
    private Repo() {}

    /** 這個 App 認得的資料格式版本(跟網頁版的 SCHEMA_VERSION 一樣)。版本不同就不寫入。 */
    static final int SCHEMA = 11;
    private static final int MAX_BYTES = 1000000;   // Firestore 單一文件上限約 1 MiB,網頁版也是 1,000,000 就停

    private static final Object LOCK = new Object();
    private static final Object SYNC = new Object();
    private static JSONObject data;
    private static JSONArray pending = new JSONArray();
    private static boolean loaded = false;

    private static final ScheduledExecutorService EXEC = Executors.newSingleThreadScheduledExecutor();
    private static ScheduledFuture<?> scheduled;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static volatile Runnable onChange;
    private static volatile String lastError = "";

    static void setOnChange(Runnable r) { onChange = r; }
    static String lastError() { return lastError; }
    static int pendingCount() { synchronized (LOCK) { return pending.length(); } }

    // ---------- 載入 / 儲存 ----------

    static void init(Context c) {
        synchronized (LOCK) {
            if (loaded) return;
            loaded = true;
            try {
                File f = file(c);
                if (f.exists()) data = new JSONObject(read(f));
            } catch (Exception e) {
                data = null;
            }
            try { pending = new JSONArray(Store.pending(c)); } catch (Exception e) { pending = new JSONArray(); }
            if (data != null) {
                for (int i = 0; i < pending.length(); i++) {
                    try { apply(data, pending.getJSONObject(i)); } catch (Exception ignore) { }
                }
            }
        }
    }

    static JSONObject data() { synchronized (LOCK) { return data; } }

    static void clear(Context c) {
        synchronized (LOCK) {
            data = null;
            pending = new JSONArray();
            file(c).delete();
        }
    }

    private static File file(Context c) { return new File(c.getApplicationContext().getFilesDir(), "data.json"); }

    private static String read(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    private static void saveFile(Context c, JSONObject d) {
        try {
            File f = file(c);
            File tmp = new File(f.getParentFile(), "data.json.tmp");
            FileOutputStream out = new FileOutputStream(tmp);
            out.write(d.toString().getBytes("UTF-8"));
            out.close();
            if (!tmp.renameTo(f)) {
                f.delete();
                tmp.renameTo(f);
            }
        } catch (Exception ignore) { }
    }

    // ---------- 操作 ----------

    /** 組一個操作:鍵值成對給,例如 op("op","task_done","id",id,"done",true)。 */
    static JSONObject op(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]);
        } catch (JSONException ignore) { }
        return o;
    }

    private static JSONObject findById(JSONArray arr, String id) {
        if (arr == null || id == null) return null;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && id.equals(Model.s(o, "id"))) return o;
        }
        return null;
    }

    /** 把一個操作套到資料上。每個操作都是「設成某個狀態」,重複套用結果一樣。 */
    static void apply(JSONObject d, JSONObject op) throws JSONException {
        String kind = Model.s(op, "op");
        if ("task_done".equals(kind)) {
            JSONObject t = findById(d.optJSONArray("tasks"), Model.s(op, "id"));
            if (t == null) return;
            boolean done = op.optBoolean("done");
            t.put("status", done ? "done" : "pending");
            t.put("completedAt", done ? Model.s(op, "day") : JSONObject.NULL);
        } else if ("sub_done".equals(kind)) {
            JSONObject t = findById(d.optJSONArray("tasks"), Model.s(op, "tid"));
            if (t == null) return;
            JSONObject s = findById(t.optJSONArray("subtasks"), Model.s(op, "sid"));
            if (s == null) return;
            boolean done = op.optBoolean("done");
            s.put("status", done ? "done" : "pending");
            s.put("completedAt", done ? Model.s(op, "day") : JSONObject.NULL);
        } else if ("task_add".equals(kind)) {
            JSONArray tasks = d.optJSONArray("tasks");
            if (tasks == null) return;
            if (findById(tasks, Model.s(op, "id")) != null) return;
            JSONObject t = new JSONObject();
            t.put("id", Model.s(op, "id"));
            t.put("categoryId", Model.s(op, "cat"));
            t.put("title", Model.s(op, "title"));
            t.put("dueDate", Model.s(op, "due"));
            t.put("status", "pending");
            t.put("subtasks", new JSONArray());
            tasks.put(t);
        } else if ("habit_log".equals(kind)) {
            String hid = Model.s(op, "hid"), day = Model.s(op, "day");
            if (findById(d.optJSONArray("habits"), hid) == null) return;
            JSONObject logs = d.optJSONObject("habitLogs");
            if (logs == null) { logs = new JSONObject(); d.put("habitLogs", logs); }
            Object cur = logs.opt(hid);
            JSONObject days;
            if (cur instanceof JSONObject) {
                days = (JSONObject) cur;
            } else {
                days = new JSONObject();
                if (cur instanceof JSONArray) {   // 很舊的格式:只存打過卡的日期
                    JSONArray a = (JSONArray) cur;
                    for (int i = 0; i < a.length(); i++) days.put(a.optString(i), true);
                }
                logs.put(hid, days);
            }
            String mode = Model.s(op, "mode");
            if ("bool".equals(mode)) {
                if (op.optBoolean("checked")) {
                    days.put(day, true);
                } else {
                    JSONObject o = new JSONObject();
                    o.put("value", true);
                    o.put("checked", false);
                    days.put(day, o);
                }
            } else if ("num".equals(mode)) {
                days.put(day, op.optDouble("num"));
            } else if ("str".equals(mode)) {
                JSONObject o = new JSONObject();
                o.put("value", Model.s(op, "str"));
                o.put("checked", true);
                days.put(day, o);
            } else if ("clear".equals(mode)) {
                days.remove(day);
            }
        }
    }

    /** 使用者做了一個動作:先改手機上的畫面,再排程同步到雲端。 */
    static void submit(Context c, JSONObject op) {
        Context app = c.getApplicationContext();
        synchronized (LOCK) {
            if (data == null) return;
            try { apply(data, op); } catch (Exception e) { return; }
            pending.put(op);
            Store.setPending(app, pending.toString());
        }
        syncLater(app, 700);
    }

    // ---------- 同步 ----------

    static void syncLater(final Context c, long delayMs) {
        final Context app = c.getApplicationContext();
        synchronized (LOCK) {
            if (scheduled != null) scheduled.cancel(false);
            scheduled = EXEC.schedule(new Runnable() {
                @Override public void run() { syncNow(app); }
            }, delayMs, TimeUnit.MILLISECONDS);
        }
    }

    /** 同步一次(要在背景執行緒)。成功回傳 true。 */
    static boolean syncNow(Context c) {
        Context app = c.getApplicationContext();
        init(app);
        String err = sync(app);
        lastError = err == null ? "" : err;
        if (err != null) Store.saveError(app, err);
        CalendarWidget.renderAll(app);
        Runnable r = onChange;
        if (r != null) MAIN.post(r);
        return err == null;
    }

    private static String today() {
        Calendar t = Calendar.getInstance();
        return String.format(Locale.US, "%04d-%02d-%02d", t.get(Calendar.YEAR), t.get(Calendar.MONTH) + 1, t.get(Calendar.DAY_OF_MONTH));
    }

    private static String shortMsg(Exception e) {
        String m = e.getMessage();
        if (m == null) m = e.getClass().getSimpleName();
        return m.length() > 80 ? m.substring(0, 80) : m;
    }

    private static String sync(Context c) {
        synchronized (SYNC) {
            if (!Store.linked(c)) return "尚未連結";
            try {
                for (int attempt = 0; attempt < 4; attempt++) {
                    Api.Doc doc = Api.getDoc(c);
                    JSONObject rd = new JSONObject(doc.value);
                    if (rd.optJSONArray("tasks") == null) return "雲端資料格式不認得,不處理";

                    JSONArray snap;
                    synchronized (LOCK) {
                        snap = new JSONArray(pending.toString());
                    }
                    if (snap.length() == 0) {
                        finish(c, rd, doc.updateTime, 0);
                        return null;
                    }
                    int sv = rd.optInt("schemaVersion", 0);
                    if (sv != SCHEMA) {
                        return "資料版本 " + sv + " 和這個 App(" + SCHEMA + ")不同,先不寫入。請先用網頁版開啟一次";
                    }
                    for (int i = 0; i < snap.length(); i++) apply(rd, snap.getJSONObject(i));
                    String out = rd.toString();
                    if (out.getBytes("UTF-8").length > MAX_BYTES) return "資料太大,無法儲存";

                    String day = today();
                    boolean backup = !day.equals(Store.backupDay(c));
                    String newTime;
                    try {
                        newTime = Api.commit(c, out, doc.updateTime, backup ? "native-" + day : null, backup ? doc.value : null);
                    } catch (Api.Conflict e) {
                        continue;   // 剛好有別的裝置存檔,重抓最新版再套一次
                    }
                    if (backup) Store.setBackupDay(c, day);
                    finish(c, rd, newTime, snap.length());
                    return null;
                }
                return "資料剛好被其他裝置修改,稍後會再試";
            } catch (Exception e) {
                return shortMsg(e);
            }
        }
    }

    /** 同步成功:換成雲端最新版(再把同步期間新做的動作補上去),存檔,更新小工具用的快取。 */
    private static void finish(Context c, JSONObject rd, String updateTime, int consumed) throws Exception {
        synchronized (LOCK) {
            JSONArray rest = new JSONArray();
            for (int i = consumed; i < pending.length(); i++) rest.put(pending.get(i));
            for (int i = 0; i < rest.length(); i++) apply(rd, rest.getJSONObject(i));
            pending = rest;
            data = rd;
            Store.setPending(c, pending.toString());
            Store.setUpdateTime(c, updateTime);
            saveFile(c, rd);
            Store.saveCache(c, Events.compact(rd.toString()));
        }
    }
}
