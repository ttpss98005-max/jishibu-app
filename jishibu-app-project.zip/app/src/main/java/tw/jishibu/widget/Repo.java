package tw.jishibu.widget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * 資料層。手機上留一份完整資料(含這個 App 不認得的欄位),
 * 改動只記成很小的「操作」(完成某件事、打卡…),同步時把操作套到「雲端最新版」再寫回去。
 * 所以不會用舊資料蓋掉網頁版剛存的內容,也不會動到這個 App 不認得的欄位。
 */
final class Repo {
    private Repo() {}

    /** 這個 App 認得的資料格式版本(跟網頁版的 SCHEMA_VERSION 一樣)。版本不同就不寫入。 */
    static final int SCHEMA = 11;
    private static final int MAX_BYTES = 1000000;   // Firestore 單一文件上限約 1 MiB,網頁版也是 1,000,000 就停

    private static final Object LOCK = new Object();
    private static final Object SYNC = new Object();
    private static JSONObject data;
    private static JSONArray pending = new JSONArray();
    private static boolean loaded = false;

    private static final ScheduledExecutorService EXEC = Executors.newSingleThreadScheduledExecutor();
    private static ScheduledFuture<?> scheduled;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static volatile Runnable onChange;
    private static volatile String lastError = "";
    private static long retryDelay = 0;
    private static volatile int version = 0;

    /** 畫面用的資料有「內容變動」就加一(同步回來的內容跟手機上一樣就不會加),畫面靠它決定要不要重畫。 */
    static int version() { return version; }

    /** 給別的類別讀資料時用的鎖(跟寫入同一把)。 */
    static Object lock() { return LOCK; }

    /** 登出時選擇放棄未同步的修改:先另存一份檔案在手機裡,不直接丟掉。 */
    static void stashPending(Context c) {
        try {
            String p = Store.pending(c);
            if (p == null || p.length() <= 2) return;
            FileOutputStream out = new FileOutputStream(new File(c.getApplicationContext().getFilesDir(), "lost-pending-" + System.currentTimeMillis() + ".json"));
            out.write(p.getBytes("UTF-8"));
            out.close();
        } catch (Exception ignore) { }
    }

    // 網頁版壓縮收納的舊資料:手機上只讀(解開放進畫面用的副本),寫回雲端時永遠不碰那一塊。
    // 這兩組記下「哪些項目是從收納檔補回來的」,這些項目在手機上不能改/刪(改了也寫不進收納檔)。
    private static final Set<String> ARC_EXP = new HashSet<>();
    private static final Set<String> ARC_LOG = new HashSet<>();
    private static int cloudBytes = 0;
    private static List<String> archiveYears = new ArrayList<>();

    static int cloudBytes() { synchronized (LOCK) { return cloudBytes; } }
    static List<String> archiveYears() { synchronized (LOCK) { return new ArrayList<>(archiveYears); } }

    private static File metaFile(Context c) { return new File(c.getApplicationContext().getFilesDir(), "archived.json"); }

    private static void saveMeta(Context c) {
        try {
            JSONObject m = new JSONObject();
            m.put("bytes", cloudBytes);
            JSONArray y = new JSONArray(), e = new JSONArray(), l = new JSONArray();
            for (String x : archiveYears) y.put(x);
            for (String x : ARC_EXP) e.put(x);
            for (String x : ARC_LOG) l.put(x);
            m.put("years", y);
            m.put("e", e);
            m.put("l", l);
            FileOutputStream out = new FileOutputStream(metaFile(c));
            out.write(m.toString().getBytes("UTF-8"));
            out.close();
        } catch (Exception ignore) { }
    }

    private static void loadMeta(Context c) {
        ARC_EXP.clear(); ARC_LOG.clear(); archiveYears = new ArrayList<>(); cloudBytes = 0;
        try {
            File f = metaFile(c);
            if (!f.exists()) return;
            JSONObject m = new JSONObject(read(f));
            cloudBytes = m.optInt("bytes", 0);
            JSONArray y = m.optJSONArray("years"), e = m.optJSONArray("e"), l = m.optJSONArray("l");
            for (int i = 0; y != null && i < y.length(); i++) archiveYears.add(y.optString(i));
            for (int i = 0; e != null && i < e.length(); i++) ARC_EXP.add(e.optString(i));
            for (int i = 0; l != null && i < l.length(); i++) ARC_LOG.add(l.optString(i));
        } catch (Exception ignore) { }
    }

    /** 這個操作會不會動到「收納的舊資料」?會的話手機上先不做。 */
    private static boolean touchesArchived(JSONObject op) {
        String kind = Model.s(op, "op");
        if (!"del".equals(kind) && !"patch".equals(kind)) return false;
        JSONArray p = op.optJSONArray("path");
        if (p == null) return false;
        synchronized (LOCK) {
            if (p.length() >= 2 && "expenses".equals(p.optString(0)) && ARC_EXP.contains(p.optString(1))) return true;
            if (p.length() >= 3 && "habitLogs".equals(p.optString(0)) && "del".equals(kind)
                    && ARC_LOG.contains(p.optString(1) + "|" + p.optString(2))) return true;
        }
        return false;
    }

    static void setOnChange(Runnable r) { onChange = r; }
    static String lastError() { return lastError; }
    static int pendingCount() { synchronized (LOCK) { return pending.length(); } }

    // ---------- 載入 / 儲存 ----------

    static void init(Context c) {
        synchronized (LOCK) {
            if (loaded) return;
            loaded = true;
            loadMeta(c);
            try {
                File f = file(c);
                if (!f.exists()) {
                    File bak = new File(f.getParentFile(), "data.json.bak");
                    if (bak.exists()) bak.renameTo(f);   // 上次存檔到一半被中斷時,用前一份
                }
                if (f.exists()) data = new JSONObject(read(f));
            } catch (Exception e) {
                data = null;
            }
            try { pending = new JSONArray(Store.pending(c)); } catch (Exception e) { pending = new JSONArray(); }
            if (data != null) {
                for (int i = 0; i < pending.length(); i++) {
                    try { apply(data, pending.getJSONObject(i)); } catch (Exception ignore) { }
                }
            }
        }
    }

    static JSONObject data() { synchronized (LOCK) { return data; } }

    static void clear(Context c) {
        synchronized (LOCK) {
            data = null;
            pending = new JSONArray();
            file(c).delete();
            metaFile(c).delete();
            ARC_EXP.clear(); ARC_LOG.clear(); archiveYears = new ArrayList<>(); cloudBytes = 0;
        }
    }

    private static File file(Context c) { return new File(c.getApplicationContext().getFilesDir(), "data.json"); }

    private static String read(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    private static void saveFile(Context c, JSONObject d) {
        try {
            File f = file(c);
            if (f.exists()) {
                File bak = new File(f.getParentFile(), "data.json.bak");
                bak.delete();
                f.renameTo(bak);
            }
            File tmp = new File(f.getParentFile(), "data.json.tmp");
            FileOutputStream out = new FileOutputStream(tmp);
            out.write(d.toString().getBytes("UTF-8"));
            out.close();
            if (!tmp.renameTo(f)) {
                f.delete();
                tmp.renameTo(f);
            }
        } catch (Exception ignore) { }
    }

    // ---------- 操作 ----------

    /** 組一個操作:鍵值成對給,例如 op("op","task_done","id",id,"done",true)。 */
    static JSONObject op(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]);
        } catch (JSONException ignore) { }
        return o;
    }

    private static JSONObject findById(JSONArray arr, String id) {
        if (arr == null || id == null) return null;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && id.equals(Model.s(o, "id"))) return o;
        }
        return null;
    }

    /** 把一個操作套到資料上。每個操作都是「設成某個狀態」,重複套用結果一樣。 */
    static void apply(JSONObject d, JSONObject op) throws JSONException { apply(d, op, null); }

    static void apply(JSONObject d, JSONObject op, Doc.Stats st) throws JSONException {
        String kind = Model.s(op, "op");
        if ("set".equals(kind) || "del".equals(kind) || "add".equals(kind) || "patch".equals(kind) || "order".equals(kind)) {
            Doc.apply(d, op, st);
        } else if ("task_done".equals(kind)) {
            JSONObject t = findById(d.optJSONArray("tasks"), Model.s(op, "id"));
            if (t == null) return;
            boolean done = op.optBoolean("done");
            t.put("status", done ? "done" : "pending");
            t.put("completedAt", done ? Model.s(op, "day") : JSONObject.NULL);
        } else if ("sub_done".equals(kind)) {
            JSONObject t = findById(d.optJSONArray("tasks"), Model.s(op, "tid"));
            if (t == null) return;
            JSONObject s = findById(t.optJSONArray("subtasks"), Model.s(op, "sid"));
            if (s == null) return;
            boolean done = op.optBoolean("done");
            s.put("status", done ? "done" : "pending");
            s.put("completedAt", done ? Model.s(op, "day") : JSONObject.NULL);
        } else if ("task_add".equals(kind)) {
            JSONArray tasks = d.optJSONArray("tasks");
            if (tasks == null) return;
            if (findById(tasks, Model.s(op, "id")) != null) return;
            JSONObject t = new JSONObject();
            t.put("id", Model.s(op, "id"));
            t.put("categoryId", Model.s(op, "cat"));
            t.put("title", Model.s(op, "title"));
            t.put("dueDate", Model.s(op, "due"));
            t.put("status", "pending");
            t.put("subtasks", new JSONArray());
            tasks.put(t);
        } else if ("habit_log".equals(kind)) {
            String hid = Model.s(op, "hid"), day = Model.s(op, "day");
            if (findById(d.optJSONArray("habits"), hid) == null) return;
            JSONObject logs = d.optJSONObject("habitLogs");
            if (logs == null) { logs = new JSONObject(); d.put("habitLogs", logs); }
            Object cur = logs.opt(hid);
            JSONObject days;
            if (cur instanceof JSONObject) {
                days = (JSONObject) cur;
            } else {
                days = new JSONObject();
                if (cur instanceof JSONArray) {   // 很舊的格式:只存打過卡的日期
                    JSONArray a = (JSONArray) cur;
                    for (int i = 0; i < a.length(); i++) days.put(a.optString(i), true);
                }
                logs.put(hid, days);
            }
            String mode = Model.s(op, "mode");
            if ("bool".equals(mode)) {
                if (op.optBoolean("checked")) {
                    days.put(day, true);
                } else {
                    JSONObject o = new JSONObject();
                    o.put("value", true);
                    o.put("checked", false);
                    days.put(day, o);
                }
            } else if ("num".equals(mode)) {
                days.put(day, op.optDouble("num"));
            } else if ("str".equals(mode)) {
                JSONObject o = new JSONObject();
                o.put("value", Model.s(op, "str"));
                o.put("checked", true);
                days.put(day, o);
            } else if ("clear".equals(mode)) {
                days.remove(day);
            }
        }
    }

    // ---------- 通用操作(之後所有功能都用這幾個) ----------

    static String newId() { return Long.toString(System.nanoTime(), 36) + Long.toString(System.currentTimeMillis(), 36); }

    private static JSONArray pathArr(String[] path) {
        JSONArray a = new JSONArray();
        for (String x : path) a.put(x);
        return a;
    }

    /** 把 path 路徑上的值設成 value。 */
    static boolean set(Context c, Object value, String... path) {
        JSONObject o = op("op", "set", "value", value);
        try { o.put("path", pathArr(path)); } catch (JSONException ignore) { }
        return submit(c, o);
    }

    static boolean del(Context c, String... path) {
        JSONObject o = op("op", "del");
        try { o.put("path", pathArr(path)); } catch (JSONException ignore) { }
        return submit(c, o);
    }

    /** 在 path 指到的陣列加一項(item 要有 id)。index 0 = 放最前面,-1 = 放最後面。 */
    static boolean add(Context c, JSONObject item, int index, String... path) {
        JSONObject o = op("op", "add", "item", item, "index", index);
        try { o.put("path", pathArr(path)); } catch (JSONException ignore) { }
        return submit(c, o);
    }

    /** 修改 path 指到的那一項的某幾個欄位。unset 可為 null。 */
    static boolean patch(Context c, JSONObject set, String[] unset, String... path) {
        JSONObject o = op("op", "patch", "set", set);
        try {
            o.put("path", pathArr(path));
            if (unset != null && unset.length > 0) o.put("unset", pathArr(unset));
        } catch (JSONException ignore) { }
        return submit(c, o);
    }

    /** 陣列依 ids 重排。 */
    static void order(Context c, java.util.List<String> ids, String... path) {
        JSONArray a = new JSONArray();
        for (String x : ids) a.put(x);
        JSONObject o = op("op", "order", "ids", a);
        try { o.put("path", pathArr(path)); } catch (JSONException ignore) { }
        submit(c, o);
    }

    /** 使用者做了一個動作:先改手機上的畫面,再排程同步到雲端。 */
    static boolean submit(Context c, JSONObject op) {
        Context app = c.getApplicationContext();
        if (touchesArchived(op)) {
            Ui.toast(c, "這是網頁版收納的舊資料(約 3 個月前),請先用網頁版修改");
            return false;
        }
        synchronized (LOCK) {
            if (data == null) return false;
            try { apply(data, op); } catch (Exception e) { return false; }
            pending.put(op);
            Store.setPending(app, pending.toString());
        }
        syncLater(app, 700);
        return true;
    }

    // ---------- 同步 ----------

    static void syncLater(final Context c, long delayMs) {
        final Context app = c.getApplicationContext();
        synchronized (LOCK) {
            if (scheduled != null) scheduled.cancel(false);
            scheduled = EXEC.schedule(new Runnable() {
                @Override public void run() { syncNow(app); }
            }, delayMs, TimeUnit.MILLISECONDS);
        }
    }

    /** 同步一次(要在背景執行緒)。成功回傳 true。 */
    static boolean syncNow(Context c) {
        Context app = c.getApplicationContext();
        init(app);
        String err = sync(app);
        try { Reminders.flush(app); } catch (Exception ignore) { }
        // 失敗但還有沒存到雲端的修改:過一陣子自己再試(1 分鐘、2 分鐘…最久 10 分鐘),網路恢復後就會補上
        if (err != null && Store.linked(app) && (pendingCount() > 0 || Reminders.queued(app) > 0)) {
            retryDelay = retryDelay == 0 ? 60000L : Math.min(retryDelay * 2, 600000L);
            syncLater(app, retryDelay);
        } else if (err == null) {
            retryDelay = 0;
        }
        lastError = err == null ? "" : err;
        if (err != null) Store.saveError(app, err);
        CalendarWidget.renderAll(app);
        Runnable r = onChange;
        if (r != null) MAIN.post(r);
        return err == null;
    }

    private static String today() {
        Calendar t = Calendar.getInstance();
        return String.format(Locale.US, "%04d-%02d-%02d", t.get(Calendar.YEAR), t.get(Calendar.MONTH) + 1, t.get(Calendar.DAY_OF_MONTH));
    }

    private static String shortMsg(Exception e) {
        String m = e.getMessage();
        if (m == null) m = e.getClass().getSimpleName();
        return m.length() > 80 ? m.substring(0, 80) : m;
    }

    private static String sync(Context c) {
        synchronized (SYNC) {
            if (!Store.linked(c)) return "尚未連結";
            try {
                for (int attempt = 0; attempt < 4; attempt++) {
                    Api.Doc doc = Api.getDoc(c);
                    JSONObject rd = new JSONObject(doc.value);
                    if (rd.optJSONArray("tasks") == null) return "雲端資料格式不認得,不處理";

                    JSONArray snap;
                    synchronized (LOCK) {
                        snap = new JSONArray(pending.toString());
                    }
                    if (snap.length() == 0) {
                        finish(c, rd, doc.updateTime, 0);
                        return null;
                    }
                    int sv = rd.optInt("schemaVersion", 0);
                    if (sv != SCHEMA) {
                        return "資料版本 " + sv + " 和這個 App(" + SCHEMA + ")不同,先不寫入。請先用網頁版開啟一次";
                    }
                    JSONObject before = new JSONObject(doc.value);
                    Doc.Stats st = new Doc.Stats();
                    for (int i = 0; i < snap.length(); i++) apply(rd, snap.getJSONObject(i), st);
                    String bad = Doc.guard(before, rd, st);
                    if (bad != null) {
                        return "安全檢查沒通過(" + bad + "),這次沒有寫入雲端,你的資料沒有被動到";
                    }
                    String out = rd.toString();
                    if (out.getBytes("UTF-8").length > MAX_BYTES) return "資料太大,無法儲存";

                    String day = today();
                    boolean dayBackup = !day.equals(Store.backupDay(c));
                    // 這批操作有刪除東西時,另外多備份一份(一小時最多一份),萬一刪錯可以救回來
                    boolean hasDel = false;
                    for (int i = 0; i < snap.length(); i++) if ("del".equals(Model.s(snap.getJSONObject(i), "op"))) hasDel = true;
                    long nowMs = System.currentTimeMillis();
                    boolean delBackup = hasDel && nowMs - Store.delBackupTs(c) > 3600000L;
                    String label = dayBackup ? "native-" + day : delBackup ? "native-del-" + nowMs : null;
                    boolean backup = dayBackup;
                    String newTime;
                    try {
                        newTime = Api.commit(c, out, doc.updateTime, label, label != null ? doc.value : null);
                        if (delBackup) Store.setDelBackupTs(c, nowMs);
                    } catch (Api.Conflict e) {
                        continue;   // 剛好有別的裝置存檔,重抓最新版再套一次
                    }
                    if (backup) Store.setBackupDay(c, day);
                    finish(c, rd, newTime, snap.length());
                    return null;
                }
                return "資料剛好被其他裝置修改,稍後會再試";
            } catch (Exception e) {
                return shortMsg(e);
            }
        }
    }

    /**
     * 從備份檔還原:整份取代。雲端現在的整份資料會在同一個動作裡先備份到 history(pre-restore-時間),
     * 而且只有雲端還停在剛讀到的版本時才寫入。要在背景執行緒呼叫。成功回傳 null,失敗回傳原因(什麼都沒動)。
     */
    static String replaceAll(Context c, JSONObject cand) {
        Context app = c.getApplicationContext();
        init(app);
        synchronized (SYNC) {
            if (!Store.linked(app)) return "尚未登入";
            if (pendingCount() > 0) return "還有修改沒有同步到雲端，請先按「立即同步」，成功後再還原";
            try {
                Api.Doc doc = Api.getDoc(app);
                JSONObject cur = new JSONObject(doc.value);
                if (cur.optJSONArray("tasks") == null) return "雲端資料格式不認得，不處理";
                cand.put("schemaVersion", SCHEMA);
                cand.remove("archives");
                String out = cand.toString();
                if (out.getBytes("UTF-8").length > MAX_BYTES) {
                    return "備份內容太大（約 " + Math.round(out.getBytes("UTF-8").length / 1024f) + " KB），超過雲端單一文件的上限。請用網頁版還原，它會自動壓縮收納舊資料";
                }
                String newTime;
                try {
                    newTime = Api.commit(app, out, doc.updateTime, "pre-restore-" + System.currentTimeMillis(), doc.value);
                } catch (Api.Conflict e) {
                    return "雲端剛好被其他裝置修改，這次沒有還原，請再試一次";
                }
                finish(app, new JSONObject(out), newTime, 0);
                return null;
            } catch (Exception e) {
                return "還原失敗：" + shortMsg(e);
            }
        }
    }

    /** 同步成功:換成雲端最新版(再把同步期間新做的動作補上去),存檔,更新小工具用的快取。 */
    private static void finish(Context c, JSONObject rd, String updateTime, int consumed) throws Exception {
        synchronized (LOCK) {
            if (!Store.linked(c)) return;   // 同步途中剛好登出了:不要再把資料存回手機
            // 雲端這份(已經寫完,不會再被改)原本的大小和收納年份先記下來,再把收納的舊資料解開放進畫面用的副本
            int bytes = rd.toString().getBytes("UTF-8").length;
            List<String> years = new ArrayList<>();
            JSONObject arc = rd.optJSONObject("archives");
            if (arc != null) {
                Iterator<String> it = arc.keys();
                while (it.hasNext()) years.add(it.next());
                Collections.sort(years);
            }
            Set<String> ne = new HashSet<>(), nl = new HashSet<>();
            try {
                Backup.inflate(rd, ne, nl);
            } catch (Exception ex) {
                // 解不開:畫面上少一些舊資料而已,雲端那份完全沒動,下次同步再試
            }
            ARC_EXP.clear(); ARC_EXP.addAll(ne);
            ARC_LOG.clear(); ARC_LOG.addAll(nl);
            cloudBytes = bytes;
            archiveYears = years;
            saveMeta(c);
            JSONArray rest = new JSONArray();
            for (int i = consumed; i < pending.length(); i++) rest.put(pending.get(i));
            for (int i = 0; i < rest.length(); i++) apply(rd, rest.getJSONObject(i));
            pending = rest;
            boolean same = data != null && data.toString().equals(rd.toString());
            if (!same) version++;
            data = rd;
            Store.setPending(c, pending.toString());
            Store.setUpdateTime(c, updateTime);
            saveFile(c, rd);
            Store.saveCache(c, Events.compact(rd.toString()));
        }
    }
}
