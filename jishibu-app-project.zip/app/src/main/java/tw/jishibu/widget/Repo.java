package tw.jishibu.widget;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

/**
 * 資料層。手機上留一份完整資料(含這個 App 不認得的欄位),
 * 改動只記成很小的「操作」(完成某件事、打卡…),同步時把操作套到「雲端最新版」再寫回去。
 * 所以不會用舊資料蓋掉網頁版剛存的內容,也不會動到這個 App 不認得的欄位。
 */
final class Repo {
    private Repo() {}

    /** 這個 App 認得的資料格式版本(跟網頁版的 SCHEMA_VERSION 一樣)。版本不同就不寫入。 */
    static final int SCHEMA = 12;
    private static final int MAX_BYTES = 1000000;   // Firestore 單一文件上限約 1 MiB,網頁版也是 1,000,000 就停

    private static final Object LOCK = new Object();
    private static final Object SYNC = new Object();
    private static JSONObject data;
    private static JSONArray pending = new JSONArray();
    private static boolean loaded = false;

    private static final ScheduledExecutorService EXEC = Executors.newSingleThreadScheduledExecutor();
    private static ScheduledFuture<?> scheduled;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static volatile Runnable onChange;
    private static volatile String lastError = "";
    private static long retryDelay = 0;
    private static volatile int version = 0;

    /** 畫面用的資料有「內容變動」就加一(同步回來的內容跟手機上一樣就不會加),畫面靠它決定要不要重畫。 */
    static int version() { return version; }

    /** 給別的類別讀資料時用的鎖(跟寫入同一把)。 */
    static Object lock() { return LOCK; }

    /** 登出時選擇放棄未同步的修改:先另存一份檔案在手機裡,不直接丟掉。 */
    static void stashPending(Context c) {
        try {
            String p = Store.pending(c);
            if (p == null || p.length() <= 2) return;
            FileOutputStream out = new FileOutputStream(new File(c.getApplicationContext().getFilesDir(), "lost-pending-" + System.currentTimeMillis() + ".json"));
            out.write(p.getBytes("UTF-8"));
            out.close();
            // 最多留最新 10 份,避免一直登出入把空間塞滿
            File[] all = c.getApplicationContext().getFilesDir().listFiles();
            if (all != null) {
                List<File> l = new ArrayList<>();
                for (File x : all) if (x.getName().startsWith("lost-pending-")) l.add(x);
                Collections.sort(l);
                for (int i = 0; i < l.size() - 10; i++) l.get(i).delete();
            }
        } catch (Exception ignore) { }
    }

    // 網頁版壓縮收納的舊資料:手機上看到的是解開後的副本,可以直接改/刪;
    // 同步時由 Archive 把修改套進雲端的壓縮包(只重新壓縮被動到的那一年)。
    private static int cloudBytes = 0;
    private static List<String> archiveYears = new ArrayList<>();

    static int cloudBytes() { synchronized (LOCK) { return cloudBytes; } }
    static List<String> archiveYears() { synchronized (LOCK) { return new ArrayList<>(archiveYears); } }

    private static File metaFile(Context c) { return new File(c.getApplicationContext().getFilesDir(), "archived.json"); }

    private static void saveMeta(Context c) {
        try {
            JSONObject m = new JSONObject();
            m.put("bytes", cloudBytes);
            JSONArray y = new JSONArray();
            for (String x : archiveYears) y.put(x);
            m.put("years", y);
            FileOutputStream out = new FileOutputStream(metaFile(c));
            out.write(m.toString().getBytes("UTF-8"));
            out.close();
        } catch (Exception ignore) { }
    }

    private static void loadMeta(Context c) {
        archiveYears = new ArrayList<>(); cloudBytes = 0;
        try {
            File f = metaFile(c);
            if (!f.exists()) return;
            JSONObject m = new JSONObject(read(f));
            cloudBytes = m.optInt("bytes", 0);
            JSONArray y = m.optJSONArray("years");
            for (int i = 0; y != null && i < y.length(); i++) archiveYears.add(y.optString(i));
        } catch (Exception ignore) { }
    }

    static void setOnChange(Runnable r) { onChange = r; }
    static String lastError() { return lastError; }
    static int pendingCount() { synchronized (LOCK) { return pending.length(); } }

    // ---------- 載入 / 儲存 ----------

    static void init(Context c) {
        synchronized (LOCK) {
            if (loaded) return;
            loaded = true;
            loadMeta(c);
            try {
                File f = file(c);
                File bak = new File(f.getParentFile(), "data.json.bak");
                if (!f.exists() && bak.exists()) bak.renameTo(f);   // 上次存檔到一半被中斷時,用前一份
                if (f.exists()) {
                    try {
                        data = new JSONObject(read(f));
                    } catch (Exception bad) {
                        // 主檔壞了:壞掉的留一份(data.json.corrupt)供檢查,改讀前一份備份;都不行才當作沒有本機資料(下次同步會從雲端重抓)
                        try { copyFile(f, new File(f.getParentFile(), "data.json.corrupt")); } catch (Exception ignore) { }
                        data = bak.exists() ? new JSONObject(read(bak)) : null;
                    }
                }
            } catch (Exception e) {
                data = null;
            }
            try { pending = new JSONArray(Store.pending(c)); } catch (Exception e) { pending = new JSONArray(); }
            if (data != null) {
                for (int i = 0; i < pending.length(); i++) {
                    try { apply(data, pending.getJSONObject(i)); } catch (Exception ignore) { }
                }
            }
        }
    }

    static JSONObject data() { synchronized (LOCK) { return data; } }

    static void clear(Context c) {
        synchronized (LOCK) {
            data = null;
            pending = new JSONArray();
            File f = file(c);
            f.delete();
            // 登出要把舊帳號的備份副本也清掉,不然下次開啟可能讀回上一個帳號的資料
            new File(f.getParentFile(), "data.json.bak").delete();
            new File(f.getParentFile(), "data.json.tmp").delete();
            new File(f.getParentFile(), "data.json.corrupt").delete();
            metaFile(c).delete();
            archiveYears = new ArrayList<>(); cloudBytes = 0;
        }
    }

    private static File file(Context c) { return new File(c.getApplicationContext().getFilesDir(), "data.json"); }

    private static String read(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        return bo.toString("UTF-8");
    }

    private static void copyFile(File from, File to) throws Exception {
        FileInputStream in = new FileInputStream(from);
        FileOutputStream out = new FileOutputStream(to);
        try {
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        } finally {
            in.close();
            out.close();
        }
    }

    /**
     * 存檔順序:1) 新內容先完整寫進暫存檔並確實寫入儲存空間(fsync);寫失敗就丟掉暫存檔,舊檔完全不動。
     * 2) 舊檔換成 .bak。3) 暫存檔換成正式檔;換失敗就把 .bak 換回去。任何一步被打斷,下次開啟都能讀到完整的一份。
     */
    private static void saveFile(Context c, JSONObject d) {
        File f = file(c);
        File tmp = new File(f.getParentFile(), "data.json.tmp");
        File bak = new File(f.getParentFile(), "data.json.bak");
        try {
            FileOutputStream out = new FileOutputStream(tmp);
            try {
                out.write(d.toString().getBytes("UTF-8"));
                out.flush();
                out.getFD().sync();
            } finally {
                out.close();
            }
        } catch (Exception e) {
            tmp.delete();
            return;
        }
        try {
            if (f.exists()) {
                bak.delete();
                f.renameTo(bak);
            }
            if (!tmp.renameTo(f)) {
                if (bak.exists() && !f.exists()) bak.renameTo(f);
            }
        } catch (Exception ignore) { }
    }

    // ---------- 操作 ----------

    /** 組一個操作:鍵值成對給,例如 op("op","set","path",…,"value",…)。 */
    static JSONObject op(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]);
        } catch (JSONException ignore) { }
        return o;
    }

    /** 把一個操作套到資料上。每個操作都是「設成某個狀態」,重複套用結果一樣。不認得的操作(例如很舊版本留下的)直接略過。 */
    static void apply(JSONObject d, JSONObject op) throws JSONException { apply(d, op, null); }

    static void apply(JSONObject d, JSONObject op, Doc.Stats st) throws JSONException {
        String kind = Model.s(op, "op");
        if ("set".equals(kind) || "del".equals(kind) || "add".equals(kind) || "patch".equals(kind) || "order".equals(kind)) {
            Doc.apply(d, op, st);
        }
    }

    // ---------- 通用操作(之後所有功能都用這幾個) ----------

    static String newId() { return Long.toString(System.nanoTime(), 36) + Long.toString(System.currentTimeMillis(), 36); }

    private static JSONArray pathArr(String[] path) {
        JSONArray a = new JSONArray();
        for (String x : path) a.put(x);
        return a;
    }

    /** 把 path 路徑上的值設成 value。 */
    static boolean set(Context c, Object value, String... path) {
        JSONObject o = op("op", "set", "value", value);
        try { o.put("path", pathArr(path)); } catch (JSONException ignore) { }
        return submit(c, o);
    }

    static boolean del(Context c, String... path) {
        JSONObject o = op("op", "del");
        try { o.put("path", pathArr(path)); } catch (JSONException ignore) { }
        return submit(c, o);
    }

    /** 在 path 指到的陣列加一項(item 要有 id)。index 0 = 放最前面,-1 = 放最後面。 */
    static boolean add(Context c, JSONObject item, int index, String... path) {
        JSONObject o = op("op", "add", "item", item, "index", index);
        try { o.put("path", pathArr(path)); } catch (JSONException ignore) { }
        return submit(c, o);
    }

    /** 修改 path 指到的那一項的某幾個欄位。unset 可為 null。 */
    static boolean patch(Context c, JSONObject set, String[] unset, String... path) {
        JSONObject o = op("op", "patch", "set", set);
        try {
            o.put("path", pathArr(path));
            if (unset != null && unset.length > 0) o.put("unset", pathArr(unset));
        } catch (JSONException ignore) { }
        return submit(c, o);
    }

    /** 陣列依 ids 重排。 */
    static void order(Context c, java.util.List<String> ids, String... path) {
        JSONArray a = new JSONArray();
        for (String x : ids) a.put(x);
        JSONObject o = op("op", "order", "ids", a);
        try { o.put("path", pathArr(path)); } catch (JSONException ignore) { }
        submit(c, o);
    }

    /** 使用者做了一個動作:先改手機上的畫面,再排程同步到雲端。 */
    static boolean submit(Context c, JSONObject op) {
        Context app = c.getApplicationContext();
        synchronized (LOCK) {
            if (data == null) return false;
            try { apply(data, op); } catch (Exception e) { return false; }
            pending.put(op);
            Store.setPending(app, pending.toString());
        }
        syncLater(app, 700);
        return true;
    }

    // ---------- 同步 ----------

    static void syncLater(final Context c, long delayMs) {
        final Context app = c.getApplicationContext();
        synchronized (LOCK) {
            if (scheduled != null) scheduled.cancel(false);
            scheduled = EXEC.schedule(new Runnable() {
                @Override public void run() { syncNow(app); }
            }, delayMs, TimeUnit.MILLISECONDS);
        }
    }

    /** 同步一次(要在背景執行緒)。成功回傳 true。 */
    static boolean syncNow(Context c) {
        Context app = c.getApplicationContext();
        init(app);
        String err = sync(app);
        try { Reminders.flush(app); } catch (Exception ignore) { }
        // 失敗但還有沒存到雲端的修改:過一陣子自己再試(1 分鐘、2 分鐘…最久 10 分鐘),網路恢復後就會補上
        if (err != null && Store.linked(app) && (pendingCount() > 0 || Reminders.queued(app) > 0)) {
            retryDelay = retryDelay == 0 ? 60000L : Math.min(retryDelay * 2, 600000L);
            syncLater(app, retryDelay);
        } else if (err == null) {
            retryDelay = 0;
        }
        lastError = err == null ? "" : err;
        if (err != null) Store.saveError(app, err);
        CalendarWidget.renderAll(app);
        Widgets.renderAll(app);
        Runnable r = onChange;
        if (r != null) MAIN.post(r);
        return err == null;
    }

    private static String today() {
        Calendar t = Calendar.getInstance();
        return String.format(Locale.US, "%04d-%02d-%02d", t.get(Calendar.YEAR), t.get(Calendar.MONTH) + 1, t.get(Calendar.DAY_OF_MONTH));
    }

    private static String shortMsg(Exception e) {
        String m = e.getMessage();
        if (m == null) m = e.getClass().getSimpleName();
        return m.length() > 80 ? m.substring(0, 80) : m;
    }

    private static String sync(Context c) {
        synchronized (SYNC) {
            if (!Store.linked(c)) return "尚未連結";
            try {
                for (int attempt = 0; attempt < 4; attempt++) {
                    Api.Doc doc = Api.getDoc(c);
                    JSONObject rd = new JSONObject(doc.value);
                    if (rd.optJSONArray("tasks") == null) return "雲端資料格式不認得,不處理";

                    JSONArray snap;
                    synchronized (LOCK) {
                        snap = new JSONArray(pending.toString());
                    }
                    int sv = rd.optInt("schemaVersion", 0);
                    boolean mig = sv == Migrate.FROM;   // 雲端還是舊的資料版本(11):這次順便升級
                    if (snap.length() == 0 && !mig) {
                        finish(c, rd, doc.updateTime, 0);
                        return null;
                    }
                    if (!mig && sv != SCHEMA) {
                        return "資料版本 " + sv + " 和這個 App(" + SCHEMA + ")不同,先不寫入。請先用網頁版開啟一次";
                    }
                    JSONObject before = new JSONObject(doc.value);
                    Doc.Stats st = new Doc.Stats();
                    Migrate.Result mr = null;
                    if (mig) {
                        mr = Migrate.run(rd);   // 核對沒過會丟例外:整批不寫入、什麼都不動
                        st.remove("tasks", mr.removedNodes);
                        rd.put("schemaVersion", SCHEMA);
                    }
                    Archive ax = new Archive(rd);
                    for (int i = 0; i < snap.length(); i++) {
                        // 單一個壞掉的動作不能卡住後面所有的同步:跳過它(整體結果還是會過安全檢查才寫入)
                        try {
                            JSONObject one = snap.getJSONObject(i);
                            Migrate.remap(rd, one);   // 舊版排隊的操作如果指到已搬成事項的細項,改指到那個事項
                            if (!ax.tryApply(one, st)) apply(rd, one, st);   // 對象在收納的舊資料裡 → 改壓縮包;解不開壓縮包會直接丟例外,整批不寫入
                        } catch (JSONException skip) { }
                    }
                    ax.commit();
                    if (Migrate.needed(rd)) {   // 舊版排隊的操作又加了帶時間的細項:一樣轉成事項
                        Migrate.Result r2 = Migrate.run(rd);
                        st.remove("tasks", r2.removedNodes);
                        if (mr == null) mr = r2;
                        else {
                            mr.promoted += r2.promoted;
                            mr.removedNodes += r2.removedNodes;
                            mr.reminderDelete.addAll(r2.reminderDelete);
                            mr.reminderWrite.addAll(r2.reminderWrite);
                        }
                    }
                    String bad = Doc.guard(before, rd, st);
                    if (bad != null) {
                        return "安全檢查沒通過(" + bad + "),這次沒有寫入雲端,你的資料沒有被動到";
                    }
                    String out = rd.toString();
                    if (out.getBytes("UTF-8").length > MAX_BYTES) return "資料太大,無法儲存";

                    String day = today();
                    boolean dayBackup = !day.equals(Store.backupDay(c));
                    // 這批操作有刪除東西時,另外多備份一份(一小時最多一份),萬一刪錯可以救回來
                    boolean hasDel = false;
                    for (int i = 0; i < snap.length(); i++) if ("del".equals(Model.s(snap.getJSONObject(i), "op"))) hasDel = true;
                    long nowMs = System.currentTimeMillis();
                    boolean delBackup = hasDel && nowMs - Store.delBackupTs(c) > 3600000L;
                    // 升級資料版本:寫入前的整份舊資料另外備份(跟網頁版同名規則 pre-v12-日期),萬一要退回可以救
                    String label = mig || (mr != null && mr.changed()) ? "pre-v" + SCHEMA + "-" + day
                            : dayBackup ? "native-" + day : delBackup ? "native-del-" + nowMs : null;
                    boolean backup = dayBackup;
                    String newTime;
                    try {
                        newTime = Api.commit(c, out, doc.updateTime, label, label != null ? doc.value : null);
                        if (delBackup) Store.setDelBackupTs(c, nowMs);
                    } catch (Api.Conflict e) {
                        continue;   // 剛好有別的裝置存檔,重抓最新版再套一次
                    }
                    if (backup) Store.setBackupDay(c, day);
                    if (mr != null) fixReminders(c, rd, mr);
                    finish(c, rd, newTime, snap.length());
                    return null;
                }
                return "資料剛好被其他裝置修改,稍後會再試";
            } catch (Exception e) {
                return shortMsg(e);
            }
        }
    }

    /**
     * 從備份檔還原:整份取代。雲端現在的整份資料會在同一個動作裡先備份到 history(pre-restore-時間),
     * 而且只有雲端還停在剛讀到的版本時才寫入。要在背景執行緒呼叫。成功回傳 null,失敗回傳原因(什麼都沒動)。
     */
    static String replaceAll(Context c, JSONObject cand) {
        Context app = c.getApplicationContext();
        init(app);
        synchronized (SYNC) {
            if (!Store.linked(app)) return "尚未登入";
            if (pendingCount() > 0) return "還有修改沒有同步到雲端，請先按「立即同步」，成功後再還原";
            try {
                Api.Doc doc = Api.getDoc(app);
                JSONObject cur = new JSONObject(doc.value);
                if (cur.optJSONArray("tasks") == null) return "雲端資料格式不認得，不處理";
                cand.put("schemaVersion", SCHEMA);
                cand.remove("archives");
                String out = cand.toString();
                if (out.getBytes("UTF-8").length > MAX_BYTES) {
                    return "備份內容太大（約 " + Math.round(out.getBytes("UTF-8").length / 1024f) + " KB），超過雲端單一文件的上限。請用網頁版還原，它會自動壓縮收納舊資料";
                }
                String newTime;
                try {
                    newTime = Api.commit(app, out, doc.updateTime, "pre-restore-" + System.currentTimeMillis(), doc.value);
                } catch (Api.Conflict e) {
                    return "雲端剛好被其他裝置修改，這次沒有還原，請再試一次";
                }
                finish(app, new JSONObject(out), newTime, 0);
                return null;
            } catch (Exception e) {
                return "還原失敗：" + shortMsg(e);
            }
        }
    }

    /** 升級轉換後,雲端的通知提醒跟著換:被清掉的刪掉,搬成事項的用事項的資料重寫(同一個 id,不會重複)。 */
    private static void fixReminders(Context c, JSONObject rd, Migrate.Result mr) {
        try {
            for (String id : mr.reminderDelete) Reminders.remove(c, id);
            JSONArray tasks = rd.optJSONArray("tasks");
            for (String id : mr.reminderWrite) {
                for (int i = 0; tasks != null && i < tasks.length(); i++) {
                    JSONObject t = tasks.optJSONObject(i);
                    if (t != null && id.equals(Model.s(t, "id"))) { Reminders.sync(c, t); break; }
                }
            }
        } catch (Exception ignore) { }
    }

    /** 同步成功:換成雲端最新版(再把同步期間新做的動作補上去),存檔,更新小工具用的快取。 */
    private static void finish(Context c, JSONObject rd, String updateTime, int consumed) throws Exception {
        synchronized (LOCK) {
            if (!Store.linked(c)) return;   // 同步途中剛好登出了:不要再把資料存回手機
            // 雲端這份(已經寫完,不會再被改)原本的大小和收納年份先記下來,再把收納的舊資料解開放進畫面用的副本
            int bytes = rd.toString().getBytes("UTF-8").length;
            List<String> years = new ArrayList<>();
            JSONObject arc = rd.optJSONObject("archives");
            if (arc != null) {
                Iterator<String> it = arc.keys();
                while (it.hasNext()) years.add(it.next());
                Collections.sort(years);
            }
            try {
                Backup.inflate(rd, null, null);
            } catch (Exception ex) {
                // 解不開:畫面上少一些舊資料而已,雲端那份完全沒動,下次同步再試
            }
            cloudBytes = bytes;
            archiveYears = years;
            saveMeta(c);
            JSONArray rest = new JSONArray();
            for (int i = consumed; i < pending.length(); i++) rest.put(pending.get(i));
            for (int i = 0; i < rest.length(); i++) {
                JSONObject one = rest.getJSONObject(i);
                Migrate.remap(rd, one);
                apply(rd, one);
            }
            pending = rest;
            boolean same = data != null && data.toString().equals(rd.toString());
            if (!same) version++;
            data = rd;
            Store.setPending(c, pending.toString());
            Store.setUpdateTime(c, updateTime);
            saveFile(c, rd);
            Store.saveCache(c, Events.compact(rd.toString()));
        }
    }
}
