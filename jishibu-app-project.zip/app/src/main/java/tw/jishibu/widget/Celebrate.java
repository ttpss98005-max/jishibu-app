package tw.jishibu.widget;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 特別的日子慶祝動畫。
 * 什麼時候:當天打開 App、資料載入完、早安動畫/每日提醒(或晚安回顧)都結束之後;同一天同一支手機只跳一次(記在手機上,不寫進雲端)。
 * 哪些日子:節日(生日、紀念日…)、計算天數的每一個週年、整百天(1000 天以內每 100 天;之後 1500 天,以及 2000、3000、4000… 每 1000 天)。
 *         計算天數的「起點」那天不慶祝。
 * 同一天好幾個:同一個畫面,第一個放大,其他列在下面。
 * 設定頁可關閉(資料欄位 specialCelebrateDisabled),開發者工具可以隨時手動播放。
 */
final class Celebrate {
    private Celebrate() {}

    private static final String PREF = "jishibu_celebrate", KEY_DAY = "day";

    // ---------- 哪些日子要慶祝 ----------

    /** 計算天數的第 n 天值不值得慶祝:1000 天以內整百;之後 1500,以及每 1000 天。 */
    static boolean worthDay(int n) {
        if (n <= 0 || n % 100 != 0) return false;
        if (n <= 1000) return true;
        return n == 1500 || (n >= 2000 && n % 1000 == 0);
    }

    static final class Item {
        int pri;            // 0 節日、1 週年、2 整百天(數字小的當主角)
        String icon, kicker, title, text;
    }

    static String iconFor(String name, String type) {
        String n = name == null ? "" : name;
        if (n.contains("生日")) return "🎂";
        if (n.contains("畢業")) return "🎓";
        if (n.contains("結婚") || n.contains("婚")) return "💍";
        if (n.contains("聖誕")) return "🎄";
        if (n.contains("新年") || n.contains("過年") || n.contains("春節")) return "🧧";
        if (n.contains("情人")) return "💝";
        if (n.contains("貓") || n.contains("狗") || n.contains("寵") || n.contains("毛孩") || n.contains("養")) return "🐾";
        if ("anniv".equals(type)) return "💞";
        if ("hundred".equals(type)) return "🏁";
        return "🎉";
    }

    /** 某一天要慶祝的東西,主角排第一。沒有就是空的。 */
    static List<Item> itemsFor(String day) {
        List<Item> out = new ArrayList<>();
        Special.On on = Special.on(day);
        for (JSONObject sd : on.festivals) {
            String name = Model.s(sd, "name");
            Item it = new Item();
            it.pri = 0;
            it.icon = iconFor(name, "festival");
            it.kicker = "今天是";
            it.title = name;
            it.text = name.contains("生日") ? "生日快樂！" : "祝你有美好的一天。";
            out.add(it);
        }
        for (Special.Mark mk : on.marks) {
            if ("anniv".equals(mk.type)) {
                Item it = new Item();
                it.pri = 1;
                it.icon = iconFor(Model.s(mk.sd, "name"), "anniv");
                it.kicker = "恭喜";
                it.title = mk.text;
                it.text = "一起走過的每一天都值得慶祝。";
                out.add(it);
            } else if ("hundred".equals(mk.type) && worthDay(mk.n)) {
                Item it = new Item();
                it.pri = 2;
                it.icon = iconFor(Model.s(mk.sd, "name"), "hundred");
                it.kicker = "里程碑";
                it.title = mk.text;
                it.text = "累積了 " + mk.n + " 天，真不簡單。";
                out.add(it);
            }
        }
        // 穩定排序:節日 → 週年 → 整百天
        for (int i = 1; i < out.size(); i++) {
            Item x = out.get(i);
            int j = i - 1;
            while (j >= 0 && out.get(j).pri > x.pri) { out.set(j + 1, out.get(j)); j--; }
            out.set(j + 1, x);
        }
        return out;
    }

    // ---------- 自動跳出 ----------

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    /** 今天要慶祝的話就跳出來(今天已經跳過、設定關閉、沒有要慶祝的日子都不會跳)。 */
    static void maybe(final MainActivity a) {
        JSONObject d = Repo.data();
        if (d == null || d.optBoolean("specialCelebrateDisabled", false)) return;
        String today = Model.today();
        if (today.equals(sp(a).getString(KEY_DAY, ""))) return;
        if (itemsFor(today).isEmpty()) return;
        if (Modal.anyOpen()) return;     // 手上正開著別的視窗:這次不插隊,也不算已跳過
        sp(a).edit().putString(KEY_DAY, today).commit();
        show(a, itemsFor(today));
    }

    /** 開發者工具:今天有要慶祝的就用真的,沒有就用範例。不管今天跳過了沒。 */
    static void dev(MainActivity a) {
        List<Item> l = Repo.data() == null ? new ArrayList<Item>() : itemsFor(Model.today());
        if (l.isEmpty()) {
            Item it = new Item();
            it.pri = 0; it.icon = "🎂"; it.kicker = "今天是"; it.title = "媽媽生日"; it.text = "生日快樂！";
            l.add(it);
            Item e = new Item();
            e.pri = 2; e.icon = "🏁"; e.kicker = "里程碑"; e.title = "在一起 第 400 天"; e.text = "";
            l.add(e);
        }
        show(a, l);
    }

    /** 開發者工具的「重置」:清掉今天已跳過的記號。 */
    static void devReset(Context c) { sp(c).edit().remove(KEY_DAY).commit(); }

    // ---------- 畫面 ----------

    private static void show(final MainActivity a, List<Item> items) {
        if (items.isEmpty()) return;
        Item main = items.get(0);
        StringBuilder more = new StringBuilder();
        for (int i = 1; i < items.size(); i++) {
            if (more.length() > 0) more.append("、");
            more.append(items.get(i).title);
        }

        final FrameLayout root = new FrameLayout(a);
        boolean dark = Color.luminance(Ui.BG) < 0.4f;
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                dark ? new int[]{0xF53C341E, 0xF51E2A26} : new int[]{0xF5FFF4D6, 0xF5EAF1EF}));
        final Fx fx = new Fx(a);
        root.addView(fx, new FrameLayout.LayoutParams(-1, -1));

        final LinearLayout card = Ui.col(a);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(Ui.dp(a, 22), Ui.dp(a, 26), Ui.dp(a, 22), Ui.dp(a, 20));
        card.setBackground(Ui.shape(a, 0xFFFFFFFF, 24, 0, 0));
        card.setClickable(true);

        final TextView icon = Ui.tv(a, main.icon, 44, Ui.CARD_INK, false);
        icon.setGravity(Gravity.CENTER);
        card.addView(icon, new LinearLayout.LayoutParams(-2, -2));
        TextView k = Ui.tv(a, main.kicker, 12, Ui.ACCENT, true);
        k.setPadding(0, Ui.dp(a, 10), 0, Ui.dp(a, 4));
        card.addView(k);
        TextView title = Ui.tv(a, main.title, 22, Ui.CARD_INK, true);
        title.setGravity(Gravity.CENTER);
        card.addView(title, new LinearLayout.LayoutParams(-2, -2));
        if (!main.text.isEmpty()) {
            TextView t = Ui.tv(a, main.text, 13.5f, Ui.SOFT, false);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(a, 6), 0, 0);
            card.addView(t);
        }
        if (more.length() > 0) {
            TextView m = Ui.tv(a, "另外：" + more, 12.5f, Ui.SOFT, false);
            m.setGravity(Gravity.CENTER);
            m.setPadding(0, Ui.dp(a, 10), 0, 0);
            card.addView(m);
        }
        final Dialog[] dref = new Dialog[1];
        final boolean[] closing = {false};
        final Runnable close = new Runnable() {
            @Override public void run() {
                if (closing[0]) return;
                closing[0] = true;
                root.animate().alpha(0f).setDuration(450).withEndAction(new Runnable() {
                    @Override public void run() { if (dref[0] != null) dref[0].dismiss(); }
                }).start();
            }
        };
        card.addView(Ui.btnPrimary(a, "太棒了", new View.OnClickListener() {
            @Override public void onClick(View v) { close.run(); }
        }), Ui.mw(a, 18));
        root.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { close.run(); } });

        int cw = Math.min(Ui.dp(a, 340), (int) (a.getResources().getDisplayMetrics().widthPixels * .84f));
        root.addView(card, new FrameLayout.LayoutParams(cw, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        // 卡片:0.25 秒後由下浮上來;圖案晚一點「彈」出來
        card.setAlpha(0f);
        card.setTranslationY(Ui.dp(a, 40));
        card.setScaleX(.92f); card.setScaleY(.92f);
        card.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setStartDelay(250).setDuration(800)
                .setInterpolator(new DecelerateInterpolator(2.2f)).start();
        icon.setScaleX(.4f); icon.setScaleY(.4f); icon.setRotation(-12f);
        icon.animate().scaleX(1f).scaleY(1f).rotation(0f).setStartDelay(900).setDuration(1000)
                .setInterpolator(new OvershootInterpolator(2.5f)).start();

        dref[0] = Recap.full(a, root, new Runnable() {
            @Override public void run() { fx.stop(); }
        });
        dref[0].show();
    }

    // ---------- 彩帶和氣球 ----------

    private static final class Fx extends View {
        private static final int[] COLORS = {0xFFE8A33D, 0xFFD9604C, 0xFF3A6B5E, 0xFF6FB3A0, 0xFFF2C94C, 0xFF8E6BBF, 0xFF4A90C2};
        private static final class P { float x, y, vx, vy, w, h, r, vr, ph; int c; }
        private static final class B { float x, y, r, vy, ph; int c; }

        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path string = new Path();
        private final RectF rf = new RectF();
        private final List<P> parts = new ArrayList<>();
        private final List<B> balloons = new ArrayList<>();
        private final Random rnd = new Random();
        private final float d;
        private ValueAnimator ticker;
        private long t0, last;
        private boolean burst, built;

        Fx(Context c) {
            super(c);
            d = c.getResources().getDisplayMetrics().density;
        }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (ticker != null) return;
            t0 = System.nanoTime();
            last = t0;
            ticker = ValueAnimator.ofFloat(0f, 1f);
            ticker.setDuration(1000);
            ticker.setRepeatCount(ValueAnimator.INFINITE);
            ticker.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator a) { invalidate(); }
            });
            ticker.start();
        }

        @Override protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            stop();
        }

        void stop() {
            if (ticker != null) { ticker.cancel(); ticker = null; }
        }

        private void addBurst(float x, float y, int n, float spread, float speed) {
            for (int i = 0; i < n; i++) {
                P p = new P();
                float a = (float) (-Math.PI / 2 + (rnd.nextFloat() - .5f) * spread), v = speed * d * (.5f + rnd.nextFloat());
                p.x = x; p.y = y; p.vx = (float) Math.cos(a) * v; p.vy = (float) Math.sin(a) * v;
                p.w = (5 + rnd.nextFloat() * 5) * d; p.h = (8 + rnd.nextFloat() * 7) * d;
                p.r = rnd.nextFloat() * 6f; p.vr = (rnd.nextFloat() - .5f) * .35f; p.ph = rnd.nextFloat() * 6f;
                p.c = COLORS[rnd.nextInt(COLORS.length)];
                parts.add(p);
            }
        }

        private void addDrizzle(float w) {
            P p = new P();
            p.x = rnd.nextFloat() * w; p.y = -12 * d; p.vx = (rnd.nextFloat() - .5f) * 1.2f * d; p.vy = (1.2f + rnd.nextFloat() * 1.8f) * d;
            p.w = (5 + rnd.nextFloat() * 4) * d; p.h = (8 + rnd.nextFloat() * 6) * d;
            p.r = rnd.nextFloat() * 6f; p.vr = (rnd.nextFloat() - .5f) * .25f; p.ph = rnd.nextFloat() * 6f;
            p.c = COLORS[rnd.nextInt(COLORS.length)];
            parts.add(p);
        }

        @Override protected void onDraw(Canvas cv) {
            int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            long now = System.nanoTime();
            float f = Math.min((now - last) / 1e9f, .05f) * 60f;    // 以 60 張/秒為 1 的時間比例,掉幀也不會跳
            last = now;
            float t = (now - t0) / 1e9f;

            if (!built) {
                built = true;
                int n = 6;
                for (int i = 0; i < n; i++) {
                    B b = new B();
                    b.x = w * (.08f + .84f * i / (n - 1)) + (rnd.nextFloat() - .5f) * 20 * d;
                    b.y = h + (60 + rnd.nextFloat() * 120) * d;
                    b.r = (17 + rnd.nextFloat() * 7) * d;
                    b.vy = (.9f + rnd.nextFloat() * .7f) * d;
                    b.ph = rnd.nextFloat() * 6f;
                    b.c = COLORS[i % COLORS.length];
                    balloons.add(b);
                }
            }
            // 氣球:由下往上飄,飄出畫面就不再畫
            boolean anyBalloon = false;
            for (B b : balloons) {
                b.y -= b.vy * f;
                if (b.y < -80 * d) continue;
                anyBalloon = true;
                float x = b.x + (float) Math.sin(t * 1.6 + b.ph) * 6 * d;
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(Math.max(1f, d));
                paint.setColor(0x8C787878);
                string.reset();
                string.moveTo(x, b.y + b.r * 1.25f);
                string.quadTo(x + (float) Math.sin(t * 2 + b.ph) * 6 * d, b.y + b.r * 2.4f, x, b.y + b.r * 3.2f);
                cv.drawPath(string, paint);
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(b.c);
                rf.set(x - b.r, b.y - b.r * 1.25f, x + b.r, b.y + b.r * 1.25f);
                cv.drawOval(rf, paint);
                paint.setColor(0x59FFFFFF);
                rf.set(x - b.r * .57f, b.y - b.r * .8f, x - b.r * .13f, b.y - b.r * .05f);
                cv.drawOval(rf, paint);
            }
            // 彩帶:兩側先炸開,再從上面輕輕飄落約 7 秒,之後自然落完
            if (!burst && t > .08f) {
                burst = true;
                addBurst(w * .12f, h * .78f, 46, 1.2f, 13f);
                addBurst(w * .88f, h * .78f, 46, 1.2f, 13f);
            }
            if (t > .6f && t < 7f && rnd.nextFloat() < .5f * f) addDrizzle(w);
            paint.setStyle(Paint.Style.FILL);
            for (int i = parts.size() - 1; i >= 0; i--) {
                P p = parts.get(i);
                p.vy += .16f * d * f;
                float damp = (float) Math.pow(.992, f);
                p.vx *= damp; p.vy *= damp;
                p.x += (p.vx + (float) Math.sin(t * 3 + p.ph) * .5f * d) * f;
                p.y += p.vy * f;
                p.r += p.vr * f;
                if (p.y > h + 30 * d) { parts.remove(i); continue; }
                cv.save();
                cv.translate(p.x, p.y);
                cv.rotate((float) Math.toDegrees(p.r));
                cv.scale(1f, (float) Math.cos(p.r * 1.3));
                paint.setColor(p.c);
                cv.drawRect(-p.w / 2, -p.h / 2, p.w / 2, p.h / 2, paint);
                cv.restore();
            }
            // 全部落完、氣球也飄走了就停掉計時器,不再空轉
            if (t > 9f && parts.isEmpty() && !anyBalloon) stop();
        }
    }
}
