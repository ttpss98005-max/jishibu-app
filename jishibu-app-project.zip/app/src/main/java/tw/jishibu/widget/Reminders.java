package tw.jishibu.widget;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 通知提醒的排程文件(跟網頁版同一套:reminders / habitReminders 集合,由後端排程送出)。
 * 呼叫後只是記進待辦佇列,同步時(或網路恢復時)才真的送出,失敗會留著下次再試,不會漏。
 * 所有操作都是「設成某個狀態」,重複送出結果一樣。
 */
final class Reminders {
    private Reminders() {}

    private static final Object LOCK = new Object();

    /** 一則提醒:id 固定(例如細項的 id),到時間 dueAtMs 通知 title / body。 */
    static void put(Context c, String id, String title, String body, long dueAtMs) {
        // 已經過期超過 1 分鐘的不送(送了後端會馬上補發一則「早就過了」的通知),改成清掉雲端上可能還留著的舊文件
        if (dueAtMs < System.currentTimeMillis() - 60000L) { remove(c, id); return; }
        enqueue(c, Repo.op("k", "put", "id", id, "title", title, "body", body, "due", dueAtMs));
    }

    static void remove(Context c, String id) {
        enqueue(c, Repo.op("k", "del", "id", id));
    }

    private static final java.util.Map<String, String> SIG = new java.util.HashMap<>();

    /** 舊版呼叫的入口:事項有變動就整批重排(提醒時間相同的合成一則,跟網頁版一樣)。task 參數只是保留舊的呼叫方式。 */
    static void sync(Context c, JSONObject task) { syncTasks(c); }

    /** 用目前的資料整批重排事項提醒。 */
    static void syncTasks(Context c) {
        List<JSONObject> l;
        synchronized (Repo.lock()) { l = new ArrayList<>(Model.tasks()); }
        syncTasks(c, l);
    }

    /** 用 JSON 陣列(例如剛升級轉換完的資料)整批重排。 */
    static void syncTasksFrom(Context c, JSONArray tasks) {
        List<JSONObject> l = new ArrayList<>();
        for (int i = 0; tasks != null && i < tasks.length(); i++) { JSONObject t = tasks.optJSONObject(i); if (t != null) l.add(t); }
        syncTasks(c, l);
    }

    /**
     * 事項提醒:提醒時間相同的事項合成一則(文件 id = slot_時間_帳號),事項有變動就整批重排。
     * 這台手機寫過的、現在不需要了的(事項完成、刪除、關掉提醒、改時間)會刪掉;舊版「一件事項一則」的文件也一次清掉。
     */
    static void syncTasks(Context c, List<JSONObject> tasks) {
        if (Repo.sandbox()) return;   // 新手教學的練習中,不動雲端的提醒
        Context app = c.getApplicationContext();
        if (!Store.linked(app)) return;
        List<JSONObject> list = TaskSlots.remindList(tasks);
        long now = System.currentTimeMillis();
        java.util.Map<String, String[]> want = new java.util.LinkedHashMap<>();
        java.util.Map<String, Long> dues = new java.util.HashMap<>();
        for (long ms : TaskSlots.times(list)) {
            if (ms < now - 60000L) continue;   // 已過期超過 1 分鐘的不送
            String[] ct = TaskSlots.content(ms, list);
            if (ct == null) continue;
            String id = TaskSlots.docId(app, ms);
            want.put(id, ct);
            dues.put(id, ms);
        }
        android.content.SharedPreferences sp = app.getSharedPreferences("jishibu_reminders", Context.MODE_PRIVATE);
        java.util.Set<String> prev = new java.util.LinkedHashSet<>();
        try {
            JSONArray pa = new JSONArray(sp.getString("slotIds", "[]"));
            for (int i = 0; i < pa.length(); i++) prev.add(pa.getString(i));
        } catch (Exception ignore) { }
        for (String id : prev) if (!want.containsKey(id)) { SIG.remove(id); remove(app, id); }
        for (java.util.Map.Entry<String, String[]> e : want.entrySet()) {
            String id = e.getKey();
            String sig = e.getValue()[0] + "|" + e.getValue()[1] + "|" + dues.get(id);
            if (prev.contains(id) && sig.equals(SIG.get(id))) continue;
            put(app, id, e.getValue()[0], e.getValue()[1], dues.get(id));
            SIG.put(id, sig);
        }
        JSONArray np = new JSONArray();
        for (String id : want.keySet()) np.put(id);
        android.content.SharedPreferences.Editor ed = sp.edit().putString("slotIds", np.toString());
        // 舊版:一件事項一則(文件 id = 事項 id)。換成合併版後,把這些舊文件清掉(只做一次)
        if (!sp.getBoolean("legacyCleared", false) && tasks != null) {
            for (JSONObject t : tasks) if (t != null && t.optBoolean("reminder", false)) remove(app, Model.s(t, "id"));
            ed.putBoolean("legacyCleared", true);
        }
        ed.apply();
    }

    /** 習慣的每日提醒。habit 是習慣物件(要有 id、name、remindTime);沒有 remindTime 就是取消提醒。 */
    static void habit(Context c, JSONObject habit) {
        String id = Model.s(habit, "id"), t = Model.s(habit, "remindTime", "");
        if (t.isEmpty()) enqueue(c, Repo.op("k", "hdel", "id", id));
        else enqueue(c, Repo.op("k", "habit", "id", id, "name", Model.s(habit, "name"), "time", t));
    }

    static void habitRemove(Context c, String habitId) {
        enqueue(c, Repo.op("k", "hdel", "id", habitId));
    }

    private static void enqueue(Context c, JSONObject op) {
        if (Repo.sandbox()) return;   // 新手教學的練習中,不動雲端的提醒
        Context app = c.getApplicationContext();
        if (!Store.linked(app)) return;
        synchronized (LOCK) {
            JSONArray q;
            try { q = new JSONArray(Store.side(app)); } catch (Exception e) { q = new JSONArray(); }
            q.put(op);
            Store.setSide(app, q.toString());
        }
        Repo.syncLater(app, 1500);
    }

    /** 還在排隊、沒送出去的提醒文件數量。 */
    static int queued(Context c) {
        synchronized (LOCK) {
            try { return new JSONArray(Store.side(c)).length(); } catch (Exception e) { return 0; }
        }
    }

    /** 把佇列裡的排程文件送出去(在背景執行緒呼叫)。送不出去的留著。 */
    static void flush(Context c) {
        JSONArray q;
        synchronized (LOCK) {
            try { q = new JSONArray(Store.side(c)); } catch (Exception e) { return; }
        }
        if (q.length() == 0) return;
        int done = 0;
        String uid = Store.key(c);
        for (int i = 0; i < q.length(); i++) {
            JSONObject o = q.optJSONObject(i);
            if (o == null) { done++; continue; }
            try {
                String k = Model.s(o, "k");
                if ("put".equals(k)) {
                    JSONObject f = new JSONObject();
                    f.put("uid", Api.str(uid));
                    f.put("title", Api.str(Model.s(o, "title")));
                    f.put("body", Api.str(Model.s(o, "body")));
                    f.put("dueAt", Api.integer(o.optLong("due")));
                    f.put("sent", Api.bool(false));
                    Api.setDoc(c, "reminders", Model.s(o, "id"), f);
                } else if ("del".equals(k)) {
                    Api.deleteDoc(c, "reminders", Model.s(o, "id"));
                } else if ("habit".equals(k)) {
                    JSONObject f = new JSONObject();
                    f.put("uid", Api.str(uid));
                    f.put("habitName", Api.str(Model.s(o, "name")));
                    f.put("remindTime", Api.str(Model.s(o, "time")));
                    f.put("lastRemindedDate", Api.nul());
                    Api.setDoc(c, "habitReminders", Model.s(o, "id"), f);
                } else if ("hdel".equals(k)) {
                    Api.deleteDoc(c, "habitReminders", Model.s(o, "id"));
                }
                done++;
            } catch (Exception e) {
                break;   // 後面的下次再送,順序不變
            }
        }
        if (done > 0) {
            synchronized (LOCK) {
                JSONArray cur;
                try { cur = new JSONArray(Store.side(c)); } catch (Exception e) { cur = new JSONArray(); }
                JSONArray rest = new JSONArray();
                for (int i = done; i < cur.length(); i++) rest.put(cur.opt(i));
                Store.setSide(c, rest.toString());
            }
        }
    }
}
