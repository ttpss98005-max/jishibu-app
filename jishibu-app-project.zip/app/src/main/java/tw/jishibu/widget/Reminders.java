package tw.jishibu.widget;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * 通知提醒的排程文件(跟網頁版同一套:reminders / habitReminders 集合,由後端排程送出)。
 * 呼叫後只是記進待辦佇列,同步時(或網路恢復時)才真的送出,失敗會留著下次再試,不會漏。
 * 所有操作都是「設成某個狀態」,重複送出結果一樣。
 */
final class Reminders {
    private Reminders() {}

    private static final Object LOCK = new Object();

    /** 一則提醒:id 固定(例如細項的 id),到時間 dueAtMs 通知 title / body。 */
    static void put(Context c, String id, String title, String body, long dueAtMs) {
        // 已經過期超過 1 分鐘的不送(送了後端會馬上補發一則「早就過了」的通知),改成清掉雲端上可能還留著的舊文件
        if (dueAtMs < System.currentTimeMillis() - 60000L) { remove(c, id); return; }
        enqueue(c, Repo.op("k", "put", "id", id, "title", title, "body", body, "due", dueAtMs));
    }

    static void remove(Context c, String id) {
        enqueue(c, Repo.op("k", "del", "id", id));
    }

    /**
     * 依事項現在的狀態寫入或取消這則提醒(跟網頁版 syncTaskReminder 一樣):要有日期、提醒開著、還沒完成才有效;
     * 只設日期沒設時間 → 當天早上 8:00。id = 事項的 id,標題是事項標題,內文是日期(和時間)。
     */
    static void sync(Context c, JSONObject task) {
        String id = Model.s(task, "id");
        long ms = task.optBoolean("reminder", false) && !"done".equals(Model.s(task, "status")) ? Model.taskDueMs(task) : 0L;
        if (ms > 0) put(c, id, Model.s(task, "title"), Model.fmtTaskWhen(task), ms);
        else remove(c, id);
    }

    /** 習慣的每日提醒。habit 是習慣物件(要有 id、name、remindTime);沒有 remindTime 就是取消提醒。 */
    static void habit(Context c, JSONObject habit) {
        String id = Model.s(habit, "id"), t = Model.s(habit, "remindTime", "");
        if (t.isEmpty()) enqueue(c, Repo.op("k", "hdel", "id", id));
        else enqueue(c, Repo.op("k", "habit", "id", id, "name", Model.s(habit, "name"), "time", t));
    }

    static void habitRemove(Context c, String habitId) {
        enqueue(c, Repo.op("k", "hdel", "id", habitId));
    }

    private static void enqueue(Context c, JSONObject op) {
        if (Repo.sandbox()) return;   // 新手教學的練習中,不動雲端的提醒
        Context app = c.getApplicationContext();
        if (!Store.linked(app)) return;
        synchronized (LOCK) {
            JSONArray q;
            try { q = new JSONArray(Store.side(app)); } catch (Exception e) { q = new JSONArray(); }
            q.put(op);
            Store.setSide(app, q.toString());
        }
        Repo.syncLater(app, 1500);
    }

    /** 還在排隊、沒送出去的提醒文件數量。 */
    static int queued(Context c) {
        synchronized (LOCK) {
            try { return new JSONArray(Store.side(c)).length(); } catch (Exception e) { return 0; }
        }
    }

    /** 把佇列裡的排程文件送出去(在背景執行緒呼叫)。送不出去的留著。 */
    static void flush(Context c) {
        JSONArray q;
        synchronized (LOCK) {
            try { q = new JSONArray(Store.side(c)); } catch (Exception e) { return; }
        }
        if (q.length() == 0) return;
        int done = 0;
        String uid = Store.key(c);
        for (int i = 0; i < q.length(); i++) {
            JSONObject o = q.optJSONObject(i);
            if (o == null) { done++; continue; }
            try {
                String k = Model.s(o, "k");
                if ("put".equals(k)) {
                    JSONObject f = new JSONObject();
                    f.put("uid", Api.str(uid));
                    f.put("title", Api.str(Model.s(o, "title")));
                    f.put("body", Api.str(Model.s(o, "body")));
                    f.put("dueAt", Api.integer(o.optLong("due")));
                    f.put("sent", Api.bool(false));
                    Api.setDoc(c, "reminders", Model.s(o, "id"), f);
                } else if ("del".equals(k)) {
                    Api.deleteDoc(c, "reminders", Model.s(o, "id"));
                } else if ("habit".equals(k)) {
                    JSONObject f = new JSONObject();
                    f.put("uid", Api.str(uid));
                    f.put("habitName", Api.str(Model.s(o, "name")));
                    f.put("remindTime", Api.str(Model.s(o, "time")));
                    f.put("lastRemindedDate", Api.nul());
                    Api.setDoc(c, "habitReminders", Model.s(o, "id"), f);
                } else if ("hdel".equals(k)) {
                    Api.deleteDoc(c, "habitReminders", Model.s(o, "id"));
                }
                done++;
            } catch (Exception e) {
                break;   // 後面的下次再送,順序不變
            }
        }
        if (done > 0) {
            synchronized (LOCK) {
                JSONArray cur;
                try { cur = new JSONArray(Store.side(c)); } catch (Exception e) { cur = new JSONArray(); }
                JSONArray rest = new JSONArray();
                for (int i = done; i < cur.length(); i++) rest.put(cur.opt(i));
                Store.setSide(c, rest.toString());
            }
        }
    }
}
