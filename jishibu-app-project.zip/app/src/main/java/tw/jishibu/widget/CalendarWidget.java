package tw.jishibu.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** 半透明月曆小工具。 */
public class CalendarWidget extends AppWidgetProvider {
    static final String ACTION_PREV = "tw.jishibu.widget.PREV";
    static final String ACTION_NEXT = "tw.jishibu.widget.NEXT";
    static final String ACTION_TODAY = "tw.jishibu.widget.TODAY";
    static final String ACTION_REFRESH = "tw.jishibu.widget.REFRESH";

    private static final int FLAGS = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;

    @Override
    public void onUpdate(final Context ctx, AppWidgetManager mgr, int[] ids) {
        renderAll(ctx);
        syncInBackground(ctx, goAsync(), 60_000L);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context ctx, AppWidgetManager mgr, int id, Bundle opts) {
        renderAll(ctx);
    }

    @Override
    public void onReceive(final Context ctx, Intent intent) {
        String a = intent.getAction();
        if (ACTION_PREV.equals(a)) {
            Store.setOffset(ctx, Store.offset(ctx) - 1);
            renderAll(ctx);
        } else if (ACTION_NEXT.equals(a)) {
            Store.setOffset(ctx, Store.offset(ctx) + 1);
            renderAll(ctx);
        } else if (ACTION_TODAY.equals(a)) {
            Store.setOffset(ctx, 0);
            renderAll(ctx);
        } else if (ACTION_REFRESH.equals(a)) {
            syncInBackground(ctx, goAsync(), 0L);
        } else {
            super.onReceive(ctx, intent);
        }
    }

    /** 背景抓資料,抓完重畫。minGapMs:離上次同步太近就不重抓。 */
    private static void syncInBackground(final Context ctx, final PendingResult pr, final long minGapMs) {
        final Context app = ctx.getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    if (Store.linked(app) && System.currentTimeMillis() - Store.syncTs(app) >= minGapMs) {
                        Sync.refresh(app);
                        renderAll(app);
                    }
                } finally {
                    if (pr != null) pr.finish();
                }
            }
        }).start();
    }

    static void renderAll(Context ctx) {
        if (Repo.sandbox()) return;
        AppWidgetManager m = AppWidgetManager.getInstance(ctx);
        int[] ids = m.getAppWidgetIds(new ComponentName(ctx, CalendarWidget.class));
        for (int id : ids) {
            m.updateAppWidget(id, build(ctx, m.getAppWidgetOptions(id)));
        }
    }

    private static int id(Context ctx, String name) {
        return ctx.getResources().getIdentifier(name, "id", ctx.getPackageName());
    }

    private static PendingIntent broadcast(Context ctx, String action, int code) {
        Intent i = new Intent(ctx, CalendarWidget.class).setAction(action);
        return PendingIntent.getBroadcast(ctx, code, i, FLAGS);
    }

    /** 點小工具(標題下的更新時間、日期格、＋):開這個 App 的「行事曆」頁。以前是開網頁版的網址,網址沒有架站就會看到「網站未找到」。 */
    private static PendingIntent openTarget(Context ctx) {
        Intent i = new Intent(ctx, MainActivity.class);
        i.putExtra(Widgets.EXTRA_TAB, MainActivity.TAB_CAL);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(ctx, 10, i, FLAGS);
    }

    /** 時段色塊:Android 12 以上用圓角底圖加分類色(淡淡的底);更舊的系統沒辦法改底圖顏色,改成同色的方角色塊。 */
    private static void tint(RemoteViews rv, int viewId, int drawableRes, int color, boolean done) {
        int alpha = done ? 0x1F : 0x33;
        int tinted = (alpha << 24) | (color & 0x00FFFFFF);
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            rv.setInt(viewId, "setBackgroundResource", drawableRes);
            rv.setColorStateList(viewId, "setBackgroundTintList", android.content.res.ColorStateList.valueOf(tinted));
        } else {
            rv.setInt(viewId, "setBackgroundColor", tinted);
        }
    }

    static RemoteViews build(Context ctx, Bundle opts) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_calendar);

        // 依小工具高度決定每格能放幾行事項(0 行時只顯示小圓點)
        int hDp = opts == null ? 0 : opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (hDp <= 0) hDp = 300;
        float rowDp = (hDp - 96f) / 6f;
        int lines = (int) Math.floor((rowDp - 22f) / 12f);
        if (lines < 0) lines = 0;
        if (lines > 3) lines = 3;

        int offset = Store.offset(ctx);
        Calendar today = Calendar.getInstance();
        Calendar first = Calendar.getInstance();
        first.set(Calendar.DAY_OF_MONTH, 1);
        first.add(Calendar.MONTH, offset);
        int viewMonth = first.get(Calendar.MONTH);
        rv.setTextViewText(R.id.title, String.format(Locale.TAIWAN, "%d年%d月", first.get(Calendar.YEAR), viewMonth + 1));

        String sub;
        if (!Store.linked(ctx)) sub = "尚未連結 · 點這裡設定";
        else if (!Store.error(ctx).isEmpty()) sub = "更新失敗:" + Store.error(ctx);
        else if (Store.syncTs(ctx) == 0L) sub = "更新中…";
        else {
            Calendar t = Calendar.getInstance();
            t.setTimeInMillis(Store.syncTs(ctx));
            sub = String.format(Locale.TAIWAN, "更新於 %02d:%02d", t.get(Calendar.HOUR_OF_DAY), t.get(Calendar.MINUTE));
        }
        rv.setTextViewText(R.id.subtitle, sub);

        rv.setOnClickPendingIntent(R.id.btn_prev, broadcast(ctx, ACTION_PREV, 1));
        rv.setOnClickPendingIntent(R.id.btn_next, broadcast(ctx, ACTION_NEXT, 2));
        rv.setOnClickPendingIntent(R.id.btn_refresh, broadcast(ctx, ACTION_REFRESH, 3));
        rv.setOnClickPendingIntent(R.id.title, broadcast(ctx, ACTION_TODAY, 4));
        PendingIntent open = openTarget(ctx);
        rv.setOnClickPendingIntent(R.id.btn_add, open);
        rv.setOnClickPendingIntent(R.id.subtitle, open);
        rv.setOnClickPendingIntent(R.id.grid, open);

        Map<String, List<Events.Item>> idx = Events.index(Store.cache(ctx));

        Calendar day = (Calendar) first.clone();
        day.add(Calendar.DAY_OF_MONTH, -(day.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY));

        List<Events.Range> rngs = Events.ranges(Store.cache(ctx));

        for (int r = 0; r < 6; r++) {
            // 這一週每天的日期字串,以及每個時段在這週的片段(a..b 欄)
            String[] ymds = new String[7];
            Calendar wk = (Calendar) day.clone();
            for (int c = 0; c < 7; c++) { ymds[c] = Model.ymd(wk); wk.add(Calendar.DAY_OF_MONTH, 1); }
            List<int[]> segs = new ArrayList<>();        // {a, b, 長度, 時段編號, 層, 接上週(1/0), 接下週(1/0)}
            for (int k = 0; k < rngs.size(); k++) {
                Events.Range rg = rngs.get(k);
                int sa = -1, sb = -1;
                for (int c = 0; c < 7; c++) if (ymds[c].compareTo(rg.s) >= 0 && ymds[c].compareTo(rg.e) <= 0) { if (sa < 0) sa = c; sb = c; }
                if (sa < 0) continue;
                segs.add(new int[]{sa, sb, Model.daysBetween(rg.s, rg.e), k, -1, rg.s.compareTo(ymds[sa]) < 0 ? 1 : 0, rg.e.compareTo(ymds[sb]) > 0 ? 1 : 0});
            }
            // 最長的優先、放最下面(跟網頁版一樣);層數最多 3 層,也不超過這個尺寸放得下的行數
            java.util.Collections.sort(segs, new java.util.Comparator<int[]>() {
                @Override public int compare(int[] x, int[] y) { return x[2] != y[2] ? y[2] - x[2] : (x[0] != y[0] ? x[0] - y[0] : x[3] - y[3]); }
            });
            int cap = Math.min(lines, 3);
            List<List<int[]>> laneList = new ArrayList<>();
            if (cap > 0) {
                for (int[] sg : segs) {
                    int found = -1;
                    for (int q = 0; q < laneList.size() && found < 0; q++) {
                        boolean free = true;
                        for (int[] o : laneList.get(q)) if (!(o[1] < sg[0] || o[0] > sg[1])) { free = false; break; }
                        if (free) found = q;
                    }
                    if (found < 0) { if (laneList.size() >= cap) continue; laneList.add(new ArrayList<int[]>()); found = laneList.size() - 1; }
                    laneList.get(found).add(sg);
                    sg[4] = found;
                }
            }
            int L = laneList.size();
            for (int[] sg : segs) if (sg[4] >= 0) sg[4] = L - 1 - sg[4];

            for (int c = 0; c < 7; c++) {
                int y = day.get(Calendar.YEAR), mo = day.get(Calendar.MONTH), d = day.get(Calendar.DAY_OF_MONTH);
                boolean inMonth = mo == viewMonth;
                boolean isToday = y == today.get(Calendar.YEAR) && mo == today.get(Calendar.MONTH)
                        && d == today.get(Calendar.DAY_OF_MONTH);

                int dayId = id(ctx, "d_" + r + "_" + c);
                rv.setTextViewText(dayId, String.valueOf(d));
                int color;
                if (isToday) color = ctx.getResources().getColor(R.color.on_accent, null);
                else if (!inMonth) color = ctx.getResources().getColor(R.color.ink_faint, null);
                else if (c == 0) color = ctx.getResources().getColor(R.color.sunday, null);
                else color = ctx.getResources().getColor(R.color.ink, null);
                rv.setTextColor(dayId, color);
                rv.setInt(dayId, "setBackgroundResource", isToday ? R.drawable.today_bg : 0);

                List<Events.Item> items = Events.forDay(idx, y, mo + 1, d);
                int n = items.size();
                int dot = lines == 0 && n > 0 ? 1 : 0;
                for (int k = 0; k < 3; k++) {
                    int evId = id(ctx, "e_" + r + "_" + c + "_" + k);
                    rv.setTextViewTextSize(evId, android.util.TypedValue.COMPLEX_UNIT_SP, 9f);
                    if (k < lines && k < L) {
                        // 時段的層:這一天在這層有時段 → 色塊;沒有 → 透明佔位,讓同一個時段在整週都在同一層
                        int[] sg = null;
                        for (int[] x : segs) if (x[4] == k && x[0] <= c && c <= x[1]) { sg = x; break; }
                        if (sg == null) {
                            rv.setTextViewText(evId, "\u00A0");
                            rv.setInt(evId, "setBackgroundResource", 0);
                            rv.setViewVisibility(evId, View.INVISIBLE);
                        } else {
                            Events.Range rg = rngs.get(sg[3]);
                            boolean isFirst = c == sg[0];
                            boolean head = isFirst && sg[5] == 0, tail = c == sg[1] && sg[6] == 0;
                            rv.setTextViewText(evId, isFirst ? rg.title : "\u00A0");
                            int res = head && tail ? R.drawable.rng_single : head ? R.drawable.rng_start : tail ? R.drawable.rng_end : R.drawable.rng_mid;
                            tint(rv, evId, res, rg.color, rg.done);
                            rv.setTextColor(evId, rg.done ? ctx.getResources().getColor(R.color.ink_soft, null) : rg.color);
                            rv.setViewVisibility(evId, View.VISIBLE);
                        }
                        continue;
                    }
                    int idx2 = k - L;                       // 單日事項接在時段後面
                    int room = lines - L;
                    if (k < lines && idx2 >= 0 && idx2 < n) {
                        boolean more = n > room && k == lines - 1;
                        if (more) {
                            rv.setTextViewText(evId, "+" + (n - room + 1));
                            rv.setInt(evId, "setBackgroundResource", 0);
                            rv.setTextColor(evId, ctx.getResources().getColor(R.color.ink_soft, null));
                        } else {
                            Events.Item it = items.get(idx2);
                            rv.setTextViewText(evId, it.title);
                            rv.setInt(evId, "setBackgroundResource",
                                    it.kind == Events.SPECIAL ? R.drawable.chip_special
                                            : it.kind == Events.DONE ? 0 : R.drawable.chip_task);
                            rv.setTextColor(evId, ctx.getResources().getColor(
                                    it.kind == Events.SPECIAL ? R.color.chip_special_text
                                            : it.kind == Events.DONE ? R.color.ink_soft : R.color.chip_task_text, null));
                        }
                        rv.setViewVisibility(evId, View.VISIBLE);
                    } else if (lines == 0 && k == 0) {
                        // 小尺寸(只有小圓點的高度):時段變成一條細色帶,連著整週
                        int[] sg = null;
                        for (int[] x : segs) if (x[0] <= c && c <= x[1]) { sg = x; break; }
                        if (sg != null) {
                            Events.Range rg = rngs.get(sg[3]);
                            rv.setTextViewText(evId, "\u00A0");
                            rv.setTextViewTextSize(evId, android.util.TypedValue.COMPLEX_UNIT_SP, 2f);
                            rv.setInt(evId, "setBackgroundColor", (rg.done ? 0x66000000 : 0xB3000000) | (rg.color & 0x00FFFFFF));
                            rv.setViewVisibility(evId, View.VISIBLE);
                        } else {
                            rv.setViewVisibility(evId, View.GONE);
                        }
                    } else {
                        rv.setViewVisibility(evId, View.GONE);
                    }
                }
                int dotId = id(ctx, "o_" + r + "_" + c);
                rv.setViewVisibility(dotId, dot == 1 ? View.VISIBLE : View.GONE);
                day.add(Calendar.DAY_OF_MONTH, 1);
            }
        }
        return rv;
    }
}
