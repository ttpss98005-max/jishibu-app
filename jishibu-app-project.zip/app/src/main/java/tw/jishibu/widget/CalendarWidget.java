package tw.jishibu.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** 半透明月曆小工具。 */
public class CalendarWidget extends AppWidgetProvider {
    static final String ACTION_PREV = "tw.jishibu.widget.PREV";
    static final String ACTION_NEXT = "tw.jishibu.widget.NEXT";
    static final String ACTION_TODAY = "tw.jishibu.widget.TODAY";
    static final String ACTION_REFRESH = "tw.jishibu.widget.REFRESH";

    private static final int FLAGS = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;

    @Override
    public void onUpdate(final Context ctx, AppWidgetManager mgr, int[] ids) {
        renderAll(ctx);
        syncInBackground(ctx, goAsync(), 60_000L);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context ctx, AppWidgetManager mgr, int id, Bundle opts) {
        renderAll(ctx);
    }

    @Override
    public void onReceive(final Context ctx, Intent intent) {
        String a = intent.getAction();
        if (ACTION_PREV.equals(a)) {
            Store.setOffset(ctx, Store.offset(ctx) - 1);
            renderAll(ctx);
        } else if (ACTION_NEXT.equals(a)) {
            Store.setOffset(ctx, Store.offset(ctx) + 1);
            renderAll(ctx);
        } else if (ACTION_TODAY.equals(a)) {
            Store.setOffset(ctx, 0);
            renderAll(ctx);
        } else if (ACTION_REFRESH.equals(a)) {
            syncInBackground(ctx, goAsync(), 0L);
        } else {
            super.onReceive(ctx, intent);
        }
    }

    /** 背景抓資料,抓完重畫。minGapMs:離上次同步太近就不重抓。 */
    private static void syncInBackground(final Context ctx, final PendingResult pr, final long minGapMs) {
        final Context app = ctx.getApplicationContext();
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    if (Store.linked(app) && System.currentTimeMillis() - Store.syncTs(app) >= minGapMs) {
                        Sync.refresh(app);
                        renderAll(app);
                    }
                } finally {
                    if (pr != null) pr.finish();
                }
            }
        }).start();
    }

    static void renderAll(Context ctx) {
        if (Repo.sandbox()) return;
        AppWidgetManager m = AppWidgetManager.getInstance(ctx);
        int[] ids = m.getAppWidgetIds(new ComponentName(ctx, CalendarWidget.class));
        for (int id : ids) {
            m.updateAppWidget(id, build(ctx, m.getAppWidgetOptions(id)));
        }
    }

    private static int id(Context ctx, String name) {
        return ctx.getResources().getIdentifier(name, "id", ctx.getPackageName());
    }

    private static PendingIntent broadcast(Context ctx, String action, int code) {
        Intent i = new Intent(ctx, CalendarWidget.class).setAction(action);
        return PendingIntent.getBroadcast(ctx, code, i, FLAGS);
    }

    /** 點小工具(標題下的更新時間、日期格、＋):開這個 App 的「行事曆」頁。以前是開網頁版的網址,網址沒有架站就會看到「網站未找到」。 */
    private static PendingIntent openTarget(Context ctx) {
        Intent i = new Intent(ctx, MainActivity.class);
        i.putExtra(Widgets.EXTRA_TAB, MainActivity.TAB_CAL);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(ctx, 10, i, FLAGS);
    }

    static RemoteViews build(Context ctx, Bundle opts) {
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_calendar);

        // 依小工具高度決定每格能放幾行事項(0 行時只顯示小圓點)
        int hDp = opts == null ? 0 : opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);
        if (hDp <= 0) hDp = 300;
        float rowDp = (hDp - 96f) / 6f;
        int lines = (int) Math.floor((rowDp - 22f) / 12f);
        if (lines < 0) lines = 0;
        if (lines > 3) lines = 3;

        int offset = Store.offset(ctx);
        Calendar today = Calendar.getInstance();
        Calendar first = Calendar.getInstance();
        first.set(Calendar.DAY_OF_MONTH, 1);
        first.add(Calendar.MONTH, offset);
        int viewMonth = first.get(Calendar.MONTH);
        rv.setTextViewText(R.id.title, String.format(Locale.TAIWAN, "%d年%d月", first.get(Calendar.YEAR), viewMonth + 1));

        String sub;
        if (!Store.linked(ctx)) sub = "尚未連結 · 點這裡設定";
        else if (!Store.error(ctx).isEmpty()) sub = "更新失敗:" + Store.error(ctx);
        else if (Store.syncTs(ctx) == 0L) sub = "更新中…";
        else {
            Calendar t = Calendar.getInstance();
            t.setTimeInMillis(Store.syncTs(ctx));
            sub = String.format(Locale.TAIWAN, "更新於 %02d:%02d", t.get(Calendar.HOUR_OF_DAY), t.get(Calendar.MINUTE));
        }
        rv.setTextViewText(R.id.subtitle, sub);

        rv.setOnClickPendingIntent(R.id.btn_prev, broadcast(ctx, ACTION_PREV, 1));
        rv.setOnClickPendingIntent(R.id.btn_next, broadcast(ctx, ACTION_NEXT, 2));
        rv.setOnClickPendingIntent(R.id.btn_refresh, broadcast(ctx, ACTION_REFRESH, 3));
        rv.setOnClickPendingIntent(R.id.title, broadcast(ctx, ACTION_TODAY, 4));
        PendingIntent open = openTarget(ctx);
        rv.setOnClickPendingIntent(R.id.btn_add, open);
        rv.setOnClickPendingIntent(R.id.subtitle, open);
        rv.setOnClickPendingIntent(R.id.grid, open);

        Map<String, List<Events.Item>> idx = Events.index(Store.cache(ctx));

        Calendar day = (Calendar) first.clone();
        day.add(Calendar.DAY_OF_MONTH, -(day.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY));

        for (int r = 0; r < 6; r++) {
            for (int c = 0; c < 7; c++) {
                int y = day.get(Calendar.YEAR), mo = day.get(Calendar.MONTH), d = day.get(Calendar.DAY_OF_MONTH);
                boolean inMonth = mo == viewMonth;
                boolean isToday = y == today.get(Calendar.YEAR) && mo == today.get(Calendar.MONTH)
                        && d == today.get(Calendar.DAY_OF_MONTH);

                int dayId = id(ctx, "d_" + r + "_" + c);
                rv.setTextViewText(dayId, String.valueOf(d));
                int color;
                if (isToday) color = ctx.getResources().getColor(R.color.on_accent, null);
                else if (!inMonth) color = ctx.getResources().getColor(R.color.ink_faint, null);
                else if (c == 0) color = ctx.getResources().getColor(R.color.sunday, null);
                else color = ctx.getResources().getColor(R.color.ink, null);
                rv.setTextColor(dayId, color);
                rv.setInt(dayId, "setBackgroundResource", isToday ? R.drawable.today_bg : 0);

                List<Events.Item> items = Events.forDay(idx, y, mo + 1, d);
                int n = items.size();
                for (int k = 0; k < 3; k++) {
                    int evId = id(ctx, "e_" + r + "_" + c + "_" + k);
                    if (k < lines && k < n) {
                        boolean more = n > lines && k == lines - 1;
                        if (more) {
                            rv.setTextViewText(evId, "+" + (n - lines + 1));
                            rv.setInt(evId, "setBackgroundResource", 0);
                            rv.setTextColor(evId, ctx.getResources().getColor(R.color.ink_soft, null));
                        } else {
                            Events.Item it = items.get(k);
                            rv.setTextViewText(evId, it.title);
                            rv.setInt(evId, "setBackgroundResource",
                                    it.kind == Events.SPECIAL ? R.drawable.chip_special
                                            : it.kind == Events.DONE ? 0 : R.drawable.chip_task);
                            rv.setTextColor(evId, ctx.getResources().getColor(
                                    it.kind == Events.SPECIAL ? R.color.chip_special_text
                                            : it.kind == Events.DONE ? R.color.ink_soft : R.color.chip_task_text, null));
                        }
                        rv.setViewVisibility(evId, View.VISIBLE);
                    } else {
                        rv.setViewVisibility(evId, View.GONE);
                    }
                }
                int dotId = id(ctx, "o_" + r + "_" + c);
                rv.setViewVisibility(dotId, lines == 0 && n > 0 ? View.VISIBLE : View.GONE);
                day.add(Calendar.DAY_OF_MONTH, 1);
            }
        }
        return rv;
    }
}
