package tw.jishibu.widget;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * 記帳的計算(跟網頁版 index.html 的記帳區同一套算法):餘額、本月收支、勞健保級距、薪資試算、固定扣款到期日。
 * 全部只讀資料,不會改動任何東西。
 */
final class Money {
    private Money() {}

    // ---------- 金額文字 ----------

    /** JS toLocaleString():千分位,小數最多 3 位。 */
    static String num(double n) {
        NumberFormat f = NumberFormat.getInstance(Locale.US);
        f.setMaximumFractionDigits(3);
        f.setGroupingUsed(true);
        return f.format(n);
    }

    static String fmt(double n) { return (n < 0 ? "-" : "") + "$" + num(Math.abs(n)); }

    /** 整數就存成整數(JSON 裡看起來跟網頁版一樣)。 */
    static Object numObj(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 9e15) return (long) v;
        return v;
    }

    static double d(JSONObject o, String k) {
        if (o == null) return 0;
        double v = o.optDouble(k, 0);
        return Double.isNaN(v) ? 0 : v;
    }

    /** JS 的 Number(x)||0:字串也能轉,轉不了就 0。 */
    static double n0(Object v) {
        if (v == null || v == JSONObject.NULL) return 0;
        if (v instanceof Number) { double x = ((Number) v).doubleValue(); return Double.isNaN(x) || Double.isInfinite(x) ? 0 : x; }
        try { double x = Double.parseDouble(String.valueOf(v).trim()); return Double.isNaN(x) || Double.isInfinite(x) ? 0 : x; }
        catch (NumberFormatException e) { return 0; }
    }

    // ---------- 資料取得 ----------

    static JSONObject root() { return Repo.data(); }

    static List<JSONObject> list(String key) { return Model.list(key); }

    static JSONObject obj(String key) {
        JSONObject r = root();
        JSONObject o = r == null ? null : r.optJSONObject(key);
        return o == null ? new JSONObject() : o;
    }

    /** 頂層陣列欄位轉成文字(用來比對有沒有被改過);沒有這個欄位就是 "[]"。 */
    static String arrStr(String key) {
        JSONObject r = root();
        org.json.JSONArray a = r == null ? null : r.optJSONArray(key);
        return a == null ? "[]" : a.toString();
    }

    static JSONObject payroll() { return obj("payroll"); }

    static String monthKey(int y, int month1) { return String.format(Locale.US, "%04d-%02d", y, month1); }

    static List<JSONObject> forMonth(String key) {
        List<JSONObject> r = new ArrayList<>();
        for (JSONObject e : list("expenses")) {
            String dt = Model.s(e, "date");
            if (dt.length() >= 7 && dt.substring(0, 7).equals(key)) r.add(e);
        }
        return r;
    }

    // ---------- 帳戶 ----------

    static double balance(JSONObject acc, String today) {
        double b = d(acc, "opening");
        String id = Model.s(acc, "id");
        for (JSONObject e : list("expenses")) {
            if (Model.s(e, "date").compareTo(today) > 0) continue;
            String type = Model.s(e, "type");
            double amt = d(e, "amount");
            if ("transfer".equals(type)) {
                if (Model.s(e, "accountId").equals(id)) b -= amt;
                if (Model.s(e, "toAccountId").equals(id)) b += amt;
                continue;
            }
            if (!Model.s(e, "accountId").equals(id)) continue;
            b += "income".equals(type) ? amt : "expense".equals(type) ? -amt : amt;
        }
        return b;
    }

    static double balance(JSONObject acc) { return balance(acc, Model.today()); }

    static double totalBalance() {
        double s = 0;
        for (JSONObject a : list("accounts")) s += balance(a);
        return s;
    }

    static String accountName(String id) {
        for (JSONObject a : list("accounts")) if (Model.s(a, "id").equals(id)) return Model.s(a, "name");
        return "未指定";
    }

    /** 薪資入帳帳戶:設定的 → 第一個銀行 → 第一個帳戶。 */
    static String salaryAccountId() {
        List<JSONObject> accs = list("accounts");
        if (accs.isEmpty()) return "";
        String want = Model.s(payroll(), "accountId");
        for (JSONObject a : accs) if (Model.s(a, "id").equals(want)) return want;
        for (JSONObject a : accs) if ("bank".equals(Model.s(a, "type"))) return Model.s(a, "id");
        return Model.s(accs.get(0), "id");
    }

    // ---------- 月曆小工具 ----------

    static int daysInMonth(int y, int monthIdx) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(y, monthIdx, 1);
        return c.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    static int workDaysInMonth(int y, int monthIdx) {
        int days = daysInMonth(y, monthIdx), count = 0;
        Calendar c = Calendar.getInstance();
        for (int d = 1; d <= days; d++) {
            c.clear();
            c.set(y, monthIdx, d);
            int dow = c.get(Calendar.DAY_OF_WEEK);
            if (dow != Calendar.SUNDAY && dow != Calendar.SATURDAY) count++;
        }
        return count;
    }

    // ---------- 勞健保 ----------

    static final int[] LABOR_LEVELS = {29500, 30300, 31800, 33300, 34800, 36300, 38200, 40100, 42000, 43900, 45800};
    static final int[] HEALTH_LEVELS = {29500, 30300, 31800, 33300, 34800, 36300, 38200, 40100, 42000, 43900, 45800, 48200, 50600, 53000, 55400, 57800, 60800, 63800, 66800, 69800, 72800, 76500, 80200, 83900, 87600, 92100, 96600, 101100, 105600, 110100, 115500, 120900, 126300, 131700, 137100, 142500, 147900, 150000, 156400, 162800, 169200, 175600, 182000, 189500, 197000, 204500, 212000, 219500, 228200, 236900, 245600, 254300, 263000, 273000, 283000, 293000, 303000, 313000};

    static int levelFor(double salary, int[] levels) {
        if (!(salary > 0)) return 0;
        for (int lv : levels) if (salary <= lv) return lv;
        return levels[levels.length - 1];
    }

    /** 勞保:投保薪資 ×(普通事故 11.5% + 就業保險 1%)× 20%。回傳 {級距, 自付}。 */
    static long[] laborFee(double salary) {
        int lv = levelFor(salary, LABOR_LEVELS);
        if (lv == 0) return new long[]{0, 0};
        return new long[]{lv, Math.round(lv * 23 / 1000.0) + Math.round(lv * 2 / 1000.0)};
    }

    /** 健保:投保金額 × 5.17% × 30% ×(本人 + 眷屬,最多 3 人)。回傳 {級距, 每人, 人數, 自付}。 */
    static long[] healthFee(double salary, double dependents) {
        int lv = levelFor(salary, HEALTH_LEVELS);
        if (lv == 0) return new long[]{0, 0, 1, 0};
        long each = Math.round(lv * 0.0517 * 0.3);
        int dep = (int) Math.min(Math.max(Math.floor(dependents), 0), 3);
        long people = 1 + dep;
        return new long[]{lv, each, people, each * people};
    }

    // ---------- 薪資 ----------

    static final class Breakdown {
        double dailyRate, personalDeduct, sickDeduct, labor, health, pension, customTotal, additionsTotal, net, base;
    }

    private static double leaveDeduct(JSONObject rule, double dailyRate, double days) {
        String t = Model.s(rule, "type");
        if ("fullpay".equals(t)) return 0;
        if ("halfpay".equals(t)) return dailyRate * 0.5 * days;
        return d(rule, "fixedAmount") * days;
    }

    static double sumAmounts(JSONArray a) {
        double s = 0;
        if (a == null) return 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null) s += n0(o.opt("amount"));
        }
        return s;
    }

    static Breakdown computeSalary(int year, int monthIdx, double personalDays, double sickDays) {
        JSONObject p = payroll();
        double base = d(p, "baseSalary");
        int divisor = "workdays".equals(Model.s(p, "leaveDivisor")) ? workDaysInMonth(year, monthIdx) : daysInMonth(year, monthIdx);
        double dailyRate = divisor > 0 ? base / divisor : 0;
        Breakdown b = new Breakdown();
        b.dailyRate = dailyRate;
        b.personalDeduct = leaveDeduct(p.optJSONObject("personalRule"), dailyRate, personalDays);
        b.sickDeduct = leaveDeduct(p.optJSONObject("sickRule"), dailyRate, sickDays);
        b.labor = n0(p.opt("laborFee"));
        b.health = n0(p.opt("healthFee"));
        b.pension = Math.round(base * d(p, "pensionSelfRate") / 100);
        b.customTotal = sumAmounts(p.optJSONArray("deductions"));
        b.additionsTotal = sumAmounts(p.optJSONArray("additions"));
        b.net = base + b.additionsTotal - b.personalDeduct - b.sickDeduct - b.labor - b.health - b.pension - b.customTotal;
        b.base = base;
        return b;
    }

    static double leaveDays(double amount, String unit) { return "hours".equals(unit) ? amount / 8 : amount; }

    /** 某個薪資月份(yyyy-MM)依目前設定與當月請假算出的薪資。 */
    static Breakdown salaryForMonth(String monthKey) {
        int y = Integer.parseInt(monthKey.substring(0, 4)), m = Integer.parseInt(monthKey.substring(5, 7));
        JSONObject leave = obj("leaveByMonth").optJSONObject(monthKey);
        if (leave == null) leave = new JSONObject();
        String pu = Model.s(leave, "personalUnit", "days"), su = Model.s(leave, "sickUnit", "days");
        return computeSalary(y, m - 1,
                leaveDays(n0(leave.opt("personalAmount")), pu.isEmpty() ? "days" : pu),
                leaveDays(n0(leave.opt("sickAmount")), su.isEmpty() ? "days" : su));
    }

    static final class PayDate {
        int py, pm, day;
        String dateStr;
    }

    /** 薪資月份 monthIdx(0 起算)的發放日。 */
    static PayDate payDate(int year, int monthIdx) {
        JSONObject p = payroll();
        int off = (int) n0(p.opt("payMonthOffset"));
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, monthIdx + off, 1);
        int py = c.get(Calendar.YEAR), pm = c.get(Calendar.MONTH);
        double sd = p.has("salaryDay") ? n0(p.opt("salaryDay")) : 1;
        if (sd == 0) sd = 1;   // JS: p.salaryDay||1
        int day = (int) Math.min(Math.max(sd, 1), daysInMonth(py, pm));
        PayDate r = new PayDate();
        r.py = py;
        r.pm = pm + 1;
        r.day = day;
        r.dateStr = Model.ymd(py, pm + 1, day);
        return r;
    }

    static boolean isSalaryEntry(JSONObject e) {
        return "income".equals(Model.s(e, "type")) && "salary".equals(Model.s(e, "category"));
    }

    /** 這筆薪水屬於哪個薪資月份(舊紀錄沒有 salaryMonth,依備註「N月薪資」推算)。找不到回 null。 */
    static String salaryEntryMonthKey(JSONObject e) {
        String sm = Model.s(e, "salaryMonth");
        if (!sm.isEmpty()) return sm;
        String note = Model.s(e, "note");
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\d{1,2})月薪資$").matcher(note);
        if (!m.find()) return null;
        int mm = Integer.parseInt(m.group(1));
        String date = Model.s(e, "date");
        int ey = Integer.parseInt(date.substring(0, 4));
        String best = null;
        double bestDiff = Double.MAX_VALUE;
        for (int y = ey - 1; y <= ey + 1; y++) {
            double diff = Math.abs(Model.parse(payDate(y, mm - 1).dateStr).getTimeInMillis() - Model.parse(date).getTimeInMillis());
            if (diff < bestDiff) { bestDiff = diff; best = String.format(Locale.US, "%d-%02d", y, mm); }
        }
        return best;
    }

    static String salaryEntryKeyLoose(JSONObject e) {
        String k = salaryEntryMonthKey(e);
        if (k != null) return k;
        Calendar c = Model.parse(Model.s(e, "date"));
        c.set(Calendar.DAY_OF_MONTH, 1);
        c.add(Calendar.MONTH, -(int) n0(payroll().opt("payMonthOffset")));
        return monthKey(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1);
    }

    private static JSONArray namedAmounts(JSONArray src) throws JSONException {
        JSONArray r = new JSONArray();
        if (src == null) return r;
        for (int i = 0; i < src.length(); i++) {
            JSONObject o = src.optJSONObject(i);
            if (o == null) continue;
            r.put(new JSONObject().put("name", Model.s(o, "name")).put("amount", numObj(n0(o.opt("amount")))));
        }
        return r;
    }

    static JSONObject detailFromBreakdown(Breakdown b) throws JSONException {
        JSONObject p = payroll();
        JSONObject r = new JSONObject();
        r.put("base", numObj(b.base));
        r.put("labor", numObj(b.labor));
        r.put("health", numObj(b.health));
        r.put("pension", numObj(b.pension));
        r.put("personal", numObj(Math.round(b.personalDeduct)));
        r.put("sick", numObj(Math.round(b.sickDeduct)));
        r.put("additions", namedAmounts(p.optJSONArray("additions")));
        r.put("items", namedAmounts(p.optJSONArray("deductions")));
        return r;
    }

    static double detailNet(JSONObject dt) {
        double adds = sumAmounts(dt.optJSONArray("additions"));
        double items = sumAmounts(dt.optJSONArray("items"));
        return d(dt, "base") + adds - d(dt, "labor") - d(dt, "health") - d(dt, "pension") - d(dt, "personal") - d(dt, "sick") - items;
    }

    static JSONObject defaultDetail(String key, double fallbackAmount) throws JSONException {
        if (!(d(payroll(), "baseSalary") > 0)) {
            return new JSONObject().put("base", numObj(fallbackAmount)).put("labor", 0).put("health", 0).put("pension", 0)
                    .put("personal", 0).put("sick", 0).put("additions", new JSONArray()).put("items", new JSONArray());
        }
        return detailFromBreakdown(salaryForMonth(key));
    }

    // ---------- 固定扣款 ----------

    /** 固定扣款 item 到 today 為止還沒記的日期(網頁版 recurringOccurrences)。 */
    static List<String> recurringOccurrences(JSONObject item, String today) {
        List<String> out = new ArrayList<>();
        String last = Model.s(item, "lastRun");
        String start = Model.s(item, "startDate");
        if (!Model.isDay(start)) return out;
        int day = (int) n0(item.opt("day"));
        if ("weekly".equals(Model.s(item, "freq"))) {
            Calendar d = Model.parse(start);
            if (!last.isEmpty() && last.compareTo(start) >= 0) {
                Calendar l = Model.parse(last);
                l.add(Calendar.DAY_OF_MONTH, 1);
                if (l.after(d)) d = l;
            }
            while (Model.ymd(d).compareTo(today) <= 0 && out.size() < 200) {
                String ds = Model.ymd(d);
                if (d.get(Calendar.DAY_OF_WEEK) - 1 == day && ds.compareTo(last) > 0 && ds.compareTo(start) >= 0) out.add(ds);
                d.add(Calendar.DAY_OF_MONTH, 1);
            }
        } else {
            Calendar s = Model.parse(start), t = Model.parse(today);
            int y = s.get(Calendar.YEAR), m = s.get(Calendar.MONTH);
            while ((y < t.get(Calendar.YEAR) || (y == t.get(Calendar.YEAR) && m <= t.get(Calendar.MONTH))) && out.size() < 200) {
                int dim = daysInMonth(y, m);
                String ds = Model.ymd(y, m + 1, Math.min(day, dim));
                if (ds.compareTo(start) >= 0 && ds.compareTo(today) <= 0 && ds.compareTo(last) > 0) out.add(ds);
                m++;
                if (m > 11) { m = 0; y++; }
            }
        }
        return out;
    }
}
