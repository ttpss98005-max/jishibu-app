package tw.jishibu.widget;

import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 記帳(網頁版 view-expense):記帳 / 統計 兩個分頁。
 * 記帳:月份切換、本月收入/支出/結餘/存款、預算、本月薪資(請假)、固定扣款、記一筆、依日期的明細。
 * 進來時會像網頁版一樣自動處理「到期的固定扣款」和「到了發薪日的薪水」(用固定的 id,重複也不會記兩次)。
 */
final class ExpenseScreen extends ScrollScreen {
    static int tab = 0;   // 0 記帳、1 統計
    static int monthY = -1, monthM = -1;   // monthM 從 0 起算
    static String lastAccountId = "";

    private EditText leavePersonal, leaveSick;
    private String leaveKey = "";
    private String personalUnit = "days", sickUnit = "days";

    ExpenseScreen(MainActivity a) { super(a); }

    private static void ensureMonth() {
        if (monthY < 0) {
            Calendar c = Calendar.getInstance();
            monthY = c.get(Calendar.YEAR);
            monthM = c.get(Calendar.MONTH);
        }
    }

    @Override void onShow() {
        autoRun();
        refresh();
    }

    @Override void onHide() { flushLeave(); }

    @Override void refresh() {
        flushLeave();
        super.refresh();
    }

    // ---------- 自動記帳(固定扣款 + 薪水) ----------

    private void autoRun() {
        if (Repo.data() == null || !Store.linked(a)) return;
        // 網頁版也會自動記帳;手機上的資料如果不是剛剛才跟雲端對過,就先不記,免得兩邊各記一筆(同步完會再來一次)
        if (System.currentTimeMillis() - Store.syncTs(a) > 120000L) return;
        List<JSONObject> accs = Money.list("accounts");
        if (accs.isEmpty()) return;
        int made = runRecurring(accs);
        List<String> sal = runSalary();
        if (made > 0) a.flash("已自動記入 " + made + " 筆固定扣款");
        if (!sal.isEmpty()) a.flash(sal.size() == 1 ? sal.get(0) : "已自動記入 " + sal.size() + " 筆薪資");
    }

    private int runRecurring(List<JSONObject> accs) {
        int created = 0;
        String today = Model.today();
        List<JSONObject> expenses = Money.list("expenses");
        for (JSONObject item : Money.list("recurring")) {
            String rid = Model.s(item, "id");
            String accId = Model.s(accs.get(0), "id");
            for (JSONObject ac : accs) if (Model.s(ac, "id").equals(Model.s(item, "accountId"))) accId = Model.s(ac, "id");
            List<String> occ = Money.recurringOccurrences(item, today);
            for (String ds : occ) {
                boolean have = false;   // 網頁版或之前已經記過同一天的,就不再記
                for (JSONObject e : expenses) if (rid.equals(Model.s(e, "recurringId")) && ds.equals(Model.s(e, "date"))) have = true;
                if (!have) {
                    JSONObject e = new JSONObject();
                    try {
                        e.put("id", "rec_" + rid + "_" + ds);
                        e.put("type", "expense");
                        e.put("amount", Money.numObj(Money.d(item, "amount")));
                        e.put("category", Model.s(item, "category"));
                        e.put("note", Model.s(item, "name") + "（固定扣款）");
                        e.put("date", ds);
                        e.put("accountId", accId);
                        e.put("recurringId", rid);
                        e.put("createdAt", System.currentTimeMillis());
                    } catch (JSONException ex) { continue; }
                    Repo.add(a, e, -1, "expenses");
                }
                created++;
            }
            if (!occ.isEmpty()) {
                JSONObject set = new JSONObject();
                try { set.put("lastRun", occ.get(occ.size() - 1)); } catch (JSONException ignore) { }
                Repo.patch(a, set, null, "recurring", rid);
            }
        }
        return created;
    }

    private List<String> runSalary() {
        List<String> made = new ArrayList<>();
        JSONObject p = Money.payroll();
        String autoFrom = Model.s(p, "autoFrom");
        if (!(Money.d(p, "baseSalary") > 0) || autoFrom.length() < 7) return made;
        String today = Model.today();
        int fy = Integer.parseInt(autoFrom.substring(0, 4)), fm = Integer.parseInt(autoFrom.substring(5, 7));
        Calendar d = Calendar.getInstance();
        d.clear();
        d.set(fy, fm - 2, 1);
        Calendar now = Calendar.getInstance();
        Calendar end = Calendar.getInstance();
        end.clear();
        end.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH), 1);
        JSONObject recorded = Money.obj("salaryRecorded");
        List<JSONObject> expenses = Money.list("expenses");
        while (!d.after(end)) {
            int y = d.get(Calendar.YEAR), m = d.get(Calendar.MONTH);
            String key = Money.monthKey(y, m + 1);
            Money.PayDate pay = Money.payDate(y, m);
            boolean skip = recorded.optBoolean(key, false) || pay.dateStr.compareTo(autoFrom) <= 0 || pay.dateStr.compareTo(today) > 0;
            if (!skip) for (JSONObject e : expenses) if (key.equals(Model.s(e, "salaryMonth"))) skip = true;
            if (!skip) {
                try {
                    JSONObject detail = Money.detailFromBreakdown(Money.salaryForMonth(key));
                    double amount = Math.max(0, Money.detailNet(detail));
                    JSONObject e = new JSONObject();
                    e.put("id", "sal_" + key);
                    e.put("type", "income");
                    e.put("amount", Money.numObj(amount));
                    e.put("category", "salary");
                    e.put("note", (m + 1) + "月薪資");
                    e.put("date", pay.dateStr);
                    e.put("accountId", Money.salaryAccountId());
                    e.put("salaryMonth", key);
                    e.put("salaryDetail", detail);
                    e.put("createdAt", System.currentTimeMillis());
                    Repo.add(a, e, -1, "expenses");
                    Repo.set(a, true, "salaryRecorded", key);
                    made.add("已自動記入 " + (m + 1) + "月薪資 " + Money.fmt(amount) + "（" + pay.pm + "/" + pay.day + " 發放）");
                } catch (JSONException ignore) { }
            }
            d.add(Calendar.MONTH, 1);
        }
        return made;
    }

    // ---------- 請假 ----------

    private void flushLeave() {
        if (leavePersonal == null || leaveSick == null || leaveKey.isEmpty()) return;
        double pa = Money.n0(leavePersonal.getText().toString().trim()), sa = Money.n0(leaveSick.getText().toString().trim());
        JSONObject cur = Money.obj("leaveByMonth").optJSONObject(leaveKey);
        if (cur == null && pa == 0 && sa == 0) return;
        if (cur != null && Money.n0(cur.opt("personalAmount")) == pa && Money.n0(cur.opt("sickAmount")) == sa
                && personalUnit.equals(Model.s(cur, "personalUnit", "days")) && sickUnit.equals(Model.s(cur, "sickUnit", "days"))) return;
        JSONObject next = new JSONObject();
        try {
            next.put("personalAmount", Money.numObj(pa));
            next.put("personalUnit", personalUnit);
            next.put("sickAmount", Money.numObj(sa));
            next.put("sickUnit", sickUnit);
        } catch (JSONException e) { return; }
        Repo.set(a, next, "leaveByMonth", leaveKey);
    }

    // ---------- 畫面 ----------

    @Override void build() {
        ensureMonth();
        leavePersonal = null;
        leaveSick = null;
        leaveKey = "";
        content.addView(Ui.pillTabs(a, new String[]{"記帳", "統計"}, tab, new Ui.IntCb() {
            @Override public void on(int i) {
                flushLeave();
                tab = i;
                if (i == 0) autoRun();
                refresh();
            }
        }), Ui.mw(a, 0));
        Ui.lp(content.getChildAt(0)).bottomMargin = Ui.dp(a, 14);
        if (Money.list("accounts").isEmpty()) {
            content.addView(Ui.empty(a, "還沒有帳戶資料。請先用網頁版開啟一次記帳頁，再回來。"));
            return;
        }
        if (tab == 0) buildRecord(); else buildStats();
    }

    private View navBtn(String s, final int delta) {
        View t = new Chevron(a, "‹".equals(s), Ui.CARD_INK, 32);
        t.setBackground(Ui.shape(a, 0xFFFFFFFF, 16, Ui.BORDER, 1.5f));
        Ui.soft(t, 2);
        t.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(a, 32), Ui.dp(a, 32)));
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                flushLeave();
                Calendar c = Calendar.getInstance();
                c.clear();
                c.set(monthY, monthM + delta, 1);
                monthY = c.get(Calendar.YEAR);
                monthM = c.get(Calendar.MONTH);
                refresh();
            }
        });
        return t;
    }

    private View summaryCard(String label, String amount, int color, View.OnClickListener click) {
        LinearLayout c = Ui.col(a);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setPadding(Ui.dp(a, 10), Ui.dp(a, 12), Ui.dp(a, 10), Ui.dp(a, 12));
        c.setBackground(Ui.shape(a, Ui.TASK_BG, 14, Ui.BORDER, 1.5f));
        Ui.soft(c, 2);
        TextView l = Ui.tv(a, label, 11, Ui.SOFT, false);
        l.setGravity(Gravity.CENTER);
        c.addView(l);
        TextView v = Ui.tv(a, amount, 16, color, true);
        v.setGravity(Gravity.CENTER);
        c.addView(v, Ui.mw(a, 4));
        if (click != null) c.setOnClickListener(click);
        return c;
    }

    private void buildRecord() {
        final String key = Money.monthKey(monthY, monthM + 1);
        List<JSONObject> list = Money.forMonth(key);
        double income = 0, expense = 0, adjust = 0;
        for (JSONObject e : list) {
            String t = Model.s(e, "type");
            double amt = Money.d(e, "amount");
            if ("income".equals(t)) income += amt; else if ("expense".equals(t)) expense += amt; else if ("adjust".equals(t)) adjust += amt;
        }

        // 月份列
        Flow nav = new Flow(a, 10, 8);
        nav.addView(navBtn("‹", -1));
        nav.addView(Ui.tv(a, monthY + "年" + (monthM + 1) + "月", 15, Ui.INK, true));
        nav.addView(navBtn("›", 1));
        nav.addView(Ui.btnGhost(a, "分類設定", new View.OnClickListener() {
            @Override public void onClick(View v) { ExpenseDialogs.openCategories(a); }
        }));
        nav.addView(Ui.btnGhost(a, "薪資設定", new View.OnClickListener() {
            @Override public void onClick(View v) { ExpenseDialogs.openPayroll(a); }
        }));
        content.addView(nav, Ui.mw(a, 0));

        // 摘要 2x2
        LinearLayout r1 = Ui.row(a), r2 = Ui.row(a);
        r1.addView(summaryCard("本月收入", Money.fmt(income), 0xFF3A8A5E, null), new LinearLayout.LayoutParams(0, -2, 1f));
        View ex = summaryCard("本月支出", Money.fmt(expense), 0xFFC0504D, null);
        r1.addView(ex, new LinearLayout.LayoutParams(0, -2, 1f));
        Ui.lp(ex).leftMargin = Ui.dp(a, 10);
        r2.addView(summaryCard("本月結餘", Money.fmt(income - expense), Ui.CARD_INK, null), new LinearLayout.LayoutParams(0, -2, 1f));
        View bank = summaryCard("目前存款（合計）✎", Money.fmt(Money.totalBalance()), Ui.CARD_INK, new View.OnClickListener() {
            @Override public void onClick(View v) { ExpenseDialogs.openAccounts(a); }
        });
        r2.addView(bank, new LinearLayout.LayoutParams(0, -2, 1f));
        Ui.lp(bank).leftMargin = Ui.dp(a, 10);
        content.addView(r1, Ui.mw(a, 16));
        content.addView(r2, Ui.mw(a, 10));
        if (adjust != 0) {
            content.addView(Ui.hint(a, "本月誤差調整 " + (adjust > 0 ? "+" : "-") + "$" + Money.num(Math.abs(adjust)) + "（不計入收支）"), Ui.mw(a, 6));
        }

        budgetBlock(list);
        salaryBlock(key);
        recurringBlock();

        content.addView(Ui.btnPrimary(a, "＋ 記一筆", new View.OnClickListener() {
            @Override public void onClick(View v) { ExpenseDialogs.openExpense(a); }
        }), Ui.mw(a, 18));
        Ui.lp(content.getChildAt(content.getChildCount() - 1)).bottomMargin = Ui.dp(a, 14);

        listBlock(list);
        content.addView(Ui.spacer(a, 24));
    }

    // ---------- 預算 ----------

    private void budgetBlock(List<JSONObject> monthList) {
        JSONObject budgets = Money.obj("categoryBudgets");
        List<String> ids = new ArrayList<>();
        Iterator<String> it = budgets.keys();
        while (it.hasNext()) {
            String id = it.next();
            if (Money.d(budgets, id) > 0) ids.add(id);
        }
        if (ids.isEmpty()) return;
        Map<String, Double> spent = new LinkedHashMap<>();
        for (JSONObject e : monthList) {
            if (!"expense".equals(Model.s(e, "type"))) continue;
            String c = Model.s(e, "category");
            Double cur = spent.get(c);
            spent.put(c, (cur == null ? 0 : cur) + Money.d(e, "amount"));
        }
        LinearLayout box = Ui.col(a);
        box.addView(Ui.blockTitle(a, "本月預算"));
        boolean any = false;
        for (String id : ids) {
            JSONObject cat = null;
            for (JSONObject c : Money.list("expenseCategories")) if (Model.s(c, "id").equals(id)) cat = c;
            if (cat == null) continue;
            double limit = Money.d(budgets, id);
            Double sp = spent.get(id);
            double s = sp == null ? 0 : sp;
            int pct = (int) Math.min(100, Math.round(s / limit * 100));
            boolean over = s > limit;
            LinearLayout row = Ui.row(a);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView l = Ui.tv(a, Model.s(cat, "name"), 11.5f, Ui.SOFT, false);
            l.setSingleLine(true);
            l.setEllipsize(TextUtils.TruncateAt.END);
            row.addView(l, new LinearLayout.LayoutParams(Ui.dp(a, 52), -2));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, Ui.dp(a, 8), 1f);
            bp.leftMargin = Ui.dp(a, 10);
            bp.rightMargin = Ui.dp(a, 10);
            row.addView(new RateBar(a, pct, over), bp);
            TextView amt = Ui.tv(a, Money.fmt(s) + "/" + Money.fmt(limit), 11, over ? Ui.DANGER : Ui.SOFT, over);
            row.addView(amt);
            box.addView(row, Ui.mw(a, any ? 9 : 0));
            any = true;
        }
        if (any) content.addView(box, Ui.mw(a, 0));
    }

    // ---------- 本月薪資 ----------

    private void salaryBlock(String key) {
        Money.PayDate pay = Money.payDate(monthY, monthM);
        boolean hasBase = Money.d(Money.payroll(), "baseSalary") > 0;
        boolean recorded = Money.obj("salaryRecorded").optBoolean(key, false);
        content.addView(Ui.blockTitle(a, (monthM + 1) + "月薪資（" + pay.pm + "/" + pay.day + " 發放）"));
        String hint = !hasBase ? "先到「薪資設定」填底薪，薪水才會在發薪日自動入帳"
                : recorded ? "這個月的薪水已入帳，之後再改請假不會變動已入帳的金額"
                : (monthM + 1) + "月的請假天數，會在 " + pay.pm + "/" + pay.day + " 薪水入帳時一併扣除，不會馬上動到存款";
        content.addView(Ui.hint(a, hint));

        JSONObject leave = Money.obj("leaveByMonth").optJSONObject(key);
        double pa = leave == null ? 0 : Money.n0(leave.opt("personalAmount")), sa = leave == null ? 0 : Money.n0(leave.opt("sickAmount"));
        personalUnit = leave == null ? "days" : Model.s(leave, "personalUnit", "days");
        sickUnit = leave == null ? "days" : Model.s(leave, "sickUnit", "days");
        if (personalUnit.isEmpty()) personalUnit = "days";
        if (sickUnit.isEmpty()) sickUnit = "days";
        leaveKey = key;
        leavePersonal = Ui.numberInput(a, "0", pa == 0 ? "" : trimNum(pa), true);
        leaveSick = Ui.numberInput(a, "0", sa == 0 ? "" : trimNum(sa), true);
        content.addView(leaveRow("事假", leavePersonal, true), Ui.mw(a, 10));
        content.addView(leaveRow("病假", leaveSick, false), Ui.mw(a, 8));
    }

    private static String trimNum(double v) { return v == Math.rint(v) ? String.valueOf((long) v) : String.valueOf(v); }

    private View leaveRow(String label, EditText input, final boolean personal) {
        LinearLayout row = Ui.row(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(Ui.tv(a, label, 13, Ui.INK, false), Ui.weight(1));
        input.setGravity(Gravity.END);
        input.setPadding(Ui.dp(a, 10), Ui.dp(a, 7), Ui.dp(a, 10), Ui.dp(a, 7));
        row.addView(input, new LinearLayout.LayoutParams(Ui.dp(a, 66), -2));
        String unit = personal ? personalUnit : sickUnit;
        row.addView(ExpenseDialogs.miniTabs(a, new String[]{"天", "小時"}, "hours".equals(unit) ? 1 : 0, 11, 9, 4, new Ui.IntCb() {
            @Override public void on(int i) {
                if (personal) personalUnit = i == 1 ? "hours" : "days"; else sickUnit = i == 1 ? "hours" : "days";
                flushLeave();
            }
        }), Ui.gap(a, 6));
        return row;
    }

    // ---------- 固定扣款 ----------

    private void recurringBlock() {
        content.addView(Ui.blockTitle(a, "固定扣款"));
        List<JSONObject> rs = Money.list("recurring");
        if (rs.isEmpty()) {
            content.addView(Ui.hint(a, "還沒有固定扣款，例如房租、訂閱費、每週固定花費"));
        }
        String[] wd = {"日", "一", "二", "三", "四", "五", "六"};
        for (final JSONObject r : rs) {
            final String id = Model.s(r, "id");
            int day = (int) Money.n0(r.opt("day"));
            String when = "weekly".equals(Model.s(r, "freq")) ? "每週" + wd[Math.max(0, Math.min(6, day))] : "每月" + day + "日";
            LinearLayout row = Ui.row(a);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(a, 12), Ui.dp(a, 9), Ui.dp(a, 12), Ui.dp(a, 9));
            row.setBackground(Ui.shape(a, Ui.TASK_BG, 12, Ui.BORDER, 1.5f));
            LinearLayout left = Ui.col(a);
            left.addView(Ui.tv(a, Model.s(r, "name") + "　" + when + "　" + Money.fmt(Money.d(r, "amount")), 13, Ui.CARD_INK, false));
            left.addView(Ui.tv(a, Money.accountName(Model.s(r, "accountId")), 11, Ui.SOFT, false));
            row.addView(left, Ui.weight(1));
            TextView del = Ui.tv(a, "刪除", 12, Ui.DANGER, false);
            del.setPadding(Ui.dp(a, 8), Ui.dp(a, 6), Ui.dp(a, 4), Ui.dp(a, 6));
            del.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    final JSONObject removed = r;
                    final int at = indexOf("recurring", id);
                    Repo.del(a, "recurring", id);
                    a.refreshCurrent();
                    a.undo("已刪除固定扣款（過去已記入的紀錄不受影響）", new Runnable() {
                        @Override public void run() {
                            Repo.add(a, removed, at, "recurring");
                            a.refreshCurrent();
                        }
                    });
                }
            });
            row.addView(del);
            content.addView(row, Ui.mw(a, 6));
        }
        content.addView(Ui.btnGhost(a, "＋ 新增固定扣款", new View.OnClickListener() {
            @Override public void onClick(View v) { ExpenseDialogs.openRecurring(a); }
        }), Ui.wrap(a, 8));
    }

    private int indexOf(String key, String id) {
        List<JSONObject> l = Money.list(key);
        for (int i = 0; i < l.size(); i++) if (Model.s(l.get(i), "id").equals(id)) return i;
        return -1;
    }

    // ---------- 明細 ----------

    private void listBlock(List<JSONObject> list) {
        Map<String, List<JSONObject>> byDay = new LinkedHashMap<>();
        for (JSONObject e : list) {
            String d = Model.s(e, "date");
            List<JSONObject> l = byDay.get(d);
            if (l == null) { l = new ArrayList<>(); byDay.put(d, l); }
            l.add(e);
        }
        List<String> days = new ArrayList<>(byDay.keySet());
        Collections.sort(days);
        Collections.reverse(days);
        if (days.isEmpty()) {
            content.addView(Ui.empty(a, "本月還沒有記帳紀錄"));
            return;
        }
        for (String day : days) {
            TextView dl = Ui.tv(a, day, 11.5f, Ui.SOFT, true);
            dl.setPadding(Ui.dp(a, 2), 0, 0, Ui.dp(a, 6));
            content.addView(dl, Ui.mw(a, 14));
            for (JSONObject e : byDay.get(day)) content.addView(expenseItem(e), Ui.mw(a, 6));
        }
    }

    private View expenseItem(final JSONObject e) {
        final String id = Model.s(e, "id");
        String type = Model.s(e, "type");
        String catName;
        String icon;
        if ("adjust".equals(type)) { catName = "調整誤差"; icon = "scale"; }
        else if ("transfer".equals(type)) { catName = "轉帳"; icon = "transfer"; }
        else {
            catName = Model.s(e, "category");
            icon = "other";
            for (JSONObject c : Money.list("income".equals(type) ? "incomeCategories" : "expenseCategories")) {
                if (Model.s(c, "id").equals(Model.s(e, "category"))) { catName = Model.s(c, "name"); icon = Model.s(c, "icon", "other"); }
            }
        }
        final boolean sal = Money.isSalaryEntry(e);
        List<String> parts = new ArrayList<>();
        if ("transfer".equals(type)) {
            parts.add(Money.accountName(Model.s(e, "accountId")) + " → " + Money.accountName(Model.s(e, "toAccountId")));
            if (!Model.s(e, "note").isEmpty()) parts.add(Model.s(e, "note"));
        } else {
            parts.add(Money.accountName(Model.s(e, "accountId")));
            if (!Model.s(e, "note").isEmpty()) parts.add(Model.s(e, "note"));
            if (sal) parts.add("點一下調整明細");
        }
        String noteText = TextUtils.join("・", parts);
        double amt = Money.d(e, "amount");
        String amtText;
        int amtColor;
        if ("income".equals(type)) { amtText = "+" + Money.fmt(amt); amtColor = 0xFF3A8A5E; }
        else if ("expense".equals(type)) { amtText = "-" + Money.fmt(amt); amtColor = 0xFFC0504D; }
        else if ("transfer".equals(type)) { amtText = Money.fmt(amt); amtColor = Ui.SOFT; }
        else { amtText = (amt > 0 ? "+" : "-") + Money.fmt(Math.abs(amt)); amtColor = Ui.SOFT; }

        LinearLayout row = Ui.row(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(a, 12), Ui.dp(a, 10), Ui.dp(a, 8), Ui.dp(a, 10));
        row.setBackground(Ui.shape(a, Ui.TASK_BG, 14, Ui.BORDER, 1.5f));
        Ui.soft(row, 2);
        android.widget.FrameLayout ic = new android.widget.FrameLayout(a);
        ic.setBackground(Ui.shape(a, Ui.ACCENT_SOFT, 16, 0, 0));
        ic.addView(ExpenseIcons.icon(a, icon, 18, Ui.ACCENT), new android.widget.FrameLayout.LayoutParams(Ui.dp(a, 18), Ui.dp(a, 18), Gravity.CENTER));
        row.addView(ic, new LinearLayout.LayoutParams(Ui.dp(a, 32), Ui.dp(a, 32)));
        LinearLayout info = Ui.col(a);
        info.addView(Ui.tv(a, catName, 13, Ui.CARD_INK, true));
        TextView nt = Ui.tv(a, noteText, 11, Ui.SOFT, false);
        nt.setSingleLine(true);
        nt.setEllipsize(TextUtils.TruncateAt.END);
        info.addView(nt, Ui.mw(a, 1));
        row.addView(info, Ui.weight(1));
        Ui.lp(info).leftMargin = Ui.dp(a, 10);
        row.addView(Ui.tv(a, amtText, 14, amtColor, true), Ui.gap(a, 10));
        TextView del = Ui.tv(a, "×", 17, Ui.SOFT, false);
        del.setPadding(Ui.dp(a, 10), Ui.dp(a, 4), Ui.dp(a, 6), Ui.dp(a, 4));
        del.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { deleteExpense(e); }
        });
        row.addView(del);
        if (sal) {
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { ExpenseDialogs.openSalaryDetail(a, id); }
            });
        }
        return row;
    }

    private void deleteExpense(final JSONObject e) {
        final String id = Model.s(e, "id");
        final int at = indexOf("expenses", id);
        final JSONObject copy;
        try { copy = new JSONObject(e.toString()); } catch (JSONException ex) { return; }
        String salKey = null;
        if (Money.isSalaryEntry(e)) {
            String k = Money.salaryEntryMonthKey(e);
            if (k != null && Money.obj("salaryRecorded").optBoolean(k, false)) {
                int y = Integer.parseInt(k.substring(0, 4)), mo = Integer.parseInt(k.substring(5, 7));
                if (Money.payDate(y, mo - 1).dateStr.compareTo(Model.today()) > 0) salKey = k;
            }
        }
        final String salKeyF = salKey;
        if (!Repo.del(a, "expenses", id)) return;
        if (salKeyF != null) Repo.del(a, "salaryRecorded", salKeyF);
        a.refreshCurrent();
        a.undo("已刪除這筆記帳", new Runnable() {
            @Override public void run() {
                Repo.add(a, copy, at, "expenses");
                if (salKeyF != null) Repo.set(a, true, "salaryRecorded", salKeyF);
                a.refreshCurrent();
            }
        });
    }

    // ---------- 統計 ----------

    private void buildStats() {
        ensureMonth();
        List<JSONObject> list = Money.forMonth(Money.monthKey(monthY, monthM + 1));
        content.addView(Ui.blockTitle(a, "分類佔比"));
        Map<String, Double> byCat = new LinkedHashMap<>();
        for (JSONObject e : list) {
            if (!"expense".equals(Model.s(e, "type"))) continue;
            String c = Model.s(e, "category");
            Double cur = byCat.get(c);
            byCat.put(c, (cur == null ? 0 : cur) + Money.d(e, "amount"));
        }
        List<Map.Entry<String, Double>> entries = new ArrayList<>(byCat.entrySet());
        Collections.sort(entries, new java.util.Comparator<Map.Entry<String, Double>>() {
            @Override public int compare(Map.Entry<String, Double> x, Map.Entry<String, Double> y) { return Double.compare(y.getValue(), x.getValue()); }
        });
        double total = 0;
        for (Map.Entry<String, Double> en : entries) total += en.getValue();
        if (total <= 0) {
            content.addView(Ui.empty(a, "這個月還沒有支出紀錄"));
        } else {
            float[] pct = new float[entries.size()];
            for (int i = 0; i < pct.length; i++) pct[i] = (float) (entries.get(i).getValue() / total * 100);
            LinearLayout center = Ui.row(a);
            center.setGravity(Gravity.CENTER_HORIZONTAL);
            center.addView(new ExpenseCharts.Pie(a, pct, Money.fmt(total)));
            content.addView(center, Ui.mw(a, 0));
            LinearLayout legend = Ui.col(a);
            for (int i = 0; i < entries.size(); i++) {
                String id = entries.get(i).getKey();
                String name = id, icon = "other";
                for (JSONObject c : Money.list("expenseCategories")) if (Model.s(c, "id").equals(id)) { name = Model.s(c, "name"); icon = Model.s(c, "icon", "other"); }
                LinearLayout row = Ui.row(a);
                row.setGravity(Gravity.CENTER_VERTICAL);
                View dot = new View(a);
                dot.setBackground(Ui.shape(a, ExpenseCharts.PALETTE[i % ExpenseCharts.PALETTE.length], 5, 0, 0));
                row.addView(dot, new LinearLayout.LayoutParams(Ui.dp(a, 9), Ui.dp(a, 9)));
                row.addView(ExpenseIcons.icon(a, icon, 15, Ui.SOFT), new LinearLayout.LayoutParams(Ui.dp(a, 15), Ui.dp(a, 15)));
                Ui.lp(row.getChildAt(1)).leftMargin = Ui.dp(a, 6);
                TextView nm = Ui.tv(a, name, 12, Ui.INK, false);
                row.addView(nm, Ui.weight(1));
                Ui.lp(nm).leftMargin = Ui.dp(a, 6);
                row.addView(Ui.tv(a, Money.fmt(entries.get(i).getValue()), 12, Ui.SOFT, false), Ui.gap(a, 6));
                TextView pc = Ui.tv(a, Math.round(pct[i]) + "%", 12, Ui.INK, true);
                pc.setGravity(Gravity.END);
                row.addView(pc, new LinearLayout.LayoutParams(Ui.dp(a, 34), -2));
                Ui.lp(pc).leftMargin = Ui.dp(a, 6);
                legend.addView(row, Ui.mw(a, i == 0 ? 0 : 7));
            }
            content.addView(legend, Ui.mw(a, 10));
        }

        content.addView(Ui.blockTitle(a, "近6個月收支趨勢"));
        double[] inc = new double[6], exp = new double[6];
        String[] labels = new String[6];
        Calendar now = Calendar.getInstance();
        for (int i = 5; i >= 0; i--) {
            Calendar c = Calendar.getInstance();
            c.clear();
            c.set(now.get(Calendar.YEAR), now.get(Calendar.MONTH) - i, 1);
            String key = Money.monthKey(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1);
            int idx = 5 - i;
            for (JSONObject e : Money.forMonth(key)) {
                String t = Model.s(e, "type");
                if ("income".equals(t)) inc[idx] += Money.d(e, "amount");
                else if ("expense".equals(t)) exp[idx] += Money.d(e, "amount");
            }
            labels[idx] = key.substring(5) + "月";
        }
        content.addView(new ExpenseCharts.Trend(a, inc, exp, labels), new LinearLayout.LayoutParams(-1, Ui.dp(a, 150)));
        LinearLayout lg = Ui.row(a);
        lg.setGravity(Gravity.CENTER);
        lg.addView(legendDot(0xFF3A8A5E, "收入"));
        View red = legendDot(0xFFC0504D, "支出");
        lg.addView(red, Ui.gap(a, 16));
        content.addView(lg, Ui.mw(a, 4));
        content.addView(Ui.spacer(a, 24));
    }

    private View legendDot(int color, String label) {
        LinearLayout r = Ui.row(a);
        r.setGravity(Gravity.CENTER_VERTICAL);
        View d = new View(a);
        d.setBackground(Ui.shape(a, color, 4, 0, 0));
        r.addView(d, new LinearLayout.LayoutParams(Ui.dp(a, 8), Ui.dp(a, 8)));
        TextView t = Ui.tv(a, label, 11.5f, Ui.SOFT, false);
        r.addView(t, Ui.gap(a, 5));
        return r;
    }
}
