package tw.jishibu.widget;

import android.content.Context;
import android.content.SharedPreferences;

/** 存在手機上的設定與快取。 */
final class Store {
    private Store() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("jishibu", Context.MODE_PRIVATE);
    }

    static boolean linked(Context c) {
        SharedPreferences p = sp(c);
        return !p.getString("rt", "").isEmpty() && !p.getString("key", "").isEmpty();
    }

    static void saveLink(Context c, String refreshToken, String key, String email, String origin) {
        sp(c).edit()
                .putString("rt", refreshToken)
                .putString("key", key)
                .putString("email", email)
                .putString("origin", origin)
                .remove("idToken").remove("idExp")
                .remove("cache").remove("syncTs").putString("err", "")
                .apply();
    }

    static void clearLink(Context c) {
        sp(c).edit().clear().apply();
    }

    static String refreshToken(Context c) { return sp(c).getString("rt", ""); }
    static String key(Context c) { return sp(c).getString("key", ""); }
    static String email(Context c) { return sp(c).getString("email", ""); }
    static String origin(Context c) { return sp(c).getString("origin", ""); }

    static String idToken(Context c) { return sp(c).getString("idToken", ""); }
    static long idExp(Context c) { return sp(c).getLong("idExp", 0L); }
    static void saveToken(Context c, String idToken, long expMillis, String newRefreshToken) {
        SharedPreferences.Editor e = sp(c).edit().putString("idToken", idToken).putLong("idExp", expMillis);
        if (newRefreshToken != null && !newRefreshToken.isEmpty()) e.putString("rt", newRefreshToken);
        e.apply();
    }

    static String cache(Context c) { return sp(c).getString("cache", "[]"); }
    static long syncTs(Context c) { return sp(c).getLong("syncTs", 0L); }
    static void saveCache(Context c, String json) {
        sp(c).edit().putString("cache", json).putLong("syncTs", System.currentTimeMillis()).putString("err", "").apply();
    }

    static String error(Context c) { return sp(c).getString("err", ""); }
    static void saveError(Context c, String msg) { sp(c).edit().putString("err", msg == null ? "" : msg).apply(); }

    static String pending(Context c) { return sp(c).getString("pending", "[]"); }
    static void setPending(Context c, String json) { sp(c).edit().putString("pending", json).apply(); }
    static String updateTime(Context c) { return sp(c).getString("updateTime", ""); }
    static void setUpdateTime(Context c, String t) { sp(c).edit().putString("updateTime", t).apply(); }
    static String backupDay(Context c) { return sp(c).getString("backupDay", ""); }
    static void setBackupDay(Context c, String d) { sp(c).edit().putString("backupDay", d).apply(); }

    static int offset(Context c) { return sp(c).getInt("offset", 0); }
    static void setOffset(Context c, int v) { sp(c).edit().putInt("offset", v).apply(); }
}
