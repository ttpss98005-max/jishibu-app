package tw.jishibu.widget;

import android.content.Context;
import android.content.SharedPreferences;

/** 存在手機上的設定與快取。 */
final class Store {
    private Store() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("jishibu", Context.MODE_PRIVATE);
    }

    static boolean linked(Context c) {
        SharedPreferences p = sp(c);
        return !p.getString("rt", "").isEmpty() && !p.getString("key", "").isEmpty();
    }

    // 網站網址另外存(登出時不清掉):Google 登入需要它當 Referer,不用每次重新問
    private static SharedPreferences site(Context c) {
        return c.getApplicationContext().getSharedPreferences("jishibu_site", Context.MODE_PRIVATE);
    }
    static String siteOrigin(Context c) {
        String s = site(c).getString("origin", "");
        return s.isEmpty() ? origin(c) : s;
    }
    static void setSiteOrigin(Context c, String o) {
        if (o != null && !o.isEmpty()) site(c).edit().putString("origin", o).apply();
    }

    static void saveLink(Context c, String refreshToken, String key, String email, String origin) {
        setSiteOrigin(c, origin);
        sp(c).edit()
                .putString("rt", refreshToken)
                .putString("key", key)
                .putString("email", email)
                .putString("origin", origin)
                .remove("idToken").remove("idExp")
                .remove("cache").remove("syncTs").putString("err", "")
                .apply();
    }

    static void clearLink(Context c) {
        sp(c).edit().clear().apply();
    }

    static String refreshToken(Context c) { return sp(c).getString("rt", ""); }
    static String key(Context c) { return sp(c).getString("key", ""); }
    static String email(Context c) { return sp(c).getString("email", ""); }
    static String origin(Context c) { return sp(c).getString("origin", ""); }

    static String idToken(Context c) { return sp(c).getString("idToken", ""); }
    static long idExp(Context c) { return sp(c).getLong("idExp", 0L); }
    static void saveToken(Context c, String idToken, long expMillis, String newRefreshToken) {
        SharedPreferences.Editor e = sp(c).edit().putString("idToken", idToken).putLong("idExp", expMillis);
        if (newRefreshToken != null && !newRefreshToken.isEmpty()) e.putString("rt", newRefreshToken);
        e.apply();
    }

    static String cache(Context c) { return sp(c).getString("cache", "[]"); }
    static long syncTs(Context c) { return sp(c).getLong("syncTs", 0L); }
    static void saveCache(Context c, String json) {
        sp(c).edit().putString("cache", json).putLong("syncTs", System.currentTimeMillis()).putString("err", "").apply();
    }

    static String error(Context c) { return sp(c).getString("err", ""); }
    static void saveError(Context c, String msg) { sp(c).edit().putString("err", msg == null ? "" : msg).apply(); }

    static String side(Context c) { return sp(c).getString("side", "[]"); }
    // 還沒同步的修改要「馬上」寫進手機(commit),不能等背景慢慢寫:萬一這時候被系統關掉也不會漏
    static void setSide(Context c, String json) { sp(c).edit().putString("side", json).commit(); }

    static String pending(Context c) { return sp(c).getString("pending", "[]"); }
    static void setPending(Context c, String json) { sp(c).edit().putString("pending", json).commit(); }
    static String updateTime(Context c) { return sp(c).getString("updateTime", ""); }
    static void setUpdateTime(Context c, String t) { sp(c).edit().putString("updateTime", t).apply(); }
    static String backupDay(Context c) { return sp(c).getString("backupDay", ""); }
    static void setBackupDay(Context c, String d) { sp(c).edit().putString("backupDay", d).apply(); }

    static long delBackupTs(Context c) { return sp(c).getLong("delBackupTs", 0L); }
    static void setDelBackupTs(Context c, long t) { sp(c).edit().putLong("delBackupTs", t).apply(); }

    static int offset(Context c) { return sp(c).getInt("offset", 0); }
    static void setOffset(Context c, int v) { sp(c).edit().putInt("offset", v).apply(); }
}
