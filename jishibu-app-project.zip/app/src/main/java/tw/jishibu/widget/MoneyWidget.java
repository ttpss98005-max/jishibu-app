package tw.jishibu.widget;

/** 桌面小工具:Money(內容和更新都在 Widgets)。 */
public class MoneyWidget extends Widgets.Base {
    @Override int kind() { return Widgets.MONEY; }
}
