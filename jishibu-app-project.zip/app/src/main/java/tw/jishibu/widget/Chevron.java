package tw.jishibu.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/**
 * 圓形按鈕裡的「‹ ›」箭頭。用畫的而不是用文字:文字字型的 ‹ › 本身偏上、偏一邊,
 * 放在圓形裡看起來不在正中間。這裡直接把箭頭的外框正中心對準圓心。背景(圓形)由呼叫的地方設定。
 */
final class Chevron extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final boolean left;
    private final float sizeDp;

    Chevron(Context c, boolean left, int color, float sizeDp) {
        super(c);
        this.left = left;
        this.sizeDp = sizeDp;
        p.setColor(color);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(Ui.dp(c, 1.6f));
    }

    void setColor(int color) { p.setColor(color); invalidate(); }

    @Override protected void onDraw(Canvas cv) {
        float cx = getWidth() / 2f, cy = getHeight() / 2f;
        float hh = Ui.dp(getContext(), sizeDp * 0.30f);   // 半高
        float hw = hh * 0.55f;                           // 半寬
        path.reset();
        if (left) {
            path.moveTo(cx + hw, cy - hh);
            path.lineTo(cx - hw, cy);
            path.lineTo(cx + hw, cy + hh);
        } else {
            path.moveTo(cx - hw, cy - hh);
            path.lineTo(cx + hw, cy);
            path.lineTo(cx - hw, cy + hh);
        }
        cv.drawPath(path, p);
    }
}
