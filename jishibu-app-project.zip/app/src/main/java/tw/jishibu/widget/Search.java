package tw.jishibu.widget;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 全域搜尋(網頁版 openSearch / performSearch):事項、細項、隨手記、習慣;點結果跳過去。 */
final class Search {
    private Search() {}

    static void open(final MainActivity a) {
        final Modal.Sheet s = Modal.sheet(a);
        if (s.dialog.getWindow() != null) {
            s.dialog.getWindow().setGravity(Gravity.TOP);
            s.dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        }
        LinearLayout top = Ui.row(a);
        top.setGravity(Gravity.CENTER_VERTICAL);
        final EditText input = Ui.input(a, "搜尋事項、細項、隨手記、習慣...", "");
        top.addView(input, Ui.weight(1));
        top.addView(Ui.btnGhost(a, "取消", new View.OnClickListener() {
            @Override public void onClick(View v) { s.dismiss(); }
        }), Ui.gap(a, 10));
        s.box.addView(top);
        final LinearLayout results = Ui.col(a);
        s.box.addView(results, Ui.mw(a, 14));
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence x, int p, int q, int r) { }
            @Override public void onTextChanged(CharSequence x, int p, int q, int r) { }
            @Override public void afterTextChanged(Editable e) { run(a, s, input.getText().toString().trim(), results); }
        });
        s.dialog.show();
        input.requestFocus();
    }

    private static final class Hit {
        final String text, sub;
        final Runnable go;
        Hit(String text, String sub, Runnable go) { this.text = text; this.sub = sub; this.go = go; }
    }

    private static boolean has(String field, String q) {
        return field != null && field.toLowerCase(Locale.ROOT).contains(q);
    }

    private static void run(final MainActivity a, final Modal.Sheet s, String raw, LinearLayout box) {
        box.removeAllViews();
        if (raw.isEmpty() || Repo.data() == null) return;
        String q = raw.toLowerCase(Locale.ROOT);

        List<Hit> tasks = new ArrayList<>(), subs = new ArrayList<>(), notes = new ArrayList<>(), habits = new ArrayList<>();
        for (JSONObject t : Model.tasks()) {
            final String cat = Model.s(t, "categoryId"), tid = Model.s(t, "id");
            final String title = Model.s(t, "title");
            Runnable go = new Runnable() {
                @Override public void run() { a.jumpToTask(cat, tid); }
            };
            if (has(title, q) || has(Model.s(t, "note"), q)) tasks.add(new Hit(title, Model.s(t, "note"), go));
            JSONArray ss = t.optJSONArray("subtasks");
            if (ss == null) continue;
            for (int i = 0; i < ss.length(); i++) {
                JSONObject sub = ss.optJSONObject(i);
                if (sub == null) continue;
                if (has(Model.s(sub, "title"), q) || has(Model.s(sub, "note"), q)) subs.add(new Hit(Model.s(sub, "title"), "來自：" + title, go));
            }
        }
        for (JSONObject n : Model.list("quickNotes")) {
            String text = Model.s(n, "text");
            if (!has(text, q)) continue;
            notes.add(new Hit(text.length() > 60 ? text.substring(0, 60) : text, "", new Runnable() {
                @Override public void run() { a.go(MainActivity.TAB_NOTES); }
            }));
        }
        for (JSONObject h : Model.habits()) {
            String name = Model.s(h, "name");
            if (!has(name, q)) continue;
            habits.add(new Hit(name, "", new Runnable() {
                @Override public void run() { a.go(MainActivity.TAB_HABITS); }
            }));
        }

        if (tasks.size() + subs.size() + notes.size() + habits.size() == 0) {
            box.addView(Ui.empty(a, "找不到符合「" + raw + "」的內容"));
            return;
        }
        group(a, s, box, "事項", tasks);
        group(a, s, box, "細項", subs);
        group(a, s, box, "隨手記", notes);
        group(a, s, box, "習慣", habits);
    }

    private static void group(MainActivity a, final Modal.Sheet s, LinearLayout box, String label, List<Hit> hits) {
        if (hits.isEmpty()) return;
        TextView l = Ui.tv(a, label, 11, Ui.SOFT, true);
        box.addView(l, Ui.mw(a, 10));
        for (final Hit h : hits) {
            LinearLayout item = Ui.col(a);
            item.setPadding(Ui.dp(a, 8), Ui.dp(a, 10), Ui.dp(a, 8), Ui.dp(a, 10));
            item.addView(Ui.tv(a, h.text, 13.5f, Ui.CARD_INK, false));
            if (h.sub != null && !h.sub.isEmpty()) item.addView(Ui.tv(a, h.sub, 11, Ui.SOFT, false), Ui.mw(a, 2));
            item.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { s.dismiss(); h.go.run(); }
            });
            box.addView(item, Ui.mw(a, 6));
            box.addView(Ui.hline(a));
        }
    }
}
