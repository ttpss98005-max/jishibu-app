package tw.jishibu.widget;

import android.content.Context;

/** 網頁版用到的圖示(SVG 原樣照抄),用 SvgIcon 畫。 */
final class Icons {
    private Icons() {}

    static final String SEARCH = "<circle cx=\"10.5\" cy=\"10.5\" r=\"6.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/><line x1=\"15.5\" y1=\"15.5\" x2=\"21\" y2=\"21\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/>";
    static final String GEAR = "<circle cx=\"12\" cy=\"12\" r=\"3.2\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\"/>"
            + "<line x1=\"12\" y1=\"2.5\" x2=\"12\" y2=\"5.5\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>"
            + "<line x1=\"12\" y1=\"18.5\" x2=\"12\" y2=\"21.5\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>"
            + "<line x1=\"2.5\" y1=\"12\" x2=\"5.5\" y2=\"12\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>"
            + "<line x1=\"18.5\" y1=\"12\" x2=\"21.5\" y2=\"12\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>"
            + "<line x1=\"5.1\" y1=\"5.1\" x2=\"7.2\" y2=\"7.2\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>"
            + "<line x1=\"16.8\" y1=\"16.8\" x2=\"18.9\" y2=\"18.9\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>"
            + "<line x1=\"5.1\" y1=\"18.9\" x2=\"7.2\" y2=\"16.8\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>"
            + "<line x1=\"16.8\" y1=\"7.2\" x2=\"18.9\" y2=\"5.1\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linecap=\"round\"/>";
    static final String NAV_HABITS = "<circle cx=\"12\" cy=\"12\" r=\"9\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\"/><path d=\"M7.5 12.5l3 3 6-6.5\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>";
    static final String NAV_LIST = "<rect x=\"3\" y=\"5\" width=\"3.2\" height=\"3.2\" rx=\"0.6\" fill=\"currentColor\"/><rect x=\"3\" y=\"10.4\" width=\"3.2\" height=\"3.2\" rx=\"0.6\" fill=\"currentColor\"/><rect x=\"3\" y=\"15.8\" width=\"3.2\" height=\"3.2\" rx=\"0.6\" fill=\"currentColor\"/>"
            + "<line x1=\"9\" y1=\"6.6\" x2=\"21\" y2=\"6.6\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/><line x1=\"9\" y1=\"12\" x2=\"21\" y2=\"12\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/><line x1=\"9\" y1=\"17.4\" x2=\"21\" y2=\"17.4\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\"/>";
    static final String NAV_CAL = "<rect x=\"3\" y=\"4.5\" width=\"18\" height=\"15\" rx=\"2\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\"/><line x1=\"3\" y1=\"9\" x2=\"21\" y2=\"9\" stroke=\"currentColor\" stroke-width=\"1.8\"/>"
            + "<circle cx=\"7.5\" cy=\"13\" r=\"1.3\" fill=\"currentColor\"/><circle cx=\"12\" cy=\"13\" r=\"1.3\" fill=\"currentColor\"/><circle cx=\"16.5\" cy=\"13\" r=\"1.3\" fill=\"currentColor\"/><circle cx=\"7.5\" cy=\"17\" r=\"1.3\" fill=\"currentColor\"/><circle cx=\"12\" cy=\"17\" r=\"1.3\" fill=\"currentColor\"/>";
    static final String NAV_NOTES = "<path d=\"M4 20l1-4 10-10 3 3-10 10z\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\" stroke-linejoin=\"round\" stroke-linecap=\"round\"/><line x1=\"15\" y1=\"6\" x2=\"18\" y2=\"9\" stroke=\"currentColor\" stroke-width=\"1.8\"/>";
    static final String NAV_EXPENSE = "<rect x=\"3.5\" y=\"6\" width=\"17\" height=\"13\" rx=\"2\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.8\"/><path d=\"M3.5 10h17\" stroke=\"currentColor\" stroke-width=\"1.8\"/><circle cx=\"12\" cy=\"14.2\" r=\"2.3\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"1.6\"/>";

    // 事項列表用的線條圖示(Icons.line 畫):鈴鐺=有提醒、鉛筆=編輯、叉叉=刪除
    static final String BELL = "<path d=\"M6 17V11a6 6 0 0 1 12 0v6l1.5 2h-15z\"/><path d=\"M10 21.5a2.2 2.2 0 0 0 4 0\"/>";
    static final String EDIT = "<path d=\"M4 20l1-4 10-10 3 3-10 10z\"/><line x1=\"15\" y1=\"6\" x2=\"18\" y2=\"9\"/>";
    static final String SORT = "<path d=\"M8 5L8 19M4.5 15.5L8 19L11.5 15.5M16 19L16 5M12.5 8.5L16 5L19.5 8.5\"/>";
    static final String DEL = "<line x1=\"6\" y1=\"6\" x2=\"18\" y2=\"18\"/><line x1=\"18\" y1=\"6\" x2=\"6\" y2=\"18\"/>";

    /** 整體沒設樣式的圖示(導覽列、搜尋、設定)。 */
    static SvgIcon plain(Context c, String inner, int sizeDp, int color) {
        return new SvgIcon(c, inner, sizeDp, color, 1.8f, false);
    }

    /** 線條圖示(整體 fill=none stroke=currentColor,例如記帳分類圖示)。 */
    static SvgIcon line(Context c, String inner, int sizeDp, int color) {
        return new SvgIcon(c, inner, sizeDp, color, 1.8f, true);
    }
}
